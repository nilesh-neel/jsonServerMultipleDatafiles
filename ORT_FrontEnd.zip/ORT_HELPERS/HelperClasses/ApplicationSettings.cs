﻿namespace ORT_HELPERS.HelperClasses
{
    public class ApplicationSettings
    {
        public string DataBaseService { get; set; }
        public string DataBaseName { get; set; }
        public string DataBaseUser { get; set; }
        public string DataBasePassWord { get; set; }
        public string CommandTimeout { get; set; }
        public string DataBaseType { get; set; }
        public string LogFolderPath { get; set; }
        public string EnableLog { get; set; }
        public string RelativePath { get; set; }
        public string EngineTemplatePath { get; set; }
        public string MusicRelativePath { get; set; }
        public string SmtpServer { get; set; }
        public string SmtpUser { get; set; }
        public string SmtpPassword { get; set; }
        public string GraphicRelativePath { get; set; }
        public string GraphicUpload { get; set; }
    }
}
