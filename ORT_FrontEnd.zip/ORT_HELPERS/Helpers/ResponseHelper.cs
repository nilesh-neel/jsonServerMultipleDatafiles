﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_HELPERS.Helpers
{
   public class ResponseHelper
    {
       public static bool ResponseExpected(string questionType)
       {
           var notAllowedList = new List<Question.QuestionTypes> { Question.QuestionTypes.ListenOften, Question.QuestionTypes.MediaIntro, Question.QuestionTypes.PerceptIntro, Question.QuestionTypes.ThankYou, Question.QuestionTypes.Welcome };

           foreach (var qtype in notAllowedList)
           {
               if (qtype.ToString() == questionType)
                   return false;
               continue;
           }
           return true;
       }

       public static bool NeedToBindAnswer(Question.QuestionTypes questiontype)
       {
           var notAllowedList = new List<Question.QuestionTypes> { Question.QuestionTypes.TextInput, Question.QuestionTypes.DateInput, Question.QuestionTypes.TimeInput, Question.QuestionTypes.SliderInput, Question.QuestionTypes.ListenOften, Question.QuestionTypes.MediaIntro, Question.QuestionTypes.PerceptIntro, Question.QuestionTypes.ThankYou, Question.QuestionTypes.Welcome };

           foreach (var qtype in notAllowedList)
           {
               if (qtype == questiontype)
                   return false;
               continue;
           }
           return true;
       }
    }
}
