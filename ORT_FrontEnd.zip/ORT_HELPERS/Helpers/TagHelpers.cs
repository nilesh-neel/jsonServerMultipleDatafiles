﻿using System.Collections.Generic;
using System.Web.Mvc;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_HELPERS.Helpers
{
    public static class TagHelpers
    {
        public static TagBuilder BuildQuestionTag(question question, config surveyConfig)
        {
            var topDiv = BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "topDiv"}
                });

            var quesNo = BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "quesNo"}
                });

            quesNo.InnerHtml = "Q" + question.no + ".";

            var inlineStyle = GetInlineStyle(new Dictionary<string, string>
                {
                    {"font",surveyConfig.questionFont},
                    {"fontSize",surveyConfig.questionFontSize},
                    {"fontColor",surveyConfig.questionFontColor}
                });

            var quesText = BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "quesText"},
                    {"style",inlineStyle}
                });

            quesText.InnerHtml = question.text;

            var requiredInfo = RequiredInfo(question);

            topDiv.InnerHtml = quesNo + quesText.ToString() + requiredInfo;

            return topDiv;
        }

        private static string RequiredInfo(question question)
        {
            var requiredInfo = BuildHiddenTag(new Dictionary<string, string>
                {
                    {"id", "hdnQuestion"},
                    {"type", "hidden"},
                    {"value", question.id},
                    {"name", "hdnQuestion"}
                });

            var hdnAnswerTag = BuildHiddenTag(new Dictionary<string, string>
                {
                    {"id", "hdnAnswer_" + question.id},
                    {"type", "hidden"},
                    {"name", "hdnAnswer_" + question.id},
                    {"value", ""}
                });

            var hdnQuestionType = BuildHiddenTag(new Dictionary<string, string>
                {
                    {"id", "hdnQuestionType_" + question.id},
                    {"type", "hidden"},
                    {"name", "hdnQuestionType_" + question.id},
                    {"value", question.type}
                });

            return requiredInfo + hdnAnswerTag.ToString() + hdnQuestionType;
        }

        public static TagBuilder SetMediaBlock(question question, bool autoPlay)
        {
            return !question.hasMedia ? null : BuildMediaBlock(question, autoPlay);
        }

        public static TagBuilder BuildRadioButton(IDictionary<string, string> attributes)
        {
            var radioTag = BuildInputTag(attributes);


            radioTag.MergeAttribute("type", "radio");

            string value;
            attributes.TryGetValue("value", out value);
            radioTag.SetInnerText(value);

            return radioTag;
        }

        public static TagBuilder BuildCheckBox(IDictionary<string, string> attributes)
        {
            var checkBoxTag = BuildInputTag(attributes);

            checkBoxTag.MergeAttribute("type", "checkbox");

            string value;
            attributes.TryGetValue("value", out value);
            checkBoxTag.SetInnerText(value);

            return checkBoxTag;
        }

        public static TagBuilder BuildTextBox(IDictionary<string, string> attributes)
        {
            var textTag = BuildInputTag(attributes);

            textTag.MergeAttribute("type", "text");

            string value;
            attributes.TryGetValue("value", out value);
            if (!string.IsNullOrEmpty(value)) textTag.MergeAttribute("value", value);

            return textTag;
        }

        private static TagBuilder BuildInputTag(IDictionary<string, string> attributes)
        {
            var inputTag = new TagBuilder("input");

            string tagid;
            attributes.TryGetValue("id", out tagid);
            inputTag.GenerateId(tagid);

            string name;
            attributes.TryGetValue("name", out name);
            inputTag.MergeAttribute("name", name);

            string cssClass;
            attributes.TryGetValue("class", out cssClass);
            if (!string.IsNullOrEmpty(cssClass)) inputTag.MergeAttribute("class", cssClass);

            string onClick;
            attributes.TryGetValue("onClick", out onClick);
            if (!string.IsNullOrEmpty(onClick)) inputTag.MergeAttribute("onClick", onClick);

            string onchange;
            attributes.TryGetValue("onchange", out onchange);
            if (!string.IsNullOrEmpty(onchange)) inputTag.MergeAttribute("onchange", onchange);

            string toCheck;
            attributes.TryGetValue("checked", out toCheck);
            if (!string.IsNullOrEmpty(toCheck)) inputTag.MergeAttribute("checked", toCheck);

            return inputTag;
        }

        public static TagBuilder BuildDivTag(IDictionary<string, string> attributes)
        {
            var divQuestion = new TagBuilder("div");
            divQuestion.MergeAttributes(attributes);
            return divQuestion;
        }

        public static TagBuilder BuildSpanTag(string spanId, string innerText)
        {
            var divSpan = new TagBuilder("span");
            divSpan.GenerateId(spanId);
            divSpan.SetInnerText(innerText);
            return divSpan;
        }

        public static TagBuilder BuildButton(IDictionary<string, string> attributes)
        {
            var buttonTag = new TagBuilder("button");
            buttonTag.MergeAttributes(attributes);
            string innerHtml;
            attributes.TryGetValue("text", out innerHtml);
            buttonTag.InnerHtml = innerHtml;
            return buttonTag;

        }

        public static TagBuilder BuildFieldSet(IDictionary<string, string> attributes)
        {
            var fieldset = new TagBuilder("fieldset");

            fieldset.MergeAttributes(attributes);

            return fieldset;
        }

        public static TagBuilder BuildImageTag(IDictionary<string, string> attributes)
        {
            var imgTag = new TagBuilder("img");

            imgTag.MergeAttributes(attributes);

            return imgTag;
        }

        public static TagBuilder BuildLabel(IDictionary<string, string> attributes)
        {
            var imgTag = new TagBuilder("label");

            imgTag.MergeAttributes(attributes);

            return imgTag;
        }

        private static TagBuilder BuildMediaBlock(question mediaQuestion, bool autoPlay)
        {
            var musicRelativePath = SessionHelper.AppSettings.MusicRelativePath;

            var mediaBlockJs = "<script type='text/javascript'> $(document).ready(function(){$('.jp-jplayer').jPlayer({ready: function (event) {$(this).jPlayer('setMedia', {title:'" + mediaQuestion.mediaTrackTitle + "',mp3:'" + musicRelativePath + "media/" + mediaQuestion.mediaFileName + "'})" + (autoPlay ? ".jPlayer('play')" : "") + ";},swfPath: '" + musicRelativePath + "Scripts/jQuery.jPlayer.2.1.0',solution: 'flash, html',supplied: 'mp3',wmode: 'window'});});</script>";

            const string divTags = "<div id='playerDiv' class='player'><div id='jquery_jplayer_1' class='jp-jplayer'></div><div id='jp_container_1' class='jp-audio'><div class='jp-type-single'><div class='jp-gui jp-interface'><ul class='jp-controls'><li><a href='javascript:;' class='jp-play' tabindex='1'>play</a></li><li><a href='javascript:;' class='jp-pause' tabindex='1'>pause</a></li><li><a href='javascript:;' class='jp-stop' tabindex='1'>stop</a></li><li><a href='javascript:;' class='jp-mute' tabindex='1' title='mute'>mute</a></li><li><a href='javascript:;' class='jp-unmute' tabindex='1' title='unmute'>unmute</a></li><li><a href='javascript:;' class='jp-volume-max' tabindex='1' title='max volume'>max volume</a></li></ul><div class='jp-progress'><div class='jp-seek-bar'><div class='jp-play-bar'></div></div></div><div class='jp-volume-bar'><div class='jp-volume-bar-value'></div></div><div class='jp-time-holder'><div class='jp-current-time'></div><div class='jp-duration'></div><ul class='jp-toggles'><li><a href='javascript:;' class='jp-repeat' tabindex='1' title='repeat'>repeat</a></li><li><a href='javascript:;' class='jp-repeat-off' tabindex='1' title='repeat off'>repeat off</a></li></ul></div></div><div class='jp-title' style='display:none;'><ul><li>Cro Magnon Man</li></ul></div><div class='jp-no-solution'><span>Update Required</span>To play the media you will need to either update your browser to a recent version or update your <a href='http://get.adobe.com/flashplayer/' target='_blank'>Flash plugin</a>.</div></div></div></div>";

            var skiplogicJquery = "";

            if (mediaQuestion.mediaSkipLogic != null)
            {
                skiplogicJquery = "<script type='text/javascript'>$(document).ready(function() {$('#quesTab_" + mediaQuestion.mediaSkipLogic.trueAction + "').hide();$('input[type=radio]').click(function() {if ($(this).attr('name') == 'group~" + mediaQuestion.id + "') {if ($(this).attr('id') == 'Answer_" + mediaQuestion.id + "_" + mediaQuestion.mediaSkipLogic.expectedAnswerId + "') {if ($(this).attr('checked') == 'checked') {$('#quesTab_" + mediaQuestion.mediaSkipLogic.trueAction + "').show();} else { $('#quesTab_" + mediaQuestion.mediaSkipLogic.trueAction + "').hide(); }} else { $('#quesTab_" + mediaQuestion.mediaSkipLogic.trueAction + "').hide(); }}});});</script>";
            }

            var questionAttribs = new Dictionary<string, string>
                {
                    {"id", "divMediaBlock"},
                    {"class", "quesTab greyBorder"}
                };
            var enclosed = BuildDivTag(questionAttribs);
            enclosed.InnerHtml = skiplogicJquery + mediaBlockJs + divTags;

            return enclosed;

        }

        public static TagBuilder BuildHiddenTag(IDictionary<string, string> attributes)
        {
            var hdnTag = new TagBuilder("input");

            hdnTag.MergeAttributes(attributes);

            return hdnTag;
        }

        public static string GetInlineStyle(IDictionary<string, string> styles)
        {
            var inlineStyle = "";

            string font;
            styles.TryGetValue("font", out font);
            if (!string.IsNullOrEmpty(font)) inlineStyle = inlineStyle + "font-family:" + font + ";";

            string fontSize;
            styles.TryGetValue("fontSize", out fontSize);
            if (!string.IsNullOrEmpty(fontSize)) inlineStyle = inlineStyle + "font-size:" + fontSize + ";";

            string fontColor;
            styles.TryGetValue("fontColor", out fontColor);
            if (!string.IsNullOrEmpty(fontSize)) inlineStyle = inlineStyle + "color:" + fontColor + ";";

            string logoName;
            styles.TryGetValue("logo", out logoName);
            if (!string.IsNullOrEmpty(logoName)) inlineStyle = inlineStyle + "background:url('" + logoName + "');";
            string width;
            styles.TryGetValue("width", out width);
            if (!string.IsNullOrEmpty(width)) inlineStyle = inlineStyle + "width:" + width + ";";

            string height;
            styles.TryGetValue("height", out height);
            if (!string.IsNullOrEmpty(height)) inlineStyle = inlineStyle + "height:" + height + ";";

            string bksize;
            styles.TryGetValue("background-size", out bksize);
            if (!string.IsNullOrEmpty(bksize)) inlineStyle = inlineStyle + "background-size:" + bksize + ";";

            return inlineStyle;
        }

        public static TagBuilder BuildLinkButton(IDictionary<string, string> attributes)
        {
            var linkTag = new TagBuilder("a");
            linkTag.MergeAttributes(attributes);
            return linkTag;
        }

        public static TagBuilder BuildInstructionTag(question displayQuestion)
        {
            var questionDiv = BuildDivTag(new Dictionary<string, string>
                                                         {
                                                             {"id","instructionsDiv"}
                                                         });

            var requiredInfo = BuildHiddenTag(new Dictionary<string, string>
                {
                    {"id", "hdnQuestion"},
                    {"type", "hidden"},
                    {"value", displayQuestion.id},
                    {"name", "hdnQuestion"}
                });

            var hdnQuestionType = BuildHiddenTag(new Dictionary<string, string>
                {
                    {"id", "hdnQuestionType_" + displayQuestion.id},
                    {"type", "hidden"},
                    {"name", "hdnQuestionType_" + displayQuestion.id},
                    {"value", displayQuestion.type}
                });

            questionDiv.InnerHtml = requiredInfo + hdnQuestionType.ToString() + displayQuestion.text;

            return questionDiv;
        }

    }
}
