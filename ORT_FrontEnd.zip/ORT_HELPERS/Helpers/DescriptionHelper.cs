﻿using System;
using System.ComponentModel;
using System.Linq;

namespace ORT_HELPERS.Helpers
{
    public class DescriptionHelper
    {
      public static string GetDescription(object value)
        {
            var fi = value.GetType().GetField(value.ToString());
            var attributes = 
                (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), 
                false);
            return (attributes.Length > 0) ? attributes[0].Description : value.ToString();
        }

        public static void SetPropertyValueByDescription(ref object objData, string description,object value)
        {
            var properties = objData.GetType().GetProperties();
            var objCastHelper = new ObjectCastHelper();

            foreach (var propertyInfo in from propertyInfo in properties let attribute = (DescriptionAttribute[])propertyInfo.GetCustomAttributes(typeof(DescriptionAttribute),false) where attribute.Length > 0 where attribute[0].Description == description select propertyInfo)
            {
                propertyInfo.SetValue(objData,objCastHelper.CastObject(value,propertyInfo.PropertyType),null);
            }
        }

        public static T GetValueFromDescription<T>(string description)
        {
            var type = typeof(T);
            if (!type.IsEnum) throw new InvalidOperationException();
            foreach (var field in type.GetFields())
            {
                var attribute = Attribute.GetCustomAttribute(field,
                    typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null)
                {
                    if (attribute.Description.ToLower() == description.ToLower())
                        return (T)field.GetValue(null);
                        //return (T)field.GetRawConstantValue();
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null);
                        //return (T)field.GetRawConstantValue();
                }
            }
            throw new ArgumentException("Not found.", "description");
            // or return default(T);
        }
    }
}
