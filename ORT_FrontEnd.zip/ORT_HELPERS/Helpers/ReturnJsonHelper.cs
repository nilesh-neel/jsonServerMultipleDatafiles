﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using log4net;

namespace ORT_HELPERS.Helpers
{
    public static class ReturnJsonHelper
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public static JsonResult GetExceptionJson(Exception ex)
        {
            Log.Error("Error Occured", ex);
            var jsonDict = new Dictionary<string, object>
                               {
                                   {"success", "false"},
                                   {"status", "500"},
                                   {"msg", "An unexpected error occurred."}
                               };
            return new JsonResult
                {
                    Data = jsonDict,
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
        }

        public static JsonResult GetSuccessJson(object data, string propertyName)
        {
            if (data.GetType().Name.ToLower() != "string")
            {
                HandleNulls(data);
            }

            var jsonDict = new Dictionary<string, object>
                               {
                                   {"success","true"},
                                   {"status","200"},
                                   {"msg","Success."},
                                   {propertyName,data}
                               };

            return new JsonResult
                       {
                           Data = jsonDict,
                           JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                          
                       };
        }

        private static void HandleNulls(object data)
        {
            if (data.GetType().Name.ToLower().Contains("list"))
            {
                foreach (var obj in (IEnumerable)data)
                {
                    var obj1 = obj;
                    foreach (
                        var propertyInfo in
                            obj.GetType().GetProperties().Where(propertyInfo => propertyInfo.GetValue(obj1, null) == null))
                    {
                        if (propertyInfo.PropertyType.Name.ToLower() == "string")
                            propertyInfo.SetValue(obj, string.Empty, null);
                    }
                }
            }
            else
            {
                foreach (
                    var propertyInfo in
                        data.GetType().GetProperties().Where(propertyInfo => propertyInfo.GetValue(data, null) == null))
                {
                    propertyInfo.SetValue(data, string.Empty, null);
                }
            }
        }

        public static JsonResult GetValidationJson(string message)
        {
            return new JsonResult
            {
                Data = new
                {
                    success = "false",
                    status = "301",
                    msg = message
                },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
        }

        public static JsonResult GetTimeOutJson()
        {
            return new JsonResult
            {
                Data = new
                {
                    success = "false",
                    status = "403",
                    msg = "Your session timed out, please sign-in to continue."
                },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
        }

        public static JsonResult GetPermissionDeniedJson(string controller, string action)
        {
            return new JsonResult
            {
                Data = new
                {
                    success = "false",
                    status = "401",
                    msg = string.Format("You do not have permission to access {0}/{1} module.", controller == "Customer" ? "Company" : controller, action == "SearchCustomer" ? "SearchCompany" : action == "AddCustomer" ? "AddCompany" : action)
                },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
        }


        public static JsonResult GetUploadSuccessJson(object data, string propertyName)
        {
            if (data.GetType().Name.ToLower() != "string")
            {
                HandleNulls(data);
            }

            var jsonDict = new Dictionary<string, object>
                               {
                                   {"success","true"},
                                   {"status","200"},
                                   {"msg","Success."},
                                   {propertyName,data}
                               };

            return new JsonResult
            {
                Data = jsonDict,
                JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                ContentType = "text/html"
            };
        }


    }

}

