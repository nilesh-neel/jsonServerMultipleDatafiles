﻿using System;
using System.Collections;
using System.Web;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.HelperClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using SHA256;

namespace ORT_HELPERS.Helpers
{
    public static class SessionHelper
    {
        public static ApplicationSettings AppSettings
        {
            get
            {
                var currentApp = HttpContext.Current.Application;
                return ((ApplicationSettings)currentApp["AppSettings"]);
            }
            set
            {
                var currentApp = HttpContext.Current.Application;
                currentApp["AppSettings"] = value;
            }
        }
        public static User LogggedInUser
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((User)currentSession["LogedInUser"]);
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["LogedInUser"] = value;
            }
        }

        public static string LoggedinCustomer
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((User)currentSession["LogedInUser"]).UserDetails.Customer.CustomerId;
            }
        }

        public static string LoggedinUserId
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((User)currentSession["LogedInUser"]).UserId;
            }
        }

        public static string SessionSaltString
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((SessionManageHelper)currentSession["SessionManageHelper"]).SaltString;
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["SessionManageHelper"] = new SessionManageHelper
                                                      {
                                                          SaltString = value
                                                      };
            }
        }

        public static void GetRandomEncryptString()
        {
            var rng = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const int size = 50;
            var buffer = new char[size];

            for (int i = 0; i < size; i++)
            {
                buffer[i] = chars[rng.Next(chars.Length)];
            }
            var objstring = new string(buffer);

            var objhash = new HASHClass();
            SessionSaltString = objhash.SHA256(ref objstring);
        }

        public static PublishedSurvey SessionSurvey
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((PublishedSurvey)currentSession["PublishedSurvey"]);
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["PublishedSurvey"] = value;
            }
        }

        public static Stack CardStack
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((Stack)currentSession["CardStack"]);
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["CardStack"] = value;
            }
        }

        public static string UploadSessionId
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return currentSession["UploadSessionId"].ToString();
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["UploadSessionId"] = value;
            }
        }

        public static bool IsModelValid
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return (bool) currentSession["IsModelValid"];
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["IsModelValid"] = value;
            }
        }

        public static bool IsDataValid
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return (bool)currentSession["IsDataValid"];
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["IsDataValid"] = value;
            }
        }

        public static bool ResponseExpected
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return (bool)currentSession["ResponseExpected"];
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["ResponseExpected"] = value;
            }
        }

        public static string ValidationMessage
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return (string)currentSession["ValidationMessage"];
            }
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["ValidationMessage"] = value;
            }
        }
    }
}
