﻿using System;
using System.Web.Mvc;

namespace ORT_HELPERS.Helpers
{
    public class SurveyResponseFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var questions = filterContext.HttpContext.Request.Form["hdnQuestion"].Split(Convert.ToChar(","));
        }
    }
}
