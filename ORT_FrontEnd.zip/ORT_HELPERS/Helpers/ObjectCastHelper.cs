﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ORT_HELPERS.Helpers
{
    public class ObjectCastHelper
    {
        public object CastObject(object data, Type sourceType)
        {
            object castedObject;

            if (data.GetType().Namespace == "System.Collections.Generic")
            {
                if (data.GetType() == typeof(List<object>))
                {
                    var castMethod = GetType().GetMethod("CastToList").MakeGenericMethod(sourceType);

                    castedObject = castMethod.Invoke(null, new[] { data });
                }
                else
                {
                    castedObject = data;
                }
            }
            else
            {
                var castMethod = GetType().GetMethod("CastTo").MakeGenericMethod(sourceType);
                if (sourceType.FullName == "System.Boolean")
                {
                   if(string.IsNullOrEmpty(data.ToString()))
                        data = "false";
                }
                castedObject = castMethod.Invoke(null, new[] { data });
            }

            return castedObject;
        }

        public static T CastTo<T>(object o)
        {
            if(typeof(T) == typeof(bool))
            {
                object value = Boolean.Parse(o.ToString());
                return (T) value;
            }
            return (T) o;
        }

        public static List<T> CastToList<T>(object o)
        {
            return (((List<object>)o).Cast<T>().ToList());
        }

        
    }
}
