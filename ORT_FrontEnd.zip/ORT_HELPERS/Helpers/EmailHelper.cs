﻿using System;
using System.Net;
using System.Net.Mail;

namespace ORT_HELPERS.Helpers
{
    public class EmailHelper
    {
        public string FromEmailId { get; set; }
        public string ToEmailId { get; set; }
        public string CcEmailId { get; set; }
        public string BccEmailId { get; set; }
        public string Subject { get; set; }
        public string Attachment { get; set; }
        public string EmailBody { get; set; }
        public string HostServer { get; set; }
        public int HostPort { get; set; }
        public string SmtpUser { get; set; }
        public string SmtpPassword { get; set; }

        public bool SendMail()
        {
            try
            {
                var mailMsg = new MailMessage();

                var msgAttachments = new Attachment(Attachment);

                var smtpClient = new SmtpClient(HostServer, HostPort);

                if (!string.IsNullOrEmpty(SmtpUser))
                {

                    smtpClient.Credentials = new NetworkCredential(SmtpUser, SmtpPassword);

                }


                mailMsg.From = new MailAddress(FromEmailId);

                mailMsg.To.Add(new MailAddress(ToEmailId));

                if (!string.IsNullOrEmpty(CcEmailId))
                    mailMsg.CC.Add(new MailAddress(CcEmailId));

                if (!string.IsNullOrEmpty(BccEmailId))
                    mailMsg.Bcc.Add(new MailAddress(BccEmailId));

                mailMsg.Subject = Subject;

                mailMsg.Body = EmailBody;

                mailMsg.IsBodyHtml = true;

                if (!string.IsNullOrEmpty(Attachment))
                    mailMsg.Attachments.Add(msgAttachments);

                smtpClient.Send(mailMsg);

                return true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
