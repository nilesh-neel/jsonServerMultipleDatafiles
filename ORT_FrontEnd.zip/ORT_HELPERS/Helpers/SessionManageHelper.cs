﻿namespace ORT_HELPERS.Helpers
{
    public class SessionManageHelper
    {
        public string SaltString { get; set; }
    }
}
