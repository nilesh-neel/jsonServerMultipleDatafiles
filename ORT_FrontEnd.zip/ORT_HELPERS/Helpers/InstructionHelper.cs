﻿using System.Web;
using HtmlAgilityPack;

namespace ORT_HELPERS.Helpers
{
    public class InstructionHelper
    {
        public static void SetFormAttributes(HtmlDocument doc, string method)
        {
            var formNode = doc.DocumentNode.SelectSingleNode("//form");
            formNode.Attributes.Add("method", method);
            formNode.Attributes.Add("id", "frmSurvey");
            formNode.Attributes.Add("action", "");

        }

        public static void SetDateTime(HtmlDocument doc, bool showDateTime)
        {
            var datetimeDiv = doc.GetElementbyId("dateDiv");
            datetimeDiv.InnerHtml = showDateTime ? "<script type='text/javascript'>$(document).ready(function() { var d = new Date();var dateStr = (d.getDate() < 10 ? ('0' + d.getDate()) : d.getDate()) + '-' + ((d.getMonth()+1) < 10 ? ('0' + (d.getMonth()+1)) : (d.getMonth()+1)) + '-' + d.getFullYear(); var timeStr = (d.getHours() < 10 ?  ('0' + d.getHours()) : d.getHours()) + ':' + (d.getMinutes() < 10 ? ('0' + d.getMinutes()) : d.getMinutes()); var dateTime = 'Date :'+ dateStr + '<br /> Time :' + timeStr;$('#dateDiv').html(dateTime);});</script>" : "";
        }

        public static void SetRedirectionUrl(HtmlDocument doc, bool needRedirection, string redirectionUrl)
        {
            if (!needRedirection) return;

            var nextBtn = doc.GetElementbyId("next_btn");

            if (nextBtn == null) return;

            var nextButtonLink = HttpUtility.HtmlEncode(
                "javascript:document.location.href ='" + redirectionUrl + "';");
            nextBtn.Attributes.Add("onClick", nextButtonLink);
        }
    }
}
