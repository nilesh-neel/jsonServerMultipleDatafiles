﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace ORT_HELPERS.Helpers
{
    public class AutomapperHelper
    {
        public object DoAutoMapping(Type sourceType, object data)
        {
            var objectCastHelper = new ObjectCastHelper();

            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType);

            var castedObject = objectCastHelper.CastObject(data, currentTypeMap.SourceType);

            var objDest = GetDesitinationType(currentTypeMap.DestinationType);

            return Mapper.Map(castedObject, castedObject.GetType(), objDest.GetType());

        }

        public object DoAutoMapping(Type sourceType, Type destinationType, object data)
        {
            var objectCastHelper = new ObjectCastHelper();

            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType && p.DestinationType == destinationType);

            var castedObject = objectCastHelper.CastObject(data, currentTypeMap.SourceType);
            var objDest = GetDesitinationType(currentTypeMap.DestinationType);
            return Mapper.Map(castedObject, castedObject.GetType(), objDest.GetType());
        }

        public object DoLibraryAutoMapping(Type sourceType, Type destinationType, object data)
        {
            var objectCastHelper = new ObjectCastHelper();
            
            destinationType = GetSourceMapType(sourceType);

            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType && p.DestinationType == destinationType);

            var castedObject = objectCastHelper.CastObject(data, currentTypeMap.SourceType);
            var objDest = GetDesitinationType(currentTypeMap.DestinationType);
            return Mapper.Map(castedObject, castedObject.GetType(), objDest.GetType());

        }

        public object DoLibraryComboAutoMapping(Type sourceType, Type destinationType, object data)
        {
            var objectCastHelper = new ObjectCastHelper();

            var currentTypeMap = Mapper.GetAllTypeMaps().FirstOrDefault(p => p.SourceType == sourceType && p.DestinationType == destinationType);

            var castedObject = objectCastHelper.CastObject(data, currentTypeMap.SourceType);
            var objDest = GetDesitinationType(currentTypeMap.DestinationType);
            return Mapper.Map(castedObject, castedObject.GetType(), objDest.GetType());

        }

        public object DoLibraryAutoMapping(Type sourceType, object data)
        {
            var objectCastHelper = new ObjectCastHelper();
            Type destinationType = GetSourceMapType(data.GetType());
            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType && p.DestinationType == destinationType);

            var castedObject = objectCastHelper.CastObject(data, currentTypeMap.SourceType);
          

            return Mapper.Map(castedObject, castedObject.GetType(), GetSourceMapType(sourceType));

        }    
   

        private static object GetDesitinationType(Type destType)
        {
            var generic = typeof(List<>);
            var specific = generic.MakeGenericType(destType);
            var ci = specific.GetConstructor(Type.EmptyTypes);
            return ci.Invoke(new object[] { });
        }


        public Type GetSourceMapType(Type sourceType)
        {
            var currentTypeMap = Mapper.GetAllTypeMaps().FirstOrDefault(p => p.SourceType == sourceType);
            return currentTypeMap.DestinationType;
        }


        public object DoSingleObjectAutoMapping(Type sourceType, object data)
        {
            var objectCastHelper = new ObjectCastHelper();

            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType);

            var castedObject = objectCastHelper.CastObject(data, currentTypeMap.SourceType);

            return Mapper.Map(castedObject, castedObject.GetType(), currentTypeMap.DestinationType);

        }

        
    }
}
