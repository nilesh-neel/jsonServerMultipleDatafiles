﻿using System;
using System.IO;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

namespace ORT_HELPERS.Helpers
{
    public static class JsonHelper
    {
        public static string ToJson(this object obj)
        {
            var serializer = new JavaScriptSerializer();
            return serializer.Serialize(obj);
        }

        public static string ToJson(this object obj, int recursionDepth)
        {
            var serializer = new JavaScriptSerializer {RecursionLimit = recursionDepth};
            return serializer.Serialize(obj);
        }

        private static string SerializeWithoutQuote(this object value)
        {
            var serializer = JsonSerializer.Create(null);

            var stringWriter = new StringWriter();

            using (var jsonWriter = new JsonTextWriter(stringWriter))
            {
                jsonWriter.QuoteName = false;
                jsonWriter.QuoteChar = Convert.ToChar("'");
                serializer.Serialize(jsonWriter, value);

                return stringWriter.ToString();
            }
        }

        public static object BuildReturnData(this object value)
        {
            return value.SerializeWithoutQuote();
        }
    }
}
