﻿using System.Collections.Generic;

namespace ORT_HELPERS.Helpers
{
    public class DictionaryHelper
    {
        public IDictionary<string, string> Dictionary { get; set; }
        public string GetKeyValue(string dictkey )
        {
            string value;
            Dictionary.TryGetValue(dictkey, out value);
            return value;
        }
    }
}
