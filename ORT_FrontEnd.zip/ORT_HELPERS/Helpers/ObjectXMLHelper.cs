﻿using System;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace ORT_HELPERS.Helpers
{
    public static class ObjectXmlHelper
    {
        public static string ToXml(object objConvert)
        {
            try
            {
                var stream = new MemoryStream();

                var writer = new StreamWriter(stream, Encoding.Unicode);
                
                var ns = new XmlSerializerNamespaces();
                
                ns.Add("", "");
                
                var ser = new XmlSerializer(objConvert.GetType());
                
                ser.Serialize(writer,objConvert,ns);
                
                var count = (int)stream.Length; // saves object in memory stream
                
                var arr = new byte[count];
                
                stream.Seek(0, SeekOrigin.Begin);
                
                // copy stream contents in byte array
                
                stream.Read(arr, 0, count);
                
                var utf = new UnicodeEncoding(); // convert byte array to string

                return utf.GetString(arr).Trim(); 
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}
