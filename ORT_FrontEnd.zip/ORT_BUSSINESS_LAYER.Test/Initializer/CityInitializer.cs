﻿using System.Collections.Generic;
using ORT_CORE.Class.MasterClasses;

namespace ORT_BUSSINESS_LAYER.Test.Initializer
{
   public static class CityInitializer
    {
       public static IEnumerable<City> CreateCities()
       {
           yield return new City
               {
                   CityId = "1",
                   CityCode = "BOM",
                   CityName = "Mumbai"
               };
           yield return new City
           {
               CityId = "2",
               CityCode = "NK",
               CityName = "Nasik"
           };
       }
    }
}
