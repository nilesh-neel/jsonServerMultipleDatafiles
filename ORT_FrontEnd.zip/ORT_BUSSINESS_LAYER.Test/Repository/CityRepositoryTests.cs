﻿using System;
using System.Linq;
using ORT_BUSSINESS_LAYER.Test.Initializer;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_BUSSINESS_LAYER.Test.Repository
{
    public class CityRepositoryTests : IMaster
    {
        #region Implementation of IMaster

        public object GetMasterData()
        {
            return CityInitializer.CreateCities().ToList();
        }

        public Type HomeType { get { return typeof(City); } }

        #endregion
    }
}
