﻿using System.Collections.Generic;
using NUnit.Framework;
using ORT_BUSSINESS_LAYER.ModuleMaster;
using ORT_BUSSINESS_LAYER.Test.Repository;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_BUSSINESS_LAYER.Test.MasterTest
{
    [TestFixture]
    public class MasterModuleTest
    {

        [Test]
        public void GetCityTest()
        {
            IMaster master = new CityRepositoryTests();
            var target = new MasterModule(master);
            var returnList =(List<City>) target.GetMasterList();
            Assert.True(returnList.Count == 2);
        }
       
        [Test]
        public void GetCompanyTest()
        {
            
        }
    }
}
