﻿using ORT_CORE.Interface.LibaryInterface;
using System;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using ORT_HELPERS.Helpers;
using ORT_PERSISTENCE.LibraryPersistence;
using ORT_PERSISTENCE.UploadObjects.Interface;
using ORT_BUSSINESS_LAYER.ModuleUpload;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using ORT_VIEW_MAP.MapClasses.Library;
using System.Web.Mvc;
namespace ORT_BUSSINESS_LAYER.ModuleLibrary
{
    public class LibraryModule
    {
        private static ILibrary _library;
        private static ICustomer _customerRepository;
        private static IAnswer _answerRepository;
        private static ISkipLogic _skipLogicRepository;
        private static ISoundClip _soundClipRepository;
        private static IQuestion _questionRepository;
        private static IQuota _quotaRepository;
        private static IReward _rewardRepository;
        private static ISetting _settingRepository;
        private static UploadModule _uploadModule;

        public LibraryModule(ICustomer cust, IAnswer answer, ISkipLogic skipLogic, ISoundClip sound, IQuestion question, IQuota quota, IReward reward, ISetting setting, IGraphicsUpload objgraphicUpload, IUpload objUpload)
        {
            try
            {
                _customerRepository = cust;
                _answerRepository = answer;
                _skipLogicRepository = skipLogic;
                _soundClipRepository = sound;
                _questionRepository = question;
                _quotaRepository = quota;
                _rewardRepository = reward;
                _settingRepository = setting;
                _uploadModule = new UploadModule(objUpload, objgraphicUpload);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public LibraryModule(ILibrary library)
        {
            try
            {
                _library = library;

            }
            catch (Exception)
            {
                throw;
            }
        }

        public object GetLibrary(string custId, string type)
        {
            try
            {
                return _library.GetLibraryList(custId, type);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool VerifyLibCategory(string libraryId, string category)
        {
            return _library.CheckLibraryCategory(libraryId, category);
        }

        public object GetLibraryCAtegory(string libId)
        {
            try
            {
                return _library.GetLibraryCategoryList(libId);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public object SearchLibrary(string libraryId, string category)
        {
            try
            {     var libraryData = _library.SearchLibrary(libraryId, category);
                    return libraryData == null ? null : BindDependentData(libraryData, _library.HomeType.Name);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public object EditLibrary(int libId, int category)
        {
            try
            {
                var libraryData = _library.SearchLibraryDetails(Convert.ToString(libId), Convert.ToString(category));
                return libraryData;// == null ? null : BindDependentData(libraryData,);             
            }
            catch (Exception)
            {
                throw;
            }
        }


        public object SaveLibraryDetails(object objLibrary)
        {
            try
            {               
                var libraryData = BindSaveLibraryDetails(objLibrary);
                return _library.SaveLibraryDetails(libraryData);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Library SaveLibrary(object objlibrary)
        {
            try
            {
                //var data2 = BindDependentSaveData(objlibrary, objlibrary.GetType().Name);
                var data = (Library)objlibrary;
                data.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                if (_library.SaveLibrary(data))
                {
                    return data;
                }
                return null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public object SaveLibraryCategory(object objlibrary)
        {
            try
            {
                if(_library.SaveLibraryCategory(objlibrary))
                {
                    return objlibrary;
                }
                return null;
               
            }
            catch (Exception)
            {
                throw;
            }
        }



        public object SaveGraphicsFile(string grapLibId, string category, string fileName, string folderPath, string extension)
        {
            try
            {
                return _uploadModule.SaveGraphicsFile(grapLibId, category, fileName, folderPath, extension);
            }
            catch (Exception)
            {
                throw;
            }

        }

        public string DeleteLibrary(object objlibrary)
        {
            try
            {
                var dataToDelete = BindDeleteData(objlibrary, objlibrary.GetType().Name);
                if (_library.DeleteLibrary(dataToDelete))
                {
                    return dataToDelete;
                }
                return string.Empty;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static object SaveMediaLibraryDetails(object objLibrary)
        {
            try
            {
                return _library.SaveLibraryDetails(objLibrary);
            }
            catch (Exception)
            {
                throw;
            }
        }
       

        private static object BindDependentSaveData(object libraryData, string dataType)
        {
            try
            {
                object finalData = null;
                //var libraryObject = libraryData.GetType().Name;
                switch (dataType)
                {
                    case "QuestionLibrary":
                        var returnQuestionData = (QuestionLibrary)libraryData;
                        returnQuestionData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        var objQuest = returnQuestionData.QuestionInLibrary.Select(sd => BindQuestionDependentData(sd)).ToList();
                        //returnQuestionData.QuestionInLibrary=;                       
                        finalData = returnQuestionData;
                        break;
                    case "Library":
                        var returnMessageData1 = (Library)libraryData;
                        returnMessageData1.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                        finalData = returnMessageData1;
                        break;
                    case "GraphicLibrary":
                        var returnGraphicData = (GraphicLibrary)libraryData;

                        finalData = returnGraphicData;
                        break;
                    case "SurveyLibrary":
                        var returnSurveyData = (SurveyLibrary)libraryData;
                        returnSurveyData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        returnSurveyData.SurveyInLibrary.Select(sd => BindSurveyDependentData(sd)).ToList();
                        finalData = returnSurveyData;
                        break;
                }
                return finalData;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static string BindDeleteData(object libraryData, string dataType)
        {
            try
            {
                string finalData = string.Empty;
                //var libraryObject = libraryData.GetType().Name;
                switch (dataType)
                {
                    case "QuestionLibrary":
                        var returnQuestionData = (QuestionLibrary)libraryData;
                        returnQuestionData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        var objQuest = returnQuestionData.QuestionInLibrary.Select(sd => BindQuestionDependentData(sd)).ToList();
                        //returnQuestionData.QuestionInLibrary=;                       
                        finalData = returnQuestionData.QuestionLibraryId;
                        break;
                    case "MessageLibrary":
                        var returnMessageData1 = (MessageLibrary)libraryData;
                        //returnMessageData1 Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                        finalData = returnMessageData1.MessageLibraryId;
                        break;
                    case "GraphicLibrary":
                        var returnGraphicData = (GraphicLibrary)libraryData;

                        finalData = returnGraphicData.GraphicLibraryId;
                        break;
                    case "SurveyLibrary":
                        var returnSurveyData = (SurveyLibrary)libraryData;
                        returnSurveyData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        returnSurveyData.SurveyInLibrary.Select(sd => BindSurveyDependentData(sd)).ToList();
                        finalData = returnSurveyData.SurveyLibraryId;
                        break;
                }
                return finalData;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static object BindDependentData(object libraryData, string dataType)
        {
            try
            {
                object finalData = null;
                //var libraryObject = libraryData.GetType().Name;
                switch (dataType)
                {
                    case "QuestionLibrary":
                        var returnQuestionData = (QuestionLibrary)libraryData;
                        returnQuestionData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        var objQuest = returnQuestionData.QuestionInLibrary.Select(sd => BindQuestionDependentData(sd)).ToList();
                        //returnQuestionData.QuestionInLibrary=;                       
                        finalData = returnQuestionData;
                        break;
                    case "MessageLibrary":
                        var returnMessageData1 = libraryData;
                        //returnMessageData1 Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                        finalData = returnMessageData1;
                        break;
                    case "GraphicLibrary":
                        var returnGraphicData =libraryData;

                        finalData = returnGraphicData;
                        break;
                    case "SurveyLibrary":
                        var returnSurveyData = (SurveyLibrary)libraryData;
                        returnSurveyData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        returnSurveyData.SurveyInLibrary.Select(sd => BindSurveyDependentData(sd)).ToList();
                        finalData = returnSurveyData;
                        break;
                }
                return finalData;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #region "BindQuestionLibraryDetails"
        private static Question BindQuestionDependentData(Question objQuestion)
        {
            objQuestion.Answers = _answerRepository.GetAnswers(objQuestion.QuestionId);
            if (objQuestion.HasMedia)
            {
                //objQuestion.Media = _mediaRepository.GetMediaInfo(objQuestion.QuestionId);
                //objQuestion.Media.Customer = _customerRepository.GetCustomer(objQuestion.Media.Customer.CustomerId);
                //objQuestion.Media.FileInfo = BindFileLibraryDependentData(objQuestion.Media.FileInfo.FileLibraryId);
            }
            return objQuestion;
        }

        private static FileLibrary BindFileLibraryDependentData(string fileLibId)
        {
            _library = new FileLibraryRepository();
            var fileLibrary = (FileLibrary)_library.GetLibrary(fileLibId);
            fileLibrary.Customer = _customerRepository.GetCustomer(fileLibrary.Customer.CustomerId);
            fileLibrary.SoundClip = _soundClipRepository.GetSoundClip(fileLibId);
            return fileLibrary;
        }
        #endregion

        #region "BindSurveyLibraryDetails"
        private static Survey BindSurveyDependentData(Survey objSurvey)
        {
            try
            {
                var questionInSurvey = _questionRepository.GetQuestionBySurveyId(objSurvey.SurveyId);
                if (questionInSurvey != null)
                {
                    objSurvey.Questions = questionInSurvey.Select(sd => BindQuestionDependentData(sd)).ToList();
                }
                objSurvey.Quota = _quotaRepository.GetQuota(objSurvey.SurveyId);
                objSurvey.Reward = _rewardRepository.GetReward(objSurvey.SurveyId);
                objSurvey.Settings = _settingRepository.GetSettingBySurveyId(objSurvey.SurveyId);
                return objSurvey;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region"BindSaveLibraryDetails"
        private static object BindSaveLibraryDetails(object objLibray)
        {
            try
            {
                object finalData = null;
                var libraryObject = objLibray.GetType().Name;
                switch (libraryObject)
                {
                    case "QuestionLibraryViewModel":
                        var objQues = (QuestionLibraryViewModel)objLibray;
                        var returnQuestionData = BindMapDataToQuestionLibrary(objQues);
                        finalData = returnQuestionData;
                        break;
                    case "MessageLibraryViewModel":
                        var objMessage = (MessageLibraryViewModel)objLibray;
                        var returnMessageData1 = Mapper.Map<MessageLibraryViewModel, MessageLibrary>(objMessage);
                        returnMessageData1.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                        returnMessageData1.Category = new LibraryCategory {CategoryId=objMessage.category };
                        returnMessageData1.LibType = Library.LibraryType.Message;
                        finalData = returnMessageData1;
                        break;
                    case "GraphicLibraryViewModel":
                        var objGraphic = (GraphicLibraryViewModel)objLibray;
                        var returnGraphicData = BindMapDataToGraphicsLibrary(objGraphic);
                        finalData = returnGraphicData;
                        break;
                    case "SurveyLibraryViewModel":
                        var returnSurveyData = (Survey)objLibray;
                        returnSurveyData.Customer = _customerRepository.GetCustomer(SessionHelper.LoggedinCustomer);
                        returnSurveyData = BindSurveyDependentData(returnSurveyData);
                        finalData = returnSurveyData;
                        break;
                }
                return finalData;
            }
            catch (Exception)
            {
                throw;
            }

        }

        private static object BindMapDataToQuestionLibrary(QuestionLibraryViewModel objQuestLib)
        {
        var questionLib = Mapper.Map<QuestionLibraryViewModel, QuestionLibrary>(objQuestLib);
            questionLib.QuestionInLibrary = Mapper.Map<List<question>, List<Question>>(objQuestLib.question);
            var ansList = objQuestLib.question.SelectMany(ans => ans.Answers);
            var objAnsw = Mapper.Map<List<answer>, List<Answer>>(ansList.ToList());
            questionLib.QuestionInLibrary.Select(sd => sd.Answers = objAnsw);
            //var que = (from lis in questionLib.QuestionInLibrary
            //          where lis.HasMedia == true
            //          select lis);

            return questionLib;
        }

        //private static Question BindMediaDependentData(Question objQuest)
        //{
        //    if (objQuest.HasMedia)
        //    {
        //        var objeMed = SaveMediaLibraryDetails(objQuest.Media);

        //    }
        //    return null;
        //}

        private static object BindMapDataToGraphicsLibrary(GraphicLibraryViewModel objGraphicLib)
        {
            var graphicLib = Mapper.Map<GraphicLibraryViewModel, GraphicLibrary>(objGraphicLib);
            return graphicLib;
        }


        #endregion

    }
}
