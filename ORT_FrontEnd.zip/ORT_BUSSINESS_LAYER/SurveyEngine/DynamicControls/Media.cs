﻿using System.Collections.Generic;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
   public class Media : IControl 
    {
       #region Implementation of IControl

       public MvcHtmlString BuildControl(question question)
       {
           var divQuestion = TagHelpers.BuildQuestionTag(question);


           var divAnswers = BuildAnswerTags(question.Answers, question.defaultanswer);

           var divMediaBlock = BuildMediaBlock("NeeleNeeleAmbarPar.mp3", "Neele Neele Ambar Par");

           divQuestion.InnerHtml = divQuestion.InnerHtml + divMediaBlock + divAnswers;

           return MvcHtmlString.Create(divQuestion.ToString());

       }

       private static TagBuilder BuildAnswerTags(IEnumerable<answer> answers, answer defaultAnswer)
       {
           var tagUl = new TagBuilder("ul");
           return tagUl;
       }

       private static TagBuilder BuildMediaBlock(string songFlieName,string songTitle)
       {
           var mediaBlockJs = "<script type='text/javascript'> $(document).ready(function(){$('.jp-jplayer').jPlayer({ready: function (event) {$(this).jPlayer('setMedia', {title:'" + songTitle + "',mp3:'media/" + songFlieName + "'});},swfPath: 'Scripts/jQuery.jPlayer.2.1.0',solution: 'flash, html',supplied: 'mp3',wmode: 'window'});});</script>";

           var divTags = "<div id='jquery_jplayer_1' class='jp-jplayer'></div><div id='jp_container_1' class='jp-audio'><div class='jp-type-single'><div class='jp-gui jp-interface'><ul class='jp-controls'><li><a href='javascript:;' class='jp-play' tabindex='1'>play</a></li><li><a href='javascript:;' class='jp-pause' tabindex='1'>pause</a></li><li><a href='javascript:;' class='jp-stop' tabindex='1'>stop</a></li><li><a href='javascript:;' class='jp-mute' tabindex='1' title='mute'>mute</a></li><li><a href='javascript:;' class='jp-unmute' tabindex='1' title='unmute'>unmute</a></li><li><a href='javascript:;' class='jp-volume-max' tabindex='1' title='max volume'>max volume</a></li></ul><div class='jp-progress'><div class='jp-seek-bar'><div class='jp-play-bar'></div></div></div><div class='jp-volume-bar'><div class='jp-volume-bar-value'></div></div><div class='jp-time-holder'><div class='jp-current-time'></div><div class='jp-duration'></div><ul class='jp-toggles'><li><a href='javascript:;' class='jp-repeat' tabindex='1' title='repeat'>repeat</a></li><li><a href='javascript:;' class='jp-repeat-off' tabindex='1' title='repeat off'>repeat off</a></li></ul></div></div><div class='jp-title' style='display:none;'><ul><li>Cro Magnon Man</li></ul></div><div class='jp-no-solution'><span>Update Required</span>To play the media you will need to either update your browser to a recent version or update your <a href='http://get.adobe.com/flashplayer/' target='_blank'>Flash plugin</a>.</div></div></div>";
           var enclosed = TagHelpers.BuildDivTag("divMediaBlock");
           enclosed.InnerHtml = mediaBlockJs + divTags;

           return enclosed;

       }

       #endregion
    }
}
