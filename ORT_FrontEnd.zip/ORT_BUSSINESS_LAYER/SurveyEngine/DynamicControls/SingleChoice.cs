﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
    public class SingleChoice : IControl
    {
        #region Implementation of IControl

        private string CheckedScript { get; set; }

        public SingleChoice()
        {
            CheckedScript = "";
        }

        public bool IsLastCard { get; set; }
        public config SurveyViewConfig { get; set; }

        public MvcHtmlString BuildControl(question question)
        {
            var divQuestion = TagHelpers.BuildQuestionTag(question, SurveyViewConfig);

            var divAnswers = BuildAnswerTags(question);

            var divContainer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id","quesTab_" + question.id},{"class","quesTab border"}
                });

            var mediaBlock = TagHelpers.SetMediaBlock(question, SurveyViewConfig.autoAdvance);

            if (mediaBlock != null)
                divContainer.InnerHtml = divQuestion.ToString() + mediaBlock + divAnswers;
            else
                divContainer.InnerHtml = divQuestion + divAnswers.ToString();


            return MvcHtmlString.Create(divContainer.ToString());
        }

        public List<Answer> ParseAnswer(NameValueCollection form, string questionId)
        {
            return new List<Answer>
                {
                    new Answer
                        {
                            AnswerId = form["hdnAnswer_" + questionId] 
                        }
                };
        }

        public string SurveyId { get; set; }
        public bool ValidateData(Responses toValidateResponse)
        {
            return true;
        }

        public string ValidationErrorMessage { get; set; }


        private  TagBuilder BuildAnswerTags(question question)
        {
            var tagFieldSet = TagFieldSet(question);

            var divAnswer = DivAnswer(tagFieldSet,question.id);

            return divAnswer;
        }

        private TagBuilder DivAnswer(TagBuilder tagFieldSet, string questionId)
        {
            var divAnswer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "btmDiv"}
                });

            if (!string.IsNullOrEmpty(CheckedScript))
            {
                var insertScript = "<script language='javascript'>$(document).ready(function() {$('#hdnAnswer_" + questionId + "').val('" + CheckedScript + "');});</script>";

                divAnswer.InnerHtml = divAnswer.InnerHtml + insertScript;
            }

            divAnswer.InnerHtml = divAnswer.InnerHtml + tagFieldSet;
            return divAnswer;
        }

        private  TagBuilder TagFieldSet(question question)
        {
            var tagFieldSet = TagHelpers.BuildFieldSet(new Dictionary<string, string>
                {
                    {"class", "radioGrp"}
                });

            var responseAnswerId = GetResponseAnswerId(question);

            foreach (var lblInner in from answer in question.Answers let answerTag = AnswerTag(question, answer, responseAnswerId) select InnerLabel(question, answerTag, answer))
            {
                tagFieldSet.InnerHtml = tagFieldSet.InnerHtml + lblInner;
            }
            return tagFieldSet;
        }

        private TagBuilder InnerLabel(question question, TagBuilder answerTag, answer answer)
        {
            var innerStyle = TagHelpers.GetInlineStyle(new Dictionary<string, string>
                {
                    {"font", SurveyViewConfig.answerFont},
                    {"fontSize",SurveyViewConfig.answerFontSize},
                    {"fontColor",SurveyViewConfig.answerFontColor}

                });
            var lblInner = TagHelpers.BuildLabel(new Dictionary<string, string>
                {
                    {"class", "label_radio"},
                    {"for", "Answer_" + question.id + "_" + answer.id},
                    {"style",innerStyle}
                });

            lblInner.InnerHtml = answerTag.ToString();
            return lblInner;
        }

        private  TagBuilder AnswerTag(question question, answer answer, string responseAnswerId)
        {
            var strOnClick = "javascript: $('#hdnAnswer_" + question.id + "').val(" + answer.id + ");";

            if (SurveyViewConfig.autoAdvance && question.hasMedia && !IsLastCard)
            {
                strOnClick = strOnClick + "document.forms[0].action='../Engine/CaptureResponse?surveyId=" + SurveyId + "';document.forms[0].submit();";
            }

            var attributeDict = new Dictionary<string, string>
                {
                    {"id", "Answer_" + question.id + "_" + answer.id},
                    {"value", answer.value},
                    {"name", "group~" + question.id},
                    {"onClick",strOnClick}
                };

            if (question.defaultanswer != null)
            {
                if (answer.id == question.defaultanswer.id && string.IsNullOrEmpty(responseAnswerId))
                {
                    attributeDict.Add("checked", "checked");
                    CheckedScript = answer.id;
                }
            }
            
            else if (answer.id == responseAnswerId)
            {
                attributeDict.Add("checked", "checked");
                CheckedScript = answer.id;
            }



            
            var answerTag = TagHelpers.BuildRadioButton(attributeDict);
            return answerTag;
        }

        private static string GetResponseAnswerId(question question)
        {
            return question.capturedResponse.selectedAnwers != null ? question.capturedResponse.selectedAnwers[0].id : "";
        }

        #endregion
    }
}
