﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
    public class MultiChoice : IControl
    {
        #region Implementation of IControl

        private string CheckedScript { get; set; }
        public MultiChoice()
        {
            CheckedScript = "";
        }

        public bool IsLastCard { get; set; }
        public config SurveyViewConfig { get; set; }

        public MvcHtmlString BuildControl(question question)
        {

            var divQuestion = TagHelpers.BuildQuestionTag(question, SurveyViewConfig);

            var divAnswers = BuildAnswerTags(question);

            var divContainer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id","quesTab_" + question.id},{"class","quesTab border"}
                });

            var mediaBlock = TagHelpers.SetMediaBlock(question, SurveyViewConfig.autoAdvance);

            if (mediaBlock != null)
                divContainer.InnerHtml = divQuestion.ToString() + mediaBlock + divAnswers;
            else
                divContainer.InnerHtml = divQuestion + divAnswers.ToString();


            return MvcHtmlString.Create(divContainer.ToString());
        }

        public List<Answer> ParseAnswer(NameValueCollection form, string questionId)
        {
            var uIAnswer = form["hdnAnswer_" + questionId];

            var answers = uIAnswer.Substring(0, uIAnswer.Length - 1).Split(Convert.ToChar("~"));

            var returnList = new List<Answer>();

            if (answers.Count() == 1)
            {
                returnList.Add(new Answer
                {
                    AnswerId = answers[0]
                });
            }
            else
            {
                returnList.AddRange(answers.Select(ans => new Answer
                    {
                        AnswerId = ans
                    }));
            }

            return returnList;
        }

        public string SurveyId { get; set; }
        public bool ValidateData(Responses toValidateResponse)
        {
            return true;
        }

        public string ValidationErrorMessage { get; set; }

        private TagBuilder BuildAnswerTags(question question)
        {

            var tagFieldSet = TagFieldSet(question);

            var divAnswer = GetAnswerTag(tagFieldSet, question.id);

            return divAnswer;
        }

        private TagBuilder GetAnswerTag(TagBuilder tagFieldSet, string questionId)
        {
            var divAnswer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "btmDiv"}
                });


            if (!string.IsNullOrEmpty(CheckedScript))
            {
                var insertScript = "<script language='javascript'>$(document).ready(function() {$('#hdnAnswer_" + questionId + "').val('" + CheckedScript + "');});</script>";
                divAnswer.InnerHtml = divAnswer.InnerHtml + insertScript;
            }

            divAnswer.InnerHtml = divAnswer.InnerHtml + tagFieldSet;
            return divAnswer;
        }

        private TagBuilder TagFieldSet(question question)
        {
            var tagFieldSet = TagHelpers.BuildFieldSet(new Dictionary<string, string>());

            foreach (var lblInner in from answer in question.Answers
                                     let answerTag = AnswerTag(question, answer)
                                     select InnerLabel(answerTag, answer))
            {

                tagFieldSet.InnerHtml = tagFieldSet.InnerHtml + lblInner;

            }
            return tagFieldSet;
        }

        private TagBuilder InnerLabel(TagBuilder answerTag, answer answer)
        {
            var innerStyle = TagHelpers.GetInlineStyle(new Dictionary<string, string>
                {
                    {"font", SurveyViewConfig.answerFont},
                    {"fontSize",SurveyViewConfig.answerFontSize},
                    {"fontColor",SurveyViewConfig.answerFontColor}

                });
            var lblInner = TagHelpers.BuildLabel(new Dictionary<string, string>
                {
                    {"class", "label_check"},
                    {"for", "Answer_" + answer.id},
                    {"style",innerStyle}
                });


            lblInner.InnerHtml = answerTag.ToString();
            return lblInner;
        }

        private TagBuilder AnswerTag(question question, answer answer)
        {
            var attributeDict = new Dictionary<string, string>
                {
                    {"id", "Answer_" + answer.id},
                    {"value", answer.value},
                    {"name", "group~" + question.id}
                };

            var onClick = "javascript: var value = $('#hdnAnswer_" + question.id + "').val();if($('#Answer_" +
                          answer.id + "').is(':checked')) {  value = value + '" + answer.id + "~';$('#hdnAnswer_" +
                          question.id + "').val(value);} else {value = value.replace('" + answer.id +
                          "~','');$('#hdnAnswer_" + question.id + "').val(value);}";

            attributeDict.Add("onClick", onClick);


            if (question.capturedResponse.selectedAnwers == null)
            {
                if (answer.id == question.defaultanswer.id)
                {
                    attributeDict.Add("checked", "checked");
                    CheckedScript = CheckedScript + answer.id + "~";
                }
            }
            else if (IsChecked(question, answer.id))
            {
                attributeDict.Add("checked", "checked");
                CheckedScript = CheckedScript + answer.id + "~";
            }

            var answerTag = TagHelpers.BuildCheckBox(attributeDict);

            return answerTag;
        }

        private static bool IsChecked(question askedQuestion, string answerId)
        {

            if (askedQuestion.capturedResponse.selectedAnwers == null) return false;

            var responseExists = askedQuestion.capturedResponse.selectedAnwers.Any(m => m.id == answerId);
            return responseExists;
        }

        #endregion
    }
}
