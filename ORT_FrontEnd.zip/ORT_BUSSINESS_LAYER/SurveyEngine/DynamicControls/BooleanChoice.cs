﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
    public class BooleanChoice : IControl
    {
        #region Implementation of IControl

        public bool IsLastCard { get; set; }
        public config SurveyViewConfig { get; set; }

        public MvcHtmlString BuildControl(question question)
        {
            var objSingleChoice = new SingleChoice { SurveyViewConfig = SurveyViewConfig, SurveyId = SurveyId, IsLastCard = IsLastCard };
            return objSingleChoice.BuildControl(question);
        }

        public List<Answer> ParseAnswer(NameValueCollection form, string questionId)
        {
            var objSingleChoice = new SingleChoice();
            return objSingleChoice.ParseAnswer(form, questionId);
        }

        public string SurveyId { get; set; }
        public bool ValidateData(Responses toValidateResponse)
        {
            var objSingleChoice = new SingleChoice();
            return objSingleChoice.ValidateData(toValidateResponse);
        }

        public string ValidationErrorMessage { get; set; }

        #endregion
    }
}
