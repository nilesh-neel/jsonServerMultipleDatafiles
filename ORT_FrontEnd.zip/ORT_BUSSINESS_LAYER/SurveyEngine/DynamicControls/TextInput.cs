﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
    public class TextInput : IControl
    {
        #region Implementation of IControl

        public bool IsLastCard { get; set; }
        public config SurveyViewConfig { get; set; }

        public MvcHtmlString BuildControl(question question)
        {
            var divQuestion = TagHelpers.BuildQuestionTag(question, SurveyViewConfig);

            var divAnswers = BuildAnswerTags(question);

            var divContainer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id","quesTab_" + question.id},{"class","quesTab border"}
                });

            var mediaBlock = TagHelpers.SetMediaBlock(question, SurveyViewConfig.autoAdvance);

            if (mediaBlock != null)
                divContainer.InnerHtml = divQuestion.ToString() + mediaBlock + divAnswers;
            else
                divContainer.InnerHtml = divQuestion + divAnswers.ToString();


            return MvcHtmlString.Create(divContainer.ToString());
        }

        public List<Answer> ParseAnswer(NameValueCollection form, string questionId)
        {
            return new List<Answer>
                {
                    new Answer
                        {
                            AnswerId = "",
                            AnswerText = form["hdnAnswer_" + questionId]
                        }
                };
        }

        public string SurveyId { get; set; }
        public bool ValidateData(Responses toValidateResponse)
        {
            return true;
        }

        public string ValidationErrorMessage { get; set; }


        private TagBuilder BuildAnswerTags(question question)
        {
            var divAnswer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "btmDiv"}
                });

            var value = "";
            var assingnedText = "";

            if(question.capturedResponse.selectedAnwers != null)
            {
                value = question.capturedResponse.selectedAnwers[0].value;
                assingnedText = "<script language='javascript'>$(document).ready(function() {$('#hdnAnswer_" + question.id + "').val('" + value + "');});</script>";
            }

            var attributeDict = AttributeDict(question, value);

            var answerTag = TagHelpers.BuildTextBox(attributeDict);

            divAnswer.InnerHtml = assingnedText +  answerTag;

            return divAnswer;
        }

        private Dictionary<string, string> AttributeDict(question question, string value)
        {
            var innerStyle = TagHelpers.GetInlineStyle(new Dictionary<string, string>
                {
                    {"font", SurveyViewConfig.answerFont},
                    {"fontSize", SurveyViewConfig.answerFontSize},
                    {"fontColor", SurveyViewConfig.answerFontColor}
                });

            var attributeDict = new Dictionary<string, string>
                {
                    {"id", "Answer_" + question.id},
                    {"name", "Answer_" + question.id},
                    {"value", value},
                    {"class", "txtBox"},
                    {"onchange", "javascript:$('#hdnAnswer_" + question.id + "').val(this.value);"},
                    {"style", innerStyle}
                };
            return attributeDict;
        }

        #endregion
    }
}
