﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using ORT_HELPERS.Helpers;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
    public class NumberInput : IControl
    {
        #region Implementation of IControl

        public bool IsLastCard { get; set; }
        public config SurveyViewConfig { get; set; }
        public MvcHtmlString BuildControl(question question)
        {
            var divQuestion = TagHelpers.BuildQuestionTag(question, SurveyViewConfig);

            var divAnswers = BuildAnswerTags(question);

            var divContainer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id","quesTab_" + question.id},{"class","quesTab border"}
                });

            var mediaBlock = TagHelpers.SetMediaBlock(question, SurveyViewConfig.autoAdvance);

            if (mediaBlock != null)
                divContainer.InnerHtml = divQuestion.ToString() + mediaBlock + divAnswers;
            else
                divContainer.InnerHtml = divQuestion + divAnswers.ToString();


            return MvcHtmlString.Create(divContainer.ToString());
        }

        public List<Answer> ParseAnswer(NameValueCollection form, string questionId)
        {
            var objTextInput = new TextInput();
            return objTextInput.ParseAnswer(form, questionId);
        }

        public string SurveyId { get; set; }
        public bool ValidateData(Responses toValidateResponse)
        {
            var responseDate = toValidateResponse.Answer[0].AnswerText;
            var returnResult = responseDate.IsInteger();
            if (!returnResult) ValidationErrorMessage = "Please enter a number.";
            return returnResult;
        }

        public string ValidationErrorMessage { get; set; }

        private TagBuilder BuildAnswerTags(question question)
        {
            var divAnswer = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "btmDiv"}
                });

            var value = "";
            var assingnedText = "";

            if (question.capturedResponse.selectedAnwers != null)
            {
                value = question.capturedResponse.selectedAnwers[0].value;
                assingnedText = "<script language='javascript'>$(document).ready(function() {$('#hdnAnswer_" + question.id + "').val('" + value + "');});</script>";
            }

            var attributeDict = AttributeDict(question, value);

            var answerTag = TagHelpers.BuildTextBox(attributeDict);

            divAnswer.InnerHtml = GetKeypressJquery("Answer_" + question.id) + assingnedText + answerTag;

            return divAnswer;
        }

        private static string GetKeypressJquery(string elementId)
        {
            var jqueryString = "<script language='javascript'>$(document).ready(function() { $('#" + elementId + "').keydown(function (e) {if (String.fromCharCode(e.keyCode).match(/[^0-9]/g)) return false;}); });</script>";

            return jqueryString;
        }

        private Dictionary<string, string> AttributeDict(question question, string value)
        {
            var innerStyle = TagHelpers.GetInlineStyle(new Dictionary<string, string>
                {
                    {"font", SurveyViewConfig.answerFont},
                    {"fontSize", SurveyViewConfig.answerFontSize},
                    {"fontColor", SurveyViewConfig.answerFontColor}
                });

            var attributeDict = new Dictionary<string, string>
                {
                    {"id", "Answer_" + question.id},
                    {"name", "Answer_" + question.id},
                    {"value", value},
                    {"class", "txtBox"},
                    {"onchange", "javascript:$('#hdnAnswer_" + question.id + "').val(this.value);"},
                    {"style", innerStyle}
                };
            return attributeDict;
        }

        #endregion
    }
}
