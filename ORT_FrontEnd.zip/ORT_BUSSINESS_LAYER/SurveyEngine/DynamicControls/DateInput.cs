﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using ORT_HELPERS.Helpers;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.DynamicControls
{
    public class DateInput : IControl
    {
        #region Implementation of IControl

        public bool IsLastCard { get; set; }
        public config SurveyViewConfig { get; set; }

        public MvcHtmlString BuildControl(question question)
        {
            var objTextInput = new TextInput { SurveyViewConfig = SurveyViewConfig, SurveyId = SurveyId, IsLastCard = IsLastCard };
            return objTextInput.BuildControl(question);
        }

        public List<Answer> ParseAnswer(NameValueCollection form, string questionId)
        {
            var objTextInput = new TextInput();
            return objTextInput.ParseAnswer(form, questionId);
        }

        public string SurveyId { get; set; }

        public bool ValidateData(Responses toValidateResponse)
        {
            var responseDate = toValidateResponse.Answer[0].AnswerText;
            var returnResult = responseDate.IsDateValid("MM/dd/yyyy");
            if (!returnResult) ValidationErrorMessage = "Please enter valid date";
            return returnResult;
        }

        public string ValidationErrorMessage { get; set; }

        #endregion
    }
}
