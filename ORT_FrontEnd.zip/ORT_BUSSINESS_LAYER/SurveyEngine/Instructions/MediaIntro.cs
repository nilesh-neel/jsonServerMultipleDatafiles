﻿using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.Instructions
{
    public class MediaIntro : IInstruction
    {
        public config SurveyViewConfig { get; set; }

        public MvcHtmlString BuildInstuctionPage(question question)
        {
            var questionDiv = TagHelpers.BuildInstructionTag(question);

            return MvcHtmlString.Create(questionDiv.ToString());
        }
    }
}
