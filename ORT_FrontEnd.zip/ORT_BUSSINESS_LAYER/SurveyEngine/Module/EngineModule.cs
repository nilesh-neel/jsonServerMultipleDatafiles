﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HtmlAgilityPack;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using NCalc;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.Module
{
    public class EngineModule
    {
        private static IEnumerable<IControl> _control;
        private static IEnumerable<IInstruction> _instructions;
        public List<question> SurveyQuestions { get; set; }
        public string CurrentSurveyId { get; set; }
        public string CurrentPage { get; set; }
        public config EngineSurveyConfig { get; set; }
        public bool IsLastCard { get; set; }
        public bool CurrentQuestionHasMedia { get; set; }

        public EngineModule(IEnumerable<IControl> control, IEnumerable<IInstruction> instructions)
        {
            _control = control;
            _instructions = instructions;
            CurrentQuestionHasMedia = false;
        }

        public MvcHtmlString BuildSurveyHtmlResponse(bool isModelValid, bool isDataValid)
        {
            var doc = new HtmlDocument { OptionFixNestedTags = true, OptionUseIdAttribute = true };
            doc.Load(SessionHelper.AppSettings.EngineTemplatePath + EngineSurveyConfig.surveyTemplateName);

            if (isModelValid == false || isDataValid == false)
            {
                AddValidationScript(doc);
            }

            InstructionHelper.SetFormAttributes(doc, "POST");

            InstructionHelper.SetDateTime(doc, EngineSurveyConfig.showDateTime);

            SetHeaderDiv(doc);

            SetLogo(doc);

            SetQuestionDiv(isModelValid, isDataValid, doc);

            return MvcHtmlString.Create(doc.DocumentNode.InnerHtml);
        }

        private void SetQuestionDiv(bool isModelValid, bool isDataValid, HtmlDocument doc)
        {
            var questionDiv = doc.GetElementbyId("quesDivs");

            var pageCountDiv = doc.GetElementbyId("heading");

            pageCountDiv.InnerHtml = "Page " + CurrentPage;

            var divInnerHtml = ControlHtmlstring();

            divInnerHtml = divInnerHtml + NavigationDiv();

            var clsClear = BuildClearTag();

            divInnerHtml = divInnerHtml + clsClear;
            var validationString = SetValidationMessages(isModelValid, isDataValid);
            questionDiv.InnerHtml = validationString + divInnerHtml;

        }

        public bool ValidateData(string questionType, Responses capturedResponse)
        {
            SessionHelper.ValidationMessage = "";
            var validationMsg = "";
            var currentControl = GetCurrentControl(questionType);
            var isValid = currentControl.ValidateData(capturedResponse);
            if (!isValid)
            {
                validationMsg = validationMsg + currentControl.ValidationErrorMessage + "\n";
                SessionHelper.ValidationMessage = validationMsg;
            }
            return isValid;
        }

        private static string SetValidationMessages(bool isModelValid, bool isDataValid)
        {
            return isModelValid == false
                       ? HiddenValidationMessageField("Please respond to Questions below.").ToString()
                       : (isDataValid == false
                              ? HiddenValidationMessageField(SessionHelper.ValidationMessage).ToString()
                              : "");
        }

        private void SetHeaderDiv(HtmlDocument doc)
        {
            //headerDiv
            var headerDiv = doc.GetElementbyId("titleDiv");

            var getInlineStyle = TagHelpers.GetInlineStyle(new Dictionary<string, string>
                {
                    {"font", EngineSurveyConfig.headerFont},
                    {"fontSize",EngineSurveyConfig.headerFontSize},
                    {"fontColor",EngineSurveyConfig.headerFontColor}
                });

            headerDiv.Attributes.Add("style", getInlineStyle);
        }

        public MvcHtmlString BuildWelcomeScreen()
        {
            var doc = new HtmlDocument { OptionFixNestedTags = true, OptionUseIdAttribute = true };
            doc.Load(SessionHelper.AppSettings.EngineTemplatePath + EngineSurveyConfig.surveyWelcomePage);
            InstructionHelper.SetDateTime(doc, EngineSurveyConfig.showDateTime);
            SetNextButton(doc);
            return MvcHtmlString.Create(doc.DocumentNode.InnerHtml);
        }

        private void SetNextButton(HtmlDocument doc)
        {
            var nextDiv = doc.GetElementbyId("nav_btns");
            var nextButtonLink = HttpUtility.HtmlEncode(
                    "javascript:document.location.href ='../Engine/ProcessSurvey?surveyId=" + CurrentSurveyId + "';");
            nextDiv.InnerHtml = NextButton(nextButtonLink).ToString();
        }

        public MvcHtmlString BuildThankYouScreen()
        {
            var doc = BuildEndScreen(EngineSurveyConfig.surveyThankuPage);
            if (EngineSurveyConfig.endMessageFromLibrary)
            {
                var contentDiv = doc.GetElementbyId("contentDiv");
                contentDiv.InnerHtml = EngineSurveyConfig.messageTextFromLibrary;
            }
            return MvcHtmlString.Create(doc.DocumentNode.InnerHtml);
        }

        public MvcHtmlString GetEndScreen()
        {

            return EngineSurveyConfig.rewardApplicable ? BuildRewardsScreen() : BuildThankYouScreen();
        }

        public MvcHtmlString BuildRewardsScreen()
        {
            var doc = BuildEndScreen(EngineSurveyConfig.surveyRewardPage);
            return MvcHtmlString.Create(doc.DocumentNode.InnerHtml);
        }

        public HtmlDocument BuildEndScreen(string sourcePage)
        {
            var doc = new HtmlDocument { OptionFixNestedTags = true, OptionUseIdAttribute = true };
            doc.Load(SessionHelper.AppSettings.EngineTemplatePath + sourcePage);
            InstructionHelper.SetFormAttributes(doc, "GET");
            InstructionHelper.SetDateTime(doc, EngineSurveyConfig.showDateTime);
            InstructionHelper.SetRedirectionUrl(doc, EngineSurveyConfig.redirection, EngineSurveyConfig.redirectionUrl);
            return doc;
        }

        public MvcHtmlString BuildExpiredScreen()
        {
            var doc = BuildEndScreen(EngineSurveyConfig.surveyExpiredPage);
            return MvcHtmlString.Create(doc.DocumentNode.InnerHtml);
        }

        private void SetLogo(HtmlDocument doc)
        {
            if (string.IsNullOrEmpty(EngineSurveyConfig.logo)) return;
            var logoDiv = doc.GetElementbyId("logoDiv");

            var getInlineStyle = TagHelpers.GetInlineStyle(new Dictionary<string, string>
                {
                    {"logo","../images/" + EngineSurveyConfig.logo},
                    {"background-size","100% 100%;"}

                });
            logoDiv.Attributes.Add("style", getInlineStyle);

        }

        private static TagBuilder BuildClearTag()
        {
            return TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "clr"},
                    {"class","clr"}
                });
        }

        private static void AddValidationScript(HtmlDocument doc)
        {
            var headnode = doc.DocumentNode.SelectSingleNode("/html/head");
            var scripts = doc.CreateElement("script");
            scripts.Attributes.Add("type", "text/javascript");
            scripts.InnerHtml = "$(document).ready(function() {alert($('#hdnValidaitonMessage').val());});";
            headnode.AppendChild(scripts);
        }

        private TagBuilder NavigationDiv()
        {
            var navigationDiv = TagHelpers.BuildDivTag(new Dictionary<string, string>
                {
                    {"id", "nav_btns"}
                });

            var nextButtonLink = HttpUtility.HtmlEncode(
                    "javascript:document.forms[0].action='../Engine/CaptureResponse?surveyId=" + CurrentSurveyId + "';document.forms[0].submit();");

            string navigationHtml;

            if (!IsLastCard)
            {
                if (EngineSurveyConfig.autoAdvance && CurrentQuestionHasMedia)
                {
                    navigationHtml = "";
                }
                else
                {
                    navigationHtml = BackButton() + NextButton(nextButtonLink).ToString();
                }

            }
            else
                navigationHtml = SubmitButton().ToString();

            navigationDiv.InnerHtml = navigationHtml;

            return navigationDiv;
        }

        private string ControlHtmlstring()
        {
            var returnHtmlstring = "";

            foreach (var surveyQuestion in SurveyQuestions)
            {
                var currentControl = GetCurrentControl(surveyQuestion.type);
                if (currentControl != null)
                {
                    currentControl.SurveyViewConfig = EngineSurveyConfig;
                    currentControl.SurveyId = CurrentSurveyId;
                    currentControl.IsLastCard = IsLastCard;
                    if (surveyQuestion.hasMedia) CurrentQuestionHasMedia = true;
                    returnHtmlstring = returnHtmlstring + currentControl.BuildControl(surveyQuestion);
                }
                else
                {
                    var currentInstruction = GetCurrentInstruction(surveyQuestion.type);
                    currentInstruction.SurveyViewConfig = EngineSurveyConfig;
                    returnHtmlstring = returnHtmlstring + currentInstruction.BuildInstuctionPage(surveyQuestion);
                }
            }
            return returnHtmlstring;
        }

        private TagBuilder NextButton(string nextOnclick)
        {
            var nextButton = !EngineSurveyConfig.nextBackTextLink ? BuildNextButton(nextOnclick) : BuildNextButtonAsLink(nextOnclick);

            return nextButton;
        }

        private static TagBuilder BuildNextButton(string nextOnclick)
        {
            var attribDict = new Dictionary<string, string>
                {
                    {"id", "next_btn"},
                    {"type", "button"},
                    {"onClick", nextOnclick},
                    {"class", "btn next_btn"}
                };


            var nextButton = TagHelpers.BuildButton(attribDict);
            return nextButton;
        }

        private static TagBuilder BuildNextButtonAsLink(string nextOnclick)
        {
            var attribDict = new Dictionary<string, string>
                {
                    {"id", "next_link"},
                    {"onClick", nextOnclick},
                    {"href","#"}
                };

            var nextButton = TagHelpers.BuildLinkButton(attribDict);
            nextButton.InnerHtml = "Next&raquo;";
            return nextButton;
        }

        private TagBuilder BackButton()
        {
            if (EngineSurveyConfig.allowBackButton == false) return null;

            var backOnClick =
                HttpUtility.HtmlEncode(
                    "javascript:document.forms[0].action='../Engine/MoveBack?surveyId=" + CurrentSurveyId + "';document.forms[0].submit();");

            var backButton = !EngineSurveyConfig.nextBackTextLink ? BuildBackButton(backOnClick) : BuildBackButtonAsLink(backOnClick);

            return backButton;
        }

        private static TagBuilder BuildBackButton(string backOnclick)
        {
            var attribDict = new Dictionary<string, string>
                {
                    {"id", "prev_btn"},
                    {"type", "button"},
                    {"onClick", backOnclick},
                    {"class", "btn prev_btn"}
                };


            var backButton = TagHelpers.BuildButton(attribDict);
            return backButton;
        }

        private static TagBuilder BuildBackButtonAsLink(string backOnclick)
        {
            var attribDict = new Dictionary<string, string>
                {
                    {"id", "prev_link"},
                    {"onClick", backOnclick},
                    {"href","#"}
                };

            var backButton = TagHelpers.BuildLinkButton(attribDict);
            backButton.InnerHtml = "&laquo;Previous";
            return backButton;
        }

        private TagBuilder SubmitButton()
        {
            var submitOnClick =
                HttpUtility.HtmlEncode(
                    "javascript:document.forms[0].action='../Engine/EndSurvey?surveyId=" + CurrentSurveyId + "';document.forms[0].submit();");

            var attribDict = new Dictionary<string, string>
                {
                    {"id", "submit_btn"},
                    {"type", "button"},
                    {"onClick", submitOnClick},
                    {"class", "btn submit_btn"}
                };

            var submitButton = TagHelpers.BuildButton(attribDict);

            return submitButton;
        }

        private static TagBuilder HiddenValidationMessageField(string validationMessage)
        {
            var hdnValidationField = TagHelpers.BuildHiddenTag(new Dictionary<string, string>
                {
                    {"id", "hdnValidaitonMessage"},
                    {"type", "hidden"},
                    {"value", validationMessage},
                    {"name", "hdnValidaitonMessage"}
                });
            return hdnValidationField;
        }

        private static IControl GetCurrentControl(string questionType)
        {
            try
            {
                return _control.Single(a => a.GetType().Name == questionType);
            }
            catch (Exception)
            {
                return null;
            }

        }

        private static IInstruction GetCurrentInstruction(string questionType)
        {
            try
            {
                return _instructions.Single(a => a.GetType().Name == questionType);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<Responses> ParseResponse(string[] questions, NameValueCollection form)
        {
            return (from quest in questions
                    let questionType = form["hdnQuestionType_" + quest]
                    let currentControl = GetCurrentControl(questionType)
                    select new Responses
                        {
                            Question = new Question { QuestionId = quest, QuestionType = DescriptionHelper.GetValueFromDescription<Question.QuestionTypes>(questionType) },
                            SurveyId = form["surveyId"],
                            Answer = currentControl.ParseAnswer(form, quest)
                        }).ToList();
        }

        public bool VerifySkipLogic()
        {
            if (EngineSurveyConfig.verifySkipLogic)
                if (SessionHelper.SessionSurvey.skipLogic != null)
                    return true;
            return false;
        }

        public bool HasSkipSourceQuestion(List<question> questions)
        {
            var skipLogic = SessionHelper.SessionSurvey.skipLogic;
            return skipLogic.Any(logic => questions.Any(question => question.id == logic.checkQuestionId));
        }

        public string GetMatchedAnswerQuestionId(List<question> questions)
        {
            var skipLogic = SessionHelper.SessionSurvey.skipLogic;

            string returnQuestion = null;

            foreach (var lg in from lg in skipLogic where lg.checkQuestionId == questions[0].id let matchedQuestion = questions[0] let selectedAnwsers = matchedQuestion.capturedResponse.selectedAnwers where selectedAnwsers.Any(answer => HasAnswerMatched(lg, answer)) select lg)
            {
                returnQuestion = lg.trueAction;
            }

            return returnQuestion;
        }

        private static bool HasAnswerMatched(publishedSkipLogic lg, answer ans)
        {
            if (lg.expectedAnswerId != null)
            {
                if (lg.expectedAnswerId == ans.id)
                    return true;
            }
            else if (lg.expectedAnswerText != null)
            {
                var exp = new Expression(ans.value + lg.evalOperator + lg.expectedAnswerText);
                return (bool)exp.Evaluate();
            }

            return false;
        }

        public card GetJumpCard(string searchForQuestion)
        {
            var firstCard = SessionHelper.SessionSurvey.cardobj;
            return SearchCard(firstCard, searchForQuestion);
        }

        private static card SearchCard(card currentCard, string searchQuestion)
        {
            return currentCard.questions.Any(quest => quest.id == searchQuestion) ? currentCard : SearchCard(currentCard.cardobj, searchQuestion);
        }

        public bool AllowSaveAndContinueLater()
        {
            return EngineSurveyConfig.allowContinueLater;
        }

        
    }
}
