﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Mvc;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.Interface
{
   public interface IControl
   {
       bool IsLastCard { get; set; }
       config SurveyViewConfig { get; set; }
       MvcHtmlString BuildControl(question question);
       List<Answer> ParseAnswer(NameValueCollection form, string questionId);
       string SurveyId { get; set; }
       bool ValidateData(Responses toValidateResponse);
       string ValidationErrorMessage { get; set; }

   }
}
