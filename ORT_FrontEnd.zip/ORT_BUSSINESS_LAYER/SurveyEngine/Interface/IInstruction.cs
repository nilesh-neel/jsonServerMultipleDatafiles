﻿using System.Web.Mvc;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.SurveyEngine.Interface
{
   public interface IInstruction
    {
       config SurveyViewConfig { get; set; }
       MvcHtmlString BuildInstuctionPage(question question);
    }
}
