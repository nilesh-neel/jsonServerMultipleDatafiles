﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using AutoMapper;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
    public class SurveyModule
    {
        private static ISurvey _surveyRepository;
        private static IUser _userRepository;
        private static ICustomer _customerRepository;
        private static IQuestion _questionRepository;
        private static IReward _rewardRepository;
        private static ISetting _settingRepository;
        private static IQuota _quotaRepository;
        private static IAnswer _answerRepository;
        private static ISkipLogic _skipLogicRepository;
        private static IReponses _reponsesRepository;
        private static ISoundClip _soundClipRepository;
        private static IPlayList _playList;

        private static int _questionCount = 1;

        private static int _localpageNumber = 1;

        private static int _songCount;

        public SurveyModule(ISurvey survey, IUser user, ICustomer customer, IQuestion question, ISetting setting, IReward reward, IQuota quota, IAnswer answer, ISkipLogic skipLogic, IReponses reponses, ISoundClip soundClip, IPlayList playList)
        {
            _surveyRepository = survey;
            _userRepository = user;
            _customerRepository = customer;
            _questionRepository = question;
            _settingRepository = setting;
            _rewardRepository = reward;
            _quotaRepository = quota;
            _answerRepository = answer;
            _skipLogicRepository = skipLogic;
            _reponsesRepository = reponses;
            _soundClipRepository = soundClip;
            _localpageNumber = 1;
            _playList = playList;
        }

        public IUser UserRepository { get; set; }
        public ICustomer CustomerRepository { get; set; }

        public Survey GetSurveyBySurveyId(string customerId, string surveyId)
        {
            var surveyData = _surveyRepository.GetSurvey(customerId, surveyId);
            if (surveyData == null) return null;
            var returnData = BindDependentData(surveyData);
            var datawithQuestions = BindQuestionsData(returnData);
            var datawithSettings = BindSettingsData(datawithQuestions);
            var datawithConfig = BindSettingConfig(datawithSettings);
            var dataWithSkipLogic = ImplementSkipLogic(datawithConfig);
            return dataWithSkipLogic;
        }

        public Survey GetSurveyBySessionId(string surveyId, string sessionId)
        {
            var surveyData = _surveyRepository.GetSurvey("", surveyId);
            if (surveyData == null) return null;
            var returnData = BindDependentData(surveyData);
            var datawithQuestions = BindSessionQuestionsData(returnData, sessionId);
            var datawithSettings = BindSettingsData(datawithQuestions);
            var datawithConfig = BindSettingConfig(datawithSettings);
            var dataWithSkipLogic = ImplementSkipLogic(datawithConfig);
            return dataWithSkipLogic;
        }

        public List<Survey> GetSurveyByCustomerId(string customerId)
        {
            var surveyData = _surveyRepository.GetSurvey(customerId);
            return surveyData.Select(sd => BindDependentData(sd)).ToList();
        }

        private static Survey BindDependentData(Survey surveyData)
        {
            var returnData = surveyData;
            returnData.CreatedBy = _userRepository.GetUserByUserId(surveyData.CreatedBy.UserId);
            returnData.ModifiedBy = _userRepository.GetUserByUserId(surveyData.ModifiedBy.UserId);
            returnData.Customer = _customerRepository.GetCustomer(surveyData.Customer.CustomerId);
            returnData.Reward = _rewardRepository.GetReward(surveyData.SurveyId);
            returnData.Quota = _quotaRepository.GetQuota(surveyData.SurveyId);
            returnData.SkipLogic = _skipLogicRepository.GetSkipLogic(surveyData.SurveyId);
            return returnData;
        }

        private static Survey BindQuestionsData(Survey surveyData)
        {
            var returnData = surveyData;

            returnData.Questions = _questionRepository.GetQuestionBySurveyId(surveyData.SurveyId);

            foreach (var q in returnData.Questions)
            {
                BindAnswerAndSongs(q);
                q.Customer = surveyData.Customer;
                q.MediaSkipLogic = BuildMediaSkipLogic(q);
            }
            return returnData;
        }

        private static SkipLogic BuildMediaSkipLogic(Question mediaQuestion)
        {
            var mediaskiplogic = _skipLogicRepository.GetMediaSkipLogic(mediaQuestion.QuestionId);
            ParseLogicExpression(mediaskiplogic);
            return mediaskiplogic;
        }

        private static PlayList BindSongs(PlayList playList)
        {
            var returnList = playList;
            foreach (var song in returnList.Songs)
            {
                song.SoundClip = _soundClipRepository.GetSoundClip(song.FileLibraryId);
            }

            return returnList;
        }

        private static Survey BindSessionQuestionsData(Survey surveyData, string sessionId)
        {
            var returnData = surveyData;

            returnData.Questions = _questionRepository.GetQuestionBySurveyId(surveyData.SurveyId);

            foreach (var q in returnData.Questions)
            {
                BindAnswerAndSongs(q);
                q.Customer = surveyData.Customer;
                q.CapturedResponses = BindResponses(surveyData.SurveyId, q, sessionId);
                q.MediaSkipLogic = q.MediaSkipLogic = BuildMediaSkipLogic(q);
            }
            return returnData;
        }

        private static void BindAnswerAndSongs(Question quest)
        {
            if (quest.HasMedia)
            {
                quest.Answers = _answerRepository.GetMediaAnswers();
                var playList = _playList.GetPlayList(quest.PlayListId);
                quest.SongList = BindSongs(playList);
            }
            else
            {
                quest.Answers = _answerRepository.GetAnswers(quest.QuestionId);
            }
        }

        private static Survey BindSettingsData(Survey surveyData)
        {
            var returnData = surveyData;

            returnData.Settings = _settingRepository.GetSettingBySurveyId(surveyData.SurveyId);
            foreach (var setting in returnData.Settings)
            {
                setting.Customer = returnData.Customer;

            }

            return returnData;
        }

        private static Survey BindSettingConfig(Survey surveyData)
        {
            var returnData = surveyData;

            surveyData.Config = new SurveyConfig();

            foreach (var setting in returnData.Settings)
            {
                object surveyConfig = surveyData.Config;

                DescriptionHelper.SetPropertyValueByDescription(ref surveyConfig, setting.SettingName, setting.Value);
            }

            return returnData;
        }

        public List<Survey> GetMySurveys(string customerId)
        {
            return _surveyRepository.GetMySurveys(customerId);
        }

        public PublishedSurvey BuildSurvey(Survey surveyData)
        {
            _questionCount = 1;
            var publishedSurvey = new PublishedSurvey
                {
                    id = surveyData.SurveyId,
                    name = surveyData.SurveyName,
                    company = surveyData.Customer.CustomerName,
                    cardobj = new card { pageNumber = _localpageNumber++.ToString(CultureInfo.InvariantCulture) },
                    config = Mapper.Map<SurveyConfig, config>(surveyData.Config),
                    skipLogic = Mapper.Map<List<SkipLogic>, List<publishedSkipLogic>>(surveyData.SkipLogic),
                    surveyEndDate = surveyData.SurveyEndDate
                };
            var questions = surveyData.Questions;
            var cardData = publishedSurvey.cardobj;
            var count = 0;
            AddQuestionToCard(ref cardData, ref questions, ref count);
            publishedSurvey.cardobj = cardData;
            return publishedSurvey;
        }

        public bool SaveResponses(List<Responses> userResponse)
        {
            return _reponsesRepository.SaveResponse(userResponse);
        }

        public bool CompleteSurvey(string surveyId, string sessionId)
        {
            return _reponsesRepository.CompleteSurvey(surveyId, sessionId);
        }

        private static Responses BindResponses(string surveyId, Question question, string sessionId)
        {
            return new Responses
                {
                    SurveyId = surveyId,
                    Question = question,
                    Answer = _reponsesRepository.GetResponseAnswers(surveyId, question.QuestionId, sessionId)
                };

        }

        private static card AddQuestionToCard(ref card cardData, ref List<Question> questions, ref int count)
        {
            if (count > questions.Count - 1)
            {
                return cardData;
            }

            if (questions[count].QuestionType == Question.QuestionTypes.PageBreak)
            {
                count++;
                cardData.cardobj = new card { pageNumber = _localpageNumber++.ToString(CultureInfo.InvariantCulture) };
                var newcard = cardData.cardobj;
                var newcount = count;
                return AddQuestionToCard(ref newcard, ref questions, ref newcount);
            }

            if (cardData.questions == null) cardData.questions = new List<question>();

            if (questions[count].HasMedia)
            {
                _songCount = 0;

                Question followupQuestion;

                try
                {
                    followupQuestion = questions[count + 1];
                }
                catch (Exception)
                {
                    followupQuestion = null;
                }

                BuildMediaQuestions(cardData, questions[count], questions[count].SongList.Songs, followupQuestion);
                count += 2;

                var lastCard = GetLastCard(cardData);

                return AddQuestionToCard(ref lastCard, ref questions, ref count);
            }

            GetQuestionObject(cardData, questions[count]);

            var count1 = ++count;

            return AddQuestionToCard(ref cardData, ref questions, ref count1);
        }

        private static card BuildMediaQuestions(card mediaCard, Question entityQuestion, IList<FileLibrary> songs, Question followupQuestion)
        {

            if (_songCount > songs.Count - 1)
            {
                return mediaCard;
            }

            var songQuestion = new question
                                  {
                                      id = entityQuestion.QuestionId,
                                      text = entityQuestion.QuestionText,
                                      type = entityQuestion.QuestionType.ToString(),
                                      hasMedia = entityQuestion.HasMedia,
                                      no = (_questionCount).ToString(CultureInfo.InvariantCulture),
                                      capturedResponse = GetCapturedResponse(entityQuestion),
                                      songId = songs[_songCount].FileLibraryId,
                                      mediaFileName = songs[_songCount].SoundClip.SongFileName,
                                      mediaTrackTitle = songs[_songCount].SoundClip.Title,
                                      Answers = BindAnswers(entityQuestion),
                                      mediaSkipLogic = Mapper.Map<SkipLogic,publishedSkipLogic>(entityQuestion.MediaSkipLogic)
                                  };

            
            mediaCard.questions = new List<question>
                                        {
                                            songQuestion
                                        };
            _questionCount++;

            if (followupQuestion != null)
            {
                var followQuestion = new question
                                         {
                                             id = followupQuestion.QuestionId,
                                             text = followupQuestion.QuestionText,
                                             type = followupQuestion.QuestionType.ToString(),
                                             hasMedia = followupQuestion.HasMedia,
                                             no = (_questionCount).ToString(CultureInfo.InvariantCulture),
                                             capturedResponse = GetCapturedResponse(followupQuestion),
                                             songId = songs[_songCount].FileLibraryId,
                                             Answers = BindAnswers(followupQuestion)
                                         };
                mediaCard.questions.Add(followQuestion);
            }

            if (_songCount == songs.Count - 1)
            {
                return mediaCard;
            }


            _songCount++;

            mediaCard.cardobj = new card { pageNumber = _localpageNumber++.ToString(CultureInfo.InvariantCulture) };

            return BuildMediaQuestions(mediaCard.cardobj, entityQuestion, songs, followupQuestion);
        }

        private static void GetQuestionObject(card cardData, Question entityQuestion)
        {
            var questionObject = new question
                                       {
                                           id = entityQuestion.QuestionId,
                                           text = entityQuestion.QuestionText,
                                           type = entityQuestion.QuestionType.ToString(),
                                           hasMedia = entityQuestion.HasMedia,
                                           no = (_questionCount).ToString(CultureInfo.InvariantCulture),
                                           capturedResponse = GetCapturedResponse(entityQuestion)

                                       };
            _questionCount++;
            if (ResponseHelper.NeedToBindAnswer(entityQuestion.QuestionType))
            {
                questionObject.Answers = BindAnswers(entityQuestion);
                questionObject.defaultanswer = BindAnswer(entityQuestion.DefaultAnswer);
            }
            else
            {
                if (questionObject.capturedResponse == null) questionObject.capturedResponse = new response { questionId = entityQuestion.QuestionId };
            }
            cardData.questions.Add(questionObject);

        }

        private static response GetCapturedResponse(Question entityQuestion)
        {

            return new response
                {
                    questionId = entityQuestion.QuestionId,
                    selectedAnwers = BindResponseAnswer(entityQuestion)
                };
        }

        private static List<answer> BindResponseAnswer(Question entityQuestion)
        {
            if (entityQuestion.CapturedResponses.Answer == null) return null;
            return (from entityAnswer in entityQuestion.CapturedResponses.Answer
                    select BindAnswer(entityAnswer)).ToList();
        }

        private static List<answer> BindAnswers(Question entityQuestion)
        {
            if (entityQuestion.Answers == null) return null;
            return (from entityAnswer in entityQuestion.Answers
                    select BindAnswer(entityAnswer)).ToList();

        }

        private static List<answer> BindResponseAnswerFromAnswerList(IEnumerable<Answer> entityAnswers)
        {
            return entityAnswers.Select(answer => BindAnswer(answer)).ToList();
        }

        private static answer BindAnswer(Answer entityAnswer)
        {
            return new answer
                       {
                           id = entityAnswer.AnswerId,
                           key = entityAnswer.AnswerDesc,
                           value = entityAnswer.AnswerText
                       };
        }

        public card AttachResponseToCard(card currenTcard, List<Responses> currentResponses)
        {
            foreach (var question in currenTcard.questions)
            {
                var currResponse = currentResponses.Single(m => m.Question.QuestionId == question.id);
                question.capturedResponse.selectedAnwers = BindResponseAnswerFromAnswerList(currResponse.Answer);
            }
            return currenTcard;
        }

        public Survey RemoveFirstPageBreakQuestion(Survey survey)
        {
            if (survey.Questions[0].QuestionType == Question.QuestionTypes.PageBreak)
                survey.Questions.RemoveAt(0);
            return survey;
        }

        private static Survey ImplementSkipLogic(Survey surveyData)
        {
            var returnData = surveyData;

            if (returnData.SkipLogic == null) return returnData;

            SetSkipLogicValues(returnData);

            AddRequiredPageBreaks(returnData);

            return returnData;
        }

        private static void SetSkipLogicValues(Survey returnData)
        {
            if (returnData.SkipLogic.Count <= 0 || !returnData.Config.VerifySkipLogic) return;
            foreach (var logic in returnData.SkipLogic)
            {
                ParseLogicExpression(logic);
            }
        }

        private static void ParseLogicExpression(SkipLogic skipLogic)
        {
            //Question(1234).Answer == 3654
            if(skipLogic == null) return;

            var splitToken = GetSplitToken(skipLogic.LogicExpression, skipLogic.ComparisionTokens);

            if (splitToken == null) return;

            skipLogic.EvalOperator = splitToken;

            var splitArr = skipLogic.LogicExpression.Split(splitToken.ToCharArray());

            if (splitArr[splitArr.GetUpperBound(0)].Trim().Contains("Answer"))
                skipLogic.ExpectedAnswerId = GetSkipLogicExpectedAnswer(splitArr);
            else
                skipLogic.ExpectedAnswerText = GetSkipLogicExpectedAnswer(splitArr);

            var questionId = GetSkipLogicQuestionId(splitArr);

            skipLogic.CheckQuestionId = questionId.Trim();
        }

        private static string GetSkipLogicQuestionId(IList<string> splitArr)
        {
            var leftPart = splitArr[0].Trim();
            var questionId = leftPart.Replace("Question(", "");
            questionId = questionId.Replace(").Answer", "");
            return questionId;
        }

        private static string GetSkipLogicExpectedAnswer(IList<string> splitArr)
        {
            var answerToken = splitArr[splitArr.Count - 1].Trim();

            return answerToken.Contains("Answer") ? answerToken.Replace("Answer(", "").Replace(")", "").Trim() : answerToken.Trim();

        }

        private static string GetSplitToken(string expression, IEnumerable<string> tokens)
        {
            return tokens.Where(expression.Contains).FirstOrDefault();
        }

        private static void AddRequiredPageBreaks(Survey surveyData)
        {
            if (surveyData.SkipLogic == null || !surveyData.Config.VerifySkipLogic) return;

            var originalList = surveyData.Questions;

            BuildNewList(surveyData.SkipLogic, originalList);


        }

        private static void BuildNewList(IEnumerable<SkipLogic> skipLogic, IList<Question> originalList)
        {
            foreach (var logic in skipLogic)
            {
                for (var i = 0; i < originalList.Count; i++)
                {
                    if (logic.TrueAction != originalList[i].QuestionId) continue;
                    if (GetInsertFirst(originalList, i))
                        originalList.Insert(i, GetPageBreakQuestionModel());
                    break;
                }
            }
        }


        private static bool GetInsertFirst(IList<Question> originalList, int count)
        {
            if (count > 0)
            {
                if (originalList[count - 1].QuestionType != Question.QuestionTypes.PageBreak) return true;
            }
            return false;
        }

        private static Question GetPageBreakQuestionModel()
        {
            return new Question
                {
                    QuestionId = "XXX",
                    QuestionType = Question.QuestionTypes.PageBreak
                };
        }

        public Survey GetSurveyForExpiryCheck(string surveyId)
        {
            var surveyData = _surveyRepository.GetSurvey("", surveyId);
            var datawithSettings = BindSettingsData(surveyData);
            var datawithConfig = BindSettingConfig(datawithSettings);
            return datawithConfig;
        }

        public bool HasSurveyExpired(string surveyEndDate)
        {
            if (surveyEndDate == null) return false;

            var comparison = DateTime.Compare(Convert.ToDateTime(surveyEndDate), DateTime.Now);

            return comparison < 0;
        }

        public Survey GetSurveyConfig(string surveyId)
        {
            var returnData = new Survey
                {
                    SurveyId = surveyId
                };

            var datawithSettings = BindSettingsData(returnData);
            var datawithconfig = BindSettingConfig(datawithSettings);
            return datawithconfig;
        }


        public card IsFirstCard(card checkCard)
        {
            if (checkCard == null) return null;
            foreach (var question in checkCard.questions)
            {
                if (ResponseHelper.ResponseExpected(question.type) == false) return IsFirstCard(checkCard.cardobj);

                if (question.capturedResponse == null)
                    return checkCard;
                if (question.capturedResponse.selectedAnwers == null)
                    return checkCard;

                SessionHelper.CardStack.Push(checkCard);
                return IsFirstCard(checkCard.cardobj);
            }
            return checkCard;
        }

        public static card GetLastCard(card checkCard)
        {
            return checkCard.cardobj == null ? checkCard : GetLastCard(checkCard.cardobj);
        }
    }
}
