﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
   public class ClsSurvey
    {
       public List<Survey> GetSurvey()
       {
           var objPersistanceSurvey = new PersistanceSurvey();
           return objPersistanceSurvey.GetSurvey("1");
       }
    }
}
