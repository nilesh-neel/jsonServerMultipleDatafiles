﻿using System;
using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;
using System.Linq;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
    public class CustomerModule
    {
        private static ICustomer _customer;
        private static IUser _user;
        public User LoggedInUser { get; set; }

        public string Message { get; set; }

        public CustomerModule(ICustomer customer, IUser user)
        {
            _customer = customer;
            _user = user;
        }

        public List<Customer> GetCustomerList(string abbreVation, string customerName)
        {
            try
            {
                return GetCompanyList(_customer.SearchCustomer(customerName, abbreVation));
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Customer> GetCompanyMaster()
        {
            try
            {
                return GetCompanyList(_customer.GetCustomerMaster());
            }
            catch (Exception)
            {
                throw;
            }
        }

        private List<Customer> GetCompanyList(List<Customer> companyData)
        {
            if (LoggedInUser.UserDetails.UserRole.Hierarchy != "1")
            {
                var customerId = LoggedInUser.UserDetails.Customer.CustomerId;
                var returnList = (from comp in companyData
                                  where Convert.ToInt32(comp.CustomerId) == Convert.ToInt32(customerId)
                                  select comp).ToList();
                return returnList;
            }
            return companyData;
        }


        public Customer GetCustomer(string custId)
        {
            try
            {                   
                return _customer.GetCustomer(custId);
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool SaveCustomer(Customer cust)
        {
            try
            {
                Message = "";
                if (!_customer.SaveCustomer(cust) && !string.IsNullOrEmpty(CustomerRepository.Message))
                {
                    Message = CustomerRepository.Message;
                    return false;
                }
                return true;                
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool DeleteCustomer(string customerName, string abbreVation, string customerId)
        {
            try
            {
                Message = "";
                var isDeleted = false;
                if (DeleteUsers(customerId))
                {
                    isDeleted = _customer.DeleteCustomer(customerName, abbreVation);
                }
                else
                {
                    isDeleted = false;
                    Message = "Some user's are linked with this company, You cannot delete this company.";
                }
                return isDeleted;

            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool IsValid(CustomerViewModel cust)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";
            if (!cust.name.Trim().IsAlphaNumericWithSpace())
                Message += "Invalid Company Name <br />";

            //if (!cust.abbreviation.IsAlpha())
            //    Message += "Invalid Abbreviation <br />";

            //if (!cust.address.IsAlpha())
            //    Message += "Invalid Address <br />";

            if (string.IsNullOrEmpty(cust.addressLine1) || !cust.addressLine1.IsAlphaNumericWithSpacePeriodAndHyphen())
            {
                Message += "Invalid Address Line 1 <br />";
            }
            if (string.IsNullOrEmpty(cust.addressLine2) || !cust.addressLine2.IsAlphaNumericWithSpacePeriodAndHyphen())
            {
                Message += "Invalid Address Line 2 <br />";
            }

            if (string.IsNullOrEmpty(cust.city.Trim()) && !cust.city.Trim().IsAlpha())
                Message += "Invalid City <br />";

            if (string.IsNullOrEmpty(cust.contactPerson.Trim()) && !cust.contactPerson.Trim().IsAlpha())
                Message += "Invalid Contact Person <br />";

            if (string.IsNullOrEmpty(cust.country.Trim()) && !cust.country.Trim().IsAlpha())
                Message += "Invalid Country <br />";

            if (string.IsNullOrEmpty(cust.email.Trim()) && !cust.email.Trim().IsEmail())
                Message += "Invalid Email <br />";

            if (!cust.phone1.Trim().IsPhoneNumber())
                Message += "Invalid Phone Number 1 <br />";

            if (String.CompareOrdinal(cust.phone1.Trim(), cust.phone2.Trim()) == 0)
            {
                Message += "Phone number 1 and phone number 2 should not be same <br />";
            }
            else if (!string.IsNullOrEmpty(cust.phone2.Trim()) && !cust.phone2.Trim().IsPhoneNumber())
            {
                Message += "Invalid Phone Number 2 <br />";
            }

            if (string.IsNullOrEmpty(cust.state.Trim()) && !cust.state.Trim().IsAlpha())
                Message += "Invalid State <br />";

            //if (string.IsNullOrEmpty(cust.status) && !cust.status.IsAlpha())
            //    Message += "Invalid Status <br />";

            if (!string.IsNullOrEmpty(cust.website.Trim()) && !cust.website.Trim().IsUrl())
                Message += "Invalid Website <br />";

            //if (string.IsNullOrEmpty(cust.zipCode.Trim()) && !cust.zipCode.Trim().IsZipCode())
            //    Message += "Invalid zip code <br />";

            if (Message == "Please correct following: <br />")
                return true;
            return false;
        }

        private static bool DeleteUsers(string customerId)
        {
            var userList = _user.GetUsersByCustomerId(customerId);

            foreach (var user in userList)
            {
               // _user.DeleteUser(user.LoginId);
                return false;
            }
            return true;
        }

    }
}
