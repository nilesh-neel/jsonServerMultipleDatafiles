﻿using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
   public class RewardModule
   {
       private readonly IReward _rewardRepository;

       public RewardModule(IReward reward)
       {
           _rewardRepository = reward;
       }

       public Reward GetRewardFromBl()
       {
           return _rewardRepository.GetReward("1");
       }
    }
}
