﻿using System;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;
using SHA256;
using log4net;

namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
    public class LoginModule
    {
        private static UserModule _userModule;
        public User LoggedInUser { get; set; }
        public static string SessionSaltString;

        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public LoginModule(IUser user, ICustomer cust)
        {
            _userModule = new UserModule(user, cust);
        }
        public string Message { get; set; }

        public bool ValidateUser(User uIUserData)
        {
            try
            {
                if (string.IsNullOrEmpty(uIUserData.Password.Trim())) return false;
                var userData = _userModule.GetUserDetailsByLoginId(uIUserData.LoginId);
                if (userData != null)
                {
                    Log.Info("User Data found");
                    Log.Info("User Password=" + uIUserData.Password);
                    if (IsValidPassword(userData.Password, uIUserData.Password))
                    {
                        LoggedInUser = userData;
                        Log.Info("Validate password is fine.");
                        return true;
                    }
                    Log.Info("Validate password fails.");
                    Message = "Invalid User Name or Password";
                    return false;
                }
                Log.Info("User Data not found");
                Message = "Invalid UserName and Password";
                return false;

            }
            catch (Exception)
            {
                throw;
            }

        }

        private static bool IsValidPassword(string dbPassword, string hdnPass)
        {
            try
            {
                var strEncyPwd = (SessionSaltString + dbPassword);
                var objSha = new HASHClass();
                Log.Info("dbpassword=" + dbPassword);
                Log.Info("Saltstring=" + SessionSaltString);
                Log.Info("hidden pass=" + hdnPass);
                Log.Info("encyppsw=" + objSha.SHA256(ref strEncyPwd));
                return objSha.SHA256(ref strEncyPwd) == hdnPass;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool IsValid(UserViewModel user)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";

            if (!user.loginId.IsAlphaNumeric())
                Message += "Invalid LoginId <br />";

            return Message == "Please correct following: ";
        }

        
    }
}
