﻿using System;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using System.Collections.Generic;
using ORT_VIEW_MAP.MapClasses;
using System.Linq;
using ORT_HELPERS.Helpers;
using ORT_PERSISTENCE.UploadObjects.Interface;
using ORT_BUSSINESS_LAYER.ModuleUpload;
using ORT_PERSISTENCE.UploadObjects.Class;
using ORT_VIEW_MAP.MapClasses.Panel;
using ORT_CORE.Class.LibraryClasses;
using ORT_VIEW_MAP.MapClasses.Library;


namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
    public class PanelModule
    {
        private static IPanelist _panelRepository;
        private static ICustomer _customerRepository;
        private static IRespondent _respondentRepository;
        private static UploadModule _uploadModule;
        private static IUser _user;
        public User LoggedInUser { get; set; }
        public string Message { get; set; }

        public PanelModule(IPanelist panel, ICustomer cust, IRespondent respondent, IUser user, IUpload objUpload, IGraphicsUpload objGrapUpload)
        {
            _panelRepository = panel;
            _customerRepository = cust;
            _respondentRepository = respondent;
            _uploadModule = new UploadModule(objUpload, objGrapUpload);
        }
        public bool SaveLibrary(Library objLib)
        {
            return _panelRepository.SaveLibrary(objLib);
        }

        public bool SavePanel(Panel panel)
        {
            panel.LibType = Library.LibraryType.Panel;
            panel.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
            return _panelRepository.SavePanelist(panel);
        }

        public bool SavePanelCategory(PanelCategory panelCate)
        {
            return _panelRepository.SavePanelCategory(panelCate);
        }


        public bool SaveMembers(Respondent respondent)
        {
            var curDate=System.DateTime.Now.ToString("yyyy-MM-dd");            
            respondent.BirthDate = DateTime.Parse(respondent.BirthDate).ToString("yyyy-MM-dd");       
            return _respondentRepository.SaveRespondentlist(respondent);
        }

        public bool DeletePanel(string panelId)
        {
            return _panelRepository.DeletePanel(panelId);
        }

        public bool DeleteMember(string memberId)
        {
            return _respondentRepository.DeleteMember(memberId);
        }

        public List<Library> GetPanleListCombo()
        {
            return _panelRepository.GetLibraryList(SessionHelper.LoggedinCustomer);
        }
        public List<PanelCategory> GetPanleCategory(string panleId)
        {
            return _panelRepository.GetPaneCategory(panleId);
        }

        public Panel GetPanelByPanelId(string panelId)
        {
            var panelData = _panelRepository.GetPanelist(panelId);
            return BindDependentData(panelData);
        }

        public Respondent GetMemberById(string respondId)
        {
            return _respondentRepository.GetMemberList(respondId);
        }



        public List<Panel> GetPanelList(string panelId, string panelName, string category)
        {
            var panelData = _panelRepository.GetPanelist(panelId, panelName, category);
            return panelData != null ? panelData.Select(sd => BindDependentData(sd)).ToList() : null;
        }

        public List<Respondent> GetMemberList(string panelId, string emailId)
        {
            return _respondentRepository.GetMembersList(panelId, emailId);
        }

        public IDictionary<string, string> ImportData(string panleId, string fileName, string folderPath, string extension)
        {
            return _uploadModule.ImportData(panleId, fileName, folderPath, extension);
        }

        public RespondentException GetExceptionDetails()
        {
            return _uploadModule.GetExceptionDetails();
        }

        public List<int> GetExceptionCount(string sessionId)
        {
            //var excepCount = null;//_respondentRepository.GetException(sessionId);
            //var importCount=_respondentRepository.GetBulkRespondentSave(sessionId);
            //var totalExcep = excepCount + importCount[0];

            var finalCount = new List<int>();
            //finalCount.Add(totalExcep);
            //finalCount.Add(importCount[1]);
            return finalCount;
        }

        private static Panel BindDependentData(Panel PanelData)
        {
            var returnData = PanelData;
            returnData.Customer = _customerRepository.GetCustomer(PanelData.Customer.CustomerId);
            returnData.Members = BindMembersDetails(returnData.PanelId);
            return returnData;
        }

        private static List<Respondent> BindMembersDetails(string panelId)
        {
            var respoData = _respondentRepository.GetMembersList(panelId, "");
            if (respoData != null)
            {
                respoData.Select(sd => RespondentAge(sd)).ToList();
            }
            return respoData;
        }

        private static Respondent RespondentAge(Respondent respo)
        {
            if (respo.BirthDate.IsDateTime())
            {
                var birdate = Convert.ToDateTime(respo.BirthDate);
                DateTime now = DateTime.Today;
                int age = now.Year - birdate.Year;
                if (now.Month < birdate.Month || (now.Month == birdate.Month && now.Day < birdate.Day)) age--;
                respo.Age = Convert.ToString(age);
                return respo;
            }
            return respo;
        }

        public Respondent IsTempRespondentValid(Respondent objRespond, string flag)
        {         //O=OK,E=Error
            bool result = true;
            if (!objRespond.FirstName.Trim().IsAlpha())
            {
                objRespond.StatusMessage = "Invalid First Name. ";
                result = false;
            }
            if (!objRespond.LastName.Trim().IsAlpha())
            {
                objRespond.StatusMessage += "Invalid Last Name. ";
                result = false;
            }
            if (!objRespond.RespondentEmailId.Trim().IsEmail())
            {
                objRespond.StatusMessage += "Invalid EmailId. ";
                result = false;
            }
            if (!objRespond.BirthDate.Trim().IsDateTime())
            {
                objRespond.StatusMessage += "Invalid EmailId. ";
                result = false;
            }
            if (!objRespond.Town.Trim().IsAlpha())
            {
                objRespond.StatusMessage += "Invalid Town. ";
                result = false;
            }
            if (result)
            {
                objRespond.Status = "O";
                objRespond.StatusMessage = "Success";
            }
            else
            {
                objRespond.Status = "E";
            }
            return objRespond;
        }

        private static Respondent BindTempRespondDependentData(Respondent respoData)
        {
            System.Globalization.CultureInfo dateFormat = new System.Globalization.CultureInfo("en-GB", true);
            var returnData = respoData;
            returnData.Panel.PanelId = respoData.Panel.PanelId;
            returnData.Panel.IsPanelActive = true;
            returnData.Customer.CustomerId = respoData.Customer.CustomerId;
            returnData.Customer.IsActive = true;
            returnData.CreatedBy.UserId = SessionHelper.LoggedinUserId;
            returnData.IsRespondentActive = true;
            returnData.IsRespondentDeleted = true;
            Convert.ToDateTime(returnData.BirthDate, dateFormat);
            return RespondentAge(returnData);
        }

        public bool IsValid(PanelViewModel panel)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";

            //if (!panel.PanelId.IsAlphaNumeric())
            //    Message += "Invalid LoginId <br />";

            ////if (!user.password.IsAlphaNumeric())
            ////    Message += "Invalid Password <br />";

            //if (Message == "Please correct following: ")
            return true;
            //return false;
        }

        public bool IsCategoryValid(PanelCategoryViewModel panel)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";

            //if (!panel.PanelId.IsAlphaNumeric())
            //    Message += "Invalid LoginId <br />";

            ////if (!user.password.IsAlphaNumeric())
            ////    Message += "Invalid Password <br />";

            //if (Message == "Please correct following: ")
            return true;
            //return false;
        }

        public bool IsPanelLibraryValid(LibraryViewModel panel)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";

            //if (!panel.PanelId.IsAlphaNumeric())
            //    Message += "Invalid LoginId <br />";

            ////if (!user.password.IsAlphaNumeric())
            ////    Message += "Invalid Password <br />";

            //if (Message == "Please correct following: ")
            return true;
            //return false;
        }

        public bool IsRespondentValid(PanelRespondent objRespond)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";
                       
            if (!objRespond.firstName.Trim().IsAlpha())
            {
                Message += "Invalid First Name. <br />";                
            }
            if (!objRespond.lastName.Trim().IsAlpha())
            {
                Message += "Invalid Last Name. <br />";               
            }
            if (!objRespond.emailId.Trim().IsEmail())
            {
                Message += "Invalid EmailId. <br />";               
            }
            if (!objRespond.birthDate.Trim().IsDateTime())
            {
                Message += "Invalid BirthDate. <br />";              
            }
            if (!objRespond.town.Trim().IsAlpha())
            {
                Message += "Invalid Town. <br />";                
            }
            return (Message == "Please correct following: <br />") ? true : false;
        }

    }
}
