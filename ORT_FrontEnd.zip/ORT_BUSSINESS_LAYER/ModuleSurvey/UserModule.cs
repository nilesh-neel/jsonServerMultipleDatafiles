﻿using System;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using System.Collections.Generic;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;
using System.Linq;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_BUSSINESS_LAYER.ModuleSurvey
{
    public class UserModule
    {
        private static IUser _userRepository;
        private static ICustomer _customerRepository;
        public User LoggedInUser { get; set; }

        public UserModule(IUser user, ICustomer cust)
        {
            _userRepository = user;
            _customerRepository = cust;
        }
        public string Message { get; set; }

        public User GetUserDetailsByUserId(string userId)
        {
            try
            {
                var userData = _userRepository.GetUserByUserId(userId);
                return userData == null ? null : BindDependentData(userData);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public User GetUserDetailsByLoginId(string loginId)
        {
            try
            {
                var userData = _userRepository.GetUserByLoginId(loginId);
                return userData == null ? null : BindDependentData(userData);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool SaveUser(User user)
        {
            try
            {
                Message = "";
                if (IsActiveCustomer(user.UserDetails.Customer.CustomerId))
                {
                    if (!_userRepository.SaveUser(user) && !string.IsNullOrEmpty(UserRepository.Message))
                    {
                        Message = UserRepository.Message;
                        return false;
                    }
                    return true;
                }
                return false;

            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool DeleteUser(string loginId)
        {
            try
            {
                return _userRepository.DeleteUser(loginId);
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool VerifyUserCode(string userCode, string userId)
        {
            try
            {
                if (!_userRepository.CheckUserCode(userCode, userId))
                {
                    Message = "User Code is already taken";
                    return false;
                }
                return true;

            }
            catch (Exception)
            {
                throw;
            }

        }


        public List<User> GetUserDetailsList(string code, string loginId, string name, string custName, string email)
        {
            try
            {
                var userData = GetUserByRights(_userRepository.GetUserList(code, loginId, name, custName, email));
                if (userData != null)
                {
                    var userList = (from user in userData
                                    where user.UserId != "1" && user.UserId != SessionHelper.LoggedinUserId
                                    select user).ToList();
                    return userList.Select(sd => BindDependentData(sd)).ToList();
                }
                return null;
            }
            catch (Exception)
            {
                throw;
            }

        }
        private IEnumerable<User> GetUserByRights(IEnumerable<User> user)
        {
            if (LoggedInUser.UserDetails.UserRole.Hierarchy != "1")
            {
                var customerId = LoggedInUser.UserId;
                var returnList = (from comp in user
                                  where comp.CreatedBy.UserId == customerId && comp.UserId != "1"
                                  select comp).ToList();
                return returnList;
            }
            return user;
        }


        private static User BindDependentData(User userData)
        {
            try
            {
                var returnData = userData;
                returnData.UserDetails.Customer = _customerRepository.GetCustomer(userData.UserDetails.Customer.CustomerId);                // var finaldata = from n in returnData where n.se
                return returnData;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private bool IsActiveCustomer(string custId)
        {
            Message = "";
            var isActive = true;
            var cusrData = _customerRepository.GetCustomer(custId);
            if (cusrData == null || cusrData.IsActive != true)
            {
                Message = "The company you have select has been deleted.Contact your system admin for further clarifications";
                return isActive = false;
            }
            return isActive;

        }

        public bool IsValid(UserViewModel user)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";
            if (!user.name.Trim().IsAlpha())
            {
                Message += "Invalid User Name <br />";
            }
            if (!user.code.Trim().IsAlphaNumeric())
                Message += "Invalid User Code <br />";

            if (!user.loginId.Trim().IsLoginId())
                Message += "LoginId should be alphanumeric <br />";

            //if (!VerifyUserCode(user.code))
            //    Message += "User Code is already taken <br />";
            if (!string.IsNullOrEmpty(user.department.Trim()) && !user.department.Trim().IsAlphaNumericWithSpace())
            {
                Message += "Invalid Department <br />";
            }

            if (!user.phone1.Trim().IsPhoneNumber())
                Message += "Invalid Phone Number 1 <br />";

            if (string.Compare(user.phone1.Trim(), user.phone2.Trim()) == 0)
            {
                Message += "Phone number 1 and phone number 2 should not be same <br />";
            }
            else if (!string.IsNullOrEmpty(user.phone2.Trim()) && !user.phone2.Trim().IsPhoneNumber())
            {
                Message += "Invalid Phone Number 2 <br />";
            }
            //if (string.IsNullOrEmpty(user.phone3) != true && !user.phone3.IsPhoneNumber())
            //    Message += "Invalid Phone Number 3 <br />";

            return Message == "Please correct following: <br />";
        }

        public bool IsLoginValid(UserViewModel user)
        {
            Message = string.Empty;
            Message = "Please correct following: <br />";

            if (!user.loginId.Trim().IsAlphaNumeric())
                Message += "Invalid LoginId <br />";

            //if (!user.password.IsAlphaNumeric())
            //    Message += "Invalid Password <br />";

            if (Message == "Please correct following: ")
                return true;
            return false;
        }


    }
}
