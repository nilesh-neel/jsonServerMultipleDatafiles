﻿using System;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using System.Collections.Generic;
using ORT_VIEW_MAP.MapClasses;
using System.Linq;
using ORT_HELPERS.Helpers;
using ORT_PERSISTENCE.UploadObjects.Interface;
using ORT_PERSISTENCE;
using ORT_PERSISTENCE.UploadObjects.Class;
using System.Collections;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.UploadObjects.Implmentation;
using ORT_PERSISTENCE.SurveyPersistence;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_BUSSINESS_LAYER.ModuleUpload
{
   public class UploadModule
    {
       private static IUpload _membersUpload;
       private static IGraphicsUpload _graphicUpload;      
       private static Upload _objUpload = new Upload();
       public UploadModule(IUpload upload,IGraphicsUpload objGraphic)
       {
           _membersUpload = upload;
           _graphicUpload = objGraphic;    
       }    
       public IDictionary<string, string> ImportData(string panleId, string fileName, string folderPath, string extension)
       {
           try
           {
               var countResult = new Dictionary<string, string> { };
               var fileDetails = GetUploadFileDetails(fileName, folderPath, extension);
               fileDetails.ParentId = panleId;
               var objTemRespo = _membersUpload.GetTemporaryEntity(fileDetails);
               if (objTemRespo != null)
               {
                   var tempRespondData = _membersUpload.ValidateData(((IEnumerable)objTemRespo).Cast<object>().ToList());
                   countResult.Add("TotalCount", tempRespondData[0]);
                   countResult.Add("ErrorsCount", tempRespondData[1]);
                   countResult.Add("ImportedCount", tempRespondData[2]);
                   var sessionId = ((List<Respondent>)objTemRespo).Select(x => x.SessionId.SessionId).FirstOrDefault();
                   SessionHelper.UploadSessionId = sessionId;
                   _membersUpload.MoveExceptionData(sessionId);
                   _membersUpload.MoveValidData(sessionId);                  
               }
               return countResult;
           }
           catch (Exception)
           {
               throw;
           }
       }

       public RespondentException GetExceptionDetails()
       {
           try
           {
             return (RespondentException)_membersUpload.GetException(SessionHelper.UploadSessionId);
           }
           catch(Exception)
           {
               throw;
           }           
 
       }

       private Upload GetUploadFileDetails(string fileName, string folderPath, string extension)
       {
           _objUpload.CustomerId = SessionHelper.LoggedinCustomer;
           _objUpload.FileName = fileName;
           _objUpload.FolderPath = folderPath;
           _objUpload.FileType = "";
           _objUpload.Extension =extension;
           _objUpload.TempTableName = "TempRespondent";
           _objUpload.XmlMapFile = AppDomain.CurrentDomain.RelativeSearchPath + "\\XMLMappings\\MapMembers.xml";
           return _objUpload;
       }

       public GraphicLibrary SaveGraphicsFile(string graphicsLib, string category, string fileName, string folderPath, string extension)
       {
           try
           {
               var _graphicUpload = new GraphicsUpload();             
               var fileDetails = GetUploadFileDetails(fileName, folderPath, extension);
               fileDetails.ParentId = graphicsLib;
               fileDetails.Category = category;
               return _graphicUpload.SaveGraphicFiles(fileDetails);               
           }
           catch (Exception)
           {
               throw;
           }

       }

       public Upload GetGraphicsFile(string graphicsLib, string category)
       {
           try
           {
               return  _graphicUpload.GetGraphicFiles(graphicsLib,  category);
           }
           catch (Exception)
           {
               throw;
           }
       }


      

    }
}

