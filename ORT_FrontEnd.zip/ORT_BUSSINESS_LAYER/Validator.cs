﻿using System;
using System.Text.RegularExpressions;

namespace ORT_BUSSINESS_LAYER
{
    public static class Validator
    {
        public static bool IsAlphaNumeric(this string strToCheck)
        {
            if (string.IsNullOrEmpty(strToCheck))
                return false;

            var objAlphaNumericPattern = new Regex("[^a-zA-Z0-9]");

            return !objAlphaNumericPattern.IsMatch(strToCheck);
        }

        public static bool IsLoginId(this string strToCheck)
        {
            if (string.IsNullOrEmpty(strToCheck))
                return false;
            var objAlphaPattern = new Regex(@"^[a-zA-Z][a-zA-Z0-9 ]+$");
            return objAlphaPattern.IsMatch(strToCheck);
        }

        public static bool IsAlpha(this string strToCheck)
        {
            if (string.IsNullOrEmpty(strToCheck))
                return false;

            var objAlphaPattern = new Regex("[^a-zA-Z\\s]");

            return !objAlphaPattern.IsMatch(strToCheck);
        }

        public static bool IsNumber(this string strNumber)
        {
            try
            {
                Convert.ToDouble(strNumber);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsInteger(this string strInteger)
        {
            try
            {
                if (string.IsNullOrEmpty(strInteger))
                    return false;

                Convert.ToInt32(strInteger);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsDateTime(this string strDateTime)
        {
            try
            {
                Convert.ToDateTime(strDateTime);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsEmail(this string inputEmail)
        {
            if (string.IsNullOrEmpty(inputEmail))
                return (false);

            const string strRegex = @"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$";
            var re = new Regex(strRegex);
            return re.IsMatch(inputEmail);
        }

        public static bool IsSocialSecurityNumber(this string inputSsn)
        {
            if (string.IsNullOrEmpty(inputSsn)) return false;

            const string strRegEx = @"^\d{3}-\d{2}-\d{4}$";
            var re = new Regex(strRegEx);
            return re.IsMatch(inputSsn);
        }

        public static bool IsUSPhoneNumber(this string inputPhone)
        {
            if (string.IsNullOrEmpty(inputPhone)) return false;
             const string strRegEx = @"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}";
            var re = new Regex(strRegEx);
            return re.IsMatch(inputPhone);
        }

        public static bool IsPhoneNumber(this string inputPhone)
        {
            if (string.IsNullOrEmpty(inputPhone)) return false;

            const string strRegEx = @"^(?:\p{L}\p{M}*|[\- - . $]|[0-9])*$";
            var re = new Regex(strRegEx);
            return re.IsMatch(inputPhone);
        }

        public static bool IsZipCode(this string inputZipCode)
        {
            if (string.IsNullOrEmpty(inputZipCode)) return false;

            const string strRegEx = @"^(\d{5}-\d{4}|\d{5}|\d{9})$|^([a-zA-Z]\d[a-zA-Z] \d[a-zA-Z]\d)$";
            var re = new Regex(strRegEx);
            return re.IsMatch(inputZipCode);
        }

        //It must be between 8 and 10 characters, contain at least one digit and one alphabetic character, and must not contain special characters
        public static bool IsPassword(this string inputPassword)
        {
            if (string.IsNullOrEmpty(inputPassword)) return false;

            const string strRegEx = @"(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,10})$";
            var re = new Regex(strRegEx);
            return re.IsMatch(inputPassword);
        }

        public static bool IsUrl(this string urlToVerify)
        {
            return !string.IsNullOrEmpty(urlToVerify) && Uri.IsWellFormedUriString(urlToVerify, UriKind.RelativeOrAbsolute);
        }
    }
}
