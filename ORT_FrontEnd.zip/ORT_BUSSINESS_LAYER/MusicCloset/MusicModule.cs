﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ORT_CORE.Interface.LibaryInterface;
using ORT_BUSSINESS_LAYER.ModuleLibrary;
using ORT_PERSISTENCE.UploadObjects.Interface;
using ORT_PERSISTENCE.UploadObjects.Implmentation;
using ORT_BUSSINESS_LAYER.ModuleUpload;
using System.Collections;
using ORT_HELPERS.Helpers;
using ORT_PERSISTENCE.UploadObjects.Class;

namespace ORT_BUSSINESS_LAYER.MusicCloset
{
   public class MusicModule
    {
       private static ILibrary _library;
       private static ISoundClip _soundClip;
       private static LibraryModule _libraryModuleMain;  
       private static IUpload _uploadModule;
       private static Upload _objUpload = new Upload();
       public MusicModule(ISoundClip sound)
       {
            _soundClip = sound;
            //_uploadModule = objUpload;               
       }
       public MusicModule(IUpload objUpload)
       {           
           _uploadModule = objUpload;               
       }
       
       public object GetLibrary(string custId,string type)
       {
           try
           {
               return _library.GetLibraryList(custId, type);
           }
           catch (Exception)
           {
               throw;
           }
       }

       public object SearchSoundClip(int libId)
       {
           try
           {
               return _soundClip.GetSoundClip(Convert.ToString(libId));
           }
           catch (Exception)
           {
               throw;
           }
       }

       public bool UploadSoundClip(string grapLibId, string category, string fileName, string folderPath, string extension)
       {
           try
           {
               //var countResult = new Dictionary<string, string> { };
             var countResult = UploadSoundClipInfo(grapLibId, fileName, folderPath, extension);
               return true;
           }
           catch (Exception)
           {
               throw;
           }
       }
      
       public static IDictionary<string, string> UploadSoundClipInfo(string fileLibId, string fileName, string folderPath, string extension)
       {
           try
           {
               var countResult = new Dictionary<string, string> { };
               var fileDetails = GetUploadFileDetails(fileName, folderPath, extension);
               fileDetails.ParentId = fileLibId;
               var objTemRespo = _uploadModule.GetTemporaryEntity(fileDetails);
               if (objTemRespo != null)
               {
                   var tempRespondData = _uploadModule.ValidateData(((IEnumerable)objTemRespo).Cast<object>().ToList());
                   countResult.Add("TotalCount", tempRespondData[0]);
                   countResult.Add("ErrorsCount", tempRespondData[1]);
                   countResult.Add("ImportedCount", tempRespondData[2]);
                   var sessionId = "";// ((List<SoundClipUpload>)objTemRespo).Select(x => x.SessionId.SessionId).FirstOrDefault();
                   SessionHelper.UploadSessionId = sessionId;
                   _uploadModule.MoveExceptionData(sessionId);
                   _uploadModule.MoveValidData(sessionId);
               }
               return countResult;
           }
           catch (Exception)
           {
               throw;
           }
       }

       private static Upload GetUploadFileDetails(string fileName, string folderPath, string extension)
       {
           _objUpload.CustomerId = SessionHelper.LoggedinCustomer;
           _objUpload.FileName = fileName;
           _objUpload.FolderPath = folderPath;
           _objUpload.FileType = "SoundClip";
           _objUpload.Extension = extension;
           _objUpload.TempTableName = "TempSoundClipInfo";
           _objUpload.XmlMapFile = AppDomain.CurrentDomain.RelativeSearchPath + "\\XMLMappings\\MapSoundClip.xml";
           _objUpload.UploadedBy = SessionHelper.LoggedinUserId;
           return _objUpload;
       }


       public object EditLibrary(int libId, int category)
       {
           try
           {
               var libraryData = _library.SearchLibraryDetails(Convert.ToString(libId), Convert.ToString(category));
               return libraryData == null ? null : libraryData;
           }
           catch (Exception)
           {
               throw;
           }
       }

       public object SaveLibraryDetails(object objLibrary)
       {
           try
           {
               //var libraryData = BindSaveLibraryDetails(objLibrary);
               //return _library.SaveLibraryDetails(libraryData);
               return null;
           }
           catch (Exception)
           {
               throw;
           }
       }

       public bool SaveLibrary(object objFileLib,ILibrary objLibrary)
       {
           try
           {
               _libraryModuleMain = new LibraryModule(objLibrary);
               return false;// _libraryModuleMain.SaveLibrary(objFileLib);
           }
           catch (Exception)
           {
               throw;
           }
       }

       public bool SaveLibraryCategory(object objFileLib, ILibrary objLibrary)
       {
           try
           {
               _libraryModuleMain = new LibraryModule(objLibrary);
               return false;//_libraryModuleMain.SaveLibraryCategory(objFileLib);             
           }
           catch (Exception)
           {
               throw;
           }
       }


    }
}
