﻿using System;
using System.Collections;
using System.Collections.Generic;
using ORT_CORE.Interface.MasterInterface;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Class.SurveyClasses;
using System.Linq;

namespace ORT_BUSSINESS_LAYER.ModuleMaster
{
    public class MasterModule
    {
        private static IMaster _master;
        public User LoggedInUser { get; set; }

        public MasterModule(IMaster master)
        {
            _master = master;
        }

        public object GetMasterList()
        {
            var masterData = _master.GetMasterData();
            return _master.HomeType.Name.ToLower() == "role" ? GetRoleList(masterData) : masterData;
        }

        private List<Role> GetRoleList(object roleData)
        {
            var userRoleLevel = Convert.ToUInt32(LoggedInUser.UserDetails.UserRole.Hierarchy);
            var returnList = ((IEnumerable) roleData).Cast<Role>().Where(role => Convert.ToUInt32(role.Hierarchy) >= userRoleLevel).ToList();
            return returnList;
        }


    }
}
