﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface ISurvey
   {
       bool SaveSurvey(Survey survey);
       List<Survey> GetSurvey();
       List<Survey> GetSurvey(string customerId);
       Survey GetSurvey(string customerId,string surveyId);
       List<Survey> GetMySurveys(string customerId);
   }
}
