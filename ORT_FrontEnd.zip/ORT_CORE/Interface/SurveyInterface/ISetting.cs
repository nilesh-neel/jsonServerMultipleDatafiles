﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
    public interface ISetting
    {
        bool SaveSetting(Setting setting);
        List<Setting> GetSettingBySurveyId(string surveyId);
        Setting GetSetting(string settingId);
        Setting GetSetting(string settingId, string settingName);
        
    }
}
