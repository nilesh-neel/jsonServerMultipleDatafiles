﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IMedia
   {
       bool SaveMediaInfo(Media media);
       List<Media> GetMediaInfo();
       Media GetMediaInfo(string questionId);
   }
}
