﻿using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IPlayList
   {
       PlayList GetPlayList(string playListId);
   }
}
