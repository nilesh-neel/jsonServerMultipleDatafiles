﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface ICustomer
   {
       Customer GetCustomer(string customerId);
       List<Customer> SearchCustomer(string customerName, string abbrevation);
       bool SaveCustomer(Customer cust);
       bool DeleteCustomer(string customerName, string abbrevation);
       List<Customer> GetCustomerMaster();
   }
}
