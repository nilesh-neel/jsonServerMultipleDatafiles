﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
  public interface IReward
  {
      bool SaveReward(Reward reward);
      Reward GetReward(string surveyId);
  }
}
