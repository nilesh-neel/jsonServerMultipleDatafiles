﻿using ORT_CORE.Class.SurveyClasses;
using System.Collections.Generic;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IUser
   {
       bool SaveUser(User user);
       User GetUserByUserId(string userId);
       User GetUserByLoginId(string loginId);
       List<User> GetUserList(string code, string loginId, string name, string custName, string email);
       List<User> GetUsersByCustomerId(string customerId);
       bool DeleteUser(string loginId);
       bool CheckUserCode(string userCode, string userId);
   }
}
