﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IPanelist
   {
       bool SaveLibrary(Library library);
       List<Library> GetLibraryList(string custId);
       bool SavePanelist(Panel panelist);
       bool SavePanelCategory(PanelCategory panelCate);
       List<Panel> GetPanelistCombo(string custId);
       List<PanelCategory> GetPaneCategory(string panelistId);       
       Panel GetPanelist(string panelistId);
       List<Panel> GetPanelist(string panelLib, string panelistName, string category);
       bool DeletePanel(string panelId);
      
      
   }
}
