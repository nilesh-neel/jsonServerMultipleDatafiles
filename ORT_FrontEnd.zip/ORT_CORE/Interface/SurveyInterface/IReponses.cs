﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
    public interface IReponses
    {
        bool SaveResponse(List<Responses> userResponse);
        List<Answer> GetResponseAnswers(string surveyId, string questionId,string sessionId);
        bool CompleteSurvey(string surveyId, string sessionId);
    }
}
