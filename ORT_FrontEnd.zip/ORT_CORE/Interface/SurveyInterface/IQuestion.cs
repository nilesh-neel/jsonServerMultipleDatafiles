﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IQuestion
   {
       Question GetQuestion(string questionId);
       List<Question> GetQuestionBySurveyId(string surveyId);
       List<Question> GetQuestionBySessionId(string surveyId, string sessionId);
       bool SaveQuestion(Question question);
   }
}
