﻿using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IQuota
   {
       bool SaveQuota(Quota quota);
       Quota GetQuota(string surveyId);
   }
}
