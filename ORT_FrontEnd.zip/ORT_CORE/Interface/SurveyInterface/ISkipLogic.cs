﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface ISkipLogic
   {
       bool SaveSkipLogic(SkipLogic skipLogic);
       List<SkipLogic> GetSkipLogic(string surveyId);
       SkipLogic GetMediaSkipLogic(string questionId);
   }
}
