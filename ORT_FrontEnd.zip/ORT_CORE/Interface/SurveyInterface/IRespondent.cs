﻿using ORT_CORE.Class.SurveyClasses;
using System.Collections.Generic;


namespace ORT_CORE.Interface.SurveyInterface
{
   public interface IRespondent
   {
       bool SaveRespondentlist(Respondent respondentlist);
       Respondent GetMemberList(string memberId);
       List<Respondent> GetMembersList(string panelId,string emailId);
       bool DeleteMember(string memberId);     
       List<Respondent> ReadCSV(Panel objpanel,string path, string fileName, string extension);
       
      
   }
}
