﻿using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Interface.SurveyInterface
{
   public interface ILogin
   {
       UserValidator VerifyUser(User user);    
   }
}
