﻿using System;

namespace ORT_CORE.Interface.MasterInterface
{
  public  interface IMaster
  {
      object GetMasterData();
      Type HomeType { get; }
  }
}
