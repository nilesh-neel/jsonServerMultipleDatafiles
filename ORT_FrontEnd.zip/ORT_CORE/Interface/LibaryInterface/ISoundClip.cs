﻿using ORT_CORE.Class.LibraryClasses;

namespace ORT_CORE.Interface.LibaryInterface
{
   public interface ISoundClip
   {
       SoundClip GetSoundClip(string fileLibId);
       bool SaveSoundClip(SoundClip soundClip );

   }
}
