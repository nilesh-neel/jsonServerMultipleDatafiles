﻿using System;
using System.Collections.Generic;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_CORE.Interface.LibaryInterface
{
   public interface ILibrary
   {
       Type HomeType { get; }
       string JsonModelName { get; }
       Library.LibraryType LibraryType { get; } 
       string Message { get; set; }
       object GetLibrary(string libraryId);
       List<object> SearchLibrary(string libraryId, string category);
       object SearchLibraryDetails(string detailslibraryId, string category);
       List<object> GetLibraryList(string customerId, string type);
       List<object> GetLibraryCategoryList(string libraryId);
       bool SaveLibrary(object library);
       bool SaveLibraryCategory(object library);
       object SaveLibraryDetails(object library);
       bool DeleteLibrary(string libraryId);
       bool CheckLibraryCategory(string libraryId, string category);
   }
}
