﻿namespace ORT_CORE.Class.MasterClasses
{
    public class City
    {
        public string CityId { get; set; }
        public string CityCode { get; set; }
        public string CityName { get; set; }
    }
}
