﻿namespace ORT_CORE.Class.MasterClasses
{
    public class Language
    {
        public string LanguageId { get; set; }
        public string LanguageName { get; set; }
    }
}
