﻿namespace ORT_CORE.Class.MasterClasses
{
    public class State
    {
        public string StateId { get; set; }
        public string StateCode { get; set; }
        public string StateName { get; set; }
    }
}
