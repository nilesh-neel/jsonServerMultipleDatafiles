﻿namespace ORT_CORE.Class.MasterClasses
{
   public class UserTimeZone
    {
       public string TimeZoneId { get; set; }
       public string TimeZoneName { get; set; }
       public string LocationName { get; set; }
    }
}
