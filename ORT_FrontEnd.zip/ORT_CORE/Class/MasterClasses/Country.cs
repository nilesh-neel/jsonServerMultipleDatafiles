﻿namespace ORT_CORE.Class.MasterClasses
{
    public class Country
    {
        public string CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
    }
}
