﻿namespace ORT_CORE.Class.MasterClasses
{
    public class Role
    {
        public string RoleId { get; set; }
        public string RoleType { get; set; }
        public string RoleDesc { get; set; }
        public string Hierarchy { get; set; }
    }
}
