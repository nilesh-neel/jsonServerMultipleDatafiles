﻿using ORT_CORE.Class.SurveyClasses;
namespace ORT_CORE.Class.LibraryClasses
{
   public class SoundClip
    {
       public string FileLibId { get; set; }
       public string SongFileName { get; set; }
       public string Title { get; set; }
       public string Artist { get; set; }
       public string Year { get; set; }
       public string FilePath { get; set; }

       public string TempId { get; set; }       
       public string Status { get; set; }
       public string StatusMessage { get; set; }
       public UploadSession SessionId { get; set; }
    }
}
