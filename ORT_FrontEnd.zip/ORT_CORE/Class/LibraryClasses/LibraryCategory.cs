﻿namespace ORT_CORE.Class.LibraryClasses
{
   public class LibraryCategory
    {
       public string CategoryId { get; set; }
       public string CategoryName { get; set; }
       public string CategoryDescription { get; set; }
       public string LibraryId { get; set; }
    }
}
