﻿using System.ComponentModel;

namespace ORT_CORE.Class.LibraryClasses
{
   public class FileLibrary : Library
    {
       public enum FileType
       {
           [Description("Mp3")]
           Mp3 =1,
           [Description("Mp4")]
           Mp4,
           [Description("Wma")]
           Wma,
           [Description("Aac")]
           Aac
       }

       public string FileLibraryId { get; set; }
       public string FileLibraryName { get; set; }
       public LibraryCategory Category { get; set; }
       public string FileName { get; set; }
       public FileType Extension { get; set; }
       public SoundClip SoundClip { get; set; }

    }
}
