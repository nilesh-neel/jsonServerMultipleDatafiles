﻿using System.ComponentModel;

namespace ORT_CORE.Class.LibraryClasses
{
   public class MessageLibrary : Library
    {
       public enum MessageType
       {
           [Description("END OF SURVEY")]
           EndOfSurvey=1,
           [Description("GENERAL")]
           General,
           [Description("INACTIVE SURVEY")]
           InactiveSurvey,
           [Description("INVITE")]
           Invite,
           [Description("REMINDER")]
           Reminder,
           [Description("THANK YOU")]
           ThankYou
       }

       public string MessageLibraryId { get; set; }
       public MessageType MailType { get; set; }
       public string MessageDescription { get; set; }
       public string MessageText { get; set; }
       public LibraryCategory Category { get; set; }
       public string FilePath { get; set; }
    }
}
