﻿using System.ComponentModel;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_CORE.Class.LibraryClasses
{
  public class Library
    {
      public enum LibraryType
      {
          [Description("DummyLibraryRepository")]
          Dummy = 1,
          [Description("MessageLibraryRepository")]
          Message,
          [Description("FileLibraryRepository")]
          File,
          [Description("GraphicLibraryRepository")]
          Graphic,
          [Description("QuestionLibraryRepository")]
          Question,
          [Description("SurveyLibraryRepository")]
          Survey,
          [Description("PanelistRepository")]
          Panel
      }

      public string LibraryId { get; set; }
      public LibraryType LibType { get; set; }
      public string LibraryName { get; set; }
      public Customer Customer { get; set; }
      public string Description { get; set; }
    }
}
