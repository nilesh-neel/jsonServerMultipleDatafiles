﻿using ORT_CORE.Class.SurveyClasses;
using System.Collections.Generic;

namespace ORT_CORE.Class.LibraryClasses
{
   public class QuestionLibrary:Library
    {
       public string QuestionLibraryId { get; set; }
       public List<Question> QuestionInLibrary { get; set; }
       public string QuestionLibraryName { get; set; }
       public LibraryCategory Category { get; set; }
    }
}
