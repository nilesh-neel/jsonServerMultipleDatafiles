﻿using System.ComponentModel;

namespace ORT_CORE.Class.LibraryClasses
{
   public class GraphicLibrary :Library
   {
       public enum ImageType
       {
           [Description("Gif")] Gif = 1,
           [Description("Jpg")] Jpg,
           [Description("Png")] Png
       };
       public string GraphicLibraryId { get; set; }
       public string GraphicFileName { get; set; }
       public ImageType FileType { get; set; }
       public string RelativePath { get; set; }
       public string NoOfFiles { get; set; }
       public LibraryCategory Category { get; set; }
    }
}
