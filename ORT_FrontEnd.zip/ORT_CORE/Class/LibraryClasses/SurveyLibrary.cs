﻿using ORT_CORE.Class.SurveyClasses;
using System.Collections.Generic;

namespace ORT_CORE.Class.LibraryClasses
{
   public class SurveyLibrary : Library
    {
       public string SurveyLibraryId { get; set; }
       public List<Survey> SurveyInLibrary { get; set; }
       public string SurveyLibraryName { get; set; }
       public LibraryCategory Category { get; set; }
    }
}
