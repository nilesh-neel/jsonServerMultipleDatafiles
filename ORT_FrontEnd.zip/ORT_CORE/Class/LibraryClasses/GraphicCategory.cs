﻿using System;
using System.ComponentModel;

namespace ORT_CORE.Class.LibraryClasses
{
    public class GraphicCategory
    {
        public enum ImageType
        {
            [Description("Gif")]
            Gif = 1,
            [Description("Jpg")]
            Jpg,
            [Description("Png")]
            Png
        }
        public string CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string GraphicFileName { get; set; }
        public ImageType Extension { get; set; }
        public DateTime UploadedOn { get; set; }       
    }
}
