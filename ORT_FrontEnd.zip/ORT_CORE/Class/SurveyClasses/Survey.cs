﻿using System.Collections.Generic;

namespace ORT_CORE.Class.SurveyClasses
{
    public class Survey
    {
        public string SurveyId { get; set; }
        public string SurveyName { get; set; }
        public Customer Customer { get; set; }
        public List<Question> Questions { get; set; }
        public Quota Quota { get; set; }
        public Reward Reward { get; set; }
        public List<Setting> Settings { get; set; }
        public bool RewardEnabled { get; set; }
        public bool Starred { get; set; }
        public User CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
        public User ModifiedBy { get; set; }
        public string ModifiedDateTime { get; set; }
        public bool IsActive { get; set; }
        public SurveyInfo SurveyInfo { get; set; }
        public SurveyConfig Config { get; set; }
        public List<SkipLogic> SkipLogic { get; set; }
        public string SurveyEndDate { get; set; }

    }
}
