﻿using System.Collections.Generic;

namespace ORT_CORE.Class.SurveyClasses
{
   public class SkipLogic
    {
       public string LogicExpression { get; set; }
       public string TrueAction { get; set; }
       public string FalseAction { get; set; }
       public string CheckQuestionId { get; set; }
       public string ExpectedAnswerId { get; set; }
       public string ExpectedAnswerText { get; set; }
       public string EvalOperator { get; set; }
       public List<string> ComparisionTokens
       {
           get
           {
               return new List<string>
                   {
                       "==",
                       ">=",
                       ">"                       
                   };
           }
       }
    }
}
