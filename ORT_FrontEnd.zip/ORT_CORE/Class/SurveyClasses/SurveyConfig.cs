﻿using System.ComponentModel;

namespace ORT_CORE.Class.SurveyClasses
{
    public class SurveyConfig
    {
        [Description("LogoFile")]
        public string LogoFileName { get; set; }

        [Description("BackGroundColor")]
        public string BackgroundColor { get; set; }

        [Description("AutoAdvance")]
        public bool AutoAdvance { get; set; }

        [Description("BTN_BACK")]
        public bool AllowBackButton { get; set; }

        [Description("ALLOW_SAVE_CONTINUE")]
        public bool AllowContinueLater { get; set; }

        [Description("NextBackTextLink")]
        public bool NextBackTextLink { get; set; }

        [Description("ALLOW_ANONYMOUS")]
        public bool AnnoymousAllowed { get; set; }

        [Description("BY_INVITE")]
        public bool ByInvite { get; set; }

        [Description("INVITE_HAS_PSW")]
        public bool PasswordProtected { get; set; }

        [Description("ALLOW_REPEAT")]
        public bool RepeatReponses { get; set; }

        [Description("E_O_S_MESSAGE")]
        public bool EndMessageFromLibrary { get; set; }

        [Description("E_O_S_MESSAGE_ID")]
        public string MessageFromLibrary { get; set; }

        [Description("E_O_S_MESSAGE_TEXT")]
        public string MessageTextFromLibrary { get; set; }

        [Description("E_O_S_REDIRECT")]
        public bool Redirection { get; set; }

        [Description("E_O_S_REDIRECT_URL")]
        public string RedirectionUrl { get; set; }

        [Description("E_O_S_EMAIL")]
        public bool AdditionalEmail { get; set; }

        [Description("E_O_S_EMAIL_ID")]
        public string AdditionalEmailFromLibrary { get; set; }

        [Description("SurveyTemplateName")]
        public string SurveyTemplateName { get; set; }

        [Description("SurveyWelcomePage")]
        public string SurveyWelcomePage { get; set; }

        [Description("SurveyThankuPage")]
        public string SurveyThankuPage { get; set; }

        [Description("SurveyExpiredPage")]
        public string SurveyExpiredPage { get; set; }

        [Description("SurveyRewardPage")]
        public string SurveyRewardPage { get; set; }

        [Description("ANSWER_FONT")]
        public string AnswerFont { get; set; }

        [Description("ANSWER_FONT_COLOR")]
        public string AnswerFontColor { get; set; }

        [Description("ANSWER_FONT_SIZE")]
        public string AnswerFontSize { get; set; }

        [Description("HEADER_FONT")]
        public string HeaderFont { get; set; }

        [Description("HEADER_FONT_SIZE")]
        public string HeaderFontSize { get; set; }

        [Description("HEADER_FONT_COLOR")]
        public string HeaderFontColor { get; set; }

        [Description("QUESTION_FONT")]
        public string QuestionFont { get; set; }

        [Description("QUESTION_FONT_COLOR")]
        public string QuestionFontColor { get; set; }

        [Description("QUESTION_FONT_SIZE")]
        public string QuestionFontSize { get; set; }

        [Description("HEADER_SHOW_DATE_TIME")]
        public bool ShowDateTime { get; set; }

        [Description("PipingIn")]
        public bool PipedInResponse { get; set; }

        [Description("PipingOut")]
        public bool PippedOutResponse { get; set; }

        [Description("ValidationAnswerValues")]
        public bool ValidateResponses { get; set; }

        [Description("CheckQuotas")]
        public bool CheckQuotas { get; set; }

        [Description("CheckSurveyEnd")]
        public bool CheckEndOfSurvey { get; set; }

        [Description("RewardSet")]
        public bool RewardApplicable { get; set; }

        [Description("FollowupMTBQue")]
        public string FollowUpMtbQuestion { get; set; }

        [Description("VerificationQuestion")]
        public string VerificationQuestion { get; set; }

        [Description("2ndValidation")]
        public bool ResponseCodeValidation { get; set; }

        [Description("SkipLogic")]
        public bool VerifySkipLogic { get; set; }

    }
}
