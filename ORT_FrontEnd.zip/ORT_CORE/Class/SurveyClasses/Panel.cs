﻿using System.Collections.Generic;
using System;
using ORT_CORE.Class.LibraryClasses;
namespace ORT_CORE.Class.SurveyClasses
{
   public class Panel:Library
    {
       public string PanelId { get; set; }
       public string PanelName { get; set; }
       public PanelCategory PanelCategory { get; set; }       
       public List<Respondent> Members { get; set; }
       public Customer Customer { get; set; }
       public DateTime LastUsed { get; set; }
       public bool IsPanelActive { get; set; }
       public User CreatedBy { get; set; }
       public string CreatedOn { get; set; }
       public User ModifiedBy { get; set; }
       public string ModifiedOn { get; set; }
    }
}
