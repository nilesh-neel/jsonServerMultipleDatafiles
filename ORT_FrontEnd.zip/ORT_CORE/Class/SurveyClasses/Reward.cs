﻿using System;

namespace ORT_CORE.Class.SurveyClasses
{
   public class Reward
    {
       public string RewardId { get; set; }
       public Customer Customer { get; set; }
       public int Fees { get; set; }
       public string Name { get; set; }
       public string Description { get; set; }
       public int ApproxValue { get; set; }
       public DateTime EndDate { get; set; } 
    }
}
