﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class SurveyInfo
    {
       public int Responses { get; set; }
       public int RequiredSamples { get; set; }
       public string SurveyStatus { get; set; }
    }
}
