﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class Setting
    {
       public string SettingId { get; set; }
       public string SettingName { get; set; }
       public string DisplayText { get; set; }
       public Customer Customer { get; set; }
       public string Value { get; set; }
       public bool IsAassigned { get; set; }
    }
}
