﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class AccessModule
    {
        public string ModuleName { get; set; }
    }
}
