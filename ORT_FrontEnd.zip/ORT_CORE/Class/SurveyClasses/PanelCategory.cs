﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class PanelCategory
    {
        public string CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
    }
}
