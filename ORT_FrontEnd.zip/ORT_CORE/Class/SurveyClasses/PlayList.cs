﻿using System.Collections.Generic;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_CORE.Class.SurveyClasses
{
   public class PlayList
   {
       public string PlayListId { get; set; }
       public string PlayLisName { get; set; }
       public List<FileLibrary> Songs { get; set; }
   }
}
