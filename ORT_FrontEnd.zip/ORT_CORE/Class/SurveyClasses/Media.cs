﻿using ORT_CORE.Class.LibraryClasses;

namespace ORT_CORE.Class.SurveyClasses
{
   public class Media
    {
       public FileLibrary FileInfo { get; set; }
       public Customer Customer { get; set; }
       public bool Randomize { get; set; }
       public bool AutoAdvance { get; set; }
       public bool ShowTitle { get; set; }
       public bool AutoPlay { get; set; }
       public int HideForSeconds { get; set; }
    }
}
