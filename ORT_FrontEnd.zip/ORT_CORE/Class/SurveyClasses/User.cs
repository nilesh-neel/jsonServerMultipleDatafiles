﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class User
    {
       public string UserId { get; set; }
       public string LoginId { get; set; }
       public string UserCode { get; set; }
       public string UserName { get; set; }
       public string Password { get; set; }
       public string EmailId { get; set; }
       public UserDetails UserDetails { get; set; }
       public User CreatedBy { get; set; }
       public string CreatedOn { get; set; }
       public User ModifiedBy { get; set; }
       public string ModifiedOn { get; set; }
    }
}
