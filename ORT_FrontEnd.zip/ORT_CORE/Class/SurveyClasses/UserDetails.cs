﻿using System.Collections.Generic;
using ORT_CORE.Class.MasterClasses;

namespace ORT_CORE.Class.SurveyClasses
{
    public class UserDetails
    {
        public bool IsActive { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string TimeZone { get; set; }
        public string Language { get; set; }
        public string Department { get; set; }
        public Customer Customer { get; set; }
        public List<AccessModule> Module { get; set; }
        public Role UserRole { get; set; }
        
    }
}
