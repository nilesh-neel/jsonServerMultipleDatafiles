﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class Quota
    {
       public string QuotaId { get; set; }
       public string QuotaLimit { get; set; }
    }
}
