﻿using System.Collections.Generic;

namespace ORT_CORE.Class.SurveyClasses
{
   public class Responses
    {
       public string ResponseId { get; set; }
       public string SurveyId { get; set; }
       public Question Question { get; set; }
       public List<Answer> Answer { get; set; }
       public Respondent Respondent { get; set; }
       public string ResponseSessionId { get; set; }
    }
}
