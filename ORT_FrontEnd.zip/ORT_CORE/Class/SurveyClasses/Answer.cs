﻿namespace ORT_CORE.Class.SurveyClasses
{
    public class Answer
    {
        public string AnswerId { get; set; }
        public string AnswerDesc { get; set; }
        public string AnswerText { get; set; }
    }
}
