﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class Respondent
    {
       public string RespondentId { get; set; } 
       public string RespondentCode { get; set; }
       public Panel Panel { get; set; } 
       public string FirstName { get; set; }
       public string LastName { get; set; }
       public string Gender { get; set; }
       public string Age { get; set; }
       public string BirthDate { get; set; }
       public string Town { get; set; }
       public string RespondentEmailId { get; set; }
       public string UserDefineColumn1 { get; set; }
       public string UserDefineColumn2 { get; set; }
       public string UserDefineColumn3 { get; set; }
       public string UserDefineColumn4 { get; set; }
       public string UserDefineColumn5 { get; set; }
       public bool IsRespondentDeleted { get; set; }
       public bool IsRespondentActive { get; set; }
       public Customer Customer { get; set; }
       public User CreatedBy { get; set; }
       public string CreatedOn { get; set; }
       public User ModifiedBy { get; set; }
       public string ModifiedOn { get; set; }

       public string TempId { get; set; }
       //public string Flag { get; set; }
       public string Status { get; set; }
       public string StatusMessage { get; set; }
       public UploadSession SessionId { get; set; }
    }
}
