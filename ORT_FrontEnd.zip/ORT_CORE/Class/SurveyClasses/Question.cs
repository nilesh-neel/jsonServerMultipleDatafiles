﻿using System.Collections.Generic;
using System.ComponentModel;

namespace ORT_CORE.Class.SurveyClasses
{
    public class Question
    {
        public enum QuestionTypes
        {
            [Description("singleChoice")]
            SingleChoice = 1,
            [Description("multiChoice")]
            MultiChoice,
            [Description("textInput")]
            TextInput,
            [Description("pageBreak")]
            PageBreak,
            [Description("booleanChoice")]
            BooleanChoice,
            [Description("dateInput")]
            DateInput,
            [Description("timeInput")]
            TimeInput,
            [Description("sliderInput")]
            SliderInput,
            [Description("numberInput")]
            NumberInput,
            [Description("Welcome")]
            Welcome,
            [Description("PerceptIntro")]
            PerceptIntro,
            [Description ("MediaIntro")]
            MediaIntro,
            [Description("ListenOften")]
            ListenOften,
            [Description("ThankYou")]
            ThankYou

        }
        public string QuestionId { get; set; }
        public Customer Customer { get; set; }
        public QuestionTypes QuestionType { get; set; }
        public List<Answer> Answers { get; set; }
        public Answer DefaultAnswer { get; set; }
        public string QuestionText { get; set; }
        public bool ForceResponse { get; set; }
        public bool HasSkipLogic { get; set; }
        public bool HasEmailTrigger { get; set; }
        public bool HasMedia { get; set; }
        public bool IsDeleted { get; set; }
        public Responses CapturedResponses { get; set; }
        public string PlayListId { get; set; }
        public PlayList SongList { get; set; }
        public SkipLogic MediaSkipLogic { get; set; }
    }
}
