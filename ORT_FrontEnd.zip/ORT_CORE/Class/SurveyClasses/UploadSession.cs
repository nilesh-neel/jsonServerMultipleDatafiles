﻿namespace ORT_CORE.Class.SurveyClasses
{
   public class UploadSession
    {
        public string SessionId { get; set; }
        public string FileType { get; set; }
        public string FileName { get; set; }
        public string CustomerId { get; set; }
        public string UploadedBy { get; set; }
        public string UploadedDate { get; set; }
        public string ParentId { get; set; } 
    }
}
