﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ORT_PERSISTENCE.TempClass
{
    public static class DownloadFile
    {
       public static string VirtualPath { get; set; }
       public static string FileDownloadName { get; set; }
       public static string SrcTable { get; set; }
    }


}
