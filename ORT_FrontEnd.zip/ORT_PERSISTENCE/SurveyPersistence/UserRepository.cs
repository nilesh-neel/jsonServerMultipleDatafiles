﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using System.Linq;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.SurveyPersistence
{
   public class UserRepository :IUser 
    {
       public static string Message { get; set; }
      public User GetUserByUserId(string userId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "UserId", userId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               var dsReturn = dataManager.GetSetDataFromDb();
               var objUser = BindDatasetToClass(dsReturn);             
               return objUser;
           }
           catch (Exception)
           {
               throw; 
           }
           
       }

      public User GetUserByLoginId(string loginId)
      {
          try
          {
              var parameters = new Dictionary<string, string> { { "LoginId", loginId } };
              var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
              var dsReturn = dataManager.GetSetDataFromDb();
              var objUser = BindDatasetToClass(dsReturn);
              return objUser;
          }
          catch (Exception)
          {
              throw;
          }

      }

      public bool CheckUserCode(string userCode, string userId)
      {
          try
          {
              var parameters = new Dictionary<string, string> { { "UserCode", userCode }, 
              { "UserId", userId } };
              var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
              dataManager.Operation = "CheckUserCode";
              var dsReturn = dataManager.GetSetDataFromDb();
              if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
              {//user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                  return true;
              }
              //throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
              return false;
          }
          catch (Exception)
          {
              throw;
          }

      }

      public List<User> GetUserList(string code, string loginId, string name, string custName, string email)
       {
           try
           {
               var parameters = new Dictionary<string, string> { {"UserCode",code},{"UserName",name},
                    {"LoginId",loginId},{"EmailId",email},{"CustomerName",custName} };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "SearchUsers";
               var dsReturn = dataManager.GetSetDataFromDb();             
               return GetUserList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }

       }

       public List<User> GetUsersByCustomerId(string customerId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { {"CustomerId",customerId}};
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetUserList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }

       private static List<User> GetUserList(DataSet dsData)
       {
           return dsData.Tables[0].AsEnumerable()
            .Select(r => new User
            {
                UserId = r["UserId"].ToString(),
                UserCode = r["UserCode"].ToString(),
                LoginId = r["LoginId"].ToString(),
                UserName = r["UserName"].ToString(),
                EmailId = r["EmailId"].ToString(),
                CreatedBy = new User { UserId = r["CreatedBy"].ToString() },
                CreatedOn = r["CreatedOn"].ToString(),
                ModifiedBy = new User { UserId = r["ModifiedBy"].ToString() },
                ModifiedOn = r["ModifiedOn"].ToString(),
                UserDetails = BindUserDetails(r),
            }).ToList();           
       }
       public bool SaveUser(User user)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(user) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                   return true;
               }
               else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
               {
                   Message = dsReturn.Tables[0].Rows[0]["Remark"].ToString();
                   return false;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               throw;
           }
       }

       public bool DeleteUser(string loginId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LoginId", loginId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "DeleteUser";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                   return true;
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               throw;
           }
       }

       public static List<AccessModule> GetUserAccessModule(string userType)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "RoleId", userType } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.MapType = typeof (Role);
               dataManager.Operation = "RoleAccessModule";
               var dsReturn = dataManager.GetSetDataFromDb();

               var lstModule = new List<AccessModule>((from dRow in dsReturn.Tables[0].AsEnumerable()
                  select (GetModuleDataTableRow(dRow))));

               return lstModule; 
           }
           catch (Exception)
           {
               throw;
           }
       }

       private static AccessModule GetModuleDataTableRow(DataRow dr)
       {
           var objModule = new AccessModule { ModuleName = dr["AccessModule"].ToString() };
           return objModule; 
       }
        
       private static User BindDatasetToClass(DataSet dsData)
       {
           if (dsData.Tables[0].Rows.Count == 0) return null;        
          
           return new User
           {
               UserId = dsData.Tables[0].Rows[0]["UserId"].ToString(),
               UserCode = dsData.Tables[0].Rows[0]["UserCode"].ToString(),
               LoginId = dsData.Tables[0].Rows[0]["LoginId"].ToString(),
               Password = dsData.Tables[0].Rows[0]["UserPassword"].ToString(),
               UserName = dsData.Tables[0].Rows[0]["UserName"].ToString(),
               EmailId = dsData.Tables[0].Rows[0]["EmailId"].ToString(),
               CreatedBy = new User { UserId = dsData.Tables[0].Rows[0]["CreatedBy"].ToString() },
               CreatedOn = dsData.Tables[0].Rows[0]["CreatedOn"].ToString(),
               ModifiedBy = new User { UserId = dsData.Tables[0].Rows[0]["ModifiedBy"].ToString() },
               ModifiedOn = dsData.Tables[0].Rows[0]["ModifiedOn"].ToString(),
               UserDetails = BindUserDetails(dsData),
           };
       }
       private static UserDetails BindUserDetails(DataSet dsUser)
       {
          return new UserDetails
              {
                  IsActive = (bool)dsUser.Tables[0].Rows[0]["IsActive"],
                  Customer = new Customer
                  {CustomerId = Convert.ToString(dsUser.Tables[0].Rows[0]["CustomerId"])},
                  UserRole =  BindRole(dsUser),
                  Phone1 = dsUser.Tables[0].Rows[0]["Phone1"].ToString(),
                  Phone2 = dsUser.Tables[0].Rows[0]["Phone2"].ToString(),
                  Language = dsUser.Tables[0].Rows[0]["LanguageId"].ToString(),
                  TimeZone = dsUser.Tables[0].Rows[0]["TimeZoneId"].ToString(),
                  Department = dsUser.Tables[0].Rows[0]["Department"].ToString(),
                  Module = GetUserAccessModule(dsUser.Tables[0].Rows[0]["RoleId"].ToString()),
              }; 
       }
       private static UserDetails BindUserDetails(DataRow r)
       {
           return new UserDetails
           {
               IsActive = (bool)r["IsActive"],
               UserRole =BindRole(r),
               Customer = new Customer { CustomerId = Convert.ToString(r["CustomerId"]) },
               Phone1 = r["Phone1"].ToString(),
               Phone2 = r["Phone2"].ToString(),
               Language = r["LanguageId"].ToString(),
               TimeZone = r["TimeZoneId"].ToString(),
               Department = r["Department"].ToString(),
               Module = GetUserAccessModule(r["RoleId"].ToString()),
           };
       }
       private static Role BindRole(DataSet dsUser)
       {
            return new Role
                  {
                      RoleId = dsUser.Tables[0].Rows[0]["RoleId"].ToString(),
                      RoleDesc = dsUser.Tables[0].Rows[0]["UserType"].ToString(),
                      Hierarchy = dsUser.Tables[0].Rows[0]["Hierarchy"].ToString()
                  };
       }
       private static Role BindRole(DataRow r)
       {
          return new Role { RoleId = r["RoleId"].ToString(), 
               RoleDesc = r["UserType"].ToString(), 
               Hierarchy = r["RoleId"].ToString() };
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(User), method)
           {
               Parameters = parameters
           };
       }
    }
}
