﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_PERSISTENCE.LibraryPersistence;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PersistanceMedia : IMedia
    {
        public bool SaveMediaInfo(Media media)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)media, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Media> GetMediaInfo()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return GetMediaList(dsReturn);
        }

        public Media GetMediaInfo(string questionId)
        {
            var parameters = new Dictionary<string, string> { { "QuestionId", questionId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);

        }

        private List<Media> GetMediaList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static Media BindRowToClassObject(DataRow dataRow)
        {
            var objCustomer = new PersistanceCustomer();
            var objFileLibrary = new PersistanceFileLibrary();
            return new Media
                       {
                           AutoAdvance = (bool)dataRow["AutoAdvance"],
                           Customer = objCustomer.GetCustomer((string)dataRow["CustomerId"]),
                           AutoPlay = (bool)dataRow["Autoplay"],
                           FileInfo = (FileLibrary) objFileLibrary.GetLibrary((string)dataRow["FileLibId"]), 
                           HideForSeconds = (int)dataRow["HideForSeconds"],
                           Randomize = (bool)dataRow["Randomize"],
                           ShowTitle = (bool)dataRow["ShowTitle"]
                       };
        }
        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Media), method)
            {
                Parameters = parameters
            };
        }
    }
}
