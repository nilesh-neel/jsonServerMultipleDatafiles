﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class SurveyRepository : ISurvey
    {
        public bool SaveSurvey(Survey survey)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)survey, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Survey> GetSurvey()
        {
            try
            {
                var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
                dataManager.Operation = "GetSurvey";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetSurveyList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Survey> GetSurvey(string customerId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", customerId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetSurvey";
                var dsReturn = dataManager.GetSetDataFromDb();
                return dsReturn.Tables[0].Rows.Count > 0 ? GetSurveyList(dsReturn) : null;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public Survey GetSurvey(string customerId, string surveyId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", customerId }, { "SurveyId", surveyId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetSurvey";
                var dsReturn = dataManager.GetSetDataFromDb();
                return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
            }
            catch (Exception)
            {

                throw;
            }

        }

        public List<Survey> GetMySurveys(string customerId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", customerId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetMySurvey";
                var dsReturn = dataManager.GetSetDataFromDb();
                var surveyList = GetSurveyList(dsReturn);
                return dsReturn.Tables[0].Rows.Count > 0 ? BindSurveyInfo(surveyList, dsReturn) : null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        

        

        private static List<Survey> GetSurveyList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static Survey BindRowToClassObject(DataRow dataRow)
        {
            var rData = new Survey
                            {
                                SurveyId = dataRow["SurveyId"].ToString(),
                                SurveyName = dataRow["SurveyName"].ToString(),
                                RewardEnabled = Convert.ToBoolean(dataRow["RewardEnabled"]),
                                CreatedBy = new User { UserId = dataRow["CreatedBy"].ToString() },
                                CreatedDateTime = dataRow["CreatedDate"].ToString(),
                                ModifiedBy = new User { UserId = dataRow["ModifiedBy"].ToString() },
                                ModifiedDateTime = dataRow["ModifiedDate"].ToString(),
                                Customer = new Customer { CustomerId = dataRow["CustomerId"].ToString() },
                                Starred = Convert.ToBoolean(dataRow["StarMarked"]),
                                IsActive = Convert.ToBoolean(dataRow["IsActive"]),
                                SurveyEndDate = (dataRow["SurveyEndDate"]).ToString()
                            };

            return rData;
        }

        private static List<Survey> BindSurveyInfo(List<Survey> surveys, DataSet dataSet)
        {
            var rowcounter = 0;
            var localSurveyList = surveys;
            foreach (var survey in localSurveyList)
            {
                survey.SurveyInfo = new SurveyInfo
                                 {
                                     RequiredSamples = Convert.ToInt32(dataSet.Tables[0].Rows[rowcounter]["RequiredSamples"]),
                                     Responses = Convert.ToInt32(dataSet.Tables[0].Rows[rowcounter]["Responses"]),
                                     SurveyStatus = dataSet.Tables[0].Rows[rowcounter]["SurveyStatusName"].ToString()
                                 };
                rowcounter++;
            }



            return localSurveyList.ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Survey), method)
            {
                Parameters = parameters
            };
        }



    }
}
