﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using System.Xml;
using ORT_HELPERS.Helpers;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PanelistRepository : IPanelist
    {
        public static string Message { get; set; }
        public bool SavePanelist(Panel panelist)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(panelist) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SavePanel";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                    {
                        panelist.PanelId = dsReturn.Tables[0].Rows[0]["PanelistId"].ToString();
                        return true;
                    }
                    else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
                    {
                        if (string.IsNullOrEmpty(panelist.LibraryId) || string.IsNullOrEmpty(panelist.PanelCategory.CategoryId))
                        {
                            Message = "";
                            return false;
                        }
                        else
                        {
                            Message = Convert.ToString(dsReturn.Tables[0].Rows[0]["Remark"]);
                            return false;
                        }
                    }
                }
                else
                {
                    Message = "";
                    return false;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool SavePanelCategory(PanelCategory panelCate)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(panelCate) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SavePanleCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    panelCate.CategoryId = dsReturn.Tables[0].Rows[0]["CategoryId"].ToString();
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Library> GetLibraryList(string custId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", custId }, { "LibTypeId", "7" } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "PanelLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetFileLibraryList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool SaveLibrary(Library library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    var objlib = (Library)library;
                    objlib.LibraryId = dsReturn.Tables[0].Rows[0]["LibraryId"].ToString();
                    library = objlib;
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Panel> GetPanelistCombo(string custId)
        {
            var parameters = new Dictionary<string, string> { { "CustomerId", custId } };
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetPanelistList(dsReturn) : null;
        }
        public List<PanelCategory> GetPaneCategory(string panelistId)
        {
            var parameters = new Dictionary<string, string> { { "LibId", panelistId } };
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            dataManager.Operation = "GetPanelCategory";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetPanelCategory(dsReturn) : null;
        }

        public Panel GetPanelist(string panelId)
        {
            var parameters = new Dictionary<string, string> { { "PanelistId", panelId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetPanelMember";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }

        public List<Panel> GetPanelist(string libId, string panelName, string category)
        {
            var parameters = new Dictionary<string, string> { { "LibId", libId }, { "PanelistName", panelName == "" ? null : panelName }, { "CategoryId", category == "" ? null : category } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "SearchPanel";
            var dsReturn = dataManager.GetSetDataFromDb();
            //return dsReturn.Tables[0].Rows.Count > 0 ? GetPanelistList(dsReturn) : null;
            if (dsReturn.Tables[0].Rows.Count > 0)
            {
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return GetPanelistList(dsReturn);
                }
                else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
                {
                    if (string.IsNullOrEmpty(libId) || string.IsNullOrEmpty(category))
                    {
                        Message = "";
                        return null;
                    }
                    else
                    {
                        Message = Convert.ToString(dsReturn.Tables[0].Rows[0]["Remark"]);
                        return null;
                    }
                }
            }
            else
            {
                Message = "";
                return null;
            }
            throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());

        }

        public bool DeletePanel(string panelId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "PanelistId", panelId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "DeletePanel";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                    return true;
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<Library> GetFileLibraryList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindLibraryClass(row)).ToList();
        }
        private static Library BindLibraryClass(DataRow dataRow)
        {
            return new Library
            {
                LibraryId = Convert.ToString(dataRow["LibId"]),
                LibraryName = (string)dataRow["LibName"],
                Description = Convert.ToString(dataRow["LibTypeId"])
            };
        }


        private static List<PanelCategory> GetPanelCategory(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowPanelCategory(row)).ToList();
        }

        private static PanelCategory BindRowPanelCategory(DataRow dataRow)
        {
            return new PanelCategory
            {
                CategoryId = dataRow["CategoryId"].ToString(),
                CategoryName = dataRow["CategoryName"].ToString(),
                CategoryDescription = Convert.ToString(dataRow["LibId"])
            };

        }

        private List<Panel> GetPanelistList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }


        private Panel BindRowToClassObject(DataRow dataRow)
        {
            return new Panel
                       {
                           PanelId = dataRow["PanelistId"].ToString(),
                           PanelName = dataRow["PanelistName"].ToString(),
                           LibraryId = Convert.ToString(dataRow["LibId"]),
                           PanelCategory = new PanelCategory { CategoryId = Convert.ToString(dataRow["CategoryId"]) },
                           LastUsed = Convert.ToDateTime(dataRow["LastUsed"]),
                           Members = null,
                           Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },
                           IsPanelActive = Convert.ToBoolean(dataRow["IsActive"])
                       };
        }



        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Panel), method)
            {
                Parameters = parameters
            };
        }

    }
}
