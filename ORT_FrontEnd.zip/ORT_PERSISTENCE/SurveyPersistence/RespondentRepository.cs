﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using System.Linq;
using System.Xml;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class RespondentRepository : IRespondent
    {
        public bool SaveRespondentlist(Respondent respondentlist)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(respondentlist) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveMembers";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    respondentlist.RespondentId = dsReturn.Tables[0].Rows[0]["RespondentId"].ToString();
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }

        }

        public Respondent GetMemberList(string memberId)
        {
            var parameters = new Dictionary<string, string> { { "RespondentId", memberId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetMember";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToRespondentClass(dsReturn.Tables[0].Rows[0]) : null;
        }

        public List<Respondent> GetMembersList(string panelId, string emailId)
        {
            var parameters = new Dictionary<string, string> { { "PanelistId", panelId },{"EmailId",emailId} };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "SearchMembers";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetRespondentList(dsReturn) : null;
        }

        public bool DeleteMember(string memberId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "RespondentId", memberId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "DeleteMember";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                    return true;
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<Respondent> GetRespondentList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToRespondentClass(row)).ToList();
        }

        private UploadSession SaveUploadSession(Panel objpanel, string fileName)
        {
            try
            {
                var objUpSession = SetDataToClass(objpanel, fileName);
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(objUpSession) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveUploadSession";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return BindRowToUploadSessionClass(dsReturn);
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        private UploadSession SetDataToClass(Panel objpanel, string fileName)
        {
            return new UploadSession
                {
                    ParentId = objpanel.PanelId,
                    CustomerId = objpanel.Customer.CustomerId,
                    FileName = fileName,
                    FileType = "Panel",
                    UploadedBy = SessionHelper.LoggedinUserId,
                    UploadedDate = System.DateTime.Now.ToString("yyyy-MM-dd"),
                };
        }

       

       

        public List<Respondent> ReadCSV(Panel objpanle, string path, string fileName, string extension)
        {
            var objUpSession = SaveUploadSession(objpanle, fileName);
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Set);
            var objXml = new XmlDocument();
            var xmlProfile = AppDomain.CurrentDomain.RelativeSearchPath + "\\XMLMappings\\MapMembers.xml";
            var parameters = new Dictionary<string, string> {{ "FileName", fileName }, { "FileExtension", extension }
            ,{ "FolderPath", path },{ "XMLProfileFile", xmlProfile },{ "DBTableName", "TempRespondent" }
            ,{ "ShortFileName", "" }};
            var result = false; //dataManager.ImportFile(parameters, objUpSession);
            if (result)          
                return GetTempRespondent();
            return null;
        }

        

        private List<Respondent> GetTempRespondent()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            dataManager.Operation = "GetTempRespondent";
            var dsReturn = dataManager.GetSetDataFromDb();
            return (from DataRow row in dsReturn.Tables[0].Rows
                    select BindUploadRespondent(row)).ToList();
        }

        private static Respondent BindRowToRespondentClass(DataRow dataRow)
        {
            return new Respondent
            {
                RespondentId = dataRow["RespondentId"].ToString(),
                Panel =new Panel{PanelId=Convert.ToString(dataRow["PanelistId"])},
                RespondentCode = dataRow["RespondentCode"].ToString(),
                FirstName = dataRow["FirstName"].ToString(),
                LastName = dataRow["LastName"].ToString(),
                BirthDate = dataRow["BirthDate"].ToString(),
                Gender = dataRow["Gender"].ToString(),
                RespondentEmailId = dataRow["EmailId"].ToString(),
                Town = dataRow["Town"].ToString(),
                UserDefineColumn1 = Convert.ToString(dataRow["UDF1"]),
                UserDefineColumn2 = Convert.ToString(dataRow["UDF2"]),
                UserDefineColumn3 = Convert.ToString(dataRow["UDF3"]),
                UserDefineColumn4 = Convert.ToString(dataRow["UDF4"]),
                UserDefineColumn5 = Convert.ToString(dataRow["UDF5"]),
                Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },
                IsRespondentActive = Convert.ToBoolean(dataRow["IsActive"]),
                IsRespondentDeleted = Convert.ToBoolean(dataRow["IsDeleted"]),
            };
        }

        private static UploadSession BindRowToUploadSessionClass(DataSet dsData)
        {
            return new UploadSession
           {
               SessionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]),
               FileName = dsData.Tables[0].Rows[0]["FileName"].ToString(),
               FileType = dsData.Tables[0].Rows[0]["FileType"].ToString(),
               CustomerId = Convert.ToString(dsData.Tables[0].Rows[0]["CustomerId"]),
               ParentId = Convert.ToString(dsData.Tables[0].Rows[0]["ParentId"]),
               UploadedBy = Convert.ToString(dsData.Tables[0].Rows[0]["UploadedBy"]),
               UploadedDate = dsData.Tables[0].Rows[0]["UploadedDate"].ToString()
           };
        }

        private static Respondent BindUploadRespondent(DataRow dataRow)
        {
            return new Respondent
            {
                TempId = Convert.ToString(dataRow["TempId"]),
                Panel = new Panel { PanelId = Convert.ToString(dataRow["PanelistId"]) },
                FirstName = dataRow["FirstName"].ToString(),
                LastName = dataRow["LastName"].ToString(),
                BirthDate = dataRow["BirthDate"].ToString(),
                Gender = dataRow["Gender"].ToString(),
                RespondentEmailId = dataRow["EmailId"].ToString(),
                Town = dataRow["Town"].ToString(),
                UserDefineColumn1 = Convert.ToString(dataRow["UDF1"]),
                UserDefineColumn2 = Convert.ToString(dataRow["UDF2"]),
                UserDefineColumn3 = Convert.ToString(dataRow["UDF3"]),
                UserDefineColumn4 = Convert.ToString(dataRow["UDF4"]),
                UserDefineColumn5 = Convert.ToString(dataRow["UDF5"]),
                Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },
                //Flag = Convert.ToString(dataRow["Flag"]),
                Status = Convert.ToString(dataRow["Status"]),
                StatusMessage = Convert.ToString(dataRow["StatusMessage"]),
                CreatedBy = new User { UserId = Convert.ToString(dataRow["UserId"]) },
                SessionId = new UploadSession { SessionId = Convert.ToString(dataRow["SessionId"]) }
            };

        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Respondent), method)
            {
                Parameters = parameters
            };
        }

    }
}
