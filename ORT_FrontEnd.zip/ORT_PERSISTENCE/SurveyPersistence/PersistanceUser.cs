﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
   public class PersistanceUser :IUser 
    {
       public bool SaveUser(User user)
       {
           try
           {
               var dataManager = GetDataManagerObject((IDictionary<string, string>) user, DataManager.MethodType.Set);
               var dsReturn = dataManager.GetSetDataFromDb();
               return (string) dsReturn.Tables[0].Rows[0][0] == "0";
           }
           catch (Exception)
           {
               return false;
           }
       }

       public User GetUser(string userId)
       {
           var parameters = new Dictionary<string, string> { { "UserId", userId } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return BindDatasetToClass(dsReturn);
       }

       public User GetUser(string userId, string userName)
       {
           var parameters = new Dictionary<string, string> { { "UserId", userId },{"UserName",userName} };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return BindDatasetToClass(dsReturn);
       }


       private static User BindDatasetToClass(DataSet dsData)
       {
           return new User
           {
               UserId = (string) dsData.Tables[0].Rows[0]["UserId"],
               UserName = (string) dsData.Tables[0].Rows[0]["UserName"],
           };
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(User), method)
           {
               Parameters = parameters
           };
       }
    }
}
