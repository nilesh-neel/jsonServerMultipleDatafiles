﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PersistanceRespondent : IRespondent
    {
        public bool SaveRespondent(Respondent respondent)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)respondent, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Respondent GetRespondent(string respondentId)
        {
            var parameters = new Dictionary<string, string> { { "RespondentId", respondentId }};
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        public Respondent GetRespondent(string respondentId, string respondentName)
        {
            var parameters = new Dictionary<string, string> { { "RespondentId", respondentId }, { "RespondentName", respondentName } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Respondent), method)
            {
                Parameters = parameters
            };
        }

        private static Respondent BindRowToClassObject(DataRow dataRow)
        {
            return new Respondent
                       {
                           RespondentId = (string)dataRow["RespondentId"],
                           RespondentName = (string)dataRow["RespondentName"]
                       };
        }
    }
}
