﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PersistancePanelist : IPanelist
    {
        public bool SavePanelist(Panelist panelist)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)panelist, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }

        }

        public List<Panelist> GetPanelist()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return GetPanelistList(dsReturn);
        }

        public Panelist GetPanelist(string panelistId)
        {
            var parameters = new Dictionary<string, string> { { "PanelistId", panelistId }};
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        public Panelist GetPanelist(string panelistId, string panelistName)
        {
            var parameters = new Dictionary<string, string> {{"PanelistId", panelistId},{"PanelistName",panelistName}};
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);

        }

        private static List<Panelist> GetPanelistList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static Panelist BindRowToClassObject(DataRow dataRow)
        {
            var objRespondent = new PersistanceRespondent();
            var objCustomer = new PersistanceCustomer();
            return new Panelist
                       {
                           PanelistId = (string)dataRow["PanelistId"],
                           PanelistName = (string)dataRow["PanelistName"],
                           Respondent = objRespondent.GetRespondent((string) dataRow["RespondentId"]),
                           Customer = objCustomer.GetCustomer((string) dataRow["CustomerId"])
                       };
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Panelist), method)
            {
                Parameters = parameters
            };
        }

    }
}
