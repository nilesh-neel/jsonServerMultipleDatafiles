﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
   public class PersistanceQuestion :IQuestion 
    {
       public Question GetQuestion(string questionId)
       {
           var parameters = new Dictionary<string, string> { { "QuestionId", questionId } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
       }

       public List<Question> GetQuestionBySurveyId(string surveyId)
       {
           var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return GetQuestionList(dsReturn);
       }

       public bool SaveQuestion(Question question)
       {
           try
           {
               var dataManager = GetDataManagerObject((IDictionary<string, string>)question, DataManager.MethodType.Set);
               var dsReturn = dataManager.GetSetDataFromDb();
               return (string)dsReturn.Tables[0].Rows[0][0] == "0";
           }
           catch (Exception)
           {
               return false;
           }
       }

       private static Question BindRowToClassObject(DataRow dataRow)
       {
           var objCustomer = new PersistanceCustomer();
           var objAnswers = new PersistanceAnswer();
           var objMedia = new PersistanceMedia();
           var objSkipLogic = new PersistanceSkipLogic();
           return new Question
                      {
                          QuestionId = (string)dataRow["QuestionId"],
                          Customer = objCustomer.GetCustomer((string)dataRow["CustomerId"]),
                          QuestionType = (Question.QuestionTypes)dataRow["QuestionTypeId"],
                          Answers = objAnswers.GetAnswers((string)dataRow["QuestionId"]),
                          Media = objMedia.GetMediaInfo((string)dataRow["QuestionId"]),
                          SkipLogic = objSkipLogic.GetSkipLogic((string)dataRow["QuestionId"]),
                          ForceResponse = (bool)dataRow["ForceResponse"],
                          HasEmailTrigger = (bool)dataRow["HasEmailTrigger"],
                          HasMedia = (bool)dataRow["HasMedia"],
                          HasSkipLogic = (bool)dataRow["HasSkipLogic"],
                          QuestionText = (string)dataRow["QuestionText"],
                          IsDeleted = (bool)dataRow["IsDeleted"]
                      };
       }

       private static List<Question> GetQuestionList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select BindRowToClassObject(row)).ToList();
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(Question), method)
           {
               Parameters = parameters
           };
       }

    }
}
