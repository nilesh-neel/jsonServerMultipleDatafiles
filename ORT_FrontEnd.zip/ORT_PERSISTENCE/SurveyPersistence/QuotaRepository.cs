﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class QuotaRepository : IQuota
    {
        public bool SaveQuota(Quota quota)
        {
            try
            {
                var dataManager = new DataManager(typeof(Quota), DataManager.MethodType.Set)
                {
                    Parameters = (IDictionary<string, string>)quota
                };
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Quota GetQuota(string surveyId)
        {
            var parameters = new Dictionary<string, string> {{ "SurveyId", surveyId } };
            var dataManager = new DataManager(typeof(Quota), DataManager.MethodType.Get)
            {
                Parameters = parameters
            };
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]):null;
        }

        private static Quota BindRowToClassObject(DataRow dataRow)
        {
            return new Quota
                       {
                           QuotaId = dataRow["QuotaId"].ToString(),
                           QuotaLimit = dataRow["Limit"].ToString()
                       };
        }
    }
}
