﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class ResponsesRepository : IReponses
    {
        #region Implementation of IReponses

        public bool SaveResponse(List<Responses> userResponse)
        {
            var dataManager = GetDataManagerObject(new Dictionary<string, string>
                {
                    {"XmlData", ObjectXmlHelper.ToXml(userResponse)}
                }, DataManager.MethodType.Set);

            dataManager.Operation = "SaveSurveyResponse";

            var dsReturn = dataManager.GetSetDataFromDb();

            if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
            {
                return true;
            }

            throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
        }

        public bool CompleteSurvey(string surveyId, string sessionId)
        {
            var dataManager = GetDataManagerObject(new Dictionary<string, string>
                {
                    {"SurveyId", surveyId},
                    {"SessionId",sessionId}
                }, DataManager.MethodType.Set);

            dataManager.Operation = "CompleteSurvey";

            var dsReturn = dataManager.GetSetDataFromDb();

            if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
            {
                return true;
            }

            throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
        }


        public List<Answer> GetResponseAnswers(string surveyId, string questionId, string sessionId)
        {
            var parameters = new Dictionary<string, string> { { "QuestionId", questionId }, { "SurveyId", surveyId }, { "SessionId", sessionId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetSurveyResponses";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetResponseList(dsReturn, questionId) : null;
        }

        private static List<Answer> GetResponseList(DataSet dsData, string questionId)
        {
            return (from DataRow row in dsData.Tables[0].Rows select new Answer { AnswerId = row["AnswerId"].ToString(), AnswerText = row["AnswerText"].ToString() }).ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Responses), method)
            {
                Parameters = parameters
            };
        }
        #endregion
    }
}
