﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class QuestionRepository : IQuestion
    {
        public Question GetQuestion(string questionId)
        {
            var parameters = new Dictionary<string, string> { { "QuestionId", questionId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetSurveyQuestions";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }

        public List<Question> GetQuestionBySurveyId(string surveyId)
        {
            var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetSurveyQuestions";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetQuestionList(dsReturn) : null;
        }

        public List<Question> GetQuestionBySessionId(string surveyId, string sessionId)
        {
            var parameters = new Dictionary<string, string> { { "SurveyId", surveyId }, { "SessionId", sessionId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetSurveyBySession";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetQuestionList(dsReturn) : null;
        }

        public bool SaveQuestion(Question question)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)question, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static Question BindRowToClassObject(DataRow dataRow)
        {
            return new Question
                       {
                           QuestionId = dataRow["QuestionId"].ToString(),
                           QuestionType = (Question.QuestionTypes)dataRow["QuestionTypeId"],
                           Customer = new Customer { CustomerId = dataRow["CustomerId"].ToString() },
                           ForceResponse = Convert.ToBoolean(dataRow["ForceResponse"]),
                           HasEmailTrigger = Convert.ToBoolean(dataRow["HasEmailTrigger"]),
                           HasMedia = Convert.ToBoolean(dataRow["HasMedia"]),
                           HasSkipLogic = Convert.ToBoolean(dataRow["HasSkipLogic"]),
                           QuestionText = dataRow["QuestionText"].ToString(),
                           IsDeleted = Convert.ToBoolean(dataRow["IsDeleted"]),
                           DefaultAnswer = new Answer { AnswerId = dataRow["DefaultAnswerId"].ToString()},
                           PlayListId = dataRow["PlayListId"].ToString()
                       };
        }

        private static List<Question> GetQuestionList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Question), method)
            {
                Parameters = parameters
            };
        }

    }
}
