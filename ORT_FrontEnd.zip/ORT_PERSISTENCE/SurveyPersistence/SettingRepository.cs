﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class SettingRepository : ISetting
    {
        public bool SaveSetting(Setting setting)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)setting, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Setting> GetSettingBySurveyId(string surveyId)
        {
            var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetSettingList(dsReturn) : null;
        }

        public Setting GetSetting(string settingId)
        {
            var parameters = new Dictionary<string, string> { { "SettingId", settingId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }

        public Setting GetSetting(string settingId, string settingName)
        {
            var parameters = new Dictionary<string, string> { { "SettingId", settingId }, { "SettingName", settingName } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }

        private static Setting BindRowToClassObject(DataRow dataRow)
        {
            return new Setting
                       {
                           SettingId = dataRow["SettingId"].ToString(),
                           SettingName = dataRow["SettingName"].ToString(),
                           Value = dataRow["Value"].ToString(),
                           DisplayText = dataRow["DisplayText"].ToString(),
                           IsAassigned = string.IsNullOrEmpty(dataRow["SurveyId"].ToString())
                       };
        }

        private static List<Setting> GetSettingList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Setting), method)
            {
                Parameters = parameters
            };
        }
    }
}
