﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
   public class PersistanceSetting : ISetting 
    {
       public bool SaveSetting(Setting setting)
       {
           try
           {
               var dataManager = GetDataManagerObject((IDictionary<string, string>)setting, DataManager.MethodType.Set);
               var dsReturn = dataManager.GetSetDataFromDb();
               return (string)dsReturn.Tables[0].Rows[0][0] == "0";
           }
           catch (Exception)
           {
               return false;
           }
       }

       public List<Setting> GetSettingBySurveyId(string surveyId)
       {
           var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return GetSettingList(dsReturn);
       }

       public Setting GetSetting(string settingId)
       {
           var parameters = new Dictionary<string, string> { { "SettingId", settingId }};
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
       }

       public Setting GetSetting(string settingId, string settingName)
       {
           var parameters = new Dictionary<string, string> { { "SettingId", settingId }, { "SettingName", settingName } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
       }

       private static Setting BindRowToClassObject(DataRow dataRow)
       {
           var objCustomer = new PersistanceCustomer();
           return new Setting
                      {
                          Customer = objCustomer.GetCustomer((string) dataRow["CustomerId"]),
                          DisplayText = (string) dataRow["DisplayText"],
                          SettingId = (string) dataRow["SettingId"],
                          SettingName = (string) dataRow["SettingName"],
                          Value = (string) dataRow["Value"]
                      };
       }

       private  List<Setting> GetSettingList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select BindRowToClassObject(row)).ToList();
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters,DataManager.MethodType method)
       {
           return new DataManager(typeof(Setting), method)
           {
               Parameters = parameters
           };
       }
    }
}
