﻿using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;


namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PersistanceCustomer : ICustomer
    {
        public Customer GetCustomer(string customerId)
        {
            var parameters = new Dictionary<string, string> { { "CustomerId", customerId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindDatasetToClass(dsReturn);
        }

        public Customer GetCustomer(string customerId, string customerName)
        {
            var parameters = new Dictionary<string, string> { { "CustomerId", customerId }, { "CustomerName", customerName } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindDatasetToClass(dsReturn);
        }

        private static Customer BindDatasetToClass(DataSet dsData)
        {
            return new Customer
            {
                CustomerId = dsData.Tables[0].Rows[0]["Customer_id"].ToString(),
                CustomerName = dsData.Tables[0].Rows[0]["Customer_Name"].ToString(),
            };
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Customer), method)
            {
                Parameters = parameters
            };
        }
    }
}
