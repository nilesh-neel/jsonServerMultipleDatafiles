﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PersistanceSurvey : ISurvey
    {
        public bool SaveSurvey(Survey survey)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>) survey, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Survey> GetSurvey()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return GetSurveyList(dsReturn);
        }

        public List<Survey> GetSurvey(string customerId)
        {
            var parameters = new Dictionary<string, string> { { "CustomerId", customerId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return GetSurveyList(dsReturn);
        }

        public Survey GetSurvey(string customerId, string surveyId)
        {
            var parameters = new Dictionary<string, string> { { "CustomerId", customerId }, { "SurveyId", surveyId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        

        private static List<Survey> GetSurveyList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static Survey BindRowToClassObject(DataRow dataRow)
        {
            var objUser = new PersistanceUser();
            var objCustomer = new PersistanceCustomer();
            var objQuestion = new PersistanceQuestion();
            var objQuota = new PersistanceQuota();
            var objReward = new PersistanceReward();
            var objSettings = new PersistanceSetting();
            return new Survey
            {
                SurveyId = (string)dataRow["SurveyId"],
                SurveyName = (string)dataRow["SurveyName"],
                RewardEnabled = (bool)dataRow["RewardEnabled"],
                CreatedBy = objUser.GetUser((string)dataRow["CreatedBy"]),
                CreatedDateTime = (DateTime)dataRow["CreatedDate"],
                ModifiedBy = objUser.GetUser((string)dataRow["ModifiedBy"]),
                ModifiedDateTime = (DateTime)dataRow["ModifiedDate"],
                Customer = objCustomer.GetCustomer((string)dataRow["CustomerId"]),
                Questions = objQuestion.GetQuestionBySurveyId((string)dataRow["SurveyId"]),
                Quota = objQuota.GetQuota((string)dataRow["SurveyId"]),
                Reward = objReward.GetReward((string)dataRow["SurveyId"]),
                Settings = objSettings.GetSettingBySurveyId((string)dataRow["SurveyId"]),
                Starred = (bool)dataRow["StarMarked"]
            };
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Survey), method)
            {
                Parameters = parameters
            };
        }
        
    }
}
