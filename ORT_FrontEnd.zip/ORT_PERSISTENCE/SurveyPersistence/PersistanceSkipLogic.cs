﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PersistanceSkipLogic : ISkipLogic
    {
        public bool SaveSkipLogic(SkipLogic skipLogic)
        {
            try
            {
                var dataManager = new DataManager(typeof(SkipLogic), DataManager.MethodType.Set)
                {
                    Parameters = (IDictionary<string, string>)skipLogic
                };
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public SkipLogic GetSkipLogic(string questionId)
        {
            var parameters = new Dictionary<string, string> { { "QuestionId", questionId } };
            var dataManager = new DataManager(typeof(SkipLogic), DataManager.MethodType.Get)
            {
                Parameters = parameters
            };
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindDatasetToClass(dsReturn);
        }

        private static SkipLogic BindDatasetToClass(DataSet dsData)
        {
            return new SkipLogic
                       {
                           LogicExpression = (string)dsData.Tables[0].Rows[0]["LogicExpression"],
                           FalseAction = (string)dsData.Tables[0].Rows[0]["FalseAction"],
                           TrueAction = (string)dsData.Tables[0].Rows[0]["TrueAction"]
                       };
        }
    }
}
