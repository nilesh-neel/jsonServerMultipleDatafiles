﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class PlayListRepository : IPlayList
    {
        public PlayList GetPlayList(string playListId)
        {
            var parameters = new Dictionary<string, string> { { "PlayListId", playListId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetPlayList";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }
        private static PlayList BindRowToClassObject(DataRow dataRow)
        {
            return new PlayList
                       {
                           PlayListId = dataRow["PlayListId"].ToString(),
                           PlayLisName = dataRow["PlayListName"].ToString(),
                           Songs = GetSongs(dataRow["PlayListId"].ToString())
                       };
        }

        private static List<FileLibrary> GetSongs(string playListId)
        {
            var parameters = new Dictionary<string, string> { { "PlayListId", playListId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetSongList";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetSongList(dsReturn) : null;
        }

        private static List<FileLibrary> GetSongList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToSongClassObject(row)).ToList();
        }

        private static FileLibrary BindRowToSongClassObject(DataRow dataRow)
        {
            return new FileLibrary
                       {
                           FileLibraryId = dataRow["FileLibId"].ToString()
                       };
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(PlayList), method)
            {
                Parameters = parameters
            };
        }
    }
}
