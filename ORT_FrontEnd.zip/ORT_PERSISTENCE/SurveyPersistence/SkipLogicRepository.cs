﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class SkipLogicRepository : ISkipLogic
    {
        public bool SaveSkipLogic(SkipLogic skipLogic)
        {
            try
            {
                var dataManager = new DataManager(typeof(SkipLogic), DataManager.MethodType.Set)
                {
                    Parameters = (IDictionary<string, string>)skipLogic
                };
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<SkipLogic> GetSkipLogic(string surveyId)
        {
            var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
            var dataManager = new DataManager(typeof(SkipLogic), DataManager.MethodType.Get)
            {
                Parameters = parameters
            };
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetSkipLogicList(dsReturn) : null;
        }

        public SkipLogic GetMediaSkipLogic(string questionId)
        {
            var parameters = new Dictionary<string, string> { { "QuestionId", questionId } };
            var dataManager = new DataManager(typeof(SkipLogic), DataManager.MethodType.Get)
            {
                Parameters = parameters,
                Operation = "MediaSkipLogic"
            };
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindDatasetToClass(dsReturn.Tables[0].Rows[0]) : null;
        }

        private static List<SkipLogic> GetSkipLogicList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindDatasetToClass(row)).ToList();
        }

        private static SkipLogic BindDatasetToClass(DataRow dataRow)
        {
            return new SkipLogic
                       {
                           LogicExpression = dataRow["LogicExpression"].ToString(),
                           FalseAction = dataRow["FalseAction"].ToString(),
                           TrueAction = dataRow["TrueAction"].ToString()
                       };
        }

    }
}
