﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;


namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class CustomerRepository : ICustomer
    {
        public static string Message { get; set; }
        public Customer GetCustomer(string customerId)
        {

            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", customerId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetCustomer";
                var dsReturn = dataManager.GetSetDataFromDb();
                return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Customer> SearchCustomer(string customerName, string abbrevation)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "Abbreviation", abbrevation }, { "CustomerName", customerName } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchCustomer";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetCustomerList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }

        }

        public List<Customer> GetCustomerMaster()
        {
            try
            {
                var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
                dataManager.Operation = "CustomerMaster";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetCustomerList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool SaveCustomer(Customer cust)
        {
            Message = "";
            var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(cust) } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
            var dsReturn = dataManager.GetSetDataFromDb();
            if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
            {
                cust.CustomerId = dsReturn.Tables[0].Rows[0]["CustomerId"].ToString();
                return true;
            }
            else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
            {
                Message=dsReturn.Tables[0].Rows[0]["Remark"].ToString();
                return false;
            }
            throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
        }

        public bool DeleteCustomer(string customerName, string abbrevation)
        {
            var parameters = new Dictionary<string, string> { { "CustomerName",customerName }, 
            { "Abbreviation", abbrevation } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
            dataManager.Operation = "DeleteCustomer";
            var dsReturn = dataManager.GetSetDataFromDb();
            if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                return true;
            throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
        }

        private static List<Customer> GetCustomerList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static Customer BindRowToClassObject(DataRow dataRow)
        {
            return new Customer
            {
                CustomerId = dataRow["CustomerId"].ToString(),
                CustomerName = dataRow["CustomerName"].ToString(),
                Abbreviation = dataRow["Abbreviation"].ToString(),
                Address1 = dataRow["Address1"].ToString(),
                Address2 = dataRow["Address2"].ToString(),
                CityCode = dataRow["City"].ToString(),
                ContactPerson = dataRow["ContactPerson"].ToString(),
                Email = dataRow["Email"].ToString(),
                CountryCode = dataRow["Country"].ToString(),
                Phone1 = dataRow["Phone1"].ToString(),
                Phone2 = dataRow["Phone2"].ToString(),
                StateCode = dataRow["State"].ToString(),
                WebSite = dataRow["Website"].ToString(),
                ZipCode = dataRow["ZipCode"].ToString(),
                IsActive = Convert.ToBoolean(dataRow["Status"].ToString()),
                CreatedBy = new User { UserId = dataRow["CreatedBy"].ToString() },
                CreatedOn = dataRow["CreatedOn"].ToString(),
                ModifiedBy = new User { UserId = dataRow["ModifiedBy"].ToString() },
                ModifiedOn = dataRow["ModifiedOn"].ToString(),
            };
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Customer), method)
            {
                Parameters = parameters
            };
        }
    }
}
