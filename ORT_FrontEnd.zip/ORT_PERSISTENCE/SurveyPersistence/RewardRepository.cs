﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class RewardRepository : IReward
    {
        public bool SaveReward(Reward reward)
        {
            try
            {
                var dataManager = new DataManager(typeof(Reward), DataManager.MethodType.Set)
                {
                    Parameters = (IDictionary<string, string>)reward
                };
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Reward GetReward(string surveyId)
        {
            var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
            var dataManager = new DataManager(typeof(Reward), DataManager.MethodType.Get)
            {
                Parameters = parameters
            };
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }

        private static Reward BindRowToClassObject(DataRow dataRow)
        {
            var objCustomer = new CustomerRepository();
            return new Reward
                       {
                           ApproxValue = Convert.ToInt32(dataRow["ApproxValue"]),
                           Customer = objCustomer.GetCustomer(dataRow["CustomerId"].ToString()),
                           Description = dataRow["RewardDescription"].ToString(),
                           EndDate = (DateTime)dataRow["EndDate"],
                           Fees = Convert.ToInt32(dataRow["Fees"]),
                           Name = dataRow["RewardName"].ToString(),
                           RewardId = dataRow["RewardId"].ToString()
                       };
        }

    }
}
