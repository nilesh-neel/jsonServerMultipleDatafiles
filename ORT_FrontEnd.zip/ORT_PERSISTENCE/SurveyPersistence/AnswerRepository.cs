﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;

namespace ORT_PERSISTENCE.SurveyPersistence
{
    public class AnswerRepository : IAnswer
    {
        public List<Answer> GetAnswers(string questionId)
        {
            var parameters = new Dictionary<string, string> { { "QuestionId", questionId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetAnswerList(dsReturn) : null;
        }

        public List<Answer> GetMediaAnswers()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            dataManager.Operation = "GetMediaAnswers";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? GetAnswerList(dsReturn) : null;
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Answer), method)
            {
                Parameters = parameters
            };
        }

        private static List<Answer> GetAnswerList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select BindRowToClassObject(row)).ToList();
        }

        private static Answer BindRowToClassObject(DataRow dataRow)
        {
            return new Answer
                       {
                           AnswerId = dataRow["AnswerId"].ToString(),
                           AnswerDesc = dataRow["Answer"].ToString(),
                           AnswerText = dataRow["AnswerText"].ToString()
                       };
        }

    }
}
