﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Xml;
using ORT_HELPERS.Helpers;
using SmartConnect;

namespace ORT_PERSISTENCE
{
    public class DataManager
    {
        public enum MethodType
        {
            [Description("GET")]
            Get = 1,
            [Description("SET")]
            Set = 2
        }

        public DataManager(Type classType, MethodType methodType)
        {
            MapType = classType;
            Method = methodType;
        }

        public IDictionary<string, string> Parameters { get; set; }
        public string Operation { get; set; }
        public Type MapType { get; set; }
        private MethodType Method { get; set; }

        public DataSet GetSetDataFromDb()
        {
            try
            {
                var dbManager = GetDdManagerObject();
                var dbMap = GetDbMap(MapType, DescriptionHelper.GetDescription(Method), Operation);
                var arrParam = dbMap.Parameters == null ? null : dbMap.Parameters.ToArray();
                var arrValues = dbMap.Parameters == null ? null : GetValueArray(dbMap, Parameters);
                return dbManager.ExecuteDataSet(dbMap.SpName, arrParam, arrValues, false); ;
            }
            catch (Exception)
            {
                throw; 
            }
        }

        public static DBManagerTest GetDdManagerObject()
        {
            return new DBManagerTest
                       {
                           CommandTimeOut = int.Parse(SessionHelper.AppSettings.CommandTimeout),
                           DBServiceName = SessionHelper.AppSettings.DataBaseService,
                           DatabaseName = SessionHelper.AppSettings.DataBaseName,
                           DBUserId = SessionHelper.AppSettings.DataBaseUser,

                           DBPassword = SessionHelper.AppSettings.DataBasePassWord,
                           DataBaseType = SessionHelper.AppSettings.DataBaseType,
                           EnableLog = Convert.ToBoolean(SessionHelper.AppSettings.EnableLog),
                           LogFolderPath = SessionHelper.AppSettings.LogFolderPath
                       };
        }

        private static string[] GetValueArray(DbMap dbMap, IDictionary<string, string> parameters)
        {
            var arrValues = new string[dbMap.Parameters.Count];
            for (var elementCntr = 0; elementCntr < dbMap.Parameters.Count; elementCntr++)
            {
                if (parameters != null)
                {
                    parameters.TryGetValue(dbMap.ClassProperties[elementCntr], out arrValues[elementCntr]);
                }
                else
                {
                    arrValues[elementCntr] = "";
                }
            }
            return arrValues;
        }

        private static DbMap GetDbMap(Type returntype, string fetchType, string operation)
        {
            var objXml = new XmlDocument();
            objXml.Load(AppDomain.CurrentDomain.RelativeSearchPath + "\\XMLMappings\\" + returntype.Name + ".xml");

            var objReqNodeList = GetReqNodeList(fetchType, operation, objXml);

            if (objReqNodeList == null)
            {
                return null;
            }
            var objReqNode = objReqNodeList[0];

            var selectNodes = objReqNode.SelectNodes("spName");

            if (selectNodes == null)
            {
                return null;
            }
            var dbMapData = new DbMap { SpName = selectNodes[0].InnerText };
            var xmlNodeList = objReqNode.SelectNodes("MapParam");
            if (xmlNodeList != null && xmlNodeList.Count != 0)
            {
                if (GetParameters(xmlNodeList, dbMapData)) return null;
            }
            return dbMapData;
        }

        private static XmlNodeList GetReqNodeList(string fetchType, string operation, XmlDocument objXml)
        {
            var objReqNodeList = operation != null && operation.Trim() != ""
                                     ? objXml.SelectNodes("Request/RequestType[@FetchType='" + fetchType + "' and @Operation='" +
                                                          operation + "']")
                                     : objXml.SelectNodes("Request/RequestType[@FetchType='" + fetchType + "']");
            return objReqNodeList;
        }

        private static bool GetParameters(XmlNodeList xmlNodeList, DbMap dbMapData)
        {
            dbMapData.Parameters = new List<string>();
            dbMapData.ClassProperties = new List<string>();
            for (var i = 0; i < xmlNodeList.Count; i++)
            {
                var dbParam = xmlNodeList[i].SelectSingleNode("DbParam");
                var classParam = xmlNodeList[i].SelectSingleNode("ClassParam");
                if (dbParam == null) continue;

                dbMapData.Parameters.Add(string.IsNullOrEmpty(dbParam.InnerText) == true ? null : dbParam.InnerText);

                if (classParam != null)
                    dbMapData.ClassProperties.Add(string.IsNullOrEmpty(classParam.InnerText) == true
                                                      ? null
                                                      : classParam.InnerText);
            }

            return dbMapData.Parameters.Count != dbMapData.ClassProperties.Count;
        }

        
        

        
    }
}
