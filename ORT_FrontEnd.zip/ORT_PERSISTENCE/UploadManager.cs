﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using ORT_PERSISTENCE.UploadObjects.Class;
using SmartConnect;

namespace ORT_PERSISTENCE
{
    public class UploadManager
    {
        public bool ImportFile(Upload uploadData)
        {
            bool functionReturnValue;
            try
            {
                var dataManager = DataManager.GetDdManagerObject();
                dataManager.FileName = uploadData.FileName;

                switch (uploadData.Extension.ToString().ToUpper())
                {
                    case ".CSV":
                        dataManager.FileType = FileType.TEXTDILIMETED;
                        dataManager.Delimiter = ",";
                        dataManager.HasRowHeaders = true;
                        break;
                    case ".XLS":
                    case ".XLSX":
                        var sheetName = GetExcelSheetName();
                        dataManager.FileType = FileType.EXCEL;
                        dataManager.SheetName = sheetName.Replace("$", "");
                        uploadData.SheetName = dataManager.SheetName;
                        AddProcessData(uploadData);
                        break;
                }
                dataManager.FolderPath = uploadData.FolderPath;
                var objSr = new StreamReader(uploadData.XmlMapFile);
                dataManager.XMLMapping = objSr.ReadToEnd();
                objSr.Close();
                dataManager.DBTableName = uploadData.TempTableName;
                dataManager.ConnectionTimeOut = 5000;
                dataManager.EnablePooling = true;
                dataManager.MinPoolSize = 10;
                dataManager.UnMappedFieldIndicator = "-";
                dataManager.DTSType = DTSType.IMPORT;
                functionReturnValue = dataManager.ExecuteImportDTS();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return functionReturnValue;
        }

        private static string GetExcelSheetName()
        {
            
            var tbName = "Sheet20" + DateTime.Now.TimeOfDay;
            return tbName.Replace(":", "").Replace(".", "");
            

        }

        private  void AddProcessData(Upload uploadData)
        {
            var filePath = uploadData.FolderPath + "\\" + uploadData.FileName;
            var sbConnection = GetOleDbConnection(filePath);
            var listSheet = new List<string>();
            using (var conn = new OleDbConnection(sbConnection.ToString()))
            {
                conn.Open();
                var dtSheet = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                listSheet.AddRange(from DataRow drSheet in dtSheet.Rows where drSheet["TABLE_NAME"].ToString().Contains("$") select drSheet["TABLE_NAME"].ToString());
                AddSessionIdToExcel(listSheet, conn, uploadData);
            }
        }

        private static OleDbConnectionStringBuilder GetOleDbConnection(string filePath)
        {
            var sbConnection = new OleDbConnectionStringBuilder {DataSource = filePath};
            var strExtendedProperties = GetExtendedProperties(filePath, sbConnection);
            sbConnection.Add("Extended Properties", strExtendedProperties);
            return sbConnection;
        }

        private static string GetExtendedProperties(string filePath, OleDbConnectionStringBuilder sbConnection)
        {
            var strExtendedProperties = string.Empty;
            if (Path.GetExtension(filePath).Equals(".xls")) //for 97-03 Excel file
            {
                sbConnection.Provider = "Microsoft.Jet.OLEDB.4.0";
                strExtendedProperties = "Excel 8.0;HDR=Yes;"; //IMEX=1";//HDR=ColumnHeader,IMEX=InterMixed
            }
            else if (Path.GetExtension(filePath).Equals(".xlsx")) //for 2007 Excel file
            {
                sbConnection.Provider = "Microsoft.ACE.OLEDB.12.0";
                strExtendedProperties = "Excel 12.0;HDR=Yes;"; //IMEX=1";
            }
            return strExtendedProperties;
        }

        private void AddSessionIdToExcel(IList<string> listSheet, OleDbConnection conn, Upload uploadData)
        {

            var dataAdapter = GetNewSheet(listSheet, conn, uploadData);

            var cmdUpdate = new OleDbCommand("Update [" + uploadData.SheetName.Replace(":", "").Replace(".", "") + "$] " +
            "SET [SessionId]=" + uploadData.SessionId + ", [ParentId]=" + uploadData.ParentId +
                ", [CustomerId]=" + uploadData.CustomerId + ", [UserId]=" + uploadData.UploadedBy, conn);

            var dataAdapter2 =
              new OleDbDataAdapter("SELECT * FROM [" + uploadData.SheetName.Replace(":", "").Replace(".", "") + "$] ", conn);
            var myDataSet = new DataSet();
            dataAdapter2.Fill(myDataSet, "ExcelInfo");
            dataAdapter2.UpdateCommand = cmdUpdate;
            cmdUpdate.ExecuteNonQuery();
            dataAdapter.Update(myDataSet, "ExcelInfo");
            myDataSet.AcceptChanges();
            
        }

        private OleDbDataAdapter GetNewSheet(IList<string> listSheet, OleDbConnection conn, Upload uploadData)
        {
            var cmd =
                new OleDbCommand("SELECT *,'' as [SessionId],'' as [ParentId],'' as [CustomerId],'' as [UserId] into [" + uploadData.SheetName.Replace(":", "").Replace(".", "") + "] FROM [" + listSheet[0] +"]", conn);
            var dataAdapter = new OleDbDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            return dataAdapter;
        }
    }
}
