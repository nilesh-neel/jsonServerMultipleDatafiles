﻿using System;
using ORT_PERSISTENCE.UploadObjects.Class;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_PERSISTENCE.UploadObjects.Interface
{
    public interface IGraphicsUpload
    {
        Upload GetGraphicFiles(string grapLibId, string category);
        GraphicLibrary SaveGraphicFiles(Upload objFileUpload);
    }
}
