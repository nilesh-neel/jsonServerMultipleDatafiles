﻿using System.Collections.Generic;
using ORT_PERSISTENCE.UploadObjects.Class;

namespace ORT_PERSISTENCE.UploadObjects.Interface
{
   public interface IUpload
   {
       object GetTemporaryEntity(Upload objUp);
       List<string> ValidateData(IEnumerable<object> tempData);
       bool MoveExceptionData(string sessionId);
       bool MoveValidData(string sessionId);
       object GetException(string sessionId);
       Upload GetSessionId(Upload objFileUpload);
   }
}
