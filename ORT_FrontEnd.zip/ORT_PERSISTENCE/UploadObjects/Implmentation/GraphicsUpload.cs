﻿using ORT_PERSISTENCE.UploadObjects.Class;
using ORT_PERSISTENCE.UploadObjects.Interface;
using System;
using ORT_HELPERS.Helpers;
using ORT_CORE.Class.LibraryClasses;
using System.Collections.Generic;
using ORT_PERSISTENCE;
using System.Data;
using ORT_PERSISTENCE.LibraryPersistence;
using System.Linq;
namespace ORT_PERSISTENCE.UploadObjects.Implmentation
{
   public class GraphicsUpload:IGraphicsUpload
    {
      #region IGraphicsUpload Members

       public Upload GetGraphicFiles(string grapLibId, string category)
        {            
           try
            {
                var parameters = new Dictionary<string, string> {
                { "GrapphicLibId", grapLibId }, { "category", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.MapType = typeof(GraphicLibrary);
                dataManager.Operation = "SaveGraphicsFile";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return BindRowToUploadSessionClass(dsReturn);
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

       public GraphicLibrary SaveGraphicFiles(Upload objFileUpload)
        {
            try
            {
                var objUpSession = SetDataToClass(objFileUpload);
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(objUpSession) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.MapType = typeof(GraphicLibrary);
                dataManager.Operation = "SaveGraphicsFile";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return BindRowToGraphicInfo(dsReturn.Tables[0].Rows[0]);                    
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
            
        }

       private static GraphicLibrary BindRowToGraphicInfo(DataRow dataRow)
       {
           var libId = Convert.ToString(dataRow["LibId"]);
           var cateId = Convert.ToString(dataRow["CategoryId"]);
           return new GraphicLibrary
           {
               GraphicLibraryId = Convert.ToString(dataRow["GraphicFileId"]),
               GraphicFileName = (string)dataRow["GraphicFileName"],
               RelativePath = !string.IsNullOrEmpty(cateId) ?
                 SessionHelper.AppSettings.GraphicRelativePath + "/" + libId + "/" + cateId :
                 SessionHelper.AppSettings.GraphicRelativePath + "/" + libId,
               Category = new LibraryCategory { CategoryId = cateId },
               LibraryId = Convert.ToString(dataRow["LibId"]),
               FileType = GraphicLibrary.ImageType.Jpg
           };
       }

        private static Upload SetDataToClass(Upload objFileUpload)
        {


            return new Upload
            {
                ParentId = objFileUpload.ParentId,
                Category = objFileUpload.Category,
                CustomerId = SessionHelper.LoggedinCustomer,
                FileName = objFileUpload.FileName,
                Extension = objFileUpload.Extension,
                FileType = "Graphics",
                FolderPath = objFileUpload.FolderPath,
                UploadedBy = SessionHelper.LoggedinUserId,
                UploadedDate = DateTime.Now.ToString("yyyy-MM-dd"),
            };
        }

        private static Upload BindRowToUploadSessionClass(DataSet dsData)
        {

            return new Upload
            {
                FileName = (string)dsData.Tables[0].Rows[0]["FileName"],
                Extension = (string)dsData.Tables[0].Rows[0]["FileName"],
                XmlMapFile = (string)dsData.Tables[0].Rows[0]["FileName"],
                TempTableName = (string)dsData.Tables[0].Rows[0]["FileName"],
                SheetName = (string)dsData.Tables[0].Rows[0]["FileName"],
                FolderPath = (string)dsData.Tables[0].Rows[0]["FileName"],
            };
        }    

      #endregion


        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(GraphicsUpload), method)
            {
                Parameters = parameters
            };
        }

       
    }
}
