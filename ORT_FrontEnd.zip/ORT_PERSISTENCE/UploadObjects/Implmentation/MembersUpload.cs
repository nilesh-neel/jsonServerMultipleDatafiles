﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;
using ORT_PERSISTENCE.UploadObjects.Class;
using ORT_PERSISTENCE.UploadObjects.Interface;

namespace ORT_PERSISTENCE.UploadObjects.Implmentation
{
  public class MembersUpload : IUpload 
    {
      #region Implementation of IUpload

     public Upload GetSessionId(Upload objFileUpload)
      {
          try
          {
              var objUpSession = SetDataToClass(objFileUpload); 
              var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(objUpSession) } };
              var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
              dataManager.Operation = "SaveUploadSession";
              var dsReturn = dataManager.GetSetDataFromDb();
              if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
              {
                  return BindRowToUploadSessionClass(dsReturn, objFileUpload);
              }
              throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
          }
          catch (Exception)
          {
              throw;
          }
      }


      public object GetTemporaryEntity(Upload objUploadFile)
      {
          try
          {
              var objSessionUpload = GetSessionId(objUploadFile);              
              var uploadManager = new UploadManager();
              return uploadManager.ImportFile(objSessionUpload) ? GetTempRespondent(objSessionUpload.SessionId) : null;
          }
          catch (Exception)
          {
              throw;
          }
      }

      private static List<Respondent> GetTempRespondent(string sessionId)
      {
          var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
          var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
          dataManager.Operation = "GetTempRespondent";
          var dsReturn = dataManager.GetSetDataFromDb();
          return (from DataRow row in dsReturn.Tables[0].Rows
                  select BindUploadRespondent(row)).ToList();
      }

      private static Respondent BindUploadRespondent(DataRow dataRow)
      {
          return new Respondent
          {
              TempId = Convert.ToString(dataRow["TempId"]),
              Panel = new Panel { PanelId = Convert.ToString(dataRow["PanelistId"]) },
              FirstName = dataRow["FirstName"].ToString(),
              LastName = dataRow["LastName"].ToString(),
              BirthDate = dataRow["BirthDate"].ToString(),
              Gender = dataRow["Gender"].ToString(),
              RespondentEmailId = dataRow["EmailId"].ToString(),
              Town = dataRow["Town"].ToString(),
              UserDefineColumn1 = Convert.ToString(dataRow["UDF1"]),
              UserDefineColumn2 = Convert.ToString(dataRow["UDF2"]),
              UserDefineColumn3 = Convert.ToString(dataRow["UDF3"]),
              UserDefineColumn4 = Convert.ToString(dataRow["UDF4"]),
              UserDefineColumn5 = Convert.ToString(dataRow["UDF5"]),
              Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },
              //Flag = Convert.ToString(dataRow["Flag"]),
              Status = Convert.ToString(dataRow["Status"]),
              StatusMessage = Convert.ToString(dataRow["StatusMessage"]),
              CreatedBy = new User { UserId = Convert.ToString(dataRow["UserId"]) },
              SessionId = new UploadSession { SessionId = Convert.ToString(dataRow["SessionId"]) }
          };

      }

      

      public List<string> ValidateData(IEnumerable<object> tempData)
      {
          var tempRespondData = tempData.Select(sd => IsTempRespondentValid((Respondent)sd)).ToList();
          return UpdateTempRespondentList(tempRespondData);
          
      }

      private List<string> UpdateTempRespondentList(List<Respondent> tempRespoList)
      {
          var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(tempRespoList) } };
          var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
          dataManager.Operation = "UpdateTempRespondent";
          var dsReturn = dataManager.GetSetDataFromDb();
          List<string> summaryData = new List<string>();
          if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
          {
              summaryData.Add(Convert.ToString(dsReturn.Tables[0].Rows[0]["TotalCount"]));
              summaryData.Add(Convert.ToString(dsReturn.Tables[0].Rows[0]["TotalExceptionCount"]));
              summaryData.Add(Convert.ToString(dsReturn.Tables[0].Rows[0]["TotalInsertCount"]));

              return summaryData;
          }
          throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
      }

      private static Respondent IsTempRespondentValid(Respondent objRespond)
      {         //O=OK,E=Error
          var result = true;
          if (!objRespond.FirstName.Trim().IsAlpha())
          {
              objRespond.StatusMessage = "Invalid First Name. ";
              result = false;
          }
          if (!objRespond.LastName.Trim().IsAlpha())
          {
              objRespond.StatusMessage += "Invalid Last Name. ";
              result = false;
          }
          if (!objRespond.RespondentEmailId.Trim().IsEmail())
          {
              objRespond.StatusMessage += "Invalid EmailId. ";
              result = false;
          }
          if (!objRespond.BirthDate.Trim().IsDateTime())
          {
              objRespond.StatusMessage += "Invalid BirthDate. ";
              result = false;
          }
          if (result)
          {
              objRespond.Status = "O";
              objRespond.StatusMessage = "Success";
          }
          else
          {
              objRespond.Status = "E";
          }

          if (!string.IsNullOrEmpty(objRespond.BirthDate))
          {
            objRespond.Age= RespondentAge(objRespond.BirthDate);
          }

          return objRespond;
      }

      public bool MoveExceptionData(string sessionId)
      {
          try
          {
              var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
              var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
              dataManager.Operation = "GetException";
              var dsReturn = dataManager.GetSetDataFromDb();
              if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                  return true;
              throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
          }
          catch (Exception)
          {
              throw;
          }

      }

      public bool MoveValidData(string sessionId)
      {
          try
          {
              var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
              var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
              dataManager.Operation = "GetBulkException";
              var dsReturn = dataManager.GetSetDataFromDb();
          
              if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
              {
                  return true;
              }
           
              throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
          }
          catch (Exception)
          {
              throw;
          }

      }

      public object GetException(string sessionId)
      {
          try
          {
              var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
              var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
              dataManager.Operation = "GetRespondentException";
              var dsReturn = dataManager.GetSetDataFromDb();

              if (dsReturn.Tables[0].Rows.Count > 0)
              {
                  return BindRowToRespondentException(dsReturn);
              }

              throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
          }
          catch (Exception)
          {
              throw;
          }

      }

      #endregion

      private static string RespondentAge(string birthDate)
      {
          if (birthDate.IsDateTime())
          {
              var birdate = Convert.ToDateTime(birthDate);
              DateTime now = DateTime.Today;
              int age = now.Year - birdate.Year;
              if (now.Month < birdate.Month || (now.Month == birdate.Month && now.Day < birdate.Day)) age--;
              return Convert.ToString(age);              
          }
          return string.Empty;
      }

      private static Upload SetDataToClass(Upload objFileUpload)
      {

          return new Upload
          {
              ParentId = objFileUpload.ParentId,
              CustomerId = objFileUpload.CustomerId,
              FileName = objFileUpload.FileName,
              Extension =objFileUpload.Extension,
              FileType = "Panel",
              UploadedBy = SessionHelper.LoggedinUserId,
              UploadedDate = DateTime.Now.ToString("yyyy-MM-dd"),
          };
      }

      private static Upload BindRowToUploadSessionClass(DataSet dsData, Upload objFileUpload)
      {
     
          return new Upload
          {
              SessionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]),
              FileName = dsData.Tables[0].Rows[0]["FileName"].ToString(),
              Extension =(string) dsData.Tables[0].Rows[0]["Exension"],           
              XmlMapFile = objFileUpload.XmlMapFile,
              TempTableName = objFileUpload.TempTableName,
              SheetName = objFileUpload.SheetName,
              FolderPath = objFileUpload.FolderPath, 
              FileType = dsData.Tables[0].Rows[0]["FileType"].ToString(),
              CustomerId = Convert.ToString(dsData.Tables[0].Rows[0]["CustomerId"]),
              ParentId = Convert.ToString(dsData.Tables[0].Rows[0]["ParentId"]),
              UploadedBy = Convert.ToString(dsData.Tables[0].Rows[0]["UploadedBy"]),
              UploadedDate = dsData.Tables[0].Rows[0]["UploadedDate"].ToString()
          };
      }

      private static RespondentException BindRowToRespondentException(DataSet dsData)
      {
          return new RespondentException
          {
              ExceptionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]),
              SessionId = new UploadSession { SessionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]) },
              Customer = new Customer { CustomerId = Convert.ToString(dsData.Tables[0].Rows[0]["CustomerId"]) },
              RespondentEmailId = (string)dsData.Tables[0].Rows[0]["EmailId"],
              Panel = new Panel { PanelId = Convert.ToString(dsData.Tables[0].Rows[0]["PanelistId"]) },
              FirstName=(string)dsData.Tables[0].Rows[0]["FirstName"],
              LastName=(string)dsData.Tables[0].Rows[0]["LastName"],
              Age = Convert.ToString(dsData.Tables[0].Rows[0]["Age"]),
              BirthDate=Convert.ToString(dsData.Tables[0].Rows[0]["BirthDate"]),
                Gender=(string)dsData.Tables[0].Rows[0]["Gender"],
                Town=(string)dsData.Tables[0].Rows[0]["Town"],
                UserDefineColumn1=(string)dsData.Tables[0].Rows[0]["UDF1"],
                UserDefineColumn2=(string)dsData.Tables[0].Rows[0]["UDF2"],
                UserDefineColumn3=(string)dsData.Tables[0].Rows[0]["UDF3"],
                UserDefineColumn4=(string)dsData.Tables[0].Rows[0]["UDF4"],
                UserDefineColumn5=(string)dsData.Tables[0].Rows[0]["UDF5"],
                Status=(string)dsData.Tables[0].Rows[0]["Status"],
                StatusMessage=(string)dsData.Tables[0].Rows[0]["StatusMessage"],
                ModifiedBy=new User{UserId= Convert.ToString(dsData.Tables[0].Rows[0]["UserId"]) }
          };
      }


      private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
      {
          return new DataManager(typeof(MembersUpload), method)
          {
              Parameters = parameters
          };
      }
    }
}
