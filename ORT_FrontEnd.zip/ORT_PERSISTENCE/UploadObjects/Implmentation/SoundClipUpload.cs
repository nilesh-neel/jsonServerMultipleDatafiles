﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;
using ORT_PERSISTENCE.UploadObjects.Class;
using ORT_PERSISTENCE.UploadObjects.Interface;
using ORT_CORE.Class.LibraryClasses;

namespace ORT_PERSISTENCE.UploadObjects.Implmentation
{
   public class SoundClipUpload : IUpload
    {


        #region IUpload Members

       public object GetTemporaryEntity(Upload objUploadFile)
        {
            try
            {
                var objSessionUpload = GetSessionId(objUploadFile);
                var uploadManager = new UploadManager();
                return uploadManager.ImportFile(objSessionUpload) ? GetTempSoundClipInfo(objSessionUpload.SessionId) : null;
            }
            catch (Exception)
            {
                throw;
            }
        }

       private static List<SoundClip> GetTempSoundClipInfo(string sessionId)
       {
           var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
           dataManager.Operation = "GetTempSoundClip";
           var dsReturn = dataManager.GetSetDataFromDb();
           return (from DataRow row in dsReturn.Tables[0].Rows
                   select BindUploadRespondent(row)).ToList();
       }

       private static SoundClip BindUploadRespondent(DataRow dataRow)
       {
           return new SoundClip
           {
               TempId = Convert.ToString(dataRow["TempId"]),
               FileLibId = Convert.ToString(dataRow["FileLibId"]),
               Artist = dataRow["Artist"].ToString(),
               //SongFileName = dataRow["LastName"].ToString(),
               Title = dataRow["Title"].ToString(),
               Year = dataRow["FileLibYear"].ToString(),
               FilePath = dataRow["FilePath"].ToString(),              
               //Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },              
               Status = Convert.ToString(dataRow["Status"]),
               StatusMessage = Convert.ToString(dataRow["StatusMessage"]),
               //CreatedBy = new User { UserId = Convert.ToString(dataRow["UserId"]) },
               SessionId = new UploadSession { SessionId = Convert.ToString(dataRow["SessionId"]) }
           };

       }
        public List<string> ValidateData(IEnumerable<object> tempData)
        {
            var tempRespondData = tempData.Select(sd => IsTempRespondentValid((SoundClip)sd)).ToList();
            return UpdateTempRespondentList(tempRespondData);
        }
        private List<string> UpdateTempRespondentList(List<SoundClip> tempRespoList)
        {
            var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(tempRespoList) } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
            dataManager.Operation = "UpdateTempSoundClip";
            var dsReturn = dataManager.GetSetDataFromDb();
            List<string> summaryData = new List<string>();
            if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
            {
                summaryData.Add(Convert.ToString(dsReturn.Tables[0].Rows[0]["TotalCount"]));
                summaryData.Add(Convert.ToString(dsReturn.Tables[0].Rows[0]["TotalExceptionCount"]));
                summaryData.Add(Convert.ToString(dsReturn.Tables[0].Rows[0]["TotalInsertCount"]));

                return summaryData;
            }
            throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
        }

        private static SoundClip IsTempRespondentValid(SoundClip objRespond)
        {         //O=OK,E=Error
            var result = true;
            //if (!objRespond.FirstName.Trim().IsAlpha())
            //{
            //    objRespond.StatusMessage = "Invalid First Name. ";
            //    result = false;
            //}
            //if (!objRespond.LastName.Trim().IsAlpha())
            //{
            //    objRespond.StatusMessage += "Invalid Last Name. ";
            //    result = false;
            //}
            //if (!objRespond.RespondentEmailId.Trim().IsEmail())
            //{
            //    objRespond.StatusMessage += "Invalid EmailId. ";
            //    result = false;
            //}
            //if (!objRespond.BirthDate.Trim().IsDateTime())
            //{
            //    objRespond.StatusMessage += "Invalid BirthDate. ";
            //    result = false;
            //}
            if (result)
            {
                objRespond.Status = "O";
                objRespond.StatusMessage = "Success";
            }
            else
            {
                objRespond.Status = "E";
            }          

            return objRespond;
        }

        public bool MoveExceptionData(string sessionId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "GetException";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                    return true;
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool MoveValidData(string sessionId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "GetBulkException";
                var dsReturn = dataManager.GetSetDataFromDb();

                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return true;
                }

                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }

        }

        public object GetException(string sessionId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "SessionId", sessionId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetSoundClipException";
                var dsReturn = dataManager.GetSetDataFromDb();

                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    return BindRowToSoundClipException(dsReturn);
                }

                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static SoundClipException BindRowToSoundClipException(DataSet dsData)
        {
            return new SoundClipException
            {
                ExceptionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]),
                FileLibId = Convert.ToString(dsData.Tables[0].Rows[0]["FileLibId"]),
                Artist = (string)dsData.Tables[0].Rows[0]["Artist"],
                FilePath = (string)dsData.Tables[0].Rows[0]["FilePath"],
                SessionId = new UploadSession { SessionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]) },
                //SongFileName=(string)dsData.Tables[0].Rows[0]["UDF1"],
                Status = (string)dsData.Tables[0].Rows[0]["Status"],
                StatusMessage = (string)dsData.Tables[0].Rows[0]["StatusMessage"],
                Title = (string)dsData.Tables[0].Rows[0]["Title"].ToString(),
                Year = (string)dsData.Tables[0].Rows[0]["FileLibYear"].ToString()
            };
 
        }


        public Upload GetSessionId(Upload objFileUpload)
        {
            try
            {
                var objUpSession = objFileUpload;
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(objFileUpload) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveUploadSession";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return BindRowToUploadSessionClass(dsReturn, objFileUpload);
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static Upload BindRowToUploadSessionClass(DataSet dsData, Upload objFileUpload)
        {

            return new Upload
            {
                SessionId = Convert.ToString(dsData.Tables[0].Rows[0]["SessionId"]),
                FileName = dsData.Tables[0].Rows[0]["FileName"].ToString(),
                Extension = (string)dsData.Tables[0].Rows[0]["Extension"],
                XmlMapFile = objFileUpload.XmlMapFile,
                TempTableName = objFileUpload.TempTableName,
                SheetName = objFileUpload.SheetName,
                FolderPath = objFileUpload.FolderPath,
                FileType = dsData.Tables[0].Rows[0]["FileType"].ToString(),
                CustomerId = Convert.ToString(dsData.Tables[0].Rows[0]["CustomerId"]),
                ParentId = Convert.ToString(dsData.Tables[0].Rows[0]["ParentId"]),
                UploadedBy = Convert.ToString(dsData.Tables[0].Rows[0]["UploadedBy"]),
                UploadedDate = dsData.Tables[0].Rows[0]["UploadedDate"].ToString()
            };
        }
        #endregion

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(SoundClip), method)
            {
                Parameters = parameters
            };
        }
    }

}
