﻿using ORT_CORE.Class.SurveyClasses;
namespace ORT_PERSISTENCE.UploadObjects.Class
{
   public class RespondentException:Respondent
    {
       public string ExceptionId { get; set; }       
    }
}
