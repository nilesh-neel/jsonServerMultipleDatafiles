﻿using ORT_CORE.Class.LibraryClasses;
namespace ORT_PERSISTENCE.UploadObjects.Class
{
   public class SoundClipException:SoundClip
    {
       public string ExceptionId { get; set; }       
    }
}
