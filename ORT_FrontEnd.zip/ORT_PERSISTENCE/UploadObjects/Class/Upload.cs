﻿using System.Collections.Generic;
using ORT_CORE.Class.SurveyClasses;
using System.ComponentModel;

namespace ORT_PERSISTENCE.UploadObjects.Class
{

    public class Upload : UploadSession
    { 
        public enum FileExtension
        {
            [Description("Xls")]
            Xls = 1,
            [Description("Xlsx")]
            Xlsx,
            [Description("Csv")]
            Csv,
            [Description("Dbf")]
            Dbf
        }
        public string FolderPath { get; set; }
        public string XmlMapFile { get; set; }
        public string Extension { get; set; }
        public List<string> Summary { get; set; }
        public string TempTableName { get; set; }
        public string SheetName { get; set; }
        public string Category { get; set; }
    }
}
