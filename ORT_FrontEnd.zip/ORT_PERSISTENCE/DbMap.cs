﻿using System.Collections.Generic;

namespace ORT_PERSISTENCE
{
  public  class DbMap
    {
      public string SpName { get; set; }
      public List<string> Parameters { get; set; }
      public List<string> ClassProperties { get; set; } 
    }
}
