﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_PERSISTENCE.MasterPersistence
{
   public class CityRepository : IMaster 
    {
       public Type HomeType { get { return typeof(City); } }

       #region Implementation of IMaster

       public object GetMasterData()
       {
           try
           {
               var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetCityList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(City), method)
           {
               Parameters = parameters
           };
       }

       private static List<object> GetCityList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindRowToClassObject(row)).ToList();
       }

       private static City BindRowToClassObject(DataRow dataRow)
       {
           return new City
               {
                   CityId = dataRow["CityId"].ToString(),
                   CityCode = dataRow["CityCode"].ToString(),
                   CityName = dataRow["CityName"].ToString()
               };
       }

       #endregion
    }
}
