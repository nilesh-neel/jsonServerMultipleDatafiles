﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_PERSISTENCE.MasterPersistence
{
    public class StateRepository : IMaster
    {
       public Type HomeType { get { return typeof(State); } }

        #region Implementation of IMaster

        public object GetMasterData()
        {
            try
            {
                var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetStateList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<object> GetStateList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToClassObject(row)).ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(State), method)
            {
                Parameters = parameters
            };
        }

        private static State BindRowToClassObject(DataRow dataRow)
        {
            return new State
            {
                StateId = dataRow["StateId"].ToString(),
                StateCode = dataRow["StateCode"].ToString(),
                StateName = dataRow["StateName"].ToString()
            };
        }


        #endregion
    }
}
