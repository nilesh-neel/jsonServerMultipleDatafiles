﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_PERSISTENCE.MasterPersistence
{
   public class RoleRepository : IMaster
    {
       public Type HomeType { get { return typeof(Role); } }
       #region Implementation of IMaster

       public object GetMasterData()
       {
           try
           {
               var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetRoleList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }

       private static List<object> GetRoleList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindRowToClassObject(row)).ToList();
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(Role), method)
           {
               Parameters = parameters
           };
       }

       private static Role BindRowToClassObject(DataRow dataRow)
       {
           return new Role
           {
               RoleId = dataRow["RoleId"].ToString(),
               RoleDesc = dataRow["RoleType"].ToString(),
               RoleType = dataRow["RoleDescription"].ToString(),
               Hierarchy = dataRow["Hierarchy"].ToString()
           };
       }

       #endregion
    }
}
