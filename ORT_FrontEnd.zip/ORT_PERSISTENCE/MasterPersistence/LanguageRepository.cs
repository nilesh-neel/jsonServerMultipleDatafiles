﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_PERSISTENCE.MasterPersistence
{
    public class LanguageRepository : IMaster 
    {
        public Type HomeType { get { return typeof(Language); } }

        #region Implementation of IMaster

        public object GetMasterData()
        {
            try
            {
                var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetLanguageList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<object> GetLanguageList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToClassObject(row)).ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(Language), method)
            {
                Parameters = parameters
            };
        }

        private static Language BindRowToClassObject(DataRow dataRow)
        {
            return new Language
            {
                LanguageId = dataRow["LanguageId"].ToString(),
                LanguageName = dataRow["LangauageName"].ToString()
            };
        }

        #endregion
    }
}
