﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.MasterClasses;
using ORT_CORE.Interface.MasterInterface;

namespace ORT_PERSISTENCE.MasterPersistence
{
    public class TimeZoneRepository :IMaster
    {
        public Type HomeType { get { return typeof(UserTimeZone); } }

        #region Implementation of IMaster

        public object GetMasterData()
        {
            try
            {
                var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetTimeZoneList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<object> GetTimeZoneList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToClassObject(row)).ToList();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(UserTimeZone), method)
            {
                Parameters = parameters
            };
        }

        private static UserTimeZone BindRowToClassObject(DataRow dataRow)
        {
            return new UserTimeZone
            {
                TimeZoneId = dataRow["TimeZoneId"].ToString(),
                TimeZoneName = dataRow["TimeZone"].ToString(),
                LocationName = dataRow["LocationName"].ToString()
            };
        }

        #endregion
    }
}
