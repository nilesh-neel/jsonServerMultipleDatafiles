﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class PersistanceLibrary : ILibrary
    {
        #region Implementation of FileLibrary

        public FileLibrary GetFileLibrary(string libraryId)
        {
            var parameters = new Dictionary<string, string> { { "FileLibId", libraryId } };
            var dataManager = new DataManager(typeof(FileLibrary), DataManager.MethodType.Get)
            {
                Parameters = parameters
            };

            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowDataToLibaryObject(dsReturn.Tables[0].Rows[0]);
        }

        public List<FileLibrary> GetFileLibraryList()
        {
            var dataManager = new DataManager(typeof(FileLibrary), DataManager.MethodType.Get)
            {
                Parameters = null
            };

            var dsReturn = dataManager.GetSetDataFromDb();
            return GetListofFileLibrary(dsReturn);
        }

        public bool SaveFileLibrary(FileLibrary fileLibrary)
        {
            try
            {
                var dataManager = new DataManager(typeof(FileLibrary), DataManager.MethodType.Set)
                {
                    Parameters = (IDictionary<string, string>) fileLibrary
                };
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static FileLibrary BindRowDataToLibaryObject(DataRow dataRow)
        {
            var objCustomer = new PersistanceCustomer();
            return new FileLibrary
                       {
                           Category = (string)dataRow["Category"],
                           Customer = objCustomer.GetCustomer((string) dataRow["CustomerId"]),
                           Extension = (FileLibrary.FileType) dataRow["FileType"],
                           FileLibraryId = (string) dataRow["FileLibId"],
                           FileLibraryName = (string)dataRow["FileLibName"],
                           FileName = (string) dataRow["FileName"],
                           LibType = Library.LibraryType.File,
                           LibraryId = (string)dataRow["LibraryId"],
                           LibraryName = (string)dataRow["LibName"]
                       };
        }

        private static List<FileLibrary> GetListofFileLibrary(DataSet dataSet)
        {
            return (from DataRow row in dataSet.Tables[0].Rows
                    select BindRowDataToLibaryObject(row)).ToList();
        }

        #endregion

        public GraphicLibrary GetGraphicLibrary(string libraryId)
        {
            throw new NotImplementedException();
        }

        public List<GraphicLibrary> GetGraphicLibraryList()
        {
            throw new NotImplementedException();
        }

        public bool SaveGraphicLibrary(GraphicLibrary graphicLibrary)
        {
            throw new NotImplementedException();
        }

        public MessageLibrary GetMessageLibrary(string libraryId)
        {
            throw new NotImplementedException();
        }

        public List<MessageLibrary> GetMessageLibraryList()
        {
            throw new NotImplementedException();
        }

        public bool SaveMessageLibrary(MessageLibrary messageLibrary)
        {
            throw new NotImplementedException();
        }

        public QuestionLibrary GetQuestionLibrary(string libraryId)
        {
            throw new NotImplementedException();
        }

        public List<QuestionLibrary> GetQuestionLibraryList()
        {
            throw new NotImplementedException();
        }

        public bool SaveQuestionLibrary(QuestionLibrary questionLibrary)
        {
            throw new NotImplementedException();
        }

        public SurveyLibrary GetSurveyLibrary(string libraryId)
        {
            throw new NotImplementedException();
        }

        public List<SurveyLibrary> GetSurveyLibraryList()
        {
            throw new NotImplementedException();
        }

        public bool SaveSurveyLibrary(SurveyLibrary surveyLibrary)
        {
            throw new NotImplementedException();
        }

        
    }
}
