﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class SoundClipRepository : ISoundClip
    {
        #region Implementation of ISoundClip

        public SoundClip GetSoundClip(string fileLibId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "FileLibId", fileLibId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                var dsReturn = dataManager.GetSetDataFromDb();
                return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0])                 : null;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public object SearchLibrary(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibraryId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SearchQuestionFromLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool SaveSoundClip(SoundClip soundClip)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)soundClip, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(SoundClip), method)
            {
                Parameters = parameters
            };
        }
        private static SoundClip BindRowToClassObject(DataRow dataRow)
        {
            return new SoundClip
                       {
                           Artist = dataRow["Artist"].ToString(),
                           FilePath = dataRow["FilePath"].ToString(),
                           Title = dataRow["Title"].ToString(),
                           Year  = dataRow["FileLibYear"].ToString(),
                           SongFileName = dataRow["FileName"].ToString()
                       };
        }

        #endregion
    }
}
