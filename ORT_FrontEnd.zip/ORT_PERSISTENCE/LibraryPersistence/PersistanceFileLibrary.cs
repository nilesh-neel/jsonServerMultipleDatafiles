﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class PersistanceFileLibrary : ILibrary
    {
        #region Implementation of ILibrary

        public object GetLibrary(string libraryId)
        {
            var parameters = new Dictionary<string, string> { { "FileLibId", libraryId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        public List<object> GetLibraryList()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return GetFileLibraryList(dsReturn);
        }

        private static List<object> GetFileLibraryList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object) BindRowToClassObject(row)).ToList();
        }

        public bool SaveLibrary(object library)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)library, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(FileLibrary), method)
            {
                Parameters = parameters
            };
        }
        private static FileLibrary BindRowToClassObject(DataRow dataRow)
        {
            var objCustomer = new PersistanceCustomer();
            var objSoundClip = new PersistanceSoundClip();
            return new FileLibrary
            {
                Category = (string)dataRow["Category"],
                Customer = objCustomer.GetCustomer((string)dataRow["CustomerId"]),
                Extension = (FileLibrary.FileType)dataRow["FileType"],
                FileLibraryId = (string)dataRow["FileLibId"],
                FileLibraryName = (string)dataRow["FileLibName"],
                FileName = (string)dataRow["FileName"],
                LibType = Library.LibraryType.File,
                LibraryId = (string)dataRow["LibraryId"],
                LibraryName = (string)dataRow["LibName"],
                SoundClip = objSoundClip.GetSoundClip((string)dataRow["FileLibId"])
            };
        }
        #endregion
    }
}
