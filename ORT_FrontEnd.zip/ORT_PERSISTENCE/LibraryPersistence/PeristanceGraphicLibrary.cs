﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_PERSISTENCE.LibraryPersistence
{
   public class PeristanceGraphicLibrary :ILibrary  
    {
       #region Implementation of ILibrary

       public object GetLibrary(string libraryId)
       {
           var parameters = new Dictionary<string, string> { { "GraphicLibId", libraryId } };
           var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
           var dsReturn = dataManager.GetSetDataFromDb();
           return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
       }

       public List<object> GetLibraryList()
       {
           var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
           var dsReturn = dataManager.GetSetDataFromDb();
           return GetFileLibraryList(dsReturn);
       }

       private static List<object> GetFileLibraryList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindRowToClassObject(row)).ToList();
       }
       public bool SaveLibrary(object library)
       {
           try
           {
               var dataManager = GetDataManagerObject((IDictionary<string, string>)library, DataManager.MethodType.Set);
               var dsReturn = dataManager.GetSetDataFromDb();
               return (string)dsReturn.Tables[0].Rows[0][0] == "0";
           }
           catch (Exception)
           {
               return false;
           }
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(GraphicLibrary), method)
           {
               Parameters = parameters
           };
       }

       private static GraphicLibrary BindRowToClassObject(DataRow dataRow)
       {
           var objCustomer = new PersistanceCustomer();
           return new GraphicLibrary
           {
               Category = (string)dataRow["Category"],
               Customer = objCustomer.GetCustomer((string)dataRow["CustomerId"]),
               Extension = (GraphicLibrary.ImageType)dataRow["FileType"],
               GraphicFileName = (string)dataRow["FileName"],
               GraphicLibraryId = (string)dataRow["GraphicLibId"],
               GraphicLibraryName = (string)dataRow["GraphicLibName"],
               LibraryId = (string)dataRow["LibraryId"],
               LibraryName = (string)dataRow["LibName"],
               LibType = Library.LibraryType.Graphic,
               UploadedOn = (DateTime)dataRow["UploadedOn"]
           };
       }



       #endregion
    }
}
