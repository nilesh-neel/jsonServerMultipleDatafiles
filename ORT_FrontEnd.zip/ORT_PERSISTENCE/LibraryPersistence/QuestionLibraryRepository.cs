﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.SurveyPersistence;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.LibraryPersistence
{
   public class QuestionLibraryRepository : ILibrary 
    {
       #region Implementation of ILibrary

       public Type HomeType { get { return typeof(QuestionLibrary); } }

       public string JsonModelName
       {
           get { return "questions"; }
       }

       public Library.LibraryType LibraryType
       {
           get { return Library.LibraryType.Question; }
       }

       public string Message { get; set; }

       public object GetLibrary(string libraryId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "QuestionId", libraryId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.MapType = typeof(Question);               
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetModuleDataTableRow(dsReturn.Tables[0].Rows[0]);
           }
           catch (Exception)
           {
               throw;
           }
       }


       public List<object> SearchLibrary(string libraryId, string category)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "SearchQuestionLibrary";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (dsReturn.Tables[0].Rows.Count > 0)
               {
                   return null;//BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
               }
               return null;
           }
           catch (Exception)
           {
               throw;
           }
       }
       public bool CheckLibraryCategory(string libraryId, string category)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "CheckCategory";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (dsReturn.Tables[0].Rows.Count > 0)
               {
                   return Convert.ToBoolean(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
               }
               return false;
           }
           catch (Exception)
           {
               throw;
           }
       }
       public List<object> GetLibraryList(string custId, string type)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "CustomerId", custId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "GetList";
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetFileLibraryList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }
       public List<object> GetLibraryCategoryList(string libraryId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "LibType", LibraryType.ToString() } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "GetCategory";
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetFileLibraryList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }

       public bool SaveLibrary(object library)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "SaveQuestionLibrary";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                  // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                   return true;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               return false;
           }
       }

       public bool SaveLibraryCategory(object library)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "SaveQuestionCategory";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                   return true;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               return false;
           }
       }

       public object SaveLibraryDetails(object library)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "UspSaveQuestionLibraryDetails";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                   return null;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               return false;
           }
       }

       private static object GetCategories(string homeLibraryId)
       {
           throw new NotImplementedException();
       }

       private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(QuestionLibrary), method)
           {
               Parameters = parameters
           };
       }

       public static List<Question> GetQuestionList(string QuestionId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "QuestionId", QuestionId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.MapType = typeof(Question);              
               var dsReturn = dataManager.GetSetDataFromDb();
               var lstModule = new List<Question>((from dRow in dsReturn.Tables[0].AsEnumerable()
                                                       select (GetModuleDataTableRow(dRow))));

               return lstModule;
           }
           catch (Exception)
           {
               throw;
           }
       }

       private static Question GetModuleDataTableRow(DataRow dr)
       {
           return new Question
           {
               QuestionId = dr["QuestionId"].ToString(),
               Customer = null,
               QuestionType =(Question.QuestionTypes)Convert.ToInt32(dr["QuestionTypeId"]), 
               QuestionText = dr["QuestionText"].ToString(),
               Answers = null,
               DefaultAnswer = null,
               ForceResponse = Convert.ToBoolean(dr["ForceResponse"].ToString()),
               HasSkipLogic = Convert.ToBoolean(dr["HasSkipLogic"].ToString()),
               HasEmailTrigger = Convert.ToBoolean(dr["HasEmailTrigger"].ToString()),
               HasMedia = Convert.ToBoolean(dr["HasMedia"].ToString()),
               IsDeleted = Convert.ToBoolean(dr["IsDeleted"].ToString()),
               SongList = null
           };
          
       }
        


       private static List<object> GetFileLibraryList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindRowToClassObject(row)).ToList();
       }
       private static QuestionLibrary BindRowToClassObject(DataRow dataRow)
       {     
           return new QuestionLibrary
                      {
                          Category = new LibraryCategory
                          {
                              CategoryId = Convert.ToString(dataRow["CategoryId"]),
                              CategoryName = (string)dataRow["CategoryName"]
                          },
                          Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },
                          //LibType = (Library.LibraryType)(dataRow["LibTypeId"]),
                          LibraryId = Convert.ToString(dataRow["LibId"]),
                          LibraryName = Convert.ToString(dataRow["TypeName"]),
                          QuestionInLibrary = GetQuestionList(Convert.ToString(dataRow["QuestionId"])),
                          QuestionLibraryId = Convert.ToString(dataRow["QuestionLibId"]),
                          QuestionLibraryName = Convert.ToString(dataRow["QuestionLibName"])
                      };
       }

       #endregion

       #region ILibrary Members


       public object SearchLibraryDetails(string detailslibraryId, string category)
       {
           try
           {
               var parameters = new Dictionary<string, string> { 
               { "questionLibId", detailslibraryId }, { "CategoryId", category } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "SearchQuestionLibraryDetails";
               var dsReturn = dataManager.GetSetDataFromDb();
               return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
           }
           catch (Exception)
           {
               throw;
           }
       }
       public bool DeleteLibrary(string libraryId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "QuestionLibId", libraryId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "DeleteQuestionLibrary";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {                 
                   return true;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               throw;
           }
       }

       #endregion



  
    }
}
