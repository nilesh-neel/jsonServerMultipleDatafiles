﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class GraphicLibraryRepository : ILibrary
    {
        #region Implementation of ILibrary

        public Type HomeType { get { return typeof(GraphicLibrary); } }

        public string JsonModelName
        {
            get { return "graphics"; }
        }

        public Library.LibraryType LibraryType
        {
            get { return Library.LibraryType.Graphic; }
        }

        public string Message { get; set; }

        public object GetLibrary(string libraryId)
        {
            var parameters = new Dictionary<string, string> { { "GraphicLibId", libraryId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetGraphicLibrary";
            var dsReturn = dataManager.GetSetDataFromDb();

            return dsReturn.Tables[0].Rows.Count > 0 ? BindRowToClassObject(dsReturn.Tables[0].Rows[0]) : null;
        }
        public object SearchLibraryDetails(string detailslibraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { 
               { "GraphicLibId", detailslibraryId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchGraphicLibraryDetails";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    return BindDataToGraphicInfo(dsReturn);
                }
                return null;
            }
            catch (Exception)
            {
                throw;
            }

        }

        private static List<object> BindDataToGraphicInfo(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToGraphicInfo(row)).ToList();

        }

        private static GraphicLibrary BindRowToGraphicInfo(DataRow dataRow)
        {
            var libId = Convert.ToString(dataRow["LibId"]);
            var cateId = Convert.ToString(dataRow["CategoryId"]);
            return new GraphicLibrary
              {
                  GraphicLibraryId = Convert.ToString(dataRow["GraphicLibId"]),
                  GraphicFileName = (string)dataRow["GraphicFileName"],
                  RelativePath = !string.IsNullOrEmpty(cateId) ?
                    SessionHelper.AppSettings.GraphicRelativePath + "/" + libId + "/" + cateId :
                    SessionHelper.AppSettings.GraphicRelativePath + "/" + libId,
                  Category = new LibraryCategory { CategoryId = cateId },
                  //LibraryId = Convert.ToString(dataRow["LibId"]),
                  FileType = GraphicLibrary.ImageType.Jpg
              };
        }


        public bool CheckLibraryCategory(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "CheckCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    return Convert.ToBoolean(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
                }
                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<object> SearchLibrary(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchGraphicFromLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                return dsReturn.Tables[0].Rows.Count > 0 ? GetGraphicClassList(dsReturn) : null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<object> GetLibraryList(string custId, string type)
        {
            var parameters = new Dictionary<string, string> { { "CustomerId", custId }, { "LibTypeId", type } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
            dataManager.Operation = "GetGraphicLibrary";
            var dsReturn = dataManager.GetSetDataFromDb();
            return dsReturn.Tables[0].Rows.Count > 0 ? BindGraphicClassList(dsReturn) : null;
        }
        public List<object> GetLibraryCategoryList(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "LibType", LibraryType.ToString() } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetGraphicCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                return dsReturn.Tables[0].Rows.Count > 0 ? GetGraphicCategoryList(dsReturn) : null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<object> BindGraphicClassList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindLibraryClass(row)).ToList();

        }
        private static Library BindLibraryClass(DataRow dataRow)
        {
            return new Library
            {
                LibraryId = Convert.ToString(dataRow["LibId"]),
                LibraryName = (string)dataRow["LibName"],
                Description = Convert.ToString(dataRow["LibTypeId"])
            };
        }

        private static List<object> GetGraphicCategoryList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindCategoryClass(row)).ToList();
        }

        private static LibraryCategory BindCategoryClass(DataRow dataRow)
        {
            return new LibraryCategory
            {
                CategoryId = Convert.ToString(dataRow["CategoryId"]),
                CategoryName = Convert.ToString(dataRow["CategoryName"]),
                LibraryId = Convert.ToString(dataRow["LibId"])
                //CategoryDescription = Convert.ToString(dataRow["LibId"])  
            };
        }

        public bool SaveLibrary(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "UspSaveGraphicLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool SaveLibraryCategory(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "UspSaveGraphicCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public object SaveLibraryDetails(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "UspSaveMessageLibraryDetails";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return null;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }


        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(GraphicLibrary), method)
            {
                Parameters = parameters
            };
        }

        private static List<object> GetGraphicClassList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToClassObject(row)).ToList();
        }



        private static GraphicLibrary BindRowToClassObject(DataRow dataRow)
        {
            var libId = Convert.ToString(dataRow["LibId"]);
            var cateId = Convert.ToString(dataRow["CategoryId"]);
            return new GraphicLibrary
              {
                  Customer = new Customer { CustomerId = (Convert.ToString(dataRow["CustomerId"])) },
                  GraphicFileName = (string)dataRow["GraphicFileName"],
                  FileType = GraphicLibrary.ImageType.Gif,
                  LibraryId = libId,
                  Category = new LibraryCategory { CategoryId = cateId },
                  RelativePath = !string.IsNullOrEmpty(cateId) ?
                     SessionHelper.AppSettings.GraphicRelativePath + "/" + libId + "/" + cateId  :
                     SessionHelper.AppSettings.GraphicRelativePath + "/" + libId ,
                  NoOfFiles = Convert.ToString(dataRow["NoOfFiles"])
              };
        }

        public bool DeleteLibrary(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "GraphicLibId", libraryId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "DeleteGraphicLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }


        #endregion


    }
}
