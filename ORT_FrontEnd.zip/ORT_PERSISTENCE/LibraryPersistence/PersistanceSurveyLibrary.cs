﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.SurveyPersistence;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class PersistanceSurveyLibrary : ILibrary
    {
        #region Implementation of ILibrary

        public object GetLibrary(string libraryId)
        {
            var parameters = new Dictionary<string, string> { { "SurveyLibId", libraryId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        public List<object> GetLibraryList()
        {
            var dataManager = GetDataManagerObject(null, DataManager.MethodType.Get);
            var dsReturn = dataManager.GetSetDataFromDb();
            return GetFileLibraryList(dsReturn);
        }

        private static List<object> GetFileLibraryList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToClassObject(row)).ToList();
        }

        public bool SaveLibrary(object library)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)library, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(SurveyLibrary), method)
            {
                Parameters = parameters
            };
        }
        private static SurveyLibrary BindRowToClassObject(DataRow dataRow)
        {
            var objCustomer = new PersistanceCustomer();
            var objSurvey = new PersistanceSurvey();
            return new SurveyLibrary
                       {
                           Category = (string)dataRow["Category"],
                           Customer = objCustomer.GetCustomer((string)dataRow["CustomerId"]),
                           LibType = Library.LibraryType.Message,
                           LibraryId = (string)dataRow["LibraryId"],
                           LibraryName = (string)dataRow["LibName"],
                           SurveyInLibrary = objSurvey.GetSurvey("", (string)dataRow["SurveyId"]),
                           SurveyLibraryId = (string)dataRow["SurveyLibId"],
                           SurveyLibraryName = (string)dataRow["SurveyLibName"]                           
                       };
        }

        #endregion
    }
}
