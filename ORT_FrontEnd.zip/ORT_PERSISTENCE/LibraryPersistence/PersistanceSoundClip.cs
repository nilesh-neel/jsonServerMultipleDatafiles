﻿using System;
using System.Collections.Generic;
using System.Data;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class PersistanceSoundClip : ISoundClip
    {
        #region Implementation of ISoundClip

        public SoundClip GetSoundClip(string fileLibId)
        {
            var parameters = new Dictionary<string, string> { { "FileLibId", fileLibId } };
            var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
            var dsReturn = dataManager.GetSetDataFromDb();
            return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
        }

        public bool SaveSoundClip(SoundClip soundClip)
        {
            try
            {
                var dataManager = GetDataManagerObject((IDictionary<string, string>)soundClip, DataManager.MethodType.Set);
                var dsReturn = dataManager.GetSetDataFromDb();
                return (string)dsReturn.Tables[0].Rows[0][0] == "0";
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(SoundClip), method)
            {
                Parameters = parameters
            };
        }
        private static SoundClip BindRowToClassObject(DataRow dataRow)
        {
            return new SoundClip
                       {
                           Artist = (string)dataRow["Artist"],
                           FilePath = (string)dataRow["FilePath"],
                           Title = (string)dataRow["Title"],
                           Year  = (string) dataRow["FileLibYear"]
                       };
        }

        #endregion
    }
}
