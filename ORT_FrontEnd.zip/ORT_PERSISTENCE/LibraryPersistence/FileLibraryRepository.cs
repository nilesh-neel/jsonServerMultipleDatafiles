﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class FileLibraryRepository : ILibrary
    {
        public Type HomeType { get { return typeof(FileLibrary); } }

        public string JsonModelName
        {
            get { return "files"; }
        }

        public Library.LibraryType LibraryType
        {
            get { return Library.LibraryType.File; }
        }

        public string Message { get; set; }
        #region Implementation of ILibrary


        public object GetLibrary(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "FileLibId", libraryId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetFile";
                var dsReturn = dataManager.GetSetDataFromDb();
                return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<object> SearchLibrary(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibraryId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchQuestionFromLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
              if (dsReturn.Tables[0].Rows.Count > 0)
               {
                   return null;// BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
               }
                 return null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<object> GetLibraryList(string custId, string type)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", custId },{"LibTypeId",type} };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                //dataManager.Operation = "GetList";
                dataManager.Operation = "GetLibraryList";                
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetFileLibraryList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<object> GetLibraryCategoryList(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "LibType", LibraryType .ToString()} };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetFileLibraryList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<object> GetFileLibraryList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindLibraryClass(row)).ToList();
        }

        public bool CheckLibraryCategory(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "CheckCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    return Convert.ToBoolean(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
                }
                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool SaveLibrary(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveFileLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool SaveLibraryCategory(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveFileCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public object SaveLibraryDetails(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "UspSaveMessageLibraryDetails";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                    return null;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static object GetCategories(string homeLibraryId)
        {
            throw new NotImplementedException();
        }

        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(FileLibrary), method)
            {
                Parameters = parameters
            };
        }

        private static Library BindLibraryClass(DataRow dataRow)
        {
            return new Library
            {
                LibraryId = Convert.ToString(dataRow["LibId"]),
                LibraryName = (string)dataRow["LibName"],
                Description = Convert.ToString(dataRow["LibTypeId"])
            };
        }


        private static FileLibrary BindRowToClassObject(DataRow dataRow)
        {
            return new FileLibrary
            {
                Category = new LibraryCategory
                {
                    CategoryId = (string)dataRow["CategoryId"],
                    CategoryName = (string)dataRow["CategoryName"]
                },
                Customer = new Customer { CustomerId = (Convert.ToString(dataRow["CustomerId"])) },
                Extension = FileLibrary.FileType.Mp4,//(FileLibrary.FileType)Convert.ToInt32(dataRow["FileType"]),
                FileLibraryId = Convert.ToString(dataRow["FileLibId"]),
                FileLibraryName = (string)dataRow["FileLibName"],
                FileName = (string)dataRow["FileName"],
                //LibType = Library.LibraryType.File,
                LibraryId = Convert.ToString(dataRow["LibraryId"]),
                LibraryName = (string)dataRow["LibName"],
                SoundClip = null,
            };
        }
        #endregion

        #region ILibrary Members


        public object SearchLibraryDetails(string detailslibraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "@fileLibId", detailslibraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchFileLibraryDetails";
                var dsReturn = dataManager.GetSetDataFromDb();
                return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool DeleteLibrary(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibraryId", libraryId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "DeleteFileLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

    }
}
