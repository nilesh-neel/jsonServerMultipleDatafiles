﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_PERSISTENCE.SurveyPersistence;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.LibraryPersistence
{
    public class SurveyLibraryRepository : ILibrary
    {

        #region Implementation of ILibrary

        public Type HomeType { get { return typeof(SurveyLibrary); } }

        public string JsonModelName
        {
            get { return "surveys"; }
        }

        public Library.LibraryType LibraryType
        {
            get { return Library.LibraryType.Survey; }
        }

        public string Message { get; set; }
        public object GetLibrary(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "SurveyId", libraryId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.MapType = typeof(Survey);
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetModuleDataTableRow(dsReturn.Tables[0].Rows[0]);
            }
            catch (Exception)
            {
                throw;
            }

        }
        public List<object> SearchLibrary(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchSurveyLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                return null;// BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public object SearchLibraryDetails(string detailslibraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { 
               { "SurveyLibId", detailslibraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "SearchSurveryLibraryDetails";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                 return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
                }
               return null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<object> GetLibraryList(string custId, string type)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "CustomerId", custId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetList";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetFileLibraryList(dsReturn);
             }
            catch (Exception)
            {
                throw;
            }
        }
        public List<object> GetLibraryCategoryList(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "LibType", LibraryType.ToString() } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "GetCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                return GetFileLibraryList(dsReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool CheckLibraryCategory(string libraryId, string category)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "CheckCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    return Convert.ToBoolean(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
                }
                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static List<object> GetFileLibraryList(DataSet dsData)
        {
            return (from DataRow row in dsData.Tables[0].Rows
                    select (object)BindRowToClassObject(row)).ToList();
        }

        public bool SaveLibrary(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveSurveyLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool SaveLibraryCategory(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "SaveSurveyCategory";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        public object SaveLibraryDetails(object library)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
                dataManager.Operation = "UspSaveSurveyLibraryDetails";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    // user.UserId = dsReturn.Tables[0].Rows[0]["UserId"].ToString();
                    return null;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static object GetCategories(string homeLibraryId)
        {
            throw new NotImplementedException();
        }

        private static List<Survey> GetSurveyList(string surveyId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "SurveyId", surveyId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.MapType = typeof(Survey);
                var dsReturn = dataManager.GetSetDataFromDb();
                var lstModule =  new List<Survey>((from dRow in dsReturn.Tables[0].AsEnumerable()
                                                    select (GetModuleDataTableRow(dRow))));

                return lstModule;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static Survey GetModuleDataTableRow(DataRow dataRow)
        {
            return new Survey
            {
                SurveyId = dataRow["SurveyId"].ToString(),
                SurveyName = dataRow["SurveyName"].ToString(),
                RewardEnabled = Convert.ToBoolean(dataRow["RewardEnabled"]),
                CreatedBy = new User { UserId = dataRow["CreatedBy"].ToString() },
                CreatedDateTime = dataRow["CreatedDate"].ToString(),
                ModifiedBy = new User { UserId = dataRow["ModifiedBy"].ToString() },
                ModifiedDateTime = dataRow["ModifiedDate"].ToString(),
                Customer = new Customer { CustomerId = dataRow["CustomerId"].ToString() },
                Starred = Convert.ToBoolean(dataRow["StarMarked"]),
                IsActive = Convert.ToBoolean(dataRow["IsActive"])
            };

        }


        private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
        {
            return new DataManager(typeof(SurveyLibrary), method)
            {
                Parameters = parameters
            };
        }
        private static SurveyLibrary BindRowToClassObject(DataRow dataRow)
        {
            return new SurveyLibrary
                       {
                           Category = new LibraryCategory {
                               CategoryId = Convert.ToString(dataRow["CategoryId"]),
                               CategoryName = (string)dataRow["CategoryName"]
                           },
                           Customer = new Customer { CustomerId = (Convert.ToString(dataRow["CustomerId"])) },
                           //LibType = Library.LibraryType.Survey,
                           LibraryId = Convert.ToString(dataRow["LibId"]),
                           LibraryName = (string)dataRow["LibName"],
                           SurveyInLibrary = GetSurveyList(Convert.ToString(dataRow["SurveyId"])),
                           SurveyLibraryId = Convert.ToString(dataRow["SurveyLibId"]),
                           SurveyLibraryName = (string)dataRow["SurveyLibName"]
                       };
        }

        public bool DeleteLibrary(string libraryId)
        {
            try
            {
                var parameters = new Dictionary<string, string> { { "SurveyLibId", libraryId } };
                var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
                dataManager.Operation = "DeleteSurveyLibrary";
                var dsReturn = dataManager.GetSetDataFromDb();
                if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                {
                    return true;
                }
                throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

    }
}
