﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;

namespace ORT_PERSISTENCE.LibraryPersistence
{
   public class MessageLibraryRepository : ILibrary 
    {
       #region Implementation of ILibrary

       public Type HomeType { get { return typeof(MessageLibrary); } }

       public string JsonModelName
       {
           get { return "messages"; }
       }

       public Library.LibraryType LibraryType
       {
           get { return Library.LibraryType.Message; }
       }

       public string Message { get; set; }

       public object GetLibrary(string libraryId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "MessageLibId", libraryId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               var dsReturn = dataManager.GetSetDataFromDb();
               return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
           }
           catch (Exception)
           {
               throw;
           }

       }
       public bool CheckLibraryCategory(string libraryId, string category)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "CheckCategory";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (dsReturn.Tables[0].Rows.Count > 0)
               {
                   return Convert.ToBoolean(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
               }
               return false;
           }
           catch (Exception)
           {
               throw;
           }
       }
   
       public List<object> SearchLibrary(string libraryId ,string category)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "CategoryId", category } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "SearchMessageFromLibrary";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (dsReturn.Tables[0].Rows.Count > 0)
               {

                   if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
                   {
                       return BindRowToClassObject(dsReturn);
                   }
                   else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
                   {
                       if (string.IsNullOrEmpty(libraryId) || string.IsNullOrEmpty(category))
                       {
                           Message = "";
                           return null;
                       }
                       else
                       {
                           Message = Convert.ToString(dsReturn.Tables[0].Rows[0]["Remark"]);
                           return null;
                       }
                   }
               }
               else
               {
                   Message = "";
                   return null;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
               
           }
           catch (Exception)
           {
               throw;
           }
       }

       public object SearchLibraryDetails(string detailslibraryId, string category)
       {
           try
           {
               var parameters = new Dictionary<string, string> { 
               { "messageLibId", detailslibraryId }, { "CategoryId", category } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "SearchMessageLibraryDetails";
               var dsReturn = dataManager.GetSetDataFromDb();             
               return BindRowToClassObject(dsReturn.Tables[0].Rows[0]);
              

           }
           catch (Exception)
           {
               throw;
           }
       }

       public List<object> GetLibraryList(string custId,string type)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "CustomerId", custId }, { "LibTypeId", type } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetFileLibraryList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }
       public List<object> GetLibraryCategoryList(string libraryId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "LibId", libraryId }, { "LibType", LibraryType.ToString() } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "GetCategory";
               var dsReturn = dataManager.GetSetDataFromDb();
               return GetFileCategoryList(dsReturn);
           }
           catch (Exception)
           {
               throw;
           }
       }
       public bool SaveLibrary(object library)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "UspSaveMessageLibrary";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   var objlib=(Library)library;
                   objlib.LibraryId = dsReturn.Tables[0].Rows[0]["LibraryId"].ToString();
                   library = objlib;
                   return true;
               }
               else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
               {
                   Message = dsReturn.Tables[0].Rows[0]["Remark"].ToString();
                   return false;;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               return false;
           }
       }
       
       public bool SaveLibraryCategory(object library)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "UspSaveMessageCategory";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   var objlib = (LibraryCategory)library;
                   objlib.CategoryId = dsReturn.Tables[0].Rows[0]["CategoryId"].ToString();
                   library = objlib;
                   return true;
               }
               else if(Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
               {
                   Message=dsReturn.Tables[0].Rows[0]["Remark"].ToString();
                   return false;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               return false;
           }
       }

       public object SaveLibraryDetails(object library)
       {
           try
           {  
               var objlib = (MessageLibrary)library;
               var parameters = new Dictionary<string, string> { { "XmlData", ObjectXmlHelper.ToXml(library) } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Set);
               dataManager.Operation = "SaveMessageLibraryDetails";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   objlib.MessageLibraryId = dsReturn.Tables[0].Rows[0]["MessageLibId"].ToString();                  
                   return objlib;
               }
               else if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "0")
               {
                   Message = Convert.ToString(dsReturn.Tables[0].Rows[0]["Remark"]);
                   return null;
               }

               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               return false;
           }
       }

      private static DataManager GetDataManagerObject(IDictionary<string, string> parameters, DataManager.MethodType method)
       {
           return new DataManager(typeof(MessageLibrary), method)
           {
               Parameters = parameters
           };
       }

       private static List<object> BindRowToClassObject(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindRowToClassObject(row)).ToList();         
           
       }

       private static MessageLibrary BindRowToClassObject(DataRow dataRow)
       {
           return  new MessageLibrary
                      {
                          Category = new LibraryCategory
                             {
                                 CategoryId = Convert.ToString(dataRow["CategoryId"]),
                                 CategoryName = (string)dataRow["CategoryName"]
                             },
                          Customer = new Customer { CustomerId = Convert.ToString(dataRow["CustomerId"]) },
                          //LibType = Library.LibraryType.Message,
                          LibraryId = Convert.ToString(dataRow["LibId"]),
                          LibraryName = (string)dataRow["LibName"],
                          //MailType = (MessageLibrary.MessageType)dataRow["MessageTypeId"],
                          MessageDescription = (string)dataRow["MessageDescription"],
                          MessageLibraryId = Convert.ToString(dataRow["MessageLibId"]),
                          MessageText = (string)dataRow["MessageText"],
                          FilePath = (string)dataRow["TemplateName"]
                      };
       }

       private static Library BindLibraryClass(DataRow dataRow)
       {
           return new Library
           {
               LibraryId = Convert.ToString(dataRow["LibId"]),
               LibraryName = (string)dataRow["LibName"],
               Description = Convert.ToString(dataRow["LibTypeId"])      
           };
       }

       private static LibraryCategory BindCategoryClass(DataRow dataRow)
       {
           return new LibraryCategory
           {
               CategoryId = Convert.ToString(dataRow["CategoryId"]),
               CategoryName = Convert.ToString(dataRow["CategoryName"]),
               LibraryId= Convert.ToString(dataRow["LibId"])              
               //CategoryDescription = Convert.ToString(dataRow["LibId"])              
           };
       }
       private static List<object> GetFileLibraryList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindLibraryClass(row)).ToList();
       }

       private static List<object> GetFileCategoryList(DataSet dsData)
       {
           return (from DataRow row in dsData.Tables[0].Rows
                   select (object)BindCategoryClass(row)).ToList();
       }

       public bool DeleteLibrary(string libraryId)
       {
           try
           {
               var parameters = new Dictionary<string, string> { { "MessageLibId", libraryId } };
               var dataManager = GetDataManagerObject(parameters, DataManager.MethodType.Get);
               dataManager.Operation = "DeleteMessageLibrary";
               var dsReturn = dataManager.GetSetDataFromDb();
               if (Convert.ToString(dsReturn.Tables[0].Rows[0]["RetValue"]) == "1")
               {
                   return true;
               }
               throw new Exception(dsReturn.Tables[0].Rows[0]["Remark"].ToString());
           }
           catch (Exception)
           {
               throw;
           }
       }

       #endregion
    }
}
