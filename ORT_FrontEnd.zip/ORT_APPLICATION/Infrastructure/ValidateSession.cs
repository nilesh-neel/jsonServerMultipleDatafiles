﻿using System;
using System.Web.Mvc;
using ORT_HELPERS.Helpers;

namespace ORT_APPLICATION.Infrastructure
{
    public class ValidateSession : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                var user = SessionHelper.LogggedInUser;
                if (user != null)
                {
                    base.OnActionExecuting(filterContext);
                }
                else
                {
                    filterContext.Result = ReturnJsonHelper.GetTimeOutJson();
                }

            }
            catch (Exception ex)
            {
                filterContext.Result = ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
    }
}
