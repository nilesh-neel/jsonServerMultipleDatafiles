﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ORT_CORE.Class.SurveyClasses;
using System.Web.Security;
using System.Security.Principal;
using ORT_APPLICATION.Helpers;
using System.Runtime.Serialization.Json;
using Newtonsoft.Json;

namespace ORT_APPLICATION.Infrastructure
{
    public  class CustomAuthorize : ActionFilterAttribute, IAuthorizationFilter
    {
        public static bool ErrorCode { get; set; }
        public static string ErrorMessage { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var user = (User)(HttpContext.Current.Session["LogedInUser"]);
            var controller = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            var action = filterContext.ActionDescriptor.ActionName;
            var isAccessAllowed = GetAccess(controller, user);
            if (!isAccessAllowed)
            {
                //HttpContext.Current.Session.Abandon();
                //FormsAuthentication.RedirectToLoginPage();
                var message = string.Format("You do not have permission to access {0} on {1}", action, controller);
                var returnResult = new JsonResult
                {
                    Data = message
                };
                returnResult.JsonRequestBehavior = JsonRequestBehavior.AllowGet;

                filterContext.Result = returnResult;
            } base.OnActionExecuting(filterContext);            
        } 

        public void OnAuthorization(AuthorizationContext filterContext)
        {
            var user = (User)(HttpContext.Current.Session["LogedInUser"]);
            var controller = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            var action = filterContext.ActionDescriptor.ActionName;           
            var isAccessAllowed = GetAccess(controller, user);
            if (!isAccessAllowed)
            {
                //HttpContext.Current.Session.Abandon();
                //FormsAuthentication.RedirectToLoginPage();
                var message = string.Format("You do not have permission to access {0} on {1}", action, controller);
                ErrorCode = false;
                ErrorMessage = message;
                //(JsonResult)(message).BuildReturnData();
            }
        }

        private static bool GetAccess(string search, User user)
        {
           var list =user.UserDetails.Module;
           var result = list.Any(module => module.ModuleName.Equals(search));
           return result;
        }

        private bool AuthenticateTicket(AuthorizationContext filterContext)
        {
            HttpCookie authCookie =
                filterContext.HttpContext.Request.Cookies[FormsAuthentication.FormsCookieName];

            if (authCookie != null)
            {
                FormsAuthenticationTicket authTicket =
                       FormsAuthentication.Decrypt(authCookie.Value);
                var identity = new GenericIdentity(authTicket.Name, "Forms");
                var principal = new GenericPrincipal(identity, new string[] { authTicket.UserData });
                filterContext.HttpContext.User = principal;
                var User = filterContext.HttpContext.User;
                var IP = filterContext.HttpContext.Request.UserHostAddress;

                return true;
            }
            return false;
 
        }

    }
    
}
