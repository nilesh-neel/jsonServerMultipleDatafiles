﻿using System;
using System.Linq;
using System.Web.Mvc;
using ORT_CORE.Class.SurveyClasses;
using ORT_HELPERS.Helpers;

namespace ORT_APPLICATION.Infrastructure
{
    public class SecurityFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                var user = SessionHelper.LogggedInUser;
                if (user != null)
                {
                    var action = filterContext.ActionDescriptor.ActionName;
                    if (!GetAccess(action, user))
                    {
                        var controller = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
                        filterContext.Result = ReturnJsonHelper.GetPermissionDeniedJson(controller,action);
                    }
                    base.OnActionExecuting(filterContext);
                }
                else
                {
                    filterContext.Result = ReturnJsonHelper.GetTimeOutJson();
                }

            }
            catch (Exception ex)
            {
                filterContext.Result = ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        private static bool GetAccess(string search, User user)
        {
            var list = user.UserDetails.Module;
            var result = list.Any(module => module.ModuleName.Equals(search));
            return result;
        }
    }
}
