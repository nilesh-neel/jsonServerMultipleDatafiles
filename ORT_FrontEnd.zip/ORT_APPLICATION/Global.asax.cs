﻿using System;
using System.Configuration;
using System.Web.Mvc;
using System.Web.Routing;
using ORT_APPLICATION.Configuration;
using ORT_HELPERS.HelperClasses;
using ORT_HELPERS.Helpers;

namespace ORT_APPLICATION
{
    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Login", action = "Logon", id = UrlParameter.Optional } // Parameter defaults
            );
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RegisterRoutes(RouteTable.Routes);
            BootStrapper.Run();
            log4net.Config.XmlConfigurator.Configure();
            ORT_VIEW_MAP.Configuration.Run();
            AddAppSettings();

        }

        private static void AddAppSettings()
        {
            SessionHelper.AppSettings = new ApplicationSettings
            {
                DataBaseService = ConfigurationManager.AppSettings["DataBaseService"],
                DataBaseName = ConfigurationManager.AppSettings["DataBaseName"],
                DataBaseUser = ConfigurationManager.AppSettings["DataBaseUser"],
                DataBasePassWord = ConfigurationManager.AppSettings["DataBasePassWord"],
                CommandTimeout = ConfigurationManager.AppSettings["CommandTimeout"],
                DataBaseType = ConfigurationManager.AppSettings["DataBaseType"],
                LogFolderPath = ConfigurationManager.AppSettings["LogFolderPath"],
                EnableLog = ConfigurationManager.AppSettings["EnableLog"],
                RelativePath = ConfigurationManager.AppSettings["RelativePath"],
                EngineTemplatePath = AppDomain.CurrentDomain.BaseDirectory + "\\EngineTemplates\\",
                MusicRelativePath = ConfigurationManager.AppSettings["MusicRelativePath"],
                SmtpServer = ConfigurationManager.AppSettings["SMTPSERVER"],
                SmtpUser = ConfigurationManager.AppSettings["SMTPUSER"],
                SmtpPassword = ConfigurationManager.AppSettings["SMTPPWD"],
                GraphicRelativePath = ConfigurationManager.AppSettings["GraphicRelativePath"],
                GraphicUpload = ConfigurationManager.AppSettings["GraphicUpload"]
            };
        }

        protected void Session_Start(Object sender, EventArgs e) 
        {
        }

        void Session_End(Object sender, EventArgs e) 
        {
            Session.Abandon();
           
        }

    }
}