Ext.define('ORT.controller.CompanyManager', {

    extend: 'Ext.app.Controller',
	
	requires: ['Ext.window.MessageBox'],

	views: ['admin.CompanyManager'],

	stores: ['Cities', 'States', 'Countries', 'SearchedCompanies','Companies'],

	models: ['Company'],
	
	refs: [
		{
			ref: 'companySearchGrid',
			selector: 'companysearch'
		},
		{
			ref: 'companyEditView',
			selector: 'companyedit'
		}
	],

	init: function() {
		console.log('ORT.controller.CompanyManager::init()');
		
		var store = Ext.getStore('SearchedCompanies');
		if(!store) {
			var store = this.getSearchedCompaniesStore();
		}
		
		store.on({
			scope : this,
			load : 'onStoreLoad',
			beforeload: 'onSetParams',
			create: 'onCreateRecord',
			update: 'onUpdateRecord',
			destroy: 'onDestroyRecord'
		});
		
		this.control({
            'viewport > panel': {render: this.onPanelRendered},
			'companysearch actioncolumn': {click: this.onCompanyAction},
			'companysearch button[action=search]': {click: this.onCompanySearch},
			'companysearch': {
				itemdblclick: this.onExpandCompany,
				selectionchange: this.onSelectCompany
			},
			'companyedit button[action=add]': {click: this.onNewCompany},
			'companyedit button[action=save]': {click: this.onSaveCompany},
			'companyedit button[action=revert]': {click: this.onRevertChanges}
        });
    },
	
	onExpandCompany: function() {
		if(this.getCompanyEditView().collapsed) {
			this.getCompanyEditView().expand();
		}
		else {
			this.getCompanyEditView().collapse();
		}
	},
	
	onCompanySearch: function(btn) {
		this.getSearchedCompaniesStore().load();
	},
	
	onSetParams: function(store, operation, options) {
		store.getProxy().extraParams = {};
		
		var filter = Ext.getCmp('companyAbbreviationFilter') ? Ext.getCmp('companyAbbreviationFilter').getValue() : '';
		if(filter && filter.length > 0) {
			store.getProxy().extraParams.abbreviation = filter;
			filter = null;
		}
		
		filter = Ext.getCmp('companyNameFilter') ? Ext.getCmp('companyNameFilter').getValue() : '';
		if(filter && filter.length > 0) {
			store.getProxy().extraParams.company = filter;
			filter = null;
		}
	},
	
	onStoreLoad: function(store, records, success) {
		if(success) {
			if(records && records.length == 0) {
			}
		}
		else {
			/*
			// Retrial attempts
			Ext.Msg.show({
				scope: store,
				title:'Company Manager',
				msg: 'Could not fetch companies. Do you want to retry?',
				buttons: Ext.Msg.YESNO,
				icon: Ext.MessageBox.WARNING,
				buttonText: { yes: "Retry", no: "Ignore" },
				fn: function(btn) {
					if("yes" == btn) {
						this.load({
						   params:{paramName: 'paramValue'}
						});
					}
				}
			});
			*/
		}
	},

	onCreateRecord: function(store, records, success) {
		alert('c');
	},
	
	onUpdateRecord: function(store, record, action) {
		if('edit' == action) {
			// ignore...
		}
		else if('commit' == action) {
			if(!record.get('id')) {
				Ext.Msg.show({
					title:'Server Error',
					msg: 'The data was saved with ' + record.get('id') + ' id.',
					buttons: Ext.Msg.OK,
					icon: Ext.MessageBox.ERROR
				});
				
				this.getSearchedCompaniesStore().remove(record);
				this.getSearchedCompaniesStore().sync();
				return;
			}
			
			this.getCompanyEditView().getForm().loadRecord(record);
			this.getCompaniesStore().load();
			Ext.Msg.show({
					title:'Success',
					msg: 'The Company ' + record.get('name') + ' saved successfully',
					buttons: Ext.Msg.OK,
					width: 400,
					icon: Ext.MessageBox.INFO
				});
				if(this.selectedCompany) {
					this.onEditCompany(this.selectedCompany);
				}
		}
	},
	
	onDestroyRecord: function(store, records, success) {
		alert('d');
	},
	
	onPanelRendered: function() {
		console.log('ORT.controller.CompanyManager::onPanelRendered()');
    },
	
	onCompanyAction: function(view, cell, row, col, e) {
	
		var record = view.store.getAt(row);		
		var m = e.getTarget().className.match(/\boptSmall(\w+)\b/);
		if(m){
			switch(m[1]){
				case 'Edit':
					this.onEditCompany(record);
					break;
				case 'Delete':
					Ext.Msg.show({
						scope: this,
						title:'Confirmation',
						msg: 'Are you sure you want to delete this company?',
						buttons: Ext.Msg.YESNO,
						icon: Ext.MessageBox.QUESTION,
						buttonText: { yes: "Yes", no: "No" },
						fn: function(btn) {
							if("yes" == btn) {
								this.deleteCompany(record);
							}
						}
					});
					break;
				default:
					Ext.Msg.show({
						scope: this,
						title: m[1],
						msg:  'This feature is under development.',
						buttons: Ext.Msg.OK,
						icon: Ext.MessageBox.INFO
					});
					break;
			}
		}
	},
	
	onSelectCompany: function(model, records) {
		
		if(records && records.length > 0) {
			this.selectedCompany = records[0];
			this.applyChanges();
			var form = this.getCompanyEditView().getForm();
			var record = form.getRecord();
			if(record && record.dirty) {
				var record = form.getRecord();
				Ext.Msg.show({
					scope: this,
					title:'Confirmation',
					msg: 'The company '+ record.get('name')+ ' is not saved! Do you want to save your changes?',
					buttons: Ext.Msg.YESNO,
					icon: Ext.MessageBox.QUESTION,
					buttonText: { yes: "Yes", no: "No" },
					fn: function(btn) {
						if("yes" == btn) {
							Ext.Msg.close();
							this.onSaveCompany();
						}
						else if ("no" == btn) {
							Ext.Msg.close();
							if(record.get('id') === 'undefined') {
								this.getSearchedCompaniesStore().remove(record);
							}
							else {
								record.reject();
							}
							
							this.onEditCompany(records[0]);
						}
					}
				});
			}
			else {
				this.onEditCompany(records[0]);
			}
		}
	},
	
	onNewCompany: function() {
		var form = this.getCompanyEditView().getForm();
		form.reset();
		
		var company = new ORT.model.Company();
		company.setDirty(true);
		form.loadRecord(company);
		//company.setDirty(true);
		//this.getSearchedCompaniesStore().insert(0, company);
		//this.getSearchedCompaniesStore().sync();
		//this.getCompanySearchGrid().getSelectionModel().select(company);
	},
	
	onEditCompany: function(record) {
		var form = this.getCompanyEditView().getForm();
		form.loadRecord(record);
	},
	
	onSaveCompany: function(button) {
		var newRecordFlag = false;
		
		var form = this.getCompanyEditView().getForm();
		
		if(!form.isValid()) {
			var selectRecord = form.getRecord();
			this.getCompanySearchGrid().getSelectionModel().doSelect(selectRecord);
			Ext.Msg.show({
				title:'Error',
				msg: 'Please fill all mandatory fields with valid data.',
				buttons: Ext.Msg.OK,
				icon: Ext.MessageBox.ERROR
			});
			return;
		}
		
		/*
		var values = form.getValues();
		if(values) {
			// Add record to store if its NEW
			//var recordIndex = this.getSearchedCompaniesStore().find('name', values.name);
			//var query = this.getSearchedCompaniesStore().queryBy(
			var recordIndex = this.getSearchedCompaniesStore().findBy(
				function(rec, id){
					if(rec.get('name') == this.data.name) {
							return true;  // a record with this data exists
						}
					return false;  // there is no record in the store with this data
				},
				{data: values}
			);
			
			if(recordIndex == -1) {
				newRecordFlag = true; // NO Matching record. Its a NEW record.
			}
			else { // record found.
				var record = form.getRecord();
				if(record) {
					var foundRecordId = this.getSearchedCompaniesStore().getAt(recordIndex).id;
					var currentFormRecordId = record.id;
					// make sure the record found is indeed the one referred by the form.
					// if its not, then its a duplicate new record.
					if(foundRecordId != currentFormRecordId) {
						Ext.Msg.show({
							title:'Error',
							msg: 'The record with the same company name already exists.',
							buttons: Ext.Msg.OK,
							icon: Ext.MessageBox.ERROR
						});
						return;
					}
				}
			}
		}
		*/
		this.applyChanges();
		
		var record = form.getRecord();
		if(record) {
			if(!record.dirty) {
				Ext.Msg.show({
					title:'Msg',
					msg: 'There are no changes to save',
					buttons: Ext.Msg.OK,
					width: 280,
					icon: Ext.MessageBox.INFO
				});
				return;
			}
			if(!record.get('id')) {
				record.set('id', 'undefined');
				this.getSearchedCompaniesStore().insert(0, record);
				//this.getCompanySearchGrid().getSelectionModel().select(record);
			}
			
			/*
			form.updateRecord(record);
			record.save({
				scope : this,
				success: function (record, operation, c) {
					if(!record.get('id')) {
						Ext.Msg.show({
							title:'Server Error',
							msg: 'The data was saved with ' + record.get('id') + ' id.',
							buttons: Ext.Msg.OK,
							icon: Ext.MessageBox.ERROR
						});
						
						this.getUsersStore().remove(record);
						this.getUsersStore().sync();
						return;
					}
				
					this.getCompanyEditView().getForm().loadRecord(record);
					this.getCompanySearchGrid().getSelectionModel().select(record);	
				}
			});
			*/
		}
		
		this.getSearchedCompaniesStore().sync();
	},
	
	onRevertChanges: function(button) {
		var form = this.getCompanyEditView().getForm();
		var record = form.getRecord();
		if(record) {
			form.loadRecord(record);
		}
	},
	
	applyChanges: function() {
		var form = this.getCompanyEditView().getForm();
		var record = form.getRecord();
		if(record) {
			var values = form.getValues();
			record.set(values);
		}
	},
	
	deleteCompany: function(record) {
		this.getSearchedCompaniesStore().remove(record);
		this.getSearchedCompaniesStore().sync();
		this.getCompaniesStore().load();
		this.getSearchedCompaniesStore().load();
	}
});