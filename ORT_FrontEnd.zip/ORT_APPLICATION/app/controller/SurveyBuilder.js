Ext.define('ORT.controller.SurveyBuilder', {

    extend: 'Ext.app.Controller',
	
	requires: [
		'Ext.window.MessageBox',
		'Ext.Editor'
	],

	views: ['survey.Builder'],
	
	stores: ['Questionnaire'],

	models: ['Question'],
	
	refs: [
		{
			ref: 'surveyBuilderGrid',
			selector: 'surveybuilder'
		}
	],

	init: function() {
		console.log('ORT.controller.SurveyBuilder::init()');

		this.control({
			'viewport > panel': {render: this.onPanelRendered},
			'surveybuilder actioncolumn': {click: this.onBuilderAction},
			'surveybuilder toolbar button[action=newQuestion]': {click: this.onNewQuestion},
			'surveybuilder toolbar button[action=addPageBreakAfter]': {click: this.onAddPageBreakAfter},
			'surveybuilder toolbar button[action=addPageBreakBefore]': {click: this.onAddPageBreakBefore},
			//'surveybuilder': {itemdblclick: this.onRowEdit},
			'questionedit button[action=save]': {click: this.saveQuestion},
			'questionedit button[action=cancel]': {click: this.closeQuestionEditWindow}
		});
	},
	
	onPanelRendered: function() {
		console.log('ORT.controller.SurveyBuilder::onPanelRendered()');
	},
	
	onBuilderAction: function(view, cell, row, col, e) {
	
		var record = view.store.getAt(row);		
		var m = e.getTarget().className.match(/\boptSmall(\w+)\b/);
		if(m){
			switch(m[1]){
				case 'Edit':
					if(record.get('type') === 'pageBreak') {
						Ext.Msg.show({
							scope: this,
							title: 'Page Break',
							msg:  'The selected item is a Page Break. It cannot be edited.',
							buttons: Ext.Msg.OK,
							icon: Ext.MessageBox.WARNING
						});
					}
					else {
						this.onEditQuestion(record);
					}
					break;
				case 'AddAbove':
					this.addQuestionAt(row-1);
					break;
				case 'AddBelow':
					this.addQuestionAt(row+1);
					break;
				case 'Delete':
					Ext.Msg.show({
						scope: this,
						title:'Confirmation',
						msg: 'Are you sure you want to delete this question?',
						buttons: Ext.Msg.YESNO,
						icon: Ext.MessageBox.QUESTION,
						buttonText: { yes: "Yes", no: "No" },
						fn: function(btn) {
							if("yes" == btn) {
								this.deleteQuestion(record);
							}
						}
					});
					break;
				default:
					Ext.Msg.show({
						scope: this,
						title: m[1],
						msg:  'This feature is under development.',
						buttons: Ext.Msg.OK,
						icon: Ext.MessageBox.INFO
					});
					break;
			}
		}
	},
	
	onRowEdit: function(grid, record, row, rowIndex, event, obj) {
		if(event && event.type === 'dblclick') {
			var questionElementId = 'surveyQuestionText'+record.getId();
			if(event.target.id === questionElementId) {
				var editor = new Ext.Editor({
					updateEl: true, // update the innerHTML of the bound element when editing completes
					field: {
						xtype: 'textfield'
					}
				});
				
				editor.on({
					scope : {controller: this, view: grid, record: record},
					complete : 
						function(editor, value, startValue) {
							if(value != startValue) {
								this.record.set('isDirty', true);
								this.record.set('question', value);
							}
						}
				});
				
				var el = event.target;//Ext.get(questionElementId); // The element to 'edit'
				editor.startEdit(event.target); // The value of the field will be taken as the innerHTML of the element.
				editor.realign();
			}
			
			var regEx = new RegExp('surveyQuestionOption'+ record.getId() + '-[0-9]*', 'g');
			if(event.target.id.match(regEx)) {
				var editor = new Ext.Editor({
					updateEl: true,
					field: {
						xtype: 'textfield'
					}
				});
				
				editor.on({
					scope : {controller: this, view: grid, record: record},
					complete : 
						function(editor, value, startValue) {
							if(value != startValue) {
								this.record.set('isDirty', true);
								// TODO: Code to update ans in record
							}
						}
				});
				
				editor.startEdit(event.target);
				editor.realign();
			}
		}
		return false; // to prevent row collapse upon double click.
	},
	
	onNewQuestion: function() {
		var selectedRecord = this.getSurveyBuilderGrid().getSelectionModel().getSelection()[0];
		if(selectedRecord) {
			var idx = this.getQuestionnaireStore().indexOf(selectedRecord);
			this.addQuestionAt(idx);
		}
		else {
			this.addQuestionAt(this.getQuestionnaireStore().getCount());
		}
	},
	
	addQuestionAt: function(row) {
		var position = row>=0?row:0;
		var q = new ORT.model.Question({
				questionNo: (position+1), 
				type: 'singleChoice',
				answers: [
					{key: 'Choice 1'},
					{key: 'Choice 2'},
					{key: 'Choice 3'}
				]
			});
		q.setDirty(true);
		this.getQuestionnaireStore().insert(position, q);
		this.getSurveyBuilderGrid().getSelectionModel().select(q);
		// TODO: add code to reset all questions for modified order.
		this.onEditQuestion(q);
	},
	
	onEditQuestion: function(record) {
		var qEditWin = new Ext.Window({
			constrainHeader: true,
			modal: true,
			resizable: false,
			title	: 'Edit Survey Question ' + record.get('questionNo'),
			width	: 660,
			items	: [{ xtype: 'questionedit'}]
		});
		
		qEditWin.down('form').loadRecord(record);
		
		var singleChoiceGrid = Ext.getCmp('singleChoice-card');
		var multiChoiceGrid = Ext.getCmp('multiChoice-card');
		if(singleChoiceGrid && multiChoiceGrid) {
			singleChoiceGrid.store.loadData(record.get('answers'));
			multiChoiceGrid.store.loadData(record.get('answers'));
		}  
		
		qEditWin.show();
	},
	
	deleteQuestion: function(record) {
		this.getQuestionnaireStore().remove(record);
		this.getQuestionnaireStore().sync();
	},
	
	saveQuestion: function(button) {
		var qEditWin = button.up('window');
		var form = qEditWin.down('form');
		var rec = form.getRecord();
		var values = form.getValues();
		rec.set(values);
				
		var card = Ext.getCmp(rec.get('type')+'-card');
		if(card && 
			(rec.get('type') === 'singleChoice' 
				|| rec.get('type') === 'multiChoice'
				|| rec.get('type') === 'boolean')) {
			var store = card.getStore();
			if(store && store.getRange().length >= 0) {
				store.sync();
				rec.set('answers', Ext.pluck(store.data.items, 'data'));
			}
		}
		
		qEditWin.close();
		this.getQuestionnaireStore().sync();
	},
	
	closeQuestionEditWindow: function(button) {
		var qEditWin = button.up('window');
		qEditWin.close();
	},
	
	onAddPageBreakAfter: function() {
		var selectedRecord = this.getSurveyBuilderGrid().getSelectionModel().getSelection()[0];
		if(selectedRecord) {
			var idx = this.getQuestionnaireStore().indexOf(selectedRecord);
			this.addPageBreak(idx+1);
		}
		else {
			this.addPageBreak(this.getQuestionnaireStore().getCount());
		}
	},
	
	onAddPageBreakBefore: function() {
		var selectedRecord = this.getSurveyBuilderGrid().getSelectionModel().getSelection()[0];
		if(selectedRecord) {
			var idx = this.getQuestionnaireStore().indexOf(selectedRecord);
			this.addPageBreak(idx);
		}
		else {
			this.addPageBreak(0);
		}
	},
	
	addPageBreak: function(row) {
		var position = row>=0?row:0;
		var q = new ORT.model.Question({
				questionNo: (position+1), 
				type: 'pageBreak'
			});
		this.getQuestionnaireStore().insert(position, q);
		this.getSurveyBuilderGrid().getSelectionModel().select(q);
		this.getQuestionnaireStore().sync();
	}
});