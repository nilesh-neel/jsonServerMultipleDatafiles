Ext.define('ORT.view.survey.Edit', {
	
	extend: 'Ext.panel.Panel',
	
	alias: 'widget.surveyedit',
	
	requires: ['ORT.view.PortalPanel'],
	
	items: [
		{
			xtype: 'portalpanel',
			tabTip: 'My Survey tabtip',
			border: false,
			items: [
				{
					flex: 1,
					items: [
						{
							title: 'Block 1: General questions on interest...',
							html: '<div class="portlet-content">' + 'Some block summary here...' + '</div>'
						}, 
						{
							title: 'Block 2: Media Testing Block',
							items: 
							{
								xtype: 'chartportlet'
							}
						}, 
						{
							title: 'Block 3: Questions on user personal details...',
							html: '<div class="portlet-content">' + 'Some block summary here...' + '</div>'
						}
					]
				}
			]
		}
	]
});