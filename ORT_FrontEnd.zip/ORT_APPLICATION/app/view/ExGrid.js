Ext.define('ORT.view.survey.Grid', {
	extend: 'Ext.grid.Panel',
	alias: 'widget.surveygrid',
	//title : 'My Surveys',
	/*
	
	dockedItems: [
        {
            xtype: 'mainToolbar',//'taskForm',
            dock: 'top',
            // the grid's column headers are a docked item with a weight of 100.
            // giving this a weight of 101 causes it to be docked under the column headers
            weight: 101,
            bodyStyle: {
                'background-color': '#E4E5E7'
            }		
        }
    ],
	*/
	
    requires: [
        'ORT.ux.DragDrop',
        'ORT.ux.CheckColumn',
        'ORT.ux.ReminderColumn',
        'Ext.grid.plugin.CellEditing',
        'Ext.grid.column.Action',
        'Ext.grid.column.Date',
        'Ext.grid.feature.Grouping',
        'Ext.grid.plugin.DragDrop',
        //'Ext.ux.TreePicker' // TreePicker is not found!!!
    ],
	
	
    initComponent: function() {
		var me = this;
        this.store = {
            fields: ['title', 'done', 'responses', 'requiredSamples', 'createdOn', 'modifedOn', 'status'],
            data  : [
                {title: 'Radio Mirchi 98.3 - Top 10 Survey',    done: true, responses: 110, requiredSamples: 500, modifedOn: '10/10/2012', createdOn: '06/10/2012', status: 'Active'},
                {title: 'Radio Mirchi 98.3 - Christmas Survey',    done: true, responses: 110, requiredSamples: 1000, modifedOn: '10/10/2012', createdOn: '06/10/2012', status: 'Completed'},
                {title: 'Radio City 91.1', done: false, responses: 45, requiredSamples: 50, modifedOn: '10/10/2012', createdOn: '06/10/2012', status: 'Active'},
				{title: 'Red FM 93.5', done: true, responses: 68, requiredSamples: 100, modifedOn: '10/10/2012', createdOn: '06/10/2012', status: 'Active'},
				{title: 'Vividh Bharati 101.0', done: true, responses: 23, requiredSamples: 5000, modifedOn: '10/10/2012', createdOn: '06/10/2012', status: 'Inactive'}
            ]
        };
		
		cellEditingPlugin = Ext.create('Ext.grid.plugin.CellEditing'),
            groupingFeature = Ext.create('Ext.grid.feature.Grouping', {
                groupHeaderTpl: [
                    '{groupValue:this.renderDueDate}',
                    {
                        renderDueDate: me.renderDueDate
                    }
                ],
                enableGroupingMenu: false
            });

        me.plugins = [cellEditingPlugin];

        me.features = [groupingFeature];
 
        this.columns = {
            defaults: {
                draggable: false,
                resizable: false,
                hideable: false
            },
            items: [
                {
                    xtype: 'checkcolumn',
                    dataIndex: 'done',
                    cls: 'tasks-icon-column-header tasks-done-column-header',
                    width: 24,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    listeners: {
                        'checkchange': Ext.bind(me.handleCheckChange, me)
                    }
                },
                {
                    text: 'Survey Title',
                    dataIndex: 'title',
                    flex: 1,
                    emptyCellText: '',
                    editor: {
                        xtype: 'textfield',
                        selectOnFocus: true
                    }
                },
                {
                    text: 'Responses',
                    dataIndex: 'responses',
					align: 'center',
                    width: 70
                },
                //{
                //    text: 'List',
                //    dataIndex: 'list_id',
                //    width: 200,
                //    editor: {
                //        xtype: 'treepicker',
                //        displayField: 'name',
                //        store: Ext.create('ORT.store.Lists', {storeId: 'Lists-TaskGrid' })
                //    },
                //    renderer: me.renderList
                //},
                {
                    xtype: 'datecolumn',
                    text: 'Created Date',
                    dataIndex: 'createdOn',
                    width: 90,
                    editor: 'datefield',
                    format: 'n/j/Y',
                    emptyCellText: ''
                },
                {
                    xtype: 'datecolumn',
                    text: 'modifedOn',
                    dataIndex: 'modifedOn',
                    width: 90,
                    editor: 'datefield',
                    format: 'n/j/Y',
                    emptyCellText: ''
                },
                //{
                //    xtype: 'remindercolumn',
                //    dataIndex: 'reminder',
                //    cls: 'tasks-icon-column-header tasks-reminder-column-header',
                //    width: 24,
                //    tooltip: 'Set Reminder',
                //    menuPosition: 'tr-br',
                //    menuDisabled: true,
                //    sortable: false,
                //    emptyCellText: '',
                //    listeners: {
                //        select: Ext.bind(me.handleReminderSelect, me)
                //    }
                //},
                {
                    xtype: 'actioncolumn',
                    cls: 'tasks-icon-column-header tasks-edit-column-header',
                    width: 24,
                    icon: 'resources/images/edit_task.png',
                    iconCls: 'x-hidden',
                    tooltip: 'Edit',
                    menuDisabled: true,
                    sortable: false,
                    handler: Ext.bind(me.handleEditClick, me)
                },
                {
                    xtype: 'actioncolumn',
                    cls: 'tasks-icon-column-header tasks-delete-column-header',
                    width: 24,
                    icon: 'resources/images/delete.png',
                    iconCls: 'x-hidden',
                    tooltip: 'Delete',
                    menuDisabled: true,
                    sortable: false,
                    handler: Ext.bind(me.handleDeleteClick, me)
                }
            ]
		}
		
		
        //this.columns = [
        //    {header: 'Name', dataIndex: 'title', flex: 1, sortable: false, menuDisabled: true },
		//	{header: 'Status', dataIndex: 'status', width: 70, sortable: false, menuDisabled: true },
        //    {header: 'Responses', dataIndex: 'responses', width: 70, /*sortable: false,*/ menuDisabled: true },
        //    {header: 'Samples Needed?', dataIndex: 'requiredSamples', width: 100, /*sortable: false,*/ menuDisabled: true },
		//	{header: 'Created On', dataIndex: 'createdOn', width: 90, /*sortable: false,*/ menuDisabled: true },
		//	{header: 'Modifed', dataIndex: 'modifedOn', width: 90, /*sortable: false,*/ menuDisabled: true }
        //];
		
        this.callParent(arguments);

        me.addEvents(
            'editclick',
            'deleteclick',
            'recordedit',
            'reminderselect'
        );

        cellEditingPlugin.on('edit', me.handleCellEdit, this);
    },

    handleEditClick: function(gridView, rowIndex, colIndex, column, e) {
        // Fire a "deleteclick" event with all the same args as this handler
        this.fireEvent('editclick', gridView, rowIndex, colIndex, column, e);
    },

    handleDeleteClick: function(gridView, rowIndex, colIndex, column, e) {
        // Fire a "deleteclick" event with all the same args as this handler
        this.fireEvent('deleteclick', gridView, rowIndex, colIndex, column, e);
    },

    handleCheckChange: function(column, rowIndex, checked) {
        this.fireEvent('recordedit', this.store.getAt(rowIndex));
    },

    handleReminderSelect: function(task, value) {
        this.fireEvent('reminderselect', task, value);
    },

    handleCellEdit: function(editor, e) {
        this.fireEvent('recordedit', e.record);
    },

    refreshFilters: function() {
        var store = this.store,
            filters = store.filters;

        // save a reference to the existing task filters before clearing them
        filters = filters.getRange(0, filters.getCount() - 1);

        // clear the tasks store's filters and reapply them.
        store.clearFilter();
        store.filter(filters);
    },

    renderList: function(value, metaData, task, rowIndex, colIndex, store, view) {
        var listsStore = Ext.getStore('Lists'),
            node = value ? listsStore.getNodeById(value) : listsStore.getRootNode();

        return node.get('name');
    },

    renderDueDate: function(date) {
        var today = Ext.Date.clearTime(new Date()),
            todayTime = today.getTime(),
            dueDateTime;

        if(!date) {
            return '(No Date)';
        }
        dueDateTime = Ext.Date.clearTime(date).getTime();
        if(dueDateTime === todayTime) {
            return 'Today';
        }
        if(dueDateTime > todayTime) {
            if(dueDateTime === Ext.Date.add(today, Ext.Date.DAY, 1).getTime()) {
                // due date is current date + 1 day
                return 'Tomorrow';
            }
            if(dueDateTime < Ext.Date.add(today, Ext.Date.DAY, 7).getTime()) {
                // if the due date is less than one week in the future, return the day of the week.
                return Ext.Date.format(date, 'l');
            }
        } else {
            if(dueDateTime === Ext.Date.add(today, Ext.Date.DAY, -1).getTime()) {
                // due date is current date - 1 day.
                return 'Yesterday';
            }
            if(dueDateTime > Ext.Date.add(today, Ext.Date.DAY, -7).getTime()) {
                // if the due date is less than one week past, return 'Last' + the day of the week.
                return 'Last '+ Ext.Date.format(date, 'l');
            }
        }
        return date.getFullYear() === today.getFullYear() ? Ext.Date.format(date, 'D m/d') : Ext.Date.format(date, 'D m/d/Y');
    }
});