Ext.define('ORT.view.mysurveys.Grid', {
	
	extend: 'Ext.grid.Panel',
	
	alias: 'widget.mysurveysgrid',
	
	store: 'MySurveys',
	
	requires: [
        //'ORT.ux.CheckColumn'
    ],
	
	initComponent: function() {
		var me = this;
	
		this.columns = [
			/*
			// checkcolumn is added for later use. Do not delete!
			{
				xtype: 'checkcolumn',
				dataIndex: 'done',
				cls: 'tasks-icon-column-header tasks-done-column-header',
				width: 24,
				align: 'center',
				menuDisabled: true,
				sortable: false,
				listeners: {
					'checkchange': Ext.bind(me.handleCheckChange, me)
				}
			},
			*/
			{header: 'Name', dataIndex: 'title', flex: 1, tdCls:'mySurveyName'},
			{header: 'Status', dataIndex: 'status', width: 70},
			{header: 'Responses', dataIndex: 'responses', width: 70},
			{header: 'Samples Needed?', dataIndex: 'requiredSamples', width: 100},
			{header: 'Created On', dataIndex: 'createdOn', width: 90},
			{header: 'Modifed', dataIndex: 'modifedOn', width: 90},
			{
				xtype:'actioncolumn',
				width:215,
				sortable: false,
				menuDisabled: true,
				defaults: {
					draggable: false,
					resizable: false,
					hideable: false
				},
				items: [
					{
						xtype: 'actioncolumn',
						tooltip: 'Edit',
						iconCls:'optEdit' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Results',
						iconCls:'optResults' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Send',
						iconCls:'optSend' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'View',
						iconCls:'optView' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Collaborate',
						iconCls:'optCollaborate' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Copy',
						iconCls:'optCopy' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Delete',
						iconCls:'optDelete', // used handler - do not change!
						handler: function(grid, rowIndex, colIndex) {
							var rec = grid.getStore().getAt(rowIndex);
							//alert("Del " + rec.get('firstname'));
						}
					}
				]
			}
		];
		
		this.callParent(arguments);
	},
	
	handleCheckChange: function(column, rowIndex, checked) {
        //this.fireEvent('recordedit', this.store.getAt(rowIndex));
    }
});