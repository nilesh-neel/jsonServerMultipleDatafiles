var cardNav = function(incr){
	var l = Ext.getCmp('create-survey-panel').getLayout();
	var i = l.activeItem.id.split('card-')[1];
	var next = parseInt(i, 10) + incr;
	if(next >=0 && next <= 2 ) {
		l.setActiveItem(next);
		Ext.getCmp('card-prev1').setDisabled(next===0);
		Ext.getCmp('card-next1').setDisabled(next===2);
	}
};

Ext.define('ORT.view.survey.Builder', {
	
	extend: 'Ext.panel.Panel',
	
	alias: 'widget.surveybuilder',	
	
	id:'create-survey-panel',
	
	requires: ['ORT.view.survey.Edit'],
	
	layout:'card',
	//height: 600,
	activeItem: 0,
	//bodyStyle: 'padding:15px',
	defaults: {border:false},
	
	bbar: [
		'->', 
		{
			id: 'card-prev1',
			text: '&laquo; Previous',
			handler: Ext.Function.bind(cardNav, this, [-1]),
			disabled: true
		},
		{
			id: 'card-next1',
			text: 'Next &raquo;',
			listeners: {
				click: function() {
					// this == the button, as we are in the local scope
					//this.navigate(1);
				}
			}
			//handler: this.navigate//Ext.Function.bind(cardNav, this, [1])
		}
	],
	
	items: [
		{
			id: 'card-0',
			bodyStyle: 'padding:50px',
			html: '<div align="center"><h1>Welcome to the Survey Builder Wizard!</h1><br/><p>Step 1 of 3</p><br/>User will have 3 options to choose from following options... <br/><br/><br/><h1>[Quick Survey Builder]<br/><br/>[Create from Copy]<br/><h1>[Edit Existing Survey]<br/><br/>[Survey Library]</h1><br/><br/><br/><p>Please click the "Next" button to continue...</p></div>'
		},{
			id: 'card-1',
			//xtype: 'surveyedit',
			bodyStyle: 'padding:20px',
			html: '<div align="center"><p>Step 2 of 3</p><br/><h1>Almost there.  Please click the "Next" button to continue...</h1></div>'
		},{
			id: 'card-2',
			bodyStyle: 'padding:50px',
			html: '<div align="center"><h1>Congratulations!</h1><br/><h1>Survey is ready for publishing...</h1><br/><p>Step 3 of 3 - Complete</p></div>'
		}
	],
	
	navigate: function(incr) {
		alert("s");
		/*
		var l = Ext.getCmp('create-survey-panel').getLayout();
		var i = l.activeItem.id.split('card-')[1];
		var next = parseInt(i, 10) + incr;
		if(next >=0 && next <= 2 ) {
			l.setActiveItem(next);
			Ext.getCmp('card-prev1').setDisabled(next===0);
			Ext.getCmp('card-next1').setDisabled(next===2);
		}
		*/
	}
});