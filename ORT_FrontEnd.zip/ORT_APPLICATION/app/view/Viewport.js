Ext.define('ORT.view.Viewport', {
	
	extend: 'Ext.container.Viewport',
	
	requires: [
		'ORT.view.mysurveys.Grid',
		'ORT.view.survey.Builder',
		'ORT.view.admin.CompanyManager',
		'ORT.view.admin.UserManager'
	],
	
	layout: 'border',
	
	items: [
		{
			region: 'north',
			border: false,
			cls: 'regionHeader',
			loader: {
				url:'template/header.htm',
				autoLoad: true 
			}
		},	
		{
			region: 'center',
			xtype: 'grouptabpanel',
			activeGroup: 0,
			activeItem: 2,
			items: [
				{
					mainItem: 0,
					items: [
						{
							xtype: 'mysurveysgrid',
							title: 'My Surveys',
							tooltip: 'My Surveys',
							itemId: 'My_Surveys',
							iconCls: 'ort-mySurveys',
							margin: '10',
							html: 'A simple screen showing survey summary...'
						}
					]
				}, 
				{
					expanded: false,
					items: [
						{
							title: 'Create Survey',
							tabTip: 'Create your new survey from here...',
							iconCls: 'ort-createSurveys',
							margin: '10',
							html: 'Create your new survey from here...'
						},
						{
							title: 'Survey Wizard',
							tabTip: 'Survey Wizard',
							iconCls: 'ort-createSurveys-wizard',
							style: 'padding: 10px;',
							html: 'wizard...'
						},
						{
							title: 'Add Questions',
							tabTip: 'Add Questions',
							iconCls: 'ort-createSurveys-addQuestions',
							style: 'padding: 10px;',
							html: 'add questions...'
						},
						{
							title: 'Use Questionnaire',
							tabTip: 'questionnaire from existing survey',
							iconCls: 'ort-createSurveys-useQuestionnaire',
							style: 'padding: 10px;',
							html: 'questionnaire...'
						}
					]
				}, 
				{
					activeItem: 1,
					expanded: false,
					items: [
						{
							title: 'Edit Survey',
							tabTip: 'Edit Survey...',
							iconCls: 'ort-editSurveys',
							margin: '10',
							html: 'Edit Survey...'
						},
						{
							title: 'Survey Design',
							xtype: 'surveybuilder',
							tabTip: 'Survey Design',
							iconCls: 'ort-editSurveys-surveyDesign',
							style: 'padding: 10px;',
							html: 'Survey Design...'
						},
						{
							title: 'Survey Options',
							tabTip: 'Survey Options',
							iconCls: 'ort-editSurveys-surveyOptions',
							style: 'padding: 10px;',
							html: 'Survey Options...'
						},
						{
							title: 'Print Survey',
							tabTip: 'Print Survey',
							iconCls: 'ort-editSurveys-surveyPrint',
							style: 'padding: 10px;',
							html: 'Print Survey...'
						},
						{
							title: 'Export to Word',
							tabTip: 'Export to Word',
							iconCls: 'ort-editSurveys-surveyWord',
							style: 'padding: 10px;',
							html: 'Export to Word...'
						},
						{
							title: 'Preview Survey',
							tabTip: 'Preview Survey',
							iconCls: 'ort-editSurveys-surveyPreview',
							style: 'padding: 10px;',
							html: 'Preview Survey...'
						},
						{
							title: 'Send Survey',
							tabTip: 'Send Survey',
							iconCls: 'ort-editSurveys-surveySend',
							style: 'padding: 10px;',
							html: 'Send Survey...'
						}
					]
				},
				{
					expanded: false,
					items: [
						{
							title: 'Send Survey',
							tabTip: 'Send Survey...',
							iconCls: 'ort-sendSurveys-surveySend',
							margin: '10',
							html: 'Send Survey...'
						},
						{
							title: 'Survey Link',
							tabTip: 'Survey Link',
							iconCls: 'ort-sendSurveys-surveyLink',
							style: 'padding: 10px;',
							html: 'Survey Link...'
						},
						{
							title: 'Email Survey',
							tabTip: 'Email Survey',
							iconCls: 'ort-sendSurveys-surveyEmail',
							style: 'padding: 10px;',
							html: 'Email Survey...'
						},
						{
							title: 'Email History',
							tabTip: 'Email History',
							iconCls: 'ort-sendSurveys-emailHistory',
							style: 'padding: 10px;',
							html: 'Email History...'
						}
					]
				},
				{
					expanded: false,
					items: [
						{
							title: 'Reports',
							tabTip: 'Reports...',
							iconCls: 'ort-reports',
							margin: '10',
							html: 'Reports...'
						},
						{
							title: 'View Reports',
							tabTip: 'View Reports',
							iconCls: 'ort-reports-view',
							style: 'padding: 10px;',
							html: 'View Reports...'
						},
						{
							title: 'Report Options',
							tabTip: 'Report Options',
							iconCls: 'ort-reports-options',
							style: 'padding: 10px;',
							html: 'Report Options...'
						},
						{
							title: 'Report Alerts',
							tabTip: 'Report Alerts',
							iconCls: 'ort-reports-alerts',
							style: 'padding: 10px;',
							html: 'Report Alerts...'
						},
						{
							title: 'Trend Reports',
							tabTip: 'Trend Reports',
							iconCls: 'ort-reports-trend',
							style: 'padding: 10px;',
							html: 'Trend Reports...'
						},
						{
							title: 'Export',
							tabTip: 'Export',
							iconCls: 'ort-reports-export',
							style: 'padding: 10px;',
							html: 'Export...'
						}
					]
				},
				{
					expanded: false,
					items: [
						{
							title: 'Music Closet',
							tabTip: 'Music Closet...',
							iconCls: 'ort-music',
							margin: '10',
							html: 'Music Closet...'
						}
					]
				},
				{
					expanded: false,
					items: [
						{
							title: 'Library',
							tabTip: 'Library...',
							iconCls: 'ort-library',
							margin: '10',
							html: 'Library...'
						},
						{
							title: 'Survey Library',
							tabTip: 'Survey Library',
							iconCls: 'ort-library-survey',
							style: 'padding: 10px;',
							html: 'Survey Library...'
						},
						{
							title: 'Question Library',
							tabTip: 'Question Library',
							iconCls: 'ort-library-question',
							style: 'padding: 10px;',
							html: 'Question Library...'
						},
						{
							title: 'Graphics Library',
							tabTip: 'Graphics Library',
							iconCls: 'ort-library-graphics',
							style: 'padding: 10px;',
							html: 'Graphics Library...'
						},
						{
							title: 'Message Library',
							tabTip: 'Message Library',
							iconCls: 'ort-library-message',
							style: 'padding: 10px;',
							html: 'Message Library...'
						}
					]
				},
				{
					expanded: false,
					items: [
						{
							title: 'Panels',
							tabTip: 'Panels...',
							iconCls: 'ort-panels',
							margin: '10',
							html: 'Panels...'
						}
					]
				},
				{
					expanded: false,
					items: [
						{
							title: 'Administration',
							tabTip: 'Administration...',
							iconCls: 'ort-admin',
							margin: '10',
							html: 'Administration...'
						},
						{
							xtype: 'usermanager',
							title: 'Users',
							tabTip: 'Search and Edit Users',
							iconCls: 'ort-admin-users',
							style: 'padding: 10px;'
						},
						{
							xtype: 'companymanager',
							title: 'Companies',
							tabTip: 'Search and Edit Companies',
							iconCls: 'ort-admin-groups',
							style: 'padding: 10px;'
						},
						{
							title: 'Housekeeping',
							tabTip: 'Group Types',
							iconCls: 'ort-admin-groupTypes',
							style: 'padding: 10px;',
							html: 'Group Types...'
						}
					]
				}
			]
		},
		{
			region: 'south',
			border: false,
			cls: 'regionFooter',
			loader: {
				url:'template/footer.htm',
				autoLoad: true
			}
		}]
});