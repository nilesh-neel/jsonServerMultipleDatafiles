Ext.define('ORT.view.admin.CompanyEdit', {
	extend: 'Ext.form.Panel',
	
	alias: 'widget.companyedit',
	
	defaults: {
		border: false,
		//xtype: 'form',
		flex: 1,
		layout: 'anchor'
	},
	
	title : 'Edit Company',
	
	id: 'panelEditCompany',
    
	autoShow: true,
	
	collapsible: true,
	
	floatable: false,
	
	titleCollapse: false,
	
	collapsed: true,
	
	autoScroll: true,
 
	bodyStyle: 'padding:5px 5px 0;',
	
	fieldDefaults: {
		//labelWidth: 125,
		msgTarget: 'side',
		autoFitErrors: false
	},
	
	items: [{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Abbreviation',
			name: 'abbreviation',
			allowBlank: false,
			maxLength: 20,
			vtype: 'alphanum',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		},{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Name',
			name: 'name',
			maskRe: /[a-zA-Z\s]+$/,
			allowBlank: false,
			maxLength: 150,
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			},
			validator: function(v) {
				if(!(/[a-zA-Z\s]+$/.test(v))){
					return "This field should be in alphabets";
				}
				return true;
			}
		},{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Contact Person',
			allowBlank: false,
			maxLength: 150,
			name: 'contactPerson',
			maskRe: /[a-zA-Z\s]+$/,
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			},
			validator: function(v) {
				if(!(/[a-zA-Z\s]+$/.test(v))){
					return "This field should be in alphabets";
				}
				return true;
			}
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Address Line 1',
			allowBlank: false,
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			},
			maxLength: 150,
			name: 'addressLine1'
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Address Line 2',
			maxLength: 150,
			name: 'addressLine2'
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Zip Code',
			allowBlank: true,
			name: 'zipCode',
			validator: function(v){
				if(v.length!=0 && !(/^\d{5}(-\d{4})?$/.test(v))) {
					return "This field should be a Zip Code in the format<br/>\"94105-0011\" or \"94105\"";
				}
				return true;		
			}
		}, {
			flex:1,
			border: false
		}, {
			flex:1,
			border: false
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Country',
			name: 'country',
			store: 'Countries',
			valueField: 'id',
			displayField: 'name',
			allowBlank: false,
			//typeAhead: true,
			editable: false,
			queryMode: 'local',
			emptyText: 'Select a Country',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
			
		},{
			flex:1,
			xtype:'combobox',
			fieldLabel: 'State',
			name: 'state',
			store: 'States',
			valueField: 'id',
			displayField: 'name',
			allowBlank: false,
			//typeAhead: true,
			editable: false,
			queryMode: 'local',
			emptyText: 'Select a State',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}, {
			flex:1,
			xtype:'combobox',
			fieldLabel: 'City',
			name: 'city',
			store: 'Cities',
			valueField: 'id',
			displayField: 'name',
			//typeAhead: true,
			editable: false,
			allowBlank: false,
			queryMode: 'local',
			emptyText: 'Select a City',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Phone 1',
			name: 'phone1',
			itemId: 'phone1',
			minLength: 6,
			maxLength: 15,
			allowBlank: false,
			maskRe: /[0-9\-.]+$/,
			validator: function(v) {
				if(!(/^(?:\p{L}\p{M}*|[\- - . $]|[0-9])*$/.test(v))){
					return "This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen";
				}
				return true;
			},
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer,
				 render: function(c) {
					Ext.QuickTips.register({
					target: c.getEl(),
					text: 'This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen'
					})	
				}
			}
		}, {
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Phone 2',
			name: 'phone2',
			minLength: 6,
			maxLength: 15,
			vtype: 'phoneNo',
			initialPhoneNoField: 'phone1',
			maskRe: /[0-9\-.]+$/,
			validator: function(v) {
				if(v.length==0) {
					return true;
				}
				if(!(/^(?:\p{L}\p{M}*|[\- - . $]|[0-9])*$/.test(v))){
					return "This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen";
				}
				return true;
			},
			listeners: {
				 render: function(c) {
					Ext.QuickTips.register({
					target: c.getEl(),
					text: 'This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen'
					})	
				}
			}
		}, {
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Email',
			allowBlank: false,
			maxLength: 150,
			name: 'email',
			vtype: 'email',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Website',
			name: 'website',
			maxLength: 150,
			vtype: 'url'
		}]
	}],
	
	buttons: [
		'->', 
		{
			name: 'addButton',
			text: 'New Company',
			action: 'add',
			width: 130,
			iconCls: 'icon-newCompanyBtn',
			scale:'medium'
		}, {
			name: 'saveButton',
			text: 'Save',
			action: 'save',
			width: 100,
			iconCls: 'icon-saveBtn',
			scale:'medium'
		}, {
			name: 'revertButton',
			text: 'Revert',
			action: 'revert',
			width: 100,
			iconCls: 'icon-revertBtn',
			scale:'medium'
		}
	],
	
	constructor: function (config) {
		//this.callParent(config);
		//this.callSuper(config);
		this.superclass.constructor.call(this, config);

		Ext.apply(Ext.form.field.VTypes, {
			phoneNoText: 'The two phone numbers cannot be same!',
			phoneNo: function(val, field) {
				if (field.initialPhoneNoField) {
					var pwd = field.up('form').down('#' + field.initialPhoneNoField);
					return (val != pwd.getValue());
				}
				return true;
			}
		});
	}
});
