Ext.define('ORT.view.admin.CompanyManager', {
	
	extend: 'Ext.panel.Panel',
	
	alias: 'widget.companymanager',
	
	//autoScroll: true,

	layout: 'border',
	
	requires: [
		'ORT.view.admin.CompanySearch',
		'ORT.view.admin.CompanyEdit'
	],
	
	items: [
		{
			//title: 'Search Company',
			xtype: 'companysearch',
			region: 'center',
			margin: 15
		},
		{
			title: 'Add / Edit Company',
			xtype: 'companyedit',
			region: 'south'//,
			//split: true
		}
	]	
});