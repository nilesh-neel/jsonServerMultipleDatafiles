Ext.define('ORT.view.admin.UserSearch', {
	
	extend: 'Ext.grid.Panel',
	
	alias: 'widget.usersearch',
	
	store: 'SearchedUsers',
	
	requires: ['Ext.Toolbar.TextItem'],
	
	initComponent: function() {
		var me = this;
		
		this.dockedItems = [
			{
				dock: 'top',
				border: false,
				items: [{
					layout: {
						type: 'hbox',
						padding:'5',
						align:'top'
					},
					defaults:{margins:'0 25 0 0'},
					border: false,
					items:[{
						flex:1,
						id: 'nameFilter',
						xtype:'textfield',
						fieldLabel:'Name',
						name: 'name',
						maskRe: /[a-zA-Z\s]+$/
					},{
						flex:1,
						id: 'companyFilter',
						xtype:'textfield',
						fieldLabel:'Company',
						name: 'company',
						maskRe: /[a-zA-Z\s]+$/
					}, {
						flex:1,
						id: 'loginIdFilter',
						xtype:'textfield',
						fieldLabel:'Login ID',
						name: 'loginId',
						vtype: 'alphanum'
					}]
				},{
					layout: {
						type: 'hbox',
						padding:'5',
						align:'top'
					},
					defaults:{margins:'0 25 10 0'},
					border: false,
					items:[{
						flex:1,
						id: 'emailFilter',
						xtype:'textfield',
						fieldLabel:'Email',
						name: 'email',
						vtype: 'email'
					},{
						flex:1,
						id: 'codeFilter',
						xtype:'textfield',
						fieldLabel:'Code',
						name: 'code',
						vtype: 'alphanum'
					},{
						flex:1,
						border: false,
						layout: {
							type: 'hbox',
							pack: 'end',
							align:'middle'
						},
						items:[{
							width: 100,
							xtype:'button',
							action: 'search',
							text: 'Search',
							iconCls: 'icon-searchBtn',
							scale:'medium'
							
						}]
					}]
				}]
			}
		];
		
		this.columns = [
			{header: 'Code', dataIndex: 'code', width: 60},
			{header: 'Name', dataIndex: 'name', width: 80},
			{header: 'Login ID', dataIndex: 'loginId', width: 100},
			{header: 'Email', dataIndex: 'email', width: 60},
			{
				header: 'Company', 
				dataIndex: 'company', 
				flex: 1,
				renderer: function(value) {
					var display = 'INVALID';
					var store = Ext.getStore('Companies');
					var idx = store.findExact('id', ''+value);
					if(idx != -1) {
						var rec = store.getAt(idx);
						display = rec.get('name');
					}
					return display;
				}
			},
			{
				header: 'Role', 
				dataIndex: 'role', 
				width: 60,
				renderer: function(value) {
					var display = 'INVALID';
					var store = Ext.getStore('Roles');
					var idx = store.findExact('id', ''+value);
					if(idx != -1) {
						var rec = store.getAt(idx);
						display = rec.get('name');
					}
					return display;
				}
			},
			{
				header: 'Actions',
				xtype:'actioncolumn',
				width:100,
				sortable: false,
				menuDisabled: true,
				defaults: {
					draggable: false,
					resizable: false,
					hideable: false
				},
				items: [
					{
						xtype: 'actioncolumn',
						tooltip: 'Delete',
						iconCls:'optSmallDelete'
					}
				]
			}
		];
		
		this.callParent(arguments);
	}
	
});