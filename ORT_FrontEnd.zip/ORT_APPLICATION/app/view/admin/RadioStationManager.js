Ext.define('ORT.view.admin.RadioStationManager', {
	
	extend: 'Ext.panel.Panel',
	
	alias: 'widget.radiostationmanager',
	
	items: [
		{
			title: 'Search Radio Station',
			html: 'Search Radio Stations'
		},
		{
			title: 'Add / Edit Radio Station',
			html: 'Add Edit Radio Station'
		}
	]	
});