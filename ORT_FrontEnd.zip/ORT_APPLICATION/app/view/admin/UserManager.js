Ext.define('ORT.view.admin.UserManager', {
	
	extend: 'Ext.panel.Panel',
	
	alias: 'widget.usermanager',
	
	//autoScroll: true,

	layout: 'border',
	
	requires: [
		'ORT.view.admin.UserSearch',
		'ORT.view.admin.UserEdit'
	],
	
	items: [
		{
			//title: 'Search Users',
			xtype: 'usersearch',
			region: 'center',
			margin: 10
		},
		{
			title: 'Add / Edit Users',
			xtype: 'useredit',
			region: 'south'
			//split: true
		}
	]	
});