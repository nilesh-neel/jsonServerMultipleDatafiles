Ext.namespace('ORT.user');

ORT.user.group = [
        ['master', 'Master User'],
        ['power', 'Power User'],
		['normal', 'Normal User']
	];
	
Ext.define('ORT.view.admin.UserEdit', {
	extend: 'Ext.form.Panel',
	
	alias: 'widget.useredit',
	
	defaults: {
		border: false,
		//xtype: 'form',
		flex: 1,
		layout: 'anchor'
	},
	
	title : 'Edit User',
    
	id: 'panelEditUser',
	
	autoShow: true,
	
	collapsible: true,
	
	floatable: false,
	
	titleCollapse: false,
	
	collapsed: true,
	
	autoScroll: true,
 
	bodyStyle: 'padding:5px 5px 0;',
	
	fieldDefaults: {
		//labelWidth: 125,
		msgTarget: 'side',
		autoFitErrors: false
	},
	
	items: [{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Code',
			name: 'code',
			allowBlank: false,
			disabled: true,
			maxLength: 20,
			vtype: 'alphanum',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer,
				 render: function(c) {
					Ext.QuickTips.register({
					target: c.getEl(),
					text: 'Enter uique alphanumeric code'
					})	
				}
			}
		},{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Name',
			allowBlank: false,
			disabled: true,
			maxLength: 50,
			name: 'name',
			maskRe: /[a-zA-Z\s]+$/,
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			},
			validator: function(v) {
				if(!(/[a-zA-Z\s]+$/.test(v))){
					return "This field should be in alphabets";
				}
				return true;
			}
		}, {
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Role',
			name: 'role',
			store: 'Roles',
			valueField: 'id',
			displayField: 'name',
			//typeAhead: true,
			editable: false,
			allowBlank: false,
			disabled: true,
			queryMode: 'local',
			emptyText: 'Select a Role',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Login ID',
			name: 'loginId',
			allowBlank: false,
			disabled: true,
			minLength: 6,
			maxLength: 30,
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			},
			validator: function(v) {
				if(!(/[a-zA-Z][a-zA-Z0-9]+$/.test(v))){
					return "This field should be alphanumeric";
				}
				return true;
			}			
		},{
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Company',
			name: 'company',
			store: 'Companies',
			valueField: 'id',
			displayField: 'name',
			//typeAhead: true,
			editable: false,
			allowBlank: false,
			disabled: true,
			queryMode: 'local',
			emptyText: 'Select a Company',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		},{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Department',
			name: 'department',
			maxLength: 150,
			disabled: true,
			vtype: 'alphanum'
		}
		]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Phone 1',
			name: 'phone1',
			itemId: 'phone1',
			minLength: 6,
			maxLength: 15,
			allowBlank: false,
			disabled: true,
			maskRe: /[0-9\-.]+$/,
			validator: function(v) {
				if(!(/^(?:\p{L}\p{M}*|[\- - . $]|[0-9])*$/.test(v))){
					return "This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen";
				}
				return true;
			},
			listeners: {
				 beforerender: ORT.Utility.MandatoryFieldRenderer,
				 render: function(c) {
					Ext.QuickTips.register({
					target: c.getEl(),
					text: 'This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen'
					})	
				}
			}
		}, {
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Phone 2',
			name: 'phone2',
			minLength: 6,
			maxLength: 15,
			disabled: true,
			vtype: 'phoneNo',
			initialPhoneNoField: 'phone1',
			maskRe: /[0-9\-.]+$/,
			validator: function(v) {
				if(v.length==0) {
					return true;
				}
				if(!(/^(?:\p{L}\p{M}*|[\- - . $]|[0-9])*$/.test(v))){
					return "This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen";
				}
				return true;
			},
			listeners: {
				 render: function(c) {
					Ext.QuickTips.register({
					target: c.getEl(),
					text: 'This field should be a Phone No. containing atleast 6 digits spearated by period/hyphen'
					})
				}
			}
		},{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Email',
			name: 'email',
			allowBlank: false,
			disabled: true,
			maxLength: 50,
			vtype:'email',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[{
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Timezone',
			name: 'timezone',
			store: 'Timezones',
			valueField: 'id',
			displayField: 'name',
			//typeAhead: true,
			editable: false,
			allowBlank: false,
			disabled: true,
			queryMode: 'local',
			emptyText: 'Select a Timezone',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}, {
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Language',
			name: 'language',
			store: 'Languages',
			valueField: 'id',
			displayField: 'name',
			editable: false,
			allowBlank: false,
			disabled: true,
			queryMode: 'local',
			emptyText: 'Select a Language',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
			
		}, {
			flex:1,
			border: false
		}]	
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 25 0 0'},
		items:[ {
			flex:1,
			xtype:'textfield',
			inputType: 'password',
			fieldLabel: 'Password',
			name: 'password',
			maxLength: 20,
			allowBlank: true,
			disabled: true,
			itemId: 'password'
		} ,{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Confirm Password',
			inputType: 'password',
			name: 'confirmPassword',
			disabled: true,
			labelWidth: 115,
			vtype: 'password',
			initialPassField: 'password'
		}, {
			flex:1,
			border: false
		}]
	}],
	
	buttons: [
		'->', 
		{
			text: 'Change Password',
			action: 'changePassword',
			width: 150,
			iconCls: 'icon-changePasswordBtn',
			scale:'medium',
			disabled: true,
			hidden: true
		}, {
			name: 'addButton',
			text: 'New User',
			action: 'add',
			width: 100,
			iconCls: 'icon-newUserBtn',
			scale:'medium',
			disabled: false
		}, {
			name: 'saveButton',
			text: 'Save',
			action: 'save',
			width: 100,
			iconCls: 'icon-saveBtn',
			scale:'medium',
			disabled: true
		}, {
			name: 'revertButton',
			text: 'Revert',
			action: 'revert',
			width: 100,
			iconCls: 'icon-revertBtn',
			scale:'medium',
			disabled: true
		}
	],
	
	constructor: function (config) {
		//this.callParent(config);
		//this.callSuper(config);
		this.superclass.constructor.call(this, config);

		Ext.apply(Ext.form.field.VTypes, {
			phoneNoText: 'The two phone numbers cannot be same!',
			phoneNo: function(val, field) {
				if (field.initialPhoneNoField) {
					var pwd = field.up('form').down('#' + field.initialPhoneNoField);
					return (val != pwd.getValue());
				}
				return true;
			},
			passwordText: 'Passwords do not match!',
			password: function(val, field) {
				if (field.initialPassField) {
					var pwd = field.up('form').down('#' + field.initialPassField);
					return pwd?(val == pwd.getValue()):false;
				}
				return true;
			}	
		});
	}
});
