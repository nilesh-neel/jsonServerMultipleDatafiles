Ext.define('ORT.view.admin.PasswordEdit', {
	extend: 'Ext.form.Panel',
	
    alias : 'widget.passwordedit',
 
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 115
	},
	
	//margin: 10,
	id : 'passwordEdit',
	
	items: [
		{
			flex:3,
			xtype:'textfield',
			fieldLabel: 'Password',
			inputType: 'password',
			name: 'password',
			allowBlank: false,
			maxLength: 25,
			itemId: 'password',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		},
		{
			flex:3,
			xtype:'textfield',
			fieldLabel: 'Confirm Password',
			inputType: 'password',
			name: 'confirmPassword',
			vtype: 'password',
			allowBlank: false,
			initialPassField: 'password',
			listeners: {
				beforerender: ORT.Utility.MandatoryFieldRenderer
			}
		}
	],
    
    initComponent: function() {
 
        this.buttons = [
            '->', 
			{
				name: 'okButton',
				text: 'Ok',
				action: 'ok',
				width: 100,
				iconCls: 'icon-saveBtn',
				scale:'medium'
			}, {
				name: 'cancelButton',
				text: 'Cancel',
				action: 'cancel',
				width: 100,
				iconCls: 'icon-cancelBtn',
				scale:'medium'
			}
        ];
 
        this.callParent(arguments);
    },
	constructor: function (config) {
		this.superclass.constructor.call(this, config);

		Ext.apply(Ext.form.field.VTypes, {
			passwordText: 'Passwords do not match!',
			password: function(val, field) {
				if (field.initialPassField) {
					var pwd = field.up('form').down('#' + field.initialPassField);
					return pwd?(val == pwd.getValue()):false;
				}
				return true;
			}			
			
		});
	}
});