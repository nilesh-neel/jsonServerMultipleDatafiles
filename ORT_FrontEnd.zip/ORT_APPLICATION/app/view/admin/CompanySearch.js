Ext.define('ORT.view.admin.CompanySearch', {
	
	extend: 'Ext.grid.Panel',
	
	alias: 'widget.companysearch',
	
	store: 'SearchedCompanies',
	
	requires: ['Ext.Toolbar.TextItem'],
	
	initComponent: function() {
		var me = this;
		
		this.dockedItems = [
			{
				dock: 'top',
				border: false,
				items: [{
					layout: {
						type: 'hbox',
						padding:'5',
						align:'top'
					},
					defaults:{margins:'0 25 10 0'},
					border: false,
					items:[{
						flex:1,
						id: 'companyAbbreviationFilter',
						xtype:'textfield',
						fieldLabel:'Abbreviation',
						name: 'abbreviation',
						maskRe: /[a-zA-Z0-9.]+$/
					},{
						flex:1,
						id: 'companyNameFilter',
						xtype:'textfield',
						fieldLabel:'Company Name',
						name: 'company',
						maskRe: /[a-zA-Z\s]+$/
					},{
						flex:1,
						border: false,
						layout: {
							type: 'hbox',
							pack: 'end',
							align:'middle'
						},
						items:[{
							width: 100,
							xtype:'button',
							action: 'search',
							text: 'Search',
							iconCls: 'icon-searchBtn',
							scale:'medium'
						}]
					}]
				}]
			}
		];
		
		this.columns = [
			{header: 'Abbreviation', dataIndex: 'abbreviation', width: 70},
			{header: 'Name', dataIndex: 'name', flex: 1},
			{
				header: 'City', 
				dataIndex: 'city', 
				width: 60,
				renderer: function(value) {
					var display = 'INVALID';
					var store = Ext.getStore('Cities');
					var idx = store.findExact('id', ''+value);
					if(idx != -1) {
						var rec = store.getAt(idx);
						display = rec.get('name');
					}
					return display;
				}
			},
			{
				header: 'Country', 
				dataIndex: 'country', 
				width: 60,
				renderer: function(value) {
					var display = 'INVALID';
					var store = Ext.getStore('Countries');
					var idx = store.findExact('id', ''+value);
					if(idx != -1) {
						var rec = store.getAt(idx);
						display = rec.get('name');
					}
					return display;
				}
			},
			{header: 'Email', dataIndex: 'email', width: 120},
			{header: 'Website', dataIndex: 'website', width: 200},
			{
				header: 'Actions',
				xtype:'actioncolumn',
				width:100,
				sortable: false,
				menuDisabled: true,
				defaults: {
					draggable: false,
					resizable: false,
					hideable: false
				},
				items: [
					{
						xtype: 'actioncolumn',
						tooltip: 'Delete',
						iconCls:'optSmallDelete'
					}
				]
			}
		];
		
		this.callParent(arguments);
	}
});