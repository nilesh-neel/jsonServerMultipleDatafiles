Ext.define('ORT.view.panel.Search', {
	
	extend: 'Ext.grid.Panel',
	
	alias: 'widget.panelsearch',
	
	store: 'SearchedPanels',
	
	requires: ['Ext.Toolbar.TextItem'],
	
	initComponent: function() {
		var me = this;
		
		this.dockedItems = [
			{
				dock: 'top',
				border: false,
				items: [{
					layout: {
						type: 'hbox',
						padding:'5',
						align:'top'
					},
					defaults:{
						margins:'0 25 0 0',
						labelWidth: 60
					},
					border: false,
					items:[{
						flex:1,
						id: 'panelLibrarytFilter',
						xtype:'combobox',
						fieldLabel: 'Library',
						name: 'company',
						store: 'Companies',
						valueField: 'id',
						displayField: 'name',
						editable: false,
						allowBlank: false,
						queryMode: 'local',
						emptyText: 'Select a Library'
					},{
						flex:1,
						id: 'panelCategoryFilter',
						xtype:'combobox',
						fieldLabel: 'Category',
						name: 'company',
						store: 'Companies',
						valueField: 'id',
						displayField: 'name',
						editable: false,
						allowBlank: false,
						queryMode: 'local',
						emptyText: 'Select a Category'
					},{
						flex:1,
						id: 'panelNameFilter',
						xtype:'textfield',
						fieldLabel:'Panel Name',
						labelWidth: 70,
						name: 'name',
						vtype: 'alphanum'
					},{
						width: 100,
						xtype:'button',
						action: 'search',
						text: 'Search',
						iconCls: 'icon-searchBtn',
						scale:'medium'
						
					}]
				}]
			}
		];
		
		this.columns = [
			{
				header: 'Category', 
				dataIndex: 'category', 
				width: 80,
				renderer: function(value) {
					var display = 'INVALID';
					var store = Ext.getStore('PanelCategories');
					var idx = store.findExact('id', ''+value);
					if(idx != -1) {
						var rec = store.getAt(idx);
						display = rec.get('name');
					}
					return display;
				}
			},
			{header: 'Panel Name', dataIndex: 'name', flex: 1},
			{header: 'Last Used', dataIndex: 'lastUsed', width: 150},
			{
				header: 'Members',
				dataIndex: 'members',
				width: 60,
				renderer: function(val, cell, record) {
					var members = record.get('members');
					if(members) {
						return members.length;
					}
					else {
						return 0;
					}
				}				
			},
			{
				xtype:'actioncolumn',
				width:100,
				sortable: false,
				menuDisabled: true,
				defaults: {
					draggable: false,
					resizable: false,
					hideable: false
				},
				items: [
					{
						xtype: 'actioncolumn',
						tooltip: 'Edit',
						iconCls:'optSmallEdit' // used in controller - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Send',
						iconCls:'optSend' // used in controller - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Delete',
						iconCls:'optSmallDelete'
					}
				]
			}
		];
		
		this.callParent(arguments);
	}	
});