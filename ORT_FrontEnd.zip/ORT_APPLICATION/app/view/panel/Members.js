Ext.define('ORT.view.panel.Members', {
	
	extend: 'Ext.grid.Panel',
	
	alias: 'widget.panelmembers',
	
	//store: 'SearchedPanels',
	
	//autoShow: true,
	
	collapsible: true,
	
	//collapsed: true,
	
	autoScroll: true,
	
	requires: ['Ext.Toolbar.TextItem'],
	
	initComponent: function() {
		var me = this;
		
		this.dockedItems = [
			{
				dock: 'top',
				border: false,
				items: [{
					layout: {
						type: 'hbox',
						padding:'5',
						align:'top'
					},
					defaults:{
						margins:'0 25 0 0',
						labelWidth: 60
					},
					border: false,
					items:[{
						flex:1,
						border: false
					},{
						flex:1,
						border: false
					},{
						width: 180,
						xtype:'button',
						action: 'import',
						text: 'Import/Update Members',
						iconCls: 'icon-searchBtn',
						scale:'medium'						
					},{
						width: 120,
						xtype:'button',
						action: 'add',
						text: 'Add Members',
						iconCls: 'icon-searchBtn',
						scale:'medium'						
					}]
				}]
			}
		];
		
		this.columns = [
			{header: 'Reference ID', dataIndex: 'code', width: 80},
			{header: 'Email Address', dataIndex: 'name', width: 175},
			{header: 'Name', dataIndex: 'loginId', flex: 1},
			{header: 'status', dataIndex: 'email', width: 60},
			{
				xtype:'actioncolumn',
				width:100,
				sortable: false,
				menuDisabled: true,
				defaults: {
					draggable: false,
					resizable: false,
					hideable: false
				},
				items: [
					{
						xtype: 'actioncolumn',
						tooltip: 'Edit',
						iconCls:'optSmallEdit' // used in controller - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Delete',
						iconCls:'optSmallDelete'
					}
				]
			}
		];
		
		this.callParent(arguments);
	}	
});