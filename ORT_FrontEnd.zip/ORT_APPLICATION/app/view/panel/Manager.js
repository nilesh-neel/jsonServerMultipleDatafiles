Ext.define('ORT.view.panel.Manager', {
	
	extend: 'Ext.panel.Panel',
	
	alias: 'widget.panelmanager',
	
	layout: 'border',
	
	requires: [
		'ORT.view.panel.Search',
		'ORT.view.panel.Members'
	],
	
	items: [
		{
			xtype: 'panelsearch',
			region: 'center',
			margin: 10
		},
		{
			title: 'View Panel Members',
			xtype: 'panelmembers',
			region: 'south'
		}
	]	
});