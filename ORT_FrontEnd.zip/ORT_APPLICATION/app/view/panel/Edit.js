Ext.define('ORT.view.panel.Edit', {
	
	extend: 'Ext.form.Panel',
	
	alias: 'widget.paneledit',
	
	defaults: {
		border: false,
		flex: 1,
		layout: 'anchor'
	},
	
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 80,
		width: 300
	},
	
	id: 'panelEdit',
	
	bodyStyle: 'padding:5px 5px 0;',
	
	items: [ 
		{
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Panel Library',
			name: 'library',
			store: 'PanelLibraries',
			valueField: 'id',
			displayField: 'name',
			editable: false,
			allowBlank: false,
			queryMode: 'local',
			emptyText: 'Select a Library'
		},
		{
			flex:1,
			xtype:'combobox',
			fieldLabel: 'Category',
			name: 'category',
			store: 'PanelCategories',
			valueField: 'id',
			displayField: 'name',
			editable: false,
			allowBlank: false,
			queryMode: 'local',
			emptyText: 'Select a Category'
		},
		{
			flex:1,
			xtype:'textfield',
			fieldLabel: 'Panel Name',
			name: 'name',
			allowBlank: false,
			emptyText: 'Enter panel name here...'
		}
	],
	
	buttons: [
		'->',
		{
			name: 'saveButton',
			text: 'Save',
			action: 'save',
			width: 100,
			iconCls: 'icon-saveBtn',
			scale:'medium'
		}, {
			name: 'cancelButton',
			text: 'Cancel',
			action: 'cancel',
			width: 100,
			iconCls: 'icon-cancelBtn',
			scale:'medium'
		}
	]
});
