Ext.namespace('ORT.question');

ORT.question.types = [
	['singleChoice', 'Single Choice'],
	['multiChoice', 'Multi Choice'],
	['boolean', 'Boolean'],
	['textInput', 'Text Input'],
	['sliderInput', 'Slider']
];
	

Ext.define('ORT.view.survey.QuestionEdit', {
	extend: 'Ext.form.Panel',
	
    alias : 'widget.questionedit',
 
	bodyStyle: 'padding:5px 5px 0;',
	bodyCls:'editDialogBox',
	defaults: {
		border: false,
		//xtype: 'form',
		flex: 1,
		layout: 'anchor'
	},
	
	fieldDefaults: {
		labelAlign: 'top',
		msgTarget: 'side',
		labelWidth: 60
	},
	
	items: [{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 5 0 0'},
		cls:'questionBox',
		items:[{
			flex:3,
			xtype:'textarea',
			fieldLabel: 'Enter Question Text',
			emptyText: 'Please enter your survey question here...',
			labelCls: 'questionlabel',
			name: 'question'
		}]
	},{
		layout: {
			type: 'hbox',
			padding:'5',
			align:'top'
		},
		defaults:{margins:'0 10 0 0'},
		cls:'typeBox',
		items:[{
			flex:3,
			id: 'question-edit-answers-panel',
			cls: 'question-edit-answers-panel',
			layout:'card',
			activeItem: 0,
			height: 220,
			items: [
				{
					id: 'singleChoice-card',
					xtype: 'grid',
					store: Ext.create('Ext.data.Store', {
						id: 'singleChoiceGridStore',
						fields: ['id', 'key', 'value', 'domainSet'],
						data : []
					}),
					//plugins: {ptype: 'cellediting'},
					selType: 'cellmodel',
					plugins: [
						Ext.create('Ext.grid.plugin.CellEditing', {
						  clicksToEdit: 2
						})
					],
					hideHeaders: true,
					columns: [
						{
							header: 'Single Choice Options',
							dataIndex: 'key',
							editor: {
								xtype: 'textfield',
								allowBlank: false
							},
							flex: 1,
							renderer: function(val, cell, record){
								return Ext.String.format("<input type='radio' name='dummy-radio-singlechoice-name' /> {0}", val);
							}
						}
					],
					tbar: [
						{
							xtype:'tbtext',
							text:'Single Choice Options',
							width: 50
						},
						 '->',
						{
							tooltip:'Add a new option',
							iconCls:'ort-builder-opt-add',
							width:30,
							handler : function(){
								var store = Ext.getStore('singleChoiceGridStore');
								store.insert(0, {key: 'Enter choice text'});
								//cellEditing.startEditByPosition({row: 0, column: 0});
							}
						},
						{
							tooltip:'Delete an option',
							iconCls:'ort-builder-opt-delete',
							width:30,
							handler : function(){
								var grid = Ext.getCmp('singleChoice-card');
								var record = grid.getSelectionModel().getSelection()[0];
								if(record) {
									var store = Ext.getStore('singleChoiceGridStore');
									
									var idx = store.indexOf(record);
									store.remove(record);
									store.sync();
									
									if(idx < store.getCount()) {
										grid.getSelectionModel().select(idx);
									}
								}
							}
						}
					]
				},
				{
					id: 'multiChoice-card',
					xtype: 'grid',
					store: Ext.create('Ext.data.Store', {
						id: 'multiChoiceGridStore',
						fields: ['id', 'key', 'value', 'domainSet'],
						data: []
					}),
					//plugins: {ptype: 'cellediting'},
					selType: 'cellmodel',
					plugins: [
						Ext.create('Ext.grid.plugin.CellEditing', {
						  clicksToEdit: 2
						})
					],
					hideHeaders: true,
					columns: [
						{
							header: 'Multi Choice Options',
							dataIndex: 'key',
							flex: 1,
							editor: {
								xtype: 'textfield',
								allowBlank: false
							},
							renderer: function(val, cell, record){
								return Ext.String.format("<input type='checkbox' name='dummy-checkbox-multichoice-name' /> {0}", val);
							}
						}
					],
					tbar: [
						{
							xtype:'tbtext',
							text:'Multi Choice Options',
							width: 50
						},
						 '->',
						{
							//text: 'Add',
							tooltip:'Add a new option',
							iconCls:'ort-builder-opt-add',
							width:30,
							handler : function(){
								var store = Ext.getStore('multiChoiceGridStore');
								store.insert(0, {key: 'Enter choice text'});
								//cellEditing.startEditByPosition({row: 0, column: 0});
							}
						},
						{
							tooltip:'Delete an option',
							iconCls:'ort-builder-opt-delete',
							width:30,
							handler : function(){
								var grid = Ext.getCmp('multiChoice-card');
								var record = grid.getSelectionModel().getSelection()[0];
								if(record) {
									var store = Ext.getStore('multiChoiceGridStore');
									
									var idx = store.indexOf(record);
									store.remove(record);
									store.sync();
									
									if(idx < store.getCount()) {
										grid.getSelectionModel().select(idx);
									}
								}
							}
						}
					]
				},
				{
					id: 'boolean-card',
					xtype: 'grid',
					store: Ext.create('Ext.data.Store', {
						fields: ['id', 'key', 'value', 'domainSet'],
						data : [
							{key: 'Yes', domainSet: '{yes|no}'},
							{key: 'No', domainSet: '{yes|no}'}
						]
					}),
					viewConfig: {
						plugins: {
							ptype: 'gridviewdragdrop',
							dragGroup: 'booleanGridDDGroup',
							dropGroup: 'booleanGridDDGroup',
							dragText: 'Dragging {0} choice option...'
						},
						listeners: {
							//drop: function(node, data, dropRec, dropPosition) {
							//}
						}
					},
					hideHeaders: true,
					columns: [
						{
							header: 'Boolean',
							dataIndex: 'key',
							flex: 1,
							renderer: function(val, cell, record){
								return Ext.String.format("<input type='radio' name='dummy-radio-boolean-name' /> {0}", val);
							}
						}
					],
					tbar: [
						{
							xtype:'tbtext',
							text:'Boolean Choice ( \'Yes\' or \'No\' answers)',
							width: 50
						}
					]
				},
				{
					id: 'textInput-card',
					layout : {
						type  : 'vbox',
						pack  : 'center',
						align : 'stretch'
					},
					items: [
						{
							xtype: 'textfield',
							emptyText: 'Its a text box to capture user input',
							margin: 20,
							hideLabel: true,
							//width: 214,
							tipText: function(thumb){
								return Ext.String.format('<b>Input field for free text entry.</b>', thumb.value);
							}
						}
					]
				},
				{
					id: 'dateInput-card',
					layout : {
						type  : 'vbox',
						pack  : 'center',
						align : 'stretch'
					},
					items: [
						{
							xtype: 'datepicker',
							minDate: new Date(),
							margin: 10
						}
					]
				},
				{
					id: 'sliderInput-card',
					layout : {
						type  : 'vbox',
						pack  : 'center',
						align : 'stretch'
					},
					items: [
						{
							xtype: 'label',
							text: 'Its a Slider to capture user input...',
							margin: 20,
							style: 'color:gray'
						},
						{
							xtype: 'slider',
							margin: 20,
							hideLabel: true,
							width: 214,
							increment: 10,
							minValue: 0,
							maxValue: 100,
							tipText: function(thumb){
								return Ext.String.format('<b>{0}% complete</b>', thumb.value);
							}
						},
						{
							border: false,
							margin: 30,
							items:[{
								xtype:'textfield',
								labelAlign: 'left',
								fieldLabel: 'Min Value',
								labelWidth: 60,
								width: 120
							},{
								labelAlign: 'left',
								xtype:'textfield',
								fieldLabel: 'Max Value',
								labelWidth: 60,
								width: 120
							}]
						}
					]
				},
				{
					id: 'heatMap-card',
					layout : {
						type  : 'vbox',
						pack  : 'center',
						align : 'stretch'
					},
					items: [
						{
							margin: 20,
							border: false,
							html: '<h1>Heat Map</h1>'
						}
					]
				},
				{
					id: 'mtb-card',
					layout : {
						type  : 'vbox',
						pack  : 'center',
						align : 'stretch'
					},
					items: [
						{
							margin: 20,
							border: false,
							html: '<h1>Media Testing Block</h1>'
						}
					]
				},
				{
					id: 'pageBreak-card',
					layout : {
						type  : 'vbox',
						pack  : 'center',
						align : 'stretch'
					},
					items: [
						{
							margin: 20,
							border: false,
							html: '<h1>Its a Page Break</h1>'
						}
					]
				}
			]
		}, {
			flex:1,
			xtype:'radiogroup',
			//fieldLabel: 'Type',
			layout : 'vbox',
			cls: 'type-selection',
			height: '45',
			defaults: {xtype: "radio", name: "type"},
			items: [
				{ boxLabel: 'Single Choice', inputValue: 'singleChoice'},
				{ boxLabel: 'Multi Choice',	inputValue: 'multiChoice'},
				{ boxLabel: 'Boolean (Yes or No)', inputValue: 'boolean'},
				{ boxLabel: 'Text Input', inputValue: 'textInput'},
				{ boxLabel: 'Date Input', inputValue: 'dateInput'},
				{ boxLabel: 'Slider', inputValue: 'sliderInput'},
				{ boxLabel: 'Heat Map', inputValue: 'heatMap'}
			],
			listeners: {
				change: function(field, newValue, oldValue) {
					var cardPanel = Ext.getCmp('question-edit-answers-panel').getLayout();
					cardPanel.setActiveItem(newValue.type+'-card');
					/*
					var rec = this.up('form').getRecord();
					if(oldValue) {
						var card = Ext.getCmp(oldValue.type+'-card');
						//if(card && card.getStore && oldValue.type != 'boolean') {
						if(card && 
							(oldValue.type === 'singleChoice' || oldValue.type === 'multiChoice')) {
							var store = card.getStore();
							if(store && store.getRange().length >= 0) {
								store.sync();
								rec.set('answers', Ext.pluck(store.data.items, 'data'));
							}
						}
					}
					
					var card = Ext.getCmp(newValue.type+'-card');
					if(rec && rec.get('answers')) {
						if(newValue.type === 'singleChoice'
							|| newValue.type === 'multiChoice') {
							card.getStore().loadData(rec.get('answers'));
						}
					}
					*/
				}
			}
		}]
	}],
    
    initComponent: function() {
 
        this.buttons = [
            '->', 
			{
				name: 'saveButton',
				text: 'Save',
				action: 'save',
				width: 100,
				iconCls: 'icon-saveBtn',
				scale:'medium'
			}, {
				name: 'cancelButton',
				text: 'Cancel',
				action: 'cancel',
				width: 100,
				iconCls: 'icon-cancelBtn',
				scale:'medium'
			}
		];
		
		this.callParent(arguments);
    }
});