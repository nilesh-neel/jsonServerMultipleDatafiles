Ext.define('ORT.view.survey.Builder', {
	
	extend: 'Ext.grid.Panel',
	
	// do not remove id property! Its used in css file for setting grid-body
	id: 'surveyBuilder',
	
	alias: 'widget.surveybuilder',
	
	store: 'Questionnaire',
	
	requires: [
		'Ext.Toolbar.TextItem',
		'ORT.ux.RowExpander',
		'ORT.view.survey.QuestionEdit'
	],
	
	viewConfig: {
		plugins: {
			ptype: 'gridviewdragdrop',
			dragGroup: 'questionnaireGridDDGroup',
			dropGroup: 'questionnaireGridDDGroup',
			dragText: 'Dragging {0} question. Release mouse button to drop question...{1}'
		},
		listeners: {
			drop: function(node, data, dropRec, dropPosition) {
				var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('questionNo') : ' on empty view';
				console.log('Dropped ' + data.records[0].get('questionNo') + dropOn);
				//TODO: reset all questionNo by their sequence in Grid.
				// use rec...get('questionNo') and rec... .set('questionNo', temp)
			}
		}
	},
	
	plugins: [{
		ptype: 'rowexpander',
		rowBodyTpl : [
			'<tpl if="this.isPageBreak(type)">',
				'<p><b style="padding-left:25px;">Note: </b><i>Its a page break. At the time of survey all subsequent questions will be shown in next screen.</i></p>',
			'</tpl>',
			'<tpl if="this.isNotPageBreak(type)">',
			'<div id="surveyQuestionDiv{id}" class="surveyQuestionDiv">',
				'<div class="question">',
					'<span id="surveyQuestionText{id}">{question:this.getQuestion}</span>',
					'<div class="indicators">',
						'<tpl if="this.isTrue(isMandatory)">',
								'<span class="ort-builder-indicator mandatory" title="Mandatory"></span>',
						'</tpl>',
						'<tpl if="this.isTrue(isPipedIn)">',
								'<span class="ort-builder-indicator pipedin" title="Piped In"></span>',
						'</tpl>',
						'<tpl if="this.isTrue(isPipedOut)">',
								'<span class="ort-builder-indicator pipedout" title="Piped Out"></span>',
						'</tpl>',
						'<tpl if="this.hasVerb(values.actions, \'quota\')">',
								'<span class="ort-builder-indicator quota" title="Quotas"></span>',
						'</tpl>',
						'<tpl if="this.hasVerb(values.actions, \'trigger\')">',
								'<span class="ort-builder-indicator trigger" title="Triggers"></span>',
						'</tpl>',
						'<tpl if="this.hasVerb(values.actions, \'validate\')">',
								'<span class="ort-builder-indicator validate" title="Validations"></span>',
						'</tpl>',
					'</div>',
				'</div>',
				'<tpl if="this.isMediaBlock(blockType)">',
					'<div class="media-player"></div>',
				'</tpl>',
				'<tpl if="this.isSingleChoice(type)">',
					'<div class="option">',
						'<table border="0" width="100%" cellpadding="0" cellspacing="0">',
						'<tpl for="answers">',
							'<tr>',
							'<td width="10"><input id="surveyQuestionOption{parent.id}-{[xindex-1]}" type="radio" name="radio-{parent.id}"></td>',
							'<td><label for="surveyQuestionOption{parent.id}-{[xindex-1]}">{key}</label>',
							'</td></tr>',
						'</tpl>',
						'</table>',
					'</div>',
				'</tpl>',
				'<tpl if="this.isMultichoice(type)">',
					'<div class="option">',
						'<table border="0" width="100%" cellpadding="0" cellspacing="0">',
						'<tpl for="answers">',
							'<tr>',
							'<td width="10"><input id="surveyQuestionOption{parent.id}-{[xindex-1]}" type="checkbox" name="{key}"></td>',
							'<td><label for="surveyQuestionOption{parent.id}-{[xindex-1]}">{key}</label>',
							'</td></tr>',
						'</tpl>',
						'</table>',
					'</div>',
				'</tpl>',
				'<tpl if="this.isBoolean(type)">',
					'<div class="option">',
						'<table border="0" cellpadding="0" cellspacing="0">',
							'<tr>',
							'<tpl for="answers">',
								'<td width="10"><input id="surveyQuestionOption{parent.id}-{[xindex-1]}" type="radio" name="radio-{parent.id}"></td>',
								'<td><label for="surveyQuestionOption{parent.id}-{[xindex-1]}">{key}</label></td>',
								'<td width="20">&nbsp;</td>',
							'</tpl>',
							'</tr>',
						'</table>',
					'</div>',
				'</tpl>',
				'<tpl if="this.isTextInput(type)">',
					'<div class="option">',
						'<input class="text" style="margin-left: 10px;" type="text" name="{[values.answers[0].key]}">',
					'</div>',
				'</tpl>',
				'<tpl if="this.isDateInput(type)">',
					' A <b>date picker</b> will be shown here. The value will be read as: <b>[{[values.answers[0].key]}]</b><br/><br/>',
					'<br/>',
				'</tpl>',
				'<tpl if="this.isSliderInput(type)">',
					' A <b>slider</b> will be shown here. The value will be read as: <b>[{[values.answers[0].key]}]</b><br/><br/>',
					'<br/>',
				'</tpl>',
			'</div>',
			'<div id="surveyQuestionEditDiv{id}" class="surveyQuestionEditDiv"></div>',
			'</tpl>',
			{
				getQuestion: function(question) {
					if(question) {
						return question;
					}
					else {
						return 'Please enter your survey question...';
					}
				},
				isTrue: function(flag)  {
					return ("true" == ''+flag)? true : false;
				},
				getCssSuffixForFlag: function(flag) {
					return ("true" == ''+flag)?'on':'off';
				},
				hasVerb: function(actions, verb) {
					if(actions && verb) {
						for (var i in actions){
							var logic = actions[i];
							if(logic.predicate 
								&& logic.predicate 
								&& logic.predicate.verb === verb) {
									console.log('verb: '+logic.predicate.verb);
									return true;
								}
						}
					}
					
					return false;
				},
				isMediaBlock: function(blockType) {
					return (blockType === "media");
				},
				isPageBreak: function(type) {
					return (type === "pageBreak");
				},
				isNotPageBreak: function(type) {
					return (type != "pageBreak");
				},
				isMultichoice: function(type) {
					return (type === "multiChoice");
				},
				isSingleChoice: function(type) {
					return (type === "singleChoice");
				},
				isBoolean: function(type) {
					return (type === "boolean");
				},
				isTextInput: function(type) {
					return (type === "textInput");
				},
				isDateInput: function(type) {
					return (type === "dateInput");
				},
				isSliderInput: function(type) {
					return (type === "sliderInput");
				}
			}
		]
	}],
	
	dockedItems: [{
		xtype: 'toolbar',
		dock: 'bottom',
		ui: 'footer',
		layout: {
			pack: 'center'
		}
		/*,
		items: [{
			minWidth: 80,
			text: 'Save'
		},{
			minWidth: 80,
			text: 'Cancel'
		}]
		*/
	}, {
		xtype: 'toolbar',
		items: [{
			//text:'Options',
			tooltip:'Set options',
			width:30,
			iconCls:'ort-builder-opt-options'
		},'-',{
			//text:'Add New',
			tooltip:'Add new question',
			action: 'newQuestion',
			width:30,
			iconCls:'ort-builder-opt-new-question'
		},'-',{
			//text:'Page Break (after)',
			tooltip:'Add a page break after selected row',
			action: 'addPageBreakAfter',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-pagebreak-after'
		},{
			//text:'Page Break (before)',
			tooltip:'Add a page break before selected row',
			action: 'addPageBreakBefore',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-pagebreak-before'
		},{
			tooltip:'Expand All',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-expand-all'
		},{
			tooltip:'Collapse All',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-collapse-all'
		},'-',{
			tooltip:'Copy selected question to question library',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-to-library'
		},{
			tooltip:'Insert a question from question library',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-from-library'
		},'-',{
			tooltip:'Spell check ',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-spell-check'
		},{
			tooltip:'Print Survey',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-print-survey'
		},{
			tooltip:'Preview Survey',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-preview-survey'
		},{
			tooltip:'Garbage Box',
			width: 30,//width:125,
			iconCls:'ort-builder-opt-garbage-box'
		}/*,{
			itemId: 'removeButton',
			text:'Remove Something',
			tooltip:'Remove the selected item',
			width:135,
			iconCls:'ort-builder-opt-delete',
			disabled: true
		}*/]
	}],
		
	iconCls: 'icon-grid',
	 
	animCollapse: false,
	
	initComponent: function() {
		var me = this;
		
		this.columns = [
			{header: 'Q#', dataIndex: 'questionNo', width: 25},
			{
				header: 'Question',
				dataIndex: 'question',
				flex: 1,
				clicksToEdit: 1,
				editor: new Ext.form.TextField(),
				tdCls:'questionHeading',
				renderer: function(val, cell, record){
					if (!val || val.length==0) {
						if(record.get('type') === 'pageBreak') {
							return '<span class="ort-builder-pagebreak-effect">Page Break</span>'
						}
						else {
							return '<span style="color:gray; font-weight: lighter;">Enter your survey question</span>'
						}
					}
					
					return val;
				}
			},
			//{header: '?', dataIndex: 'isDirty', renderer: this.renderIfDirty, width: 15},
			{
				header: 'Type',
				dataIndex: 'type',
				width: 50,
				sortable: false,
				resizable: false,
				hideable: false,
				renderer: function(val, cell, record){
					var iconCls = 'ort-builder-type ort-builder-'+val+'-qtn';
					return Ext.String.format("<div class=\"{0}\" />", iconCls);
				}
			},
			{
				xtype:'actioncolumn',
				width:150,
				sortable: false,
				menuDisabled: true,
				defaults: {
					draggable: false,
					resizable: false,
					hideable: false
				},
				
				items: [
					{
						xtype: 'actioncolumn',
						tooltip: 'Edit',
						iconCls:'optSmallEdit' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Add Above',
						//iconCls:'optView' 
						iconCls: 'optSmallAddAbove' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Add Below',
						//iconCls:'optCollaborate' 
						iconCls: 'optSmallAddBelow' // used handler - do not change!
					},
					{
						xtype: 'actioncolumn',
						tooltip: 'Delete',
						iconCls:'optSmallDelete' // used handler - do not change!
					}
				]
			}
		];
		
		this.callParent(arguments);
		
		/*
		// Do not delete this code!
		this.relayEvents(this.view, ["expandbody", "collapsebody"]);
		this.on("expandbody", function (rowNode, record, expandRow) {
			var containerDiv = Ext.fly(expandRow).down(".surveyQuestionEditDiv");
			formPanel = Ext.widget("questionedit", {
				renderTo: containerDiv.id,
				border: false
			});
			formPanel.loadRecord(record);
		});
		*/
	},
	
	renderIfDirty: function(val) {
        if(val == true){
            return '<span style="color:red;">*</span>';
        }else {
			return '<span style="color:green;">*</span>';            
        }
        return val;
    }
});