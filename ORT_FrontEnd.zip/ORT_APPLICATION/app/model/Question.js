Ext.define('ORT.model.Question', {
    extend: 'Ext.data.Model',
	
	fields: [
		'id',
		'questionNo',
		'question',
		'answers',
		'skipLogic',
		'type',
		'blockType',
		'isMandatory',
		'isPipedIn',
		'isPipedOut',
		'actions'
	],
	
	idProperty: 'id',
	
	proxy: {
		type: 'ajax', 
		
		api: {
			read: ORT.Configuration.GET_QUESTIONNAIRE_URI,
			create: ORT.Configuration.ADD_QUESTION_URI,
			update: ORT.Configuration.UPDATE_QUESTION_URI,
			destroy: ORT.Configuration.DELETE_QUESTION_URI
		},
		
		reader: { 
			type: 'json',
			root: 'questionnaire',
			successProperty: 'success'
		},
		
		listeners: {
			exception: function(proxy, response, options, eOpts) {
				if(response.status == 200) {
					var rsp = Ext.decode(response.responseText);
					ORT.app.fireEvent('servererror', rsp.status, rsp.msg);					
				}
				else {
					ORT.app.fireEvent('ajaxerror', proxy, response, options, eOpts);
				}
			}
		}
	}
});