Ext.define('ORT.model.Company', {
    extend: 'Ext.data.Model',
	
	fields: [
		'id',
		'abbreviation',
		'name',
		'contactPerson',
		'addressLine1',
		'addressLine2',
		'zipCode',
		'city',
		'state',
		'country',
		'phone1',
		'phone2',
		'email',
		'website',
		'status',
		'modifiedBy',
		'modifiedOn',
		'createdBy',
		'createdOn'
	],
	
	idProperty: 'id',
	
	proxy: {
		type: 'ajax', 
		
		api: {
			read: ORT.Configuration.GET_COMPANYSEARCH_URI,
			create: ORT.Configuration.ADD_COMPANY_URI,
			update: ORT.Configuration.UPDATE_COMPANY_URI,
			destroy: ORT.Configuration.DELETE_COMPANY_URI
		},
		
		reader: {
			type: 'json',
			root: 'companies',
			successProperty: 'success'
		},
		
		listeners: {
			exception: function(proxy, response, options, eOpts) {
				if(response.status == 200) {
					var rsp = Ext.decode(response.responseText);
					ORT.app.fireEvent('servererror', rsp.status, rsp.msg);					
				}
				else {
					ORT.app.fireEvent('ajaxerror', proxy, response, options, eOpts);
				}
			}
		}
	}
});