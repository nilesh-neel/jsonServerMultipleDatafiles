Ext.define('ORT.model.User', {
    extend: 'Ext.data.Model',
	
	fields: [
		'id',
		'code',
		'name',
		'loginId',
		'password',
		'email',
		'company',
		'role',
		'status',
		'phone1',
		'phone2',
		'department',
		'language',
		'timezone',
		'modifiedBy',
		'modifiedOn',
		'createdBy',
		'createdOn'
	],
	
	idProperty: 'id',
	
	proxy: {
		type: 'ajax', 
		
		api: {
			read: ORT.Configuration.GET_USERSEARCH_URI,
			create: ORT.Configuration.ADD_USER_URI,
			update: ORT.Configuration.UPDATE_USER_URI,
			destroy: ORT.Configuration.DELETE_USER_URI
		},
		
		reader: { 
			type: 'json',
			root: 'users',
			successProperty: 'success'
		},
		
		listeners: {
			exception: function(proxy, response, options, eOpts) {
				if(response.status == 200) {
					var rsp = Ext.decode(response.responseText);
					ORT.app.fireEvent('servererror', rsp.status, rsp.msg);					
				}
				else {
					ORT.app.fireEvent('ajaxerror', proxy, response, options, eOpts);
				}
			}
		}
	}
});