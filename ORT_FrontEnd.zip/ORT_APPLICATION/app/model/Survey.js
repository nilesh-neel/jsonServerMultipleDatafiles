Ext.define('ORT.model.Survey', {
    extend: 'Ext.data.Model',
	fields: [
		'title',
		'done',
		'responses',
		'requiredSamples',
		'createdOn',
		'modifedOn',
		'status'
	]
});