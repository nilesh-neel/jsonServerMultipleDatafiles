Ext.define('ORT.store.Questionnaire', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'questionnaire',
	
	model: 'ORT.model.Question',
	
	autoSync: false,
	
	autoLoad: true
});