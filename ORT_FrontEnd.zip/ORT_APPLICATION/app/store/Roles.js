Ext.define('ORT.store.Roles', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'roles',
	
	fields: ['id', 'name', 'description'],
	
	autoSync: false,
	
	autoLoad: true,
	
	proxy: {
		type: 'ajax', 
		
		api: {
			read: ORT.Configuration.GET_ROLES_URI
		},
		
		reader: { 
			type: 'json',
			root: 'roles',
			successProperty: 'success'
		},
		
		listeners: {
			exception: function(proxy, response, options, eOpts) {
				if(response.status == 200) {
					var rsp = Ext.decode(response.responseText);
					ORT.app.fireEvent('servererror', rsp.status, rsp.msg);					
				}
				else {
					ORT.app.fireEvent('ajaxerror', proxy, response, options, eOpts);
				}
			}
		}
	}
});