Ext.define('ORT.store.SearchedCompanies', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'searchedCompanies',
	
	model: 'ORT.model.Company',
	
	autoSync: false,
	
	autoLoad: true
});