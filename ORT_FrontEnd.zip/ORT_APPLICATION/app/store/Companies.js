Ext.define('ORT.store.Companies', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'companies',
	
	fields: ['id', 'name', 'description'],
	
	autoSync: false,
	
	autoLoad: true,
	
	proxy: {
		type: 'ajax', 
		
		api: {
			read: ORT.Configuration.GET_COMPANIES_URI
		},
		
		reader: { 
			type: 'json',
			root: 'companies',
			successProperty: 'success'
		},
		
		listeners: {
			exception: function(proxy, response, options, eOpts) {
				if(response.status == 200) {
					var rsp = Ext.decode(response.responseText);
					ORT.app.fireEvent('servererror', rsp.status, rsp.msg);					
				}
				else {
					ORT.app.fireEvent('ajaxerror', proxy, response, options, eOpts);
				}
			}
		}
	}
});