Ext.define('ORT.store.MySurveys', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'mySurveysStore',
	
	model: 'ORT.model.Survey',
	
	autoLoad: true,
	
	proxy: {
		type: 'ajax', // There are proxies for AJAX, JSON-P and HTML5 localStorage among others.
		
		//url: 'data/surveys.json',
		
		api: {
			read: ORT.Configuration.GET_SURVEYS_URI,
			update: ORT.Configuration.UPDATE_SURVEY_URI
		},
		
		reader: { // The reader is responsible for decoding the server response into a format the Store can understand. 
			type: 'json',
			root: 'surveys',
			successProperty: 'success'
		},
		
		listeners: {
			exception: function(proxy, response, options, eOpts) {
				if(response.status == 200) {
					var rsp = Ext.decode(response.responseText);
					ORT.app.fireEvent('servererror', rsp.status, rsp.msg);					
				}
				else {
					ORT.app.fireEvent('ajaxerror', proxy, response, options, eOpts);
				}
			}
		}
	}
});