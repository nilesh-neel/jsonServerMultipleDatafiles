Ext.define('ORT.store.SearchedPanels', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'searchedPanels',
	
	model: 'ORT.model.Panel',
	
	autoSync: false,
	
	autoLoad: true
});