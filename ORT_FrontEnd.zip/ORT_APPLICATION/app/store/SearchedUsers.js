Ext.define('ORT.store.SearchedUsers', {
	
	extend: 'Ext.data.Store',
	
	storeId: 'searchedUsers',
	
	model: 'ORT.model.User',
	
	autoSync: false,
	
	autoLoad: true
});