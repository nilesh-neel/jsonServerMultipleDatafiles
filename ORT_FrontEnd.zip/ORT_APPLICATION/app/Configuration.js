Ext.define("ORT.Configuration", {
	singleton				: true,
	
	LOGIN_URL				: "",
	LOGOUT_URL				: "logout.html",
	
	// Masters
	GET_CITIES_URI          : "Master/GetMaster/?type=1",
	GET_STATES_URI          : "Master/GetMaster/?type=3",
	GET_COUNTRIES_URI       : "Master/GetMaster/?type=2",
	GET_ROLES_URI           : "Master/GetMaster/?type=5",
	GET_LANGUAGES_URI       : "Master/GetMaster/?type=4",
	GET_TIMEZONES_URI       : "Master/GetMaster/?type=6",
	GET_COMPANIES_URI		: "Master/GetCompany",
	GET_PANEL_LIBS_URI		: "data/panellib.json",
	GET_PANEL_CATEGORIES_URI: "data/panelcat.json",
	GET_SESSIONCONTEXT_URI  : "Login/LoggedOnUserInfo",
	
	// MySurveys Module
	GET_SURVEYS_URI			: "Survey/MySurveys",
	UPDATE_SURVEY_URI		: "data/updateUsers.json",

	// Panel Manager Module
	GET_PANELSEARCH_URI		: "data/panels.json",
	GET_PANEL_URI			: "data/dummy_success.html",
	ADD_PANEL_URI			: "data/updateUser.json",
	UPDATE_PANEL_URI		: "data/dummy_success.html",
	DELETE_PANEL_URI		: "data/dummy_success.html",
	
	// User Manager Module
	GET_USERSEARCH_URI		: "User/SearchUsers",
	GET_USER_URI			: "User/GetUsers",
	ADD_USER_URI			: "User/AddUser",
	UPDATE_USER_URI			: "User/UpdateUser",
	DELETE_USER_URI			: "User/DeleteUser",
	
	// Company Manager Module
	GET_COMPANYSEARCH_URI	: "Customer/SearchCustomer",
	GET_COMPANY_URI			: "data/dummy_success.html",
	ADD_COMPANY_URI			: "Customer/AddCustomer",
	UPDATE_COMPANY_URI		: "Customer/UpdateCustomer",
	DELETE_COMPANY_URI		: "Customer/DeleteCustomer",
	
	// Survey Builder Module
	GET_QUESTIONNAIRE_URI	: "data/questionnaire.json",
	GET_QUESTION_URI		: "data/dummy_success.html",
	ADD_QUESTION_URI		: "data/dummy_success.html",
	UPDATE_QUESTION_URI		: "data/dummy_success.html",
	DELETE_QUESTION_URI		: "data/dummy_success.html",
	
	// Message Library Module
	GET_MESSAGE_LIBS_URI: "Library/GetLibraries?type=2",
	ADD_MESSAGE_LIB_URI: "Library/AddLibrary?type=2",
	//UPDATE_MESSAGE_LIB_URI: "Library/UpdateLibrary?type=2",
	//DELETE_MESSAGE_LIB_URI: "Library/DeleteLibrary?type=2",
	GET_MESSAGE_CATEGORIES_UR: "Library/GetLibraryCategories?type=2",
	ADD_MESSAGE_CATEGORIES_URI: "Library/AddLibraryCategory?type=2",
	//UPDATE_MESSAGE_CATEGORIES_URI: "Library/UpdateLibraryCategory?type=2",
	//DELETE_MESSAGE_CATEGORIES_URI: "Library/DeleteLibraryCategory?type=2",


	GET_MESSAGESEARCH_URI: "Library/SearchLibrary?type=2&libraryId=22",
	//GET_MESSAGE_URI: "Library/EditLibrary?type=2&grLibraryId=22&grCategoryId=1",
	ADD_MESSAGE_URI: "Library/SaveLibraryDetails?type=2",
	UPDATE_MESSAGE_URI: "Library/SaveLibraryDetails?type=2",
	DELETE_MESSAGE_URI: "Library/DeleteLibraryDetails?type=2"

	
	
	
	
});
