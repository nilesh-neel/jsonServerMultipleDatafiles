Ext.define("ORT.Utility", {
	singleton: true,
	
	MandatoryFieldRenderer:  function(field,options) {
			if (field && field.isFieldLabelable && field.fieldLabel && field.allowBlank == false) {
				field.fieldLabel += ' <span class="req" style="color:red">*</span>';
			}
		}
});
