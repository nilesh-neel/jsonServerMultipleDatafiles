Ext.define("ORT.Configuration", {
	singleton	: true,
	
	LOGIN_URL	: "",
	LOGOUT_URL	: "data/dummy_success.html",
	
	// Masters
	GET_CITIES_URI		: "data/cities.json",
	GET_STATES_URI		: "data/states.json",
	GET_COUNTRIES_URI	: "data/countries.json",
	GET_ROLES_URI		: "data/roles.json",
	GET_LANGUAGES_URI	: "data/languages.json",
	GET_TIMEZONES_URI	: "data/timezones.json",
	
	// MySurveys Module
	GET_SURVEYS_URI		: "data/surveys.json",
	UPDATE_SURVEY_URI	: "data/updateUsers.json",
	
	// User Manager Module
	GET_USERS_URI		: "data/users.json",
	GET_USER_URI		: "data/dummy_success.html",
	ADD_USER_URI		: "data/updateUser.json",
	UPDATE_USER_URI		: "data/dummy_success.html",
	DELETE_USER_URI		: "data/dummy_success.html",
	
	// Company Manager Module
	GET_COMPANIES_URI	: "data/companies.json",
	GET_COMPANY_URI		: "data/dummy_success.html",
	ADD_COMPANY_URI		: "data/updateCompany.json",
	UPDATE_COMPANY_URI	: "data/dummy_success.html",
	DELETE_COMPANY_URI	: "data/dummy_success.html"
});