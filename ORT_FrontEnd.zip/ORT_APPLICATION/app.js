// handle errors that are thrown not using Ext.raise()
window.onerror = function(msg, url, lineNumber) {
	alert(msg+' \rurl: '+url+' \rline: '+lineNumber)
   //console.warn('%s\rurl: %s\rline: %d', msg, url, lineNumber);
   //return true; //true means don't propogate the error
} 

function OnApplicationExit() {
	ORT.app.fireEvent('logout');
}

function ShowError(title, msg, obj) {
	Ext.Msg.show({
		scope: this,
		title: title,
		msg:  msg,
		buttons: Ext.Msg.OK,
		icon: Ext.MessageBox.ERROR,
		fn: function(btn) {
			if("ok" == btn) {
				if(obj && obj.handler) {
					obj.handler(obj.code);
				}
			}
		}
	});	
}

Ext.application({
	
	requires: [
		'ORT.Configuration',
		'ORT.Utility',
		'Ext.grid.plugin.CellEditing'
	],
	
	name: 'ORT',    
	
	appFolder: 'app',
	
	autoCreateViewport: true,
	
	controllers: ['Dashboard', 'MySurveys', 'SurveyBuilder', 'UserManager', 'CompanyManager'],
	
	launch: function() {
		console.log('ORT::launch()');
		
		ORT.app = this;
		
		Ext.Error.notify = false; // prevent ie6 and ie7 popup
        Ext.Error.handle = this.onApplicationError; // handle errors raised by Ext.Error.raise()
        //throw 'Testing: General error raised by ORT application';
		
		Ext.Ajax.on('requestexception', this.onAjaxRequestException, this);
		
		ORT.app.on({
			scope: this,
			servererror	: 'onServerError',
			ajaxerror	: 'onAjaxRequestException'
		});
		ORT.app.fireEvent('pageload');
		/*
		Ext.getBody().mask('Loading Online Research Tool...');
		Ext.onReady(function() {
			setTimeout(function(){
				Ext.getBody().unmask();
			}, 250);
		});
		*/
	},
	
	handleError: function(code) {
		console.log('ORT::handleError()');
		
		if('401' == ''+code) {
		}
		else if('403' == ''+code) {
			ORT.app.fireEvent('logout');
		}
		else {
			console.log('No handler found for error ' + code);
		}
	},
	
	onServerError: function (errCode, errMsg) {
		console.log('ORT::onServerError()');
		
		var title = 'Unknown Server Error';
		if(errCode) {
			title = 'Server Error: ' + errCode;
		}
		
		var msg = 'No error description found!'
		if(errMsg) {
			msg = errMsg
		}
		
		ShowError(title, msg, {code: errCode, handler: this.handleError});
		
		//this.handleError(errCode);
	},
	
	onApplicationError: function(error){
		console.log('ORT::onApplicationError()');
		
		var title = 'Application Error';
		if(error['error code']) {
			title = 'Application Error: ' + error['error code'];
		}
		
		var msg = 'No error description found!'
		if(error.msg) {
			msg = error.msg
		}
		
		ShowError( title, msg);
		
		return true;
	},
	
	onAjaxRequestException: function(conn, response, options, eOpts) {
		console.log('ORT::onAjaxRequestException()');
		
		var title = 'Communication Error';
		if(response.status) {
			title = 'Communication Error: ' + response.status;
		}
		
		var message;
		switch (response.status) {
			case 403:
				//this.onAuthenticationRequired(conn, response, options, eOpts);
				message = 'Your session is not valid now, please login to the site and continue.';
				break;
			case 401:
				//this.onRequestUnauthorized(conn, response, options, eOpts);
				message = 'You are not authorized to use this feature!';
				break;
			case 404:
				message = 'Resource [ '+response.request.options.url+ ' ] '+response.statusText;
				break;
			default:
				message = response.statusText;
				break;
		}
		
		ShowError(title, message);
		
		this.handleError(response.status);
	}
});
