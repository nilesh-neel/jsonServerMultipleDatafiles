﻿namespace ORT_APPLICATION.Helpers
{
    public class SessionManageHelper
    {
        public string SaltString { get; set; }
    }
}
