﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace ORT_APPLICATION.Helpers
{
    public class AutomapperHelper
    {
        public object DoAutoMapping(Type sourceType, object data)
        {
            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType);

            var castedObject = CastObject(data, currentTypeMap.SourceType);

            var objDest = GetDesitinationType(currentTypeMap.DestinationType);

            return Mapper.Map(castedObject, castedObject.GetType(), objDest.GetType());

        }

        public object DoAutoMapping(Type sourceType, Type destinationType, object data)
        {
            var currentTypeMap = Mapper.GetAllTypeMaps().Single(p => p.SourceType == sourceType && p.DestinationType == destinationType);

            var castedObject = CastObject(data, currentTypeMap.SourceType);

            var objDest = GetDesitinationType(currentTypeMap.DestinationType);

            return Mapper.Map(castedObject, castedObject.GetType(), objDest.GetType());
        }

        public static List<T> CastTo<T>(object o)
        {
            return (((List<object>)o).Cast<T>().ToList());
        }

        private static object GetDesitinationType(Type destType)
        {
            var generic = typeof(List<>);
            var specific = generic.MakeGenericType(destType);
            var ci = specific.GetConstructor(Type.EmptyTypes);
            return ci.Invoke(new object[] { });
        }

        public object CastObject(object data, Type sourceType)
        {
            object castedObject;

            if (data.GetType() == typeof(List<object>))
            {
                var castMethod = GetType().GetMethod("CastTo").MakeGenericMethod(sourceType);

                castedObject = castMethod.Invoke(null, new[] { data });
            }
            else
            {
                castedObject = data;
            }

            return castedObject;
        }
    }
}
