﻿using System;
using System.Web;
using ORT_CORE.Class.SurveyClasses;
using SHA256;

namespace ORT_APPLICATION.Helpers
{
    public static class SessionHelper
    {
        public static User LogggedInUser
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((User) currentSession["LogedInUser"]);
            } 
            set
            {
                var currentSession = HttpContext.Current.Session;
                currentSession["LogedInUser"] = value;
            }
        }

        public static string LoggedinCustomer
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((User) currentSession["LogedInUser"]).UserDetails.Customer.CustomerId;
            }
        }

        public static string LoggedinUserId
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((User) currentSession["LogedInUser"]).UserId;
            }
        }

        public static string SessionSaltString
        {
            get
            {
                var currentSession = HttpContext.Current.Session;
                return ((SessionManageHelper)currentSession["SessionManageHelper"]).SaltString;
            }
            set { 
                var currentSession = HttpContext.Current.Session;
                currentSession["SessionManageHelper"] = new SessionManageHelper
                                                      {
                                                          SaltString = value
                                                      };
            }
        }
       
        public static void GetRandomEncryptString()
        {
            var rng = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const int size = 50;
            var buffer = new char[size];

            for (int i = 0; i < size; i++)
            {
                buffer[i] = chars[rng.Next(chars.Length)];
            }
            var objstring = new string(buffer);
         
            var objhash = new HASHClass();
            SessionSaltString = objhash.SHA256(ref objstring);
        }

    }
}
