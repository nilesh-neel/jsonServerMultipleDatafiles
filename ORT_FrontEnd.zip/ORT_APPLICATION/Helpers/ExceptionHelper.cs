﻿using System;
using System.Web.Mvc;
using log4net;

namespace ORT_APPLICATION.Helpers
{
    public static class ExceptionHelper
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static JsonResult GetGenericJson(Exception ex)
        {
            Log.Error("Error Occured", ex);

            return new JsonResult
                {
                    Data= new
                        {
                            success = "false",
                            status = "500",
                            msg = "An unexpected error occurred.",
                        }
                        ,JsonRequestBehavior = JsonRequestBehavior.AllowGet
               };
        }
    }
}
