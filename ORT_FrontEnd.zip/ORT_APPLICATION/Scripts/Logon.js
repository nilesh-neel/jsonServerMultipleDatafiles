﻿$(document).ready(function() {
    $('#btnLogin').click(function() {
        var encyptedPsw = sha256_digest($("#ChalString").val() + sha256_digest($("#Password").val()));
        $("#HdnPassword").val(encyptedPsw);       
        $("#Password").val("");
    });
});