﻿using System.Text;
using System.Web.Mvc;
using ORT_HELPERS.Helpers;

namespace ORT_APPLICATION.Extensions
{
    public static class ControllerExtensions
    {
        public static ActionResult Xml(this ControllerBase controller, object model)
        {
            return new XMLResult(model);
        }
    }

    public class XMLResult : ActionResult
    {
        private readonly object _model;
        public XMLResult(object model)
        {
            _model = model;
        }
        #region Overrides of ActionResult

        public override void ExecuteResult(ControllerContext context)
        {
            if (_model == null) return;

            var response = context.HttpContext.Response;

            response.Clear();

            response.ContentType = "text/xml";

            var encoding = new UTF8Encoding();

            var b = encoding.GetBytes(ObjectXmlHelper.ToXml(_model));

            response.OutputStream.Write(b, 0, b.Length);
        }

        #endregion
    }

}
