﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Routing;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_CORE.Interface.LibaryInterface;
using ORT_CORE.Interface.MasterInterface;
using StructureMap;
using System;

namespace ORT_APPLICATION.Configuration
{
    public class BootStrapper
    {
        public static void Run()
        {

            ControllerBuilder.Current
                .SetControllerFactory(new StructureMapControllerFactory());



            ObjectFactory.Initialize(x =>
                                         {
                                             x.AddConfigurationFromXmlFile("StructureMap.xml");
                                             x.Scan(y =>
                                             {
                                                 y.TheCallingAssembly();
                                                 y.WithDefaultConventions();
                                                 y.AddAllTypesOf<ILibrary>();
                                             });
                                             x.Scan(y =>
                                                 {
                                                     y.TheCallingAssembly();
                                                     y.WithDefaultConventions();
                                                     y.AddAllTypesOf<IMaster>();
                                                 });
                                             x.Scan(y =>
                                                         {
                                                             y.TheCallingAssembly();
                                                             y.WithDefaultConventions();
                                                             y.AddAllTypesOf<IControl>();
                                                         }
                                                 );
                                             x.Scan(y=>
                                                        {
                                                            y.TheCallingAssembly();
                                                            y.WithDefaultConventions();
                                                            y.AddAllTypesOf<IInstruction>();
                                                        });

                                             x.For<IEnumerable<ILibrary>>()
                                                             .TheDefault.Is.ConstructedBy(y => ObjectFactory.GetAllInstances<ILibrary>());
                                             x.For<IEnumerable<IMaster>>()
                                                 .TheDefault.Is.ConstructedBy(
                                                     y => ObjectFactory.GetAllInstances<IMaster>());
                                             x.For<IEnumerable<IControl>>()
                                                 .TheDefault.Is.ConstructedBy(
                                                     y => ObjectFactory.GetAllInstances<IControl>());
                                             x.For<IEnumerable<IInstruction>>()
                                                 .TheDefault.Is.ConstructedBy(
                                                     y => ObjectFactory.GetAllInstances<IInstruction>());
                                         });



        }
    }
}

public class StructureMapControllerFactory : DefaultControllerFactory
{
    protected override IController GetControllerInstance(RequestContext requestContext,
    Type controllerType)
    {
        return controllerType == null ? null : ObjectFactory.GetInstance(controllerType) as Controller;
    }
}
