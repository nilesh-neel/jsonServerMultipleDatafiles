﻿using System;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using log4net;
using AutoMapper;
using ORT_VIEW_MAP.MapClasses;
using System.Web;
using System.Collections.Generic;
using System.IO;
using ORT_PERSISTENCE.UploadObjects.Interface;
using ORT_VIEW_MAP.MapClasses.Panel;
using ORT_PERSISTENCE.SurveyPersistence;
using ORT_CORE.Class.LibraryClasses;
using ORT_VIEW_MAP.MapClasses.Library;

namespace ORT_APPLICATION.Controllers
{
    public class PanelController : Controller
    {
        //
        // GET: /Panel/
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static PanelModule _panelModule;
        //private static UploadModule _uploadModule;
        //private static Upload _uploadClass;

        public PanelController(IPanelist panel, ICustomer cust, IRespondent respond, IUser user, IUpload objUpload, IGraphicsUpload objGrapUpload)
        {
            _panelModule = new PanelModule(panel, cust, respond, user, objUpload, objGrapUpload);
            //_uploadClass = new Upload();
        }


        #region "Panel"
        public JsonResult GetPanleLibrary()
        {
            Log.Info(" GetPanleLibrary Begins");
            try
            {
                var jsonData = Mapper.Map<List<Library>, List<MasterViewModel>>(_panelModule.GetPanleListCombo());
                return ReturnJsonHelper.GetSuccessJson(jsonData, "libraries");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        public JsonResult GetCategory(string panleId)
        {
            Log.Info(" GetPanleLibrary Begins");
            try
            {
                var jsonData = Mapper.Map<List<PanelCategory>, List<PanelCategoryViewModel>>(_panelModule.GetPanleCategory(""));
                return ReturnJsonHelper.GetSuccessJson(jsonData, "categories");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        public JsonResult SearchPanelList(string library, string panelName, string category)
        {
            try
            {
                Log.Info("Search Panel Begins");
                var jsonData = Mapper.Map<List<Panel>, List<PanelViewModel>>(_panelModule.GetPanelList(library  , panelName, category));
                return jsonData != null && jsonData.Count != 0 ? ReturnJsonHelper.GetSuccessJson(jsonData, "panels") :
                            !string.IsNullOrEmpty(PanelistRepository.Message) ?
                                 ReturnJsonHelper.GetValidationJson(PanelistRepository.Message) :
                                     ReturnJsonHelper.GetSuccessJson("", "panels");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        [HttpPost]
        [ObjectFilter(Param = "panelLibrary", RootType = typeof(LibraryViewModel))]
        public JsonResult AddPanelibrary(LibraryViewModel panelLibrary)
        {
            try
            {
                Log.Info("Add Panel Begins");
                if (_panelModule.IsPanelLibraryValid(panelLibrary))
                {
                    panelLibrary.type = Library.LibraryType.Panel.ToString();
                    var saveData = Mapper.Map<LibraryViewModel, Library>(panelLibrary);
                    saveData.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                    if (_panelModule.SaveLibrary(saveData))
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessPanelLibrary(saveData), "libraries");
                }
                return ReturnJsonHelper.GetValidationJson(_panelModule.Message);    
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }



        [HttpPost]
        [ObjectFilter(Param = "panelCategory", RootType = typeof(PanelCategoryViewModel))]
        public JsonResult AddPanelCatetory(PanelCategoryViewModel panelCategory)
        {
            try
            {
                Log.Info("Add Panel Begins");
                if (_panelModule.IsCategoryValid(panelCategory))
                {
                   
                    var saveData = Mapper.Map<PanelCategoryViewModel, PanelCategory>(panelCategory);
                    if (_panelModule.SavePanelCategory(saveData))
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessPanelCategory(saveData), "categories");
                }
                return ReturnJsonHelper.GetValidationJson(_panelModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        [HttpPost]
        [ObjectFilter(Param = "panelDetailViewModel", RootType = typeof(PanelViewModel))]
        public JsonResult AddPanel(PanelViewModel panelDetailViewModel)
        {
            try
            {
                Log.Info("Add PanelCategory Begins");
                if (_panelModule.IsValid(panelDetailViewModel))
                {
                    panelDetailViewModel.type = Library.LibraryType.Panel.ToString();
                    var objAutoMapping = new AutomapperHelper();
                    //var saveData = Mapper.Map<PanelViewModel, Panel>(panelDetailViewModel);
                    var saveData = (Panel)objAutoMapping.DoSingleObjectAutoMapping(typeof(PanelViewModel), panelDetailViewModel);
                    if (_panelModule.SavePanel(saveData))
                    {
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessPanel(saveData.PanelId), "panels");
                    }
                    else
                    {
                        return !string.IsNullOrEmpty(PanelistRepository.Message) ?
                            ReturnJsonHelper.GetValidationJson(PanelistRepository.Message) :
                            ReturnJsonHelper.GetSuccessJson("", "panels");
                    }                   
                }
                return ReturnJsonHelper.GetValidationJson(_panelModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        [HttpPost]
        [ObjectFilter(Param = "panelDetailViewModel", RootType = typeof(PanelViewModel))]
        public JsonResult UpdatePanel(PanelViewModel panelDetailViewModel)
        {
            try
            {
                Log.Info("Update Panel Begins");
                if (_panelModule.IsValid(panelDetailViewModel))
                {
                    var saveData = Mapper.Map<PanelViewModel, Panel>(panelDetailViewModel);
                    if (_panelModule.SavePanel(saveData))
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessPanel(saveData.PanelId), "panels");
                }
                return ReturnJsonHelper.GetValidationJson(_panelModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        [HttpPost]
        [ObjectFilter(Param = "panelDetailViewModel", RootType = typeof(PanelViewModel))]
        public ActionResult DeletePanel(PanelViewModel panelDetailViewModel)
        {
            try
            {
                Log.Info("Delete Panel Begins");
                var updateData = Mapper.Map<PanelViewModel, Panel>(panelDetailViewModel);
                updateData.IsPanelActive = Convert.ToBoolean(0);
                if (_panelModule.DeletePanel(updateData.PanelId))
                    return ReturnJsonHelper.GetSuccessJson(updateData.PanelId, "panels");
                return ReturnJsonHelper.GetExceptionJson(new Exception());
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        #endregion

        #region "Members"
        public JsonResult SearchMemberList(string panelLib, string email)
        {
            try
            {
                Log.Info("Search Panel Begins");
                var jsonData = Mapper.Map<List<Respondent>, List<PanelRespondent>>(_panelModule.GetMemberList(panelLib, email));
                return ReturnJsonHelper.GetSuccessJson(jsonData, "panels");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        [HttpPost]
        [ObjectFilter(Param = "panelRespondent", RootType = typeof(PanelRespondent))]
        public JsonResult AddMember(PanelRespondent panelRespondent)
        {
            try
            {
                Log.Info("Add Panel Begins");
                if (_panelModule.IsRespondentValid(panelRespondent))
                {
                    var saveData = Mapper.Map<PanelRespondent, Respondent>(panelRespondent);
                    saveData.Panel.LibType = ((Library.LibraryType)7);
                    saveData.CreatedBy = new User { UserId = SessionHelper.LoggedinUserId };
                    saveData.ModifiedBy = new User { UserId = null };
                    saveData.IsRespondentActive = Convert.ToBoolean(1);
                    saveData.IsRespondentDeleted = Convert.ToBoolean(1);
                    saveData.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                    if (_panelModule.SaveMembers(saveData))
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessMembers(saveData.RespondentId), "members");
                }
                return ReturnJsonHelper.GetValidationJson(_panelModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        [HttpPost]
        [ObjectFilter(Param = "panelDetailViewModel", RootType = typeof(PanelRespondent))]
        public JsonResult UpdateMember(PanelRespondent panelDetailViewModel)
        {
            try
            {
                Log.Info("Update Panel Begins");
                if (_panelModule.IsRespondentValid(panelDetailViewModel))
                {
                    var saveData = Mapper.Map<PanelRespondent, Respondent>(panelDetailViewModel);
                    saveData.Panel.LibType = Library.LibraryType.Panel;
                    saveData.ModifiedBy = new User { UserId = SessionHelper.LoggedinUserId };
                    saveData.CreatedBy = new User { UserId = null };
                    saveData.Customer = new Customer { CustomerId = SessionHelper.LoggedinCustomer };
                    if (_panelModule.SaveMembers(saveData))
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessMembers(saveData.RespondentId), "members");
                }
                return ReturnJsonHelper.GetValidationJson(_panelModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        [HttpPost]
        [ObjectFilter(Param = "panelDetailViewModel", RootType = typeof(PanelRespondent))]
        public ActionResult DeleteMember(PanelRespondent panelDetailViewModel)
        {
            try
            {
                Log.Info("Delete Panel Begins");
                var updateData = Mapper.Map<PanelRespondent, Respondent>(panelDetailViewModel);
                updateData.IsRespondentActive = Convert.ToBoolean(0);
                if (_panelModule.DeleteMember(updateData.RespondentId))
                    return ReturnJsonHelper.GetSuccessJson(updateData.RespondentId, "panels");
                return ReturnJsonHelper.GetExceptionJson(new Exception());
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }
        #endregion


        private static PanelViewModel GetSuccessPanel(string panelId)
        {
            var successUser = _panelModule.GetPanelByPanelId(panelId);
            var finalData = Mapper.Map<Panel, PanelViewModel>(successUser);
            return finalData;
        }

        private static LibraryViewModel GetSuccessPanelLibrary(Library panelCat)
        {
            var finalData = Mapper.Map<Library, LibraryViewModel>(panelCat);
            return finalData;
        }


        private static PanelCategoryViewModel GetSuccessPanelCategory(PanelCategory panelCat)
        {
            var finalData = Mapper.Map<PanelCategory, PanelCategoryViewModel>(panelCat);
            return finalData;
        }

        private static PanelRespondent GetSuccessMembers(string respondId)
        {
            var successUser = _panelModule.GetMemberById(respondId);
            var finalData = Mapper.Map<Respondent, PanelRespondent>(successUser);
            return finalData;
        }


        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(IEnumerable<HttpPostedFileBase> files, string rdbDuplicate, string rdbUpdate)
        {
            foreach (var file in files)
            {
                if (file.ContentLength > 0)
                {
                    var extnsion = Path.GetExtension(file.FileName);
                    var fileName = Path.GetFileName(file.FileName);
                    var folderPath = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["Upload"]);
                    var path = Path.Combine(folderPath, fileName);
                    file.SaveAs(path);
                    if (file.ContentLength > 0)
                    {
                        file.SaveAs(path);
                        if (!System.IO.File.Exists(folderPath))
                        {
                            var uploadResult = _panelModule.ImportData("2", fileName, folderPath, extnsion);
                            uploadResult.Add("success","true");
                            uploadResult.Add("status", "200");
                            uploadResult.Add("msg","Success.");
                            return new JsonResult
                            {
                                Data = uploadResult,
                                JsonRequestBehavior = JsonRequestBehavior.AllowGet
                            };

                        }
                    }
                }
                return ReturnJsonHelper.GetValidationJson("Please Upload File..!");
            }
            return RedirectToAction("Index");
        }

        public ActionResult GetException()
        {
            try
            {
                Log.Info("Get Exception Begins");
                return ReturnJsonHelper.GetSuccessJson(_panelModule.GetExceptionDetails(), "Panellist");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

    }
}
