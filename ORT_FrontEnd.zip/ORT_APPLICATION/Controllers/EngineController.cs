﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Collections.Generic;
using ORT_APPLICATION.Extensions;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_BUSSINESS_LAYER.SurveyEngine.Interface;
using ORT_BUSSINESS_LAYER.SurveyEngine.Module;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_APPLICATION.Controllers
{
    public class EngineController : Controller
    {
        private static SurveyModule _surveyModule;
        private static EngineModule _engineModule;

        private static bool CookieInstalled { get; set; }
        public EngineController(ISurvey survey, IUser user, ICustomer customer, IQuestion question, ISetting setting, IReward reward, IQuota quota, IAnswer answer, ISkipLogic skipLogic, IEnumerable<IControl> control, IReponses reponses, ISoundClip soundClip, IPlayList playList, IEnumerable<IInstruction> instructions)
        {
            _surveyModule = new SurveyModule(survey, user, customer, question, setting, reward, quota, answer, skipLogic, reponses, soundClip, playList);
            _engineModule = new EngineModule(control, instructions);
            CookieInstalled = false;
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var request = filterContext.HttpContext.Request;
            var surveyId = request.QueryString["surveyId"];
            switch (filterContext.ActionDescriptor.ActionName)
            {
                case "CaptureResponse":
                case "EndSurvey":
                    filterContext.ActionParameters["responses"] = GetResponses(request);
                    break;
                case "RenderSurvey":
                    CheckCookie(filterContext.HttpContext);
                    break;
                case "ProcessSurvey":

                    SetCookie(filterContext.HttpContext, surveyId);
                    break;
            }
            base.OnActionExecuting(filterContext);
        }

        private static void CheckCookie(HttpContextBase httpContext)
        {
            var browserCookie = httpContext.Request.Cookies["SessionId"];
            if (browserCookie != null)
            {
                CookieInstalled = true;
            }
        }

        private static void SetCookie(HttpContextBase httpContext, string surveyId)
        {
            var browserCookie = new HttpCookie("SessionId");
            browserCookie.Values.Add("UserSessionId", httpContext.Session.SessionID);
            if (AllowContinueLater(surveyId)) browserCookie.Expires = GetCookieExpiryDate();
            httpContext.Response.Cookies.Add(browserCookie);
        }

        private static DateTime GetCookieExpiryDate()
        {
            var surveyEndDate = SessionHelper.SessionSurvey.surveyEndDate;
            return string.IsNullOrEmpty(surveyEndDate) ? DateTime.Now.AddYears(50) : Convert.ToDateTime(surveyEndDate);
        }

        private List<Responses> GetResponses(HttpRequestBase request)
        {
            var questions = request.Form["hdnQuestion"].Split(Convert.ToChar(","));

            var surveyId = request.QueryString["surveyId"];

            var questionType = request.Form["hdnQuestionType_" + questions[0]];

            return BuildResponses(request, surveyId, questionType, questions);
        }

        private List<Responses> BuildResponses(HttpRequestBase request, string surveyId, string questionType, string[] questions)
        {
            SessionHelper.ResponseExpected = ResponseHelper.ResponseExpected(questionType);

            if (SessionHelper.ResponseExpected)
            {
                SessionHelper.IsModelValid = ValidateModel(questions, request.Form);

                if (SessionHelper.IsModelValid)
                {
                    return ParseResponse(request, surveyId, questions);
                }
            }
            else
            {
                SessionHelper.IsModelValid = true;
                SessionHelper.IsDataValid = true;
            }
            return null;
        }

        private List<Responses> ParseResponse(HttpRequestBase request, string surveyId, string[] questions)
        {
            var responses = _engineModule.ParseResponse(questions, request.Form);
            foreach (var resp in responses)
            {
                SessionHelper.IsDataValid = _engineModule.ValidateData(resp.Question.QuestionType.ToString(), resp);
                if (SessionHelper.IsDataValid == false) break;

                resp.SurveyId = surveyId;
                resp.Respondent = new Respondent {RespondentId = "0"};
                resp.ResponseSessionId = GetUserSessionId();
            }
            return responses;
        }

        private string GetUserSessionId()
        {
            var browserCookie = HttpContext.Request.Cookies["SessionId"];
            return browserCookie != null ? browserCookie.Values["UserSessionId"] : "";
        }

        public ActionResult GetSurveyXml(string surveyId)
        {
            try
            {
                var publishedData = GetPublishedSurvey(surveyId);
                return this.Xml(publishedData);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        public ActionResult RenderSurvey(string surveyId)
        {
            if (HasSurveyExpired(surveyId)) return Content(_engineModule.BuildExpiredScreen().ToHtmlString());

            if (SessionHelper.SessionSurvey == null)
            {
                AddSurveyToSession(surveyId);

                if (SessionHelper.SessionSurvey == null)
                    return Content(_engineModule.BuildThankYouScreen().ToHtmlString());
            }

            _engineModule.EngineSurveyConfig = SessionHelper.SessionSurvey.config;

            if (!CookieInstalled || SessionHelper.CardStack.Count == 0)
            {
                if (SessionHelper.CardStack.Count == 0)
                {
                    SessionHelper.CardStack.Push(SessionHelper.SessionSurvey.cardobj);
                }
                _engineModule.CurrentSurveyId = surveyId;
                return Content(_engineModule.BuildWelcomeScreen().ToHtmlString());
            }

            if (SessionHelper.CardStack.Peek() == null) return Content(_engineModule.BuildThankYouScreen().ToHtmlString());

            var currentCard = (card)SessionHelper.CardStack.Peek();

            PrepareEngineModule(currentCard);

            var renderedHtml = _engineModule.BuildSurveyHtmlResponse(SessionHelper.IsModelValid, SessionHelper.IsDataValid);

            return Content(renderedHtml.ToHtmlString());
        }

        private void AddSurveyToSession(string surveyId)
        {
            var surveyData = GetPublishedSurvey(surveyId);
            SessionHelper.SessionSurvey = surveyData;
            InitiateSurvey();

        }

        private static void InitiateSurvey()
        {
            if (SessionHelper.SessionSurvey != null) { SetFirstCard(SessionHelper.SessionSurvey); }
            SessionHelper.IsModelValid = true;
            SessionHelper.IsDataValid = true;
        }

        private static void PrepareEngineModule(card currentCard)
        {
            _engineModule.SurveyQuestions = currentCard.questions;
            _engineModule.CurrentSurveyId = SessionHelper.SessionSurvey.id;
            _engineModule.CurrentPage = currentCard.pageNumber;
            _engineModule.IsLastCard = currentCard.cardobj == null;
        }

        private PublishedSurvey GetPublishedSurvey(string surveyId)
        {
            var sessionId = GetUserSessionId();
            var surveyData = _surveyModule.GetSurveyBySessionId(surveyId, sessionId);
            if (surveyData == null) return null;
            var tobePublishedData = _surveyModule.RemoveFirstPageBreakQuestion(surveyData);
            var publishedData = _surveyModule.BuildSurvey(tobePublishedData);
            return publishedData;
        }

        [HttpPost]
        public ActionResult CaptureResponse(List<Responses> responses, string surveyId)
        {
            if (SessionHelper.IsModelValid && SessionHelper.IsDataValid)
            {
                if (responses != null) SaveResponses(responses);
            }

            SetCurrentCard();

            return RedirectToAction("RenderSurvey", new
                                                        {
                                                            surveyId
                                                        });
        }

        private static void SaveResponses(List<Responses> responses)
        {
            _surveyModule.SaveResponses(responses);

            var currentCard = (card)SessionHelper.CardStack.Pop();

            var responseAttachedCard = _surveyModule.AttachResponseToCard(currentCard, responses);

            SessionHelper.CardStack.Push(responseAttachedCard);

            
        }

        private static void SetCurrentCard()
        {
            var currentCard = GetCurrentCard();

            SessionHelper.CardStack.Push(currentCard);
        }

        [HttpPost]
        public ActionResult MoveBack(string surveyId)
        {
            SessionHelper.CardStack.Pop();

            return RedirectToAction("RenderSurvey", new
            {
                surveyId
            });
        }

        [HttpPost]
        public ActionResult EndSurvey(List<Responses> responses, string surveyId)
        {
            if (SessionHelper.IsModelValid)
            {
                _surveyModule.SaveResponses(responses);

                _surveyModule.CompleteSurvey(surveyId, GetUserSessionId());

                _engineModule.EngineSurveyConfig = SessionHelper.SessionSurvey.config;

                return Content(_engineModule.GetEndScreen().ToHtmlString());
            }

            return RedirectToAction("RenderSurvey", new
            {
                surveyId
            });
        }

        private static bool ValidateModel(IEnumerable<string> questions, NameValueCollection form)
        {
            return !questions.Any(question => string.IsNullOrEmpty(form["hdnAnswer_" + question]));
        }

        private static void SetFirstCard(PublishedSurvey surveyData)
        {
            SessionHelper.CardStack = new Stack();

            var firstcard = _surveyModule.IsFirstCard(surveyData.cardobj);


            if (surveyData.config.verifySkipLogic && SessionHelper.CardStack.Count > 0)
            {
                var skipcard = GetCurrentCard();
                firstcard = _surveyModule.IsFirstCard(skipcard);
            }

            SessionHelper.CardStack.Push(firstcard);
        }

        public ActionResult ProcessSurvey(string surveyId)
        {
            if (HasSurveyExpired(surveyId)) return Content(_engineModule.BuildExpiredScreen().ToHtmlString());

            return RedirectToAction("RenderSurvey", new
            {
                surveyId
            });
        }

        private static bool HasSurveyExpired(string surveyId)
        {
            var surveyData = _surveyModule.GetSurveyForExpiryCheck(surveyId);

            var objAutoMapping = new AutomapperHelper();

            var mappedconfig = (config)objAutoMapping.DoSingleObjectAutoMapping(typeof(SurveyConfig), surveyData.Config);

            _engineModule.EngineSurveyConfig = mappedconfig;

            return _surveyModule.HasSurveyExpired(surveyData.SurveyEndDate);

        }

        private static bool AllowContinueLater(string surveyId)
        {
            var surveyData = _surveyModule.GetSurveyConfig(surveyId);

            var objAutoMapping = new AutomapperHelper();

            var mappedconfig = (config)objAutoMapping.DoSingleObjectAutoMapping(typeof(SurveyConfig), surveyData.Config);

            _engineModule.EngineSurveyConfig = mappedconfig;

            return _engineModule.AllowSaveAndContinueLater();
        }

        private static card GetCurrentCard()
        {
            var currentCard = (card)SessionHelper.CardStack.Peek();

            PrepareEngineModule(currentCard);

            _engineModule.EngineSurveyConfig = SessionHelper.SessionSurvey.config;
            card skippedCard = null;
            var toJump = false;

            if (_engineModule.VerifySkipLogic())
            {
                if (_engineModule.HasSkipSourceQuestion(currentCard.questions))
                {
                    var matchedQuestionId = _engineModule.GetMatchedAnswerQuestionId(currentCard.questions);
                    if (!string.IsNullOrEmpty(matchedQuestionId))
                    {
                        toJump = true;
                        skippedCard = _engineModule.GetJumpCard(matchedQuestionId);
                    }
                }
            }

            return !toJump ? currentCard.cardobj : skippedCard;
        }
    }
}
