﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.ModuleLibrary;
using ORT_CORE.Class.LibraryClasses;
using ORT_CORE.Interface.LibaryInterface;
using ORT_HELPERS.Helpers;
using ORT_CORE.Interface.SurveyInterface;
using System.IO;
using System.Web;
using ORT_PERSISTENCE.UploadObjects.Interface;
using System.Runtime.Serialization.Json;
using ORT_VIEW_MAP.MapClasses;
using ORT_VIEW_MAP.MapClasses.Library;

namespace ORT_APPLICATION.Controllers
{
    //[SecurityFilter]
    public class LibraryController : Controller
    {
        private static LibraryModule _libraryModuleMain;
        private static IEnumerable<ILibrary> _iLibrary;

        public LibraryController(IEnumerable<ILibrary> library, ICustomer cust, IAnswer answer, ISkipLogic skipLogic, ISoundClip sound, IQuestion question, IQuota quota, IReward reward, ISetting setting, IGraphicsUpload objGrpUpload, IUpload objUpload)
        {
            _iLibrary = library;
            _libraryModuleMain = new LibraryModule(cust, answer, skipLogic, sound, question, quota, reward, setting, objGrpUpload, objUpload);
        }

        public ActionResult Index()
        {
            return View();
        }

        #region "GetLibrary"

        public JsonResult GetLibraries(int? type)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                var data = GetLibraryViewModel(currentLibrary, Convert.ToString(type));
                if (data == null)
                    return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson("", "libraries");
                return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(data, "libraries");

               

            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        public JsonResult GetLibraryCategories(int? type)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                var data = GetLibraryCategoryViewModel(currentLibrary);
                if (data == null)
                    return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson("", "categories");
                return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(data, "categories");
               
               
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        private static object GetLibraryCategoryViewModel(ILibrary currentLibrary)
        {
            var objAutoMapping = new AutomapperHelper();

            var data = GetLibraryCategoryData(currentLibrary);

            return objAutoMapping.DoLibraryComboAutoMapping(typeof(LibraryCategory), typeof(LibraryCategoryViewModel), data);
        }

        private static object GetLibraryCategoryData(ILibrary currentLibrary)
        {
            var libraryModule = new LibraryModule(currentLibrary);
            return libraryModule.GetLibraryCAtegory("");
        }

        private static ILibrary GetCurrentRepository(int? libraryType)
        {
            if (libraryType == null) return null;
            var type = DescriptionHelper.GetDescription((Library.LibraryType)libraryType);
            return _iLibrary.Single(library => library.GetType().Name == type);
        }

        private static object GetLibraryViewModel(ILibrary currentLibrary, string type)
        {
            var objAutoMapping = new AutomapperHelper();

            var data = GetLibraryData(currentLibrary, type);
            if (data == null) return null;
            return objAutoMapping.DoLibraryComboAutoMapping(typeof(Library), typeof(MasterViewModel), data);
        }

        private static object GetLibraryData(ILibrary currentLibrary, string type)
        {
            var libraryModule = new LibraryModule(currentLibrary);
            var customer = SessionHelper.LoggedinCustomer;
            return libraryModule.GetLibrary(customer, type);
        }
        #endregion

        #region "SearchLibrary"

        public JsonResult SearchLibrary(int? type, string libraryId, string categoryId)
        {
            try
            {
                var strCat = (categoryId == "undefined") ? "0" : categoryId;
                var currentLibrary = GetCurrentRepository(type);
                var libData = SearchLibraryViewModel(currentLibrary, libraryId, strCat);

                if (libData != null)
                {
                    return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(libData, currentLibrary.JsonModelName);
                }
                else if (!string.IsNullOrEmpty(currentLibrary.Message))
                {
                    return ReturnJsonHelper.GetValidationJson(currentLibrary.Message);
                }
                else { return ReturnJsonHelper.GetSuccessJson("", currentLibrary.JsonModelName); }
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        private static object SearchLibraryViewModel(ILibrary currentLibrary, string libraryId, string category)
        {
            string strcat;
            strcat = (category == "undefined") ? "0" : category;
            var objAutoMapping = new AutomapperHelper();
            var data = SearchLibraryData(currentLibrary, libraryId, strcat);
            if (data != null)
            {
                return objAutoMapping.DoLibraryAutoMapping(currentLibrary.HomeType, currentLibrary.HomeType, data);
            }
            else { return null; }
        }
        private static object SearchLibraryData(ILibrary currentLibrary, string libraryId, string category)
        {
            _libraryModuleMain = new LibraryModule(currentLibrary);
            return _libraryModuleMain.SearchLibrary(libraryId, category);
        }
        #endregion

        #region "EditLibrary"

        [HttpPost]
        public JsonResult EditLibrary(int? type, int libraryId, int grLibraryId, int grCategoryId)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                var libData = EditLibraryViewModel(currentLibrary, grLibraryId, grCategoryId);
                return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(libData, "details");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static object EditLibraryViewModel(ILibrary currentLibrary, int libId, int category)
        {
            var objAutoMapping = new AutomapperHelper();
            var data = EditLibraryData(currentLibrary, libId, category);
            return objAutoMapping.DoLibraryAutoMapping(currentLibrary.HomeType, currentLibrary.HomeType, data);
        }
        private static object EditLibraryData(ILibrary currentLibrary, int libId, int category)
        {
            _libraryModuleMain = new LibraryModule(currentLibrary);
            return _libraryModuleMain.EditLibrary(libId, category);
        }
        #endregion

        #region "AddLibrary"

        [HttpPost]
        public JsonResult AddLibrary(int? type, object objClientLib)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                var data = AddLibraryViewModel(currentLibrary, objClientLib);
                //return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(AddLibraryViewModel(currentLibrary, objClientLib), "libraries");

                if (data != null)
                {
                    return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(data, "categories");
                }
                else if (!string.IsNullOrEmpty(currentLibrary.Message))
                {
                    return ReturnJsonHelper.GetValidationJson(currentLibrary.Message);
                }
                else { return ReturnJsonHelper.GetSuccessJson("", currentLibrary.JsonModelName); }


            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static object AddLibraryViewModel(ILibrary currentLibrary, object objlibrary)
        {
            try
            {
                var objAutoMapping = new AutomapperHelper();
                var objLib = objAutoMapping.DoLibraryAutoMapping(typeof(LibraryViewModel), objlibrary);
                var data = AddLibraryData(currentLibrary, objLib);
                return data;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private static object AddLibraryData(ILibrary currentLibrary, object objlibrary)
        {
            var objAutoMapping = new AutomapperHelper();
            _libraryModuleMain = new LibraryModule(currentLibrary);
            var newLib = _libraryModuleMain.SaveLibrary(objlibrary);
            var objLib = objAutoMapping.DoLibraryAutoMapping(typeof(Library), newLib);
            return objLib;
        }
        #endregion

        #region "AddLibraryCategory"

        [HttpPost]
        public JsonResult AddLibraryCategory(int? type, object objClientLib)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
               var data = AddLibraryCategoryViewModel(currentLibrary, objClientLib);
                //return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(AddLibraryCategoryViewModel(currentLibrary, objClientLib), "categories");
                if (data != null)
                {
                    return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(data, "categories");
                }
                else if (!string.IsNullOrEmpty(currentLibrary.Message))
                {
                    return ReturnJsonHelper.GetValidationJson(currentLibrary.Message);
                }
                else { return ReturnJsonHelper.GetSuccessJson("", currentLibrary.JsonModelName); }


            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static object AddLibraryCategoryViewModel(ILibrary currentLibrary, object objlibrary)
        {
            var objAutoMapping = new AutomapperHelper();
            var objLib = objAutoMapping.DoLibraryAutoMapping(objlibrary.GetType(), objlibrary);
            var data = (LibraryCategoryViewModel)AddLibraryCategoryData(currentLibrary, objLib);
            return data;
        }
        private static object AddLibraryCategoryData(ILibrary currentLibrary, object objlibrary)
        {
            _libraryModuleMain = new LibraryModule(currentLibrary);
            var newLibCateg = _libraryModuleMain.SaveLibraryCategory(objlibrary);
            var objAutoMapping = new AutomapperHelper();
            var objLib = objAutoMapping.DoLibraryAutoMapping(newLibCateg.GetType(), newLibCateg);

            return objLib;
        }
        #endregion

        #region "SaveLibraryDetails"

        [HttpPost]
        public JsonResult SaveLibraryDetails(int? type, object objClientLib)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                _libraryModuleMain = new LibraryModule(currentLibrary);
                var libData = AddLibraryDetaislData(currentLibrary, objClientLib);
                if (libData != null)
                {
                    return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(libData, "messages");
                }
                else
                {
                    return ReturnJsonHelper.GetValidationJson(currentLibrary.Message);
                }
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static object AddLibraryDetaislData(ILibrary currentLibrary, object objlibrary)
        {
            _libraryModuleMain = new LibraryModule(currentLibrary);
            var objAutoMapping = new AutomapperHelper();
            var newMessgae = _libraryModuleMain.SaveLibraryDetails(objlibrary);
            if (string.IsNullOrEmpty(currentLibrary.Message))
                return objAutoMapping.DoLibraryAutoMapping(newMessgae.GetType(), newMessgae);
            return null;
        }
        #endregion

        #region "DeleteLibraryDetails"

        [HttpPost]
        public JsonResult DeleteLibraryDetails(int? type, object objClientLib)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                var deleteId = DeleteibraryDetaislData(currentLibrary, objClientLib);
                if (deleteId != string.Empty)
                    return ReturnJsonHelper.GetSuccessJson(deleteId, "libraries");
                return ReturnJsonHelper.GetExceptionJson(new Exception());
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static string DeleteibraryDetaislData(ILibrary currentLibrary, object objClientLib)
        {
            var objAutoMapping = new AutomapperHelper();
            var objLib = objAutoMapping.DoLibraryAutoMapping(objClientLib.GetType(), objClientLib);
            _libraryModuleMain = new LibraryModule(currentLibrary);
            return _libraryModuleMain.DeleteLibrary(objLib);
        }
        #endregion


        [HttpPost]
        public JsonResult SaveGraphicFile(string type, string graphicsLibrary, string graphicsCategory)
        {
            try
            {

                var files = Request.Files["ufile[]"];

                //foreach (var file in files)
                //{
                if (files.ContentLength > 0)
                {
                    var extnsion = Path.GetExtension(files.FileName);
                    if (extnsion.ToLower() == ".jpg" || extnsion.ToLower() == ".gif" || extnsion.ToLower() == ".png")
                    {
                        var fileName = Path.GetFileName(files.FileName);
                        var folderPath =
                            !string.IsNullOrEmpty(graphicsCategory) ?
                            SessionHelper.AppSettings.GraphicUpload + "/" + graphicsLibrary + "/" + graphicsCategory :
                            SessionHelper.AppSettings.GraphicUpload + "/" + graphicsLibrary + "/";
                        var path = Path.Combine(folderPath, fileName);
                        if (!System.IO.Directory.Exists(folderPath))
                        {
                            Directory.CreateDirectory(folderPath);
                        }

                        if (files.ContentLength > 0)
                        {
                            files.SaveAs(path);
                            if (!System.IO.File.Exists(folderPath))
                            {
                                var currentLibrary = GetCurrentRepository(Convert.ToInt32(type));
                                _libraryModuleMain = new LibraryModule(currentLibrary);
                                var uploadResult = (GraphicLibrary)_libraryModuleMain.SaveGraphicsFile
                                    (graphicsLibrary, graphicsCategory, fileName, folderPath, extnsion);
                                uploadResult.LibType = Library.LibraryType.Graphic;
                                var objAutoMapping = new AutomapperHelper();
                                var finalData =
                                    objAutoMapping.DoLibraryAutoMapping(currentLibrary.HomeType, uploadResult);
                                //return currentLibrary == null ? null :
                                //    ReturnJsonHelper.TestGraphicsSuccessJson();
                                return currentLibrary == null ? null :
                                    ReturnJsonHelper.GetUploadSuccessJson(finalData, currentLibrary.JsonModelName);
                            }
                        }

                    }
                    return ReturnJsonHelper.GetValidationJson("Please Upload Valid Image File..!");
                    //}

                }
                return ReturnJsonHelper.GetValidationJson("Please Upload File..!");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var user = SessionHelper.LogggedInUser;
            try
            {
                if (user != null)
                {
                    var objAutoMapping = new AutomapperHelper();
                    var action = filterContext.ActionDescriptor.ActionName;
                    var paramType = filterContext.HttpContext.Request.QueryString["type"];
                    var libraryType = Convert.ToInt32(paramType.Split(',')[0]);
                    var currentLibrary = GetCurrentRepository(libraryType);
                    var destionToMap = objAutoMapping.GetSourceMapType(currentLibrary.HomeType);
                    if (action == "AddLibraryCategory")
                    {
                        var o =
                            new DataContractJsonSerializer(typeof(LibraryCategoryViewModel)).ReadObject(filterContext.HttpContext.Request.InputStream);
                        filterContext.ActionParameters["objClientLib"] = o;
                    }
                    else if (action == "AddLibrary")
                    {
                        var o =
                            new DataContractJsonSerializer(typeof(LibraryViewModel)).ReadObject(filterContext.HttpContext.Request.InputStream);
                        var retObject = (LibraryViewModel)o;
                        retObject.type = ((Library.LibraryType)libraryType).ToString();
                        filterContext.ActionParameters["objClientLib"] = o;
                    }
                    else if (action == "SaveGraphicFile")
                    {
                        var file = Request.Form["fieldId"];
                    }

                    else if (action != "GetLibraries" && action != "GetLibraryCategories" && action != "SaveGraphicFile" && action != "SearchLibraryCategories" && action != "SearchLibrary")
                    {
                        var o =
                        new DataContractJsonSerializer(destionToMap).ReadObject(filterContext.HttpContext.Request.InputStream);
                        filterContext.ActionParameters["objClientLib"] = o;
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
