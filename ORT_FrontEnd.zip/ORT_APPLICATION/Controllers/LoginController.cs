﻿using System.Web.Mvc;
using ORT_APPLICATION.Infrastructure;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;
using log4net;
using System.Web.Security;
using System.Web;
using System;


namespace ORT_APPLICATION.Controllers
{
    [HandleError]
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static LoginModule _loginModule;

        public LoginController(IUser user, ICustomer cust)
        {
            _loginModule = new LoginModule(user, cust);
        }

        public ActionResult Logon()
        {
            if (SessionHelper.LogggedInUser !=null)
            {
                Session.Abandon();
            }
            SessionHelper.GetRandomEncryptString();
            return View(new LogonViewModel
                {
                    ChalString = SessionHelper.SessionSaltString,
                    RelativePath = SessionHelper.AppSettings.RelativePath
                });
        }

        [HttpPost]
        public ActionResult Logon(LogonViewModel logonViewModel)
        {
            try
            {
                if(ModelState.IsValid)
                {
                    var user = new User { LoginId = logonViewModel.UserName, Password = logonViewModel.HdnPassword, EmailId = "" };
                    Log.Info("User Logon Begins");
                    LoginModule.SessionSaltString = logonViewModel.ChalString;
                    if (_loginModule.ValidateUser(user))
                    {
                        logonViewModel.HdnErrorMessage = "";
                        SessionHelper.LogggedInUser = _loginModule.LoggedInUser;
                        AuthenticateTicket(user.UserName, user.LoginId);
                        return Redirect(Url.Content("~/UserLogin.html"));
                    }
                    logonViewModel.HdnErrorMessage = _loginModule.Message;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                logonViewModel.HdnErrorMessage = "Unexpected error occured";
                return View(logonViewModel);
            }
            return View(logonViewModel);
        }

        [ValidateSession]
        [HttpPost]
        public ActionResult DoLogin()
        {
            return Redirect(Url.Content("~/index.html"));
            
        }

        public ActionResult Transition()
        {
            return Redirect(Url.Content("~/logout.html"));
        }

        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();

            // Clear authentication cookie
            var rFormsCookie = new HttpCookie(FormsAuthentication.FormsCookieName, "") { Expires = DateTime.Now.AddYears(-1) };
            Response.Cookies.Add(rFormsCookie);

            // Clear session cookie 
            var rSessionCookie = new HttpCookie("ASP.NET_SessionId", "") { Expires = DateTime.Now.AddYears(-1) };
            Response.Cookies.Add(rSessionCookie);

            // Invalidate the Cache on the Client Side
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            foreach (var cookie in Request.Cookies.AllKeys)
            {
                Request.Cookies.Remove(cookie);
            }
            foreach (var cookie in Response.Cookies.AllKeys)
            {
                Response.Cookies.Remove(cookie);
            }
            return RedirectToAction("Logon");
        }

        private void AuthenticateTicket(string uName, string uId)
        {
            var authTicket = new FormsAuthenticationTicket(1, uName, DateTime.Now, DateTime.Now.AddMinutes(20), true, uId);
            var encryptedTicket = FormsAuthentication.Encrypt(authTicket);
            var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
            Response.Cookies.Add(authCookie);
        }

        [ValidateSession]
        public JsonResult LoggedOnUserInfo()
        {
            try
            {
                return ReturnJsonHelper.GetSuccessJson(new
                {
                    user = SessionHelper.LogggedInUser.UserName,
                    phone = SessionHelper.LogggedInUser.UserDetails.Phone1
                }, "context");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }
        //public ActionResult GoogleLogon()
        //{
        //    var serviceDescription = new AuthorizationServerDescription
        //    {
        //        AuthorizationEndpoint = new Uri("https://accounts.google.com/o/oauth2/auth"),
        //        ProtocolVersion = ProtocolVersion.V20,
        //        TokenEndpoint = new Uri("https://accounts.google.com/o/oauth2/token?grant_type=authorization_code")
        //    };

        //    var client = new WebServerClient(serviceDescription, "872438329936.apps.googleusercontent.com", "yZTx49Wbc9cbgyug9Zhfmql-");
        //    var request = client.PrepareRequestUserAuthorization(GetAuthorization(client), null);

        //}

        //private static IAuthorizationState GetAuthorization(WebServerClient arg)
        //{
        //    IAuthorizationState state = new AuthorizationState(new[] { "https://www.googleapis.com/auth/userinfo.email", "https://www.googleapis.com/auth/userinfo.profile" });
        //    state.Callback = new Uri("http://localhost:5000/SocialNetworks/VerifyLocalInfo.aspx");
        //    return state;
        //}



    }
}
