﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using ORT_APPLICATION.Helpers;
using ORT_CORE.Interface.SurveyInterface;
using ORT_BUSSINESS_LAYER.ModuleSurvey;

namespace ORT_APPLICATION.Controllers
{
    public class ImportCSVController : Controller
    {
        //
        // GET: /ImportCSV/

         private static PanelModule _panelModule;

         public ImportCSVController(IPanelist Panel, ICustomer cust)
        {
            _panelModule = new PanelModule(Panel, cust);
        }


        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ImportFile(IEnumerable<HttpPostedFileBase> files, string rdbDuplicate, string rdbUpdate)
        {
            foreach (var file in files)
            {
                if (file.ContentLength > 0)
                {
                    var extnsion = Path.GetExtension(file.FileName);
                    if (extnsion == ".csv")
                    {
                        var fileName = Path.GetFileName(file.FileName);
                        var folderPath = Server.MapPath("~/uploads");
                        var path = Path.Combine(folderPath, fileName);
                        //var desPath = Path.Combine(Server.MapPath("~/TempUpload"), fileName);
                        file.SaveAs(path);
                        //System.IO.File.Copy(path, desPath);

                      //.FileCopy("OpenDialog.FileName", "clsCommon.strExcelFilePath + strFilename");
                        if (!System.IO.File.Exists(folderPath))
                        {
                            _panelModule.ImportData(folderPath, fileName, extnsion);
                        }
                    }
                    return ReturnJsonHelper.GetValidationJson("Please Select csv file.");
                }
            }
            return RedirectToAction("Index");
        }

    }
}
