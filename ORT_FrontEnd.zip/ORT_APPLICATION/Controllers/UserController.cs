﻿using System;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using log4net;
using ORT_APPLICATION.Infrastructure;
using AutoMapper;
using ORT_VIEW_MAP.MapClasses;
using System.Collections.Generic;
using SHA256;
namespace ORT_APPLICATION.Controllers
{
    [HandleError]
    [ValidateSession]
    [SecurityFilter]
    public class UserController : Controller
    {
        //
        // GET: /User/
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static UserModule _userModule;

        public UserController(IUser user, ICustomer cust)
        {
            _userModule = new UserModule(user, cust);
            _userModule.LoggedInUser = SessionHelper.LogggedInUser;

        }

        public JsonResult GetUsers()
        {
            try
            {
                Log.Info("Get Users Begins");
                //_userModule.LoggedInUser = SessionHelper.LogggedInUser;
                var user = SessionHelper.LoggedinUserId;
                var jsonData = Mapper.Map<User, UserViewModel>(_userModule.GetUserDetailsByUserId(user));
                return ReturnJsonHelper.GetSuccessJson(jsonData, "users");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        public JsonResult SearchUsers(string code, string email, string loginId, string name, string company)
        {
            try
            {
                Log.Info("Search Users Begins");
                var jsonData = Mapper.Map<List<User>, List<UserViewModel>>(_userModule.GetUserDetailsList(code, loginId, name, company, email));
                return ReturnJsonHelper.GetSuccessJson(jsonData, "users");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        [HttpPost]
        [ObjectFilter(Param = "userDetailViewModel", RootType = typeof(UserViewModel))]
        public JsonResult AddUser(UserViewModel userDetailViewModel)
        {
            try
            {
                Log.Info("Add User Begins");
                if (_userModule.IsValid(userDetailViewModel))
                {
                    var saveData = Mapper.Map<UserViewModel, User>(userDetailViewModel);
                    //saveData.Password = EncryptPassword(saveData.Password);
                    saveData.CreatedBy = new User { UserId = SessionHelper.LoggedinUserId };
                    saveData.ModifiedBy = new User { UserId = "" };
                    if (_userModule.SaveUser(saveData))
                    {
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessUser(saveData.UserId), "users");
                    }
                    else if (!string.IsNullOrEmpty(_userModule.Message))
                    {
                        return ReturnJsonHelper.GetValidationJson(_userModule.Message);
                    }

                }
                return ReturnJsonHelper.GetValidationJson(_userModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        [HttpPost]
        [ObjectFilter(Param = "userDetailViewModel", RootType = typeof(UserViewModel))]
        public ActionResult UpdateUser(UserViewModel userDetailViewModel)
        {
            try
            {
                Log.Info("Update User Begins");
                User updateData;
                //for updation of password
                if (!string.IsNullOrEmpty(userDetailViewModel.password))
                {
                    updateData = _userModule.GetUserDetailsByUserId(userDetailViewModel.id);
                    updateData.Password = userDetailViewModel.password;
                    if (UpdateUserData(updateData))
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessUser(updateData.UserId), "users");
                }

                if (_userModule.IsValid(userDetailViewModel))
                {
                    updateData = Mapper.Map<UserViewModel, User>(userDetailViewModel);
                    if (UpdateUserData(updateData))
                    {
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessUser(updateData.UserId), "users");
                    }
                }
                return ReturnJsonHelper.GetValidationJson(_userModule.Message);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        [HttpPost]
        [ObjectFilter(Param = "userDetailViewModel", RootType = typeof(UserViewModel))]
        public ActionResult DeleteUser(UserViewModel userDetailViewModel)
        {
            try
            {
                Log.Info("Delete User Begins");
                var updateData = Mapper.Map<UserViewModel, User>(userDetailViewModel);
                updateData.UserDetails.IsActive = Convert.ToBoolean(0);
                if (_userModule.DeleteUser(updateData.LoginId))
                    return ReturnJsonHelper.GetSuccessJson(updateData.UserId, "users");
                return ReturnJsonHelper.GetExceptionJson(new Exception());
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        private static string EncryptPassword(string password)
        {
            if (String.IsNullOrEmpty(password))
                return null;
            var objSha = new HASHClass();
            return objSha.SHA256(ref password);
        }

        private static UserViewModel GetSuccessUser(string userId)
        {
            var successUser = _userModule.GetUserDetailsByUserId(userId);
            var finalData = Mapper.Map<User, UserViewModel>(successUser);
            finalData.password = "";
            return finalData;
        }

        private static bool UpdateUserData(User updateData)
        {
            updateData.ModifiedBy = new User { UserId = SessionHelper.LoggedinUserId };
            updateData.CreatedBy = new User { UserId = "" };
            return _userModule.SaveUser(updateData);
        }


    }
}
