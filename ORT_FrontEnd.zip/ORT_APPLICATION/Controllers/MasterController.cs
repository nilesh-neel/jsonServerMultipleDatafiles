﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.Mvc;
using ORT_APPLICATION.Infrastructure;
using ORT_BUSSINESS_LAYER.ModuleMaster;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.MasterInterface;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;

namespace ORT_APPLICATION.Controllers
{
    public enum MasterType
    {
        [Description("CityRepository")]
        City = 1,
        [Description("CountryRepository")]
        Country,
        [Description("StateRepository")]
        State,
        [Description("LanguageRepository")]
        Language,
        [Description("RoleRepository")]
        Role,
        [Description("TimeZoneRepository")]
        TimeZone
    }

    [ValidateSession]
    public class MasterController : Controller
    {
        private static MasterModule _masterModule;
        private static IEnumerable<IMaster> _iMaster;
        private static CustomerModule _customerModule;

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //LoggedOnUserInfo

            var user = SessionHelper.LogggedInUser;
            if (user == null)
            {
                filterContext.Result = ReturnJsonHelper.GetTimeOutJson();
            }
            else
            {
                base.OnActionExecuting(filterContext);
            }
        }
        readonly string[] _arrReturnNodes = new[] { "cities", "countries", "states", "languages", "roles", "timezones" };

        public MasterController(IEnumerable<IMaster> masters, ICustomer customer)
        {
            _iMaster = masters;
            _customerModule = new CustomerModule(customer, null);
        }

        public JsonResult GetMaster(int type)
        {
            try
            {
                var repository = GetCurrentRepository(DescriptionHelper.GetDescription((MasterType)type));
                var data = GetMasterViewModel(repository);
                return ReturnJsonHelper.GetSuccessJson(data, _arrReturnNodes[type - 1]);
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        public JsonResult GetCompany()
        {
            try
            {
                return ReturnJsonHelper.GetSuccessJson(GetCompanyViewModel(), "companies");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }


        private static IMaster GetCurrentRepository(string masterType)
        {
            return masterType == null ? null : _iMaster.Single(m => m.GetType().Name == masterType);
        }

        private static object GetMasterViewModel(IMaster currentMaster)
        {
            var objAutoMapping = new AutomapperHelper();

            var data = GetMasterData(currentMaster);

            return objAutoMapping.DoAutoMapping(currentMaster.HomeType, data);
        }

        private static object GetCompanyViewModel()
        {
            var objAutoMapping = new AutomapperHelper();
            _customerModule.LoggedInUser = SessionHelper.LogggedInUser;
            var customerData = _customerModule.GetCompanyMaster();
            return objAutoMapping.DoAutoMapping(typeof(Customer), typeof(MasterViewModel), customerData);

        }


        private static object GetMasterData(IMaster currentMaster)
        {
            _masterModule = new MasterModule(currentMaster) { LoggedInUser = SessionHelper.LogggedInUser };
            return _masterModule.GetMasterList();
        }
    }
}
