﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ORT_BUSSINESS_LAYER.MusicCloset;
using ORT_CORE.Interface.LibaryInterface;
using ORT_HELPERS.Helpers;
using ORT_CORE.Class.LibraryClasses;
using System.Runtime.Serialization.Json;
using ORT_PERSISTENCE.UploadObjects.Interface;
using System.IO;
using ORT_VIEW_MAP.MapClasses;
using ORT_BUSSINESS_LAYER.ModuleLibrary;

namespace ORT_APPLICATION.Controllers
{
    public class MusicClosetController : Controller
    {
        //
        // GET: /MusicCloset/
        private static MusicModule _musicModule;
        private static IEnumerable<ILibrary> _iLibrary;
        private static IEnumerable<IUpload> _iUpload;

        public MusicClosetController(IEnumerable<ILibrary> library, ISoundClip sound, IEnumerable<IUpload> objUpload)
        {
            _iLibrary = library;
            _iUpload = objUpload;
            _musicModule = new MusicModule(sound);
 
        }

        private static ILibrary GetCurrentRepository(int? type)
        {
            if (type == null) return null;
            var libType = DescriptionHelper.GetDescription((Library.LibraryType)type);
            return _iLibrary.Single(library => library.GetType().Name == libType);
        }

        #region "GetLibrary"

        public JsonResult GetLibraries(int? type)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(GetLibraryViewModel(currentLibrary, Convert.ToString(type)), "libraries");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }            

        private static object GetLibraryViewModel(ILibrary currentLibrary, string type)
        {
            var objAutoMapping = new AutomapperHelper();

            var data = GetLibraryData(currentLibrary, type);

            return objAutoMapping.DoLibraryComboAutoMapping(typeof(Library), typeof(MasterViewModel), data);
        }

        private static object GetLibraryData(ILibrary currentLibrary, string type)
        {
            var libraryModule = new LibraryModule(currentLibrary);
            var customer = SessionHelper.LoggedinCustomer;
            return libraryModule.GetLibrary(customer, type);
        }
        #endregion


        #region "AddLibrary"

        [HttpPost]
        public JsonResult AddLibrary(int? type, object objClientLib)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                
                

                //return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(EditLibraryViewModel(currentLibrary, libId), "library");

                return new JsonResult
                {
                    Data = AddLibraryViewModel(currentLibrary, objClientLib),
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
            catch (Exception ex)
            {
                throw; //return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static object AddLibraryViewModel(ILibrary currentLibrary, object objlibrary)
        {
            var objAutoMapping = new AutomapperHelper();
            var objLib = objAutoMapping.DoLibraryAutoMapping(objlibrary.GetType(), currentLibrary.HomeType, objlibrary);
            var data = AddLibraryData(currentLibrary, objLib);
            return data;
        }
        private static object AddLibraryData(ILibrary currentLibrary, object objlibrary)
        {
            return _musicModule.SaveLibrary(objlibrary, currentLibrary);
        }
        #endregion

        #region "AddLibraryCategory"

        [HttpPost]
        public JsonResult AddLibraryCategory(int? type, object objClientLib)
        {
            try
            {
                var currentLibrary = GetCurrentRepository(type);
                //return currentLibrary == null ? null : ReturnJsonHelper.GetSuccessJson(EditLibraryViewModel(currentLibrary, libId), "library");

                return new JsonResult
                {
                    Data = AddLibraryCategoryViewModel(currentLibrary, objClientLib),
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
            catch (Exception ex)
            {
                throw; //return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        private static object AddLibraryCategoryViewModel(ILibrary currentLibrary, object objlibrary)
        {
            var objAutoMapping = new AutomapperHelper();
            var objLib = objAutoMapping.DoLibraryAutoMapping(objlibrary.GetType(), currentLibrary.HomeType, objlibrary);
            var data = AddLibraryCategoryData(currentLibrary, objLib);
            return data;
        }
        private static object AddLibraryCategoryData(ILibrary currentLibrary, object objlibrary)
        {
            return _musicModule.SaveLibraryCategory(objlibrary, currentLibrary); ;
        }
        #endregion

        #region "GetSoundClipInfo"
        public JsonResult SearchSound(int filelibId)
        {
            try
            {
               
                return new JsonResult
                {
                    Data = _musicModule.SearchSoundClip(filelibId),
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
            catch (Exception ex)
            {
                throw; //return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }


        #endregion

        [HttpPost]
        public ActionResult SaveMusicFile(HttpPostedFileBase files, string type, string grLibraryId, string grCategoryId)
        {

            //foreach (var file in files)
            //{
            if (files.ContentLength > 0)
            {
                var extnsion = Path.GetExtension(files.FileName);
                if (extnsion.ToLower() == ".mp3" || extnsion.ToLower() == ".xls" || extnsion.ToLower() == ".xlsx")
                {
                    var fileName = Path.GetFileName(files.FileName);
                    var folderPath = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["SoundClip"]);
                    var path = Path.Combine(folderPath, fileName);

                    if (files.ContentLength > 0)
                    {
                        files.SaveAs(path);
                        if (!System.IO.File.Exists(folderPath))
                        {
                            var objUploadClass = _iUpload.Single(library => library.GetType().Name == "SoundClipUpload");
                            _musicModule = new MusicModule(objUploadClass);
                         var uploadResult = _musicModule.UploadSoundClip(grLibraryId, grCategoryId, fileName, folderPath, extnsion);
                            return new JsonResult
                            {
                                Data = uploadResult == true ? true : false,
                                JsonRequestBehavior = JsonRequestBehavior.AllowGet
                            };

                        }
                    }
                    return ReturnJsonHelper.GetValidationJson("Please Upload File..!");
                }
                return ReturnJsonHelper.GetValidationJson("Please Upload Valid Image File..!");
                //}

            }
            return RedirectToAction("Index");
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var user = SessionHelper.LogggedInUser;
            if (user != null)
            {
                var objAutoMapping = new AutomapperHelper();
                var action = filterContext.ActionDescriptor.ActionName;
                var type = filterContext.HttpContext.Request.QueryString["type"];
                var currentLibrary = GetCurrentRepository(Convert.ToInt32(type));
                var destionToMap = objAutoMapping.GetSourceMapType(currentLibrary.HomeType);
                if (action != "SearchSound" && action != "GetLibraries" && action != "SaveMusicFile")
                {
                    var o =
                    new DataContractJsonSerializer(destionToMap).ReadObject(filterContext.HttpContext.Request.InputStream);
                    filterContext.ActionParameters["objClientLib"] = o;
                }

            }
        }

    }
}
