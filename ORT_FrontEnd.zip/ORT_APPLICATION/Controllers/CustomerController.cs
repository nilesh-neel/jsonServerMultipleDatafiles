﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using AutoMapper;
using ORT_APPLICATION.Infrastructure;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;
using log4net;

namespace ORT_APPLICATION.Controllers
{
    [HandleError]
    [ValidateSession]
    [SecurityFilter]
    public class CustomerController : Controller
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static CustomerModule _customerModule;

        public CustomerController(ICustomer customer,IUser user)
        {
            _customerModule = new CustomerModule(customer,user);
        }

        public JsonResult SearchCustomer(string company, string abbreviation)
        {
            try
            {
                Log.Info("Get Customer List Begins");
                _customerModule.LoggedInUser = SessionHelper.LogggedInUser;
                var customerList = Mapper.Map<List<Customer>, List<CustomerViewModel>>(_customerModule.GetCustomerList(abbreviation, company));

                return ReturnJsonHelper.GetSuccessJson(customerList, "companies");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }

        [HttpPost]
        [ObjectFilter(Param = "custDetailViewModel", RootType = typeof(CustomerViewModel))]
        public ActionResult AddCustomer(CustomerViewModel custDetailViewModel)
        {
            try
            {
                Log.Info("Add Customer Begins");
                if (_customerModule.IsValid(custDetailViewModel))
                {
                    var updateData = Mapper.Map<CustomerViewModel, Customer>(custDetailViewModel);
                    updateData.CustomerId = "";
                    updateData.CreatedBy = new User { UserId=SessionHelper.LoggedinUserId };
                    updateData.ModifiedBy = new User { UserId = ""};
                    if (_customerModule.SaveCustomer(updateData))
                    {
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessCompany(updateData.CustomerId), "companies");
                    }
                    else if (!string.IsNullOrEmpty(_customerModule.Message))
                    {
                        return ReturnJsonHelper.GetValidationJson(_customerModule.Message);  
                    }
                }
                return ReturnJsonHelper.GetValidationJson(_customerModule.Message);                
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        [HttpPost]
        [ObjectFilter(Param = "custDetailViewModel", RootType = typeof(CustomerViewModel))]
        public ActionResult UpdateCustomer(CustomerViewModel custDetailViewModel)
        {
            try
            {
                Log.Info("Update Customer Begins");
                if (_customerModule.IsValid(custDetailViewModel))
                {
                    var updateData = Mapper.Map<CustomerViewModel, Customer>(custDetailViewModel);
                    updateData.ModifiedBy = new User { UserId = SessionHelper.LoggedinUserId };
                    updateData.CreatedBy = new User { UserId = "" };
                    if (_customerModule.SaveCustomer(updateData))
                    {
                        return ReturnJsonHelper.GetSuccessJson(GetSuccessCompany(updateData.CustomerId), "companies");
                    }
                   
                }
                return ReturnJsonHelper.GetValidationJson(_customerModule.Message); 
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }


        [HttpPost]
        [ObjectFilter(Param = "custDetailViewModel", RootType = typeof(CustomerViewModel))]
        public ActionResult DeleteCustomer(CustomerViewModel custDetailViewModel)
        {
            try
            {
                Log.Info("Delete Customer Begins");
                var updateData = Mapper.Map<CustomerViewModel, Customer>(custDetailViewModel);
                updateData.IsActive = Convert.ToBoolean(0);
                if (_customerModule.DeleteCustomer(updateData.CustomerName, updateData.Abbreviation, updateData.CustomerId))
                {
                    return ReturnJsonHelper.GetSuccessJson(updateData.CustomerId, "companies");
                }
                else if (!string.IsNullOrEmpty(_customerModule.Message))
                {
                    return ReturnJsonHelper.GetValidationJson(_customerModule.Message); 
                }
                return ReturnJsonHelper.GetExceptionJson(new Exception());                 
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }

        }

        private static CustomerViewModel GetSuccessCompany(string custId)
        {
            var successCusttomer = _customerModule.GetCustomer(custId);
            var finalData = Mapper.Map<Customer, CustomerViewModel>(successCusttomer);
            return finalData;
        }

    }
}
