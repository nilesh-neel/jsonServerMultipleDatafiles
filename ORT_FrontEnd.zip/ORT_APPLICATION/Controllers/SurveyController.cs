﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using AutoMapper;
using ORT_APPLICATION.Infrastructure;
using ORT_BUSSINESS_LAYER.ModuleSurvey;
using ORT_CORE.Class.SurveyClasses;
using ORT_CORE.Interface.SurveyInterface;
using ORT_HELPERS.Helpers;
using ORT_VIEW_MAP.MapClasses;
using log4net;

namespace ORT_APPLICATION.Controllers
{
    [HandleError]
    [ValidateSession]
    [SecurityFilter]
    public class SurveyController : Controller
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static SurveyModule _surveyModule;

        public SurveyController(ISurvey survey, IUser user, ICustomer customer, IQuestion question, ISetting setting, IReward reward, IQuota quota, IAnswer answer, ISkipLogic skipLogic, IPlayList playList)
        {
            _surveyModule = new SurveyModule(survey, user, customer, question, setting, reward, quota, answer, skipLogic, null, null, playList);
        }


        public JsonResult MySurveys()
        {

            try
            {
                Log.Info("My Survey Begins");
                var customer = SessionHelper.LoggedinCustomer;
                var jsonData = Mapper.Map<List<Survey>, List<SurveyViewModel>>(_surveyModule.GetMySurveys(customer));
                return ReturnJsonHelper.GetSuccessJson(jsonData, "surveys");
            }
            catch (Exception ex)
            {
                return ReturnJsonHelper.GetExceptionJson(ex);
            }
        }



    }


}
