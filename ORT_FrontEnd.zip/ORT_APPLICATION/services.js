var LOGIN_URL						= "";
var LOGOUT_URL						= "logout.html";

var GET_CITIES_URI					= "data/cities.json";
var GET_STATES_URI					= "data/states.json";
var GET_COUNTRIES_URI				= "data/countries.json";
var GET_ROLES_URI					= "data/roles.json";
var GET_LANGUAGES_URI				= "data/languages.json";
var GET_TIMEZONES_URI				= "data/timezones.json";
var GET_COMPANIES_URI				= "data/companies.json";
var GET_SESSIONCONTEXT_URI			= "data/sessionContext.json";

var GET_PANEL_LIBS_URI				= "data/panellib.json";
var ADD_PANEL_LIB_URI				= "data/addpanelLibrary.json?action=add";
var UPDATE_PANEL_LIB_URI			= "data/dummy_success.html?action=update";
var DELETE_PANEL_LIB_URI			= "data/dummy_success.html";

var GET_PANEL_CATEGORIES_URI		= "data/panelcat.json";
var ADD_PANEL_CATEGORIES_URI		= "data/dummy_success.html";
var UPDATE_PANEL_CATEGORIES_URI		= "data/dummy_success.html";
var DELETE_PANEL_CATEGORIES_URI		= "data/dummy_success.html";


var GET_MESSAGE_LIBS_URI			= "data/messagelib.json";
var ADD_MESSAGE_LIB_URI				= "data/dummy_success.html?action=add";
var UPDATE_MESSAGE_LIB_URI			= "data/dummy_success.html?action=update";
var DELETE_MESSAGE_LIB_URI			= "data/dummy_success.html";

var GET_MESSAGE_CATEGORIES_URI		= "data/categories.json";
var ADD_MESSAGE_CATEGORIES_URI		= "data/dummy_success.html?action=add";
var UPDATE_MESSAGE_CATEGORIES_URI	= "data/dummy_success.html?action=update";
var DELETE_MESSAGE_CATEGORIES_URI	= "data/dummy_success.html";

var GET_GRAPHICS_LIBS_URI			= "data/graphicslib.json";
var ADD_GRAPHICS_LIB_URI			= "data/dummy_success.html";
var UPDATE_GRAPHICS_LIB_URI			= "data/dummy_success.html";
var DELETE_GRAPHICS_LIB_URI			= "data/dummy_success.html";

var GET_GRAPHICS_CATEGORIES_URI		= "data/categories.json";
var ADD_GRAPHICS_CATEGORIES_URI		= "data/dummy_success.html";
var UPDATE_GRAPHICS_CATEGORIES_URI	= "data/dummy_success.html";
var DELETE_GRAPHICS_CATEGORIES_URI	= "data/dummy_success.html";

var GET_SURVEYS_URI					= "data/surveys.json";
var UPDATE_SURVEY_URI				= "data/updateUsers.json";

var GET_PANELSEARCH_URI				= "data/panels.json";
var GET_PANEL_URI					= "data/dummy_success.html";
var ADD_PANEL_URI					= "data/updateUser.json";
var UPDATE_PANEL_URI				= "data/dummy_success.html";
var DELETE_PANEL_URI				= "data/dummy_success.html";

var ADD_PANEL_MEMBER_URI			= "data/dummy_success.html";
var UPDATE_PANEL_MEMBER_URI			= "data/dummy_success.html";
var DELETE_PANEL_MEMBER_URI			= "data/dummy_success.html";

var GET_USERSEARCH_URI				= "data/users.json";
var GET_USER_URI					= "data/dummy_success.html";
var ADD_USER_URI					= "data/updateUser.json";
var UPDATE_USER_URI					= "data/dummy_success.html";
var DELETE_USER_URI					= "data/dummy_success.html";

var GET_COMPANYSEARCH_URI			= "data/searchedCompanies.json";
var GET_COMPANY_URI					= "data/dummy_success.html";
var ADD_COMPANY_URI					= "data/updateCompany.json";
var UPDATE_COMPANY_URI				= "data/dummy_success.html";
var DELETE_COMPANY_URI				= "data/dummy_success.html";

var GET_QUESTIONNAIRE_URI			= "data/questionnaire.json";
var GET_QUESTION_URI				= "data/dummy_success.html";
var ADD_QUESTION_URI				= "data/dummy_success.html";
var UPDATE_QUESTION_URI				= "data/dummy_success.html";
var DELETE_QUESTION_URI				= "data/dummy_success.html";

var GET_MESSAGESEARCH_URI			= "data/messages.json";
var GET_MESSAGE_URI					= "data/dummy_success.html";
var ADD_MESSAGE_URI					= "data/updateMessage.json";
var UPDATE_MESSAGE_URI				= "data/dummy_success.html";
var DELETE_MESSAGE_URI				= "data/dummy_success.html";

var GET_GRAPHICSSEARCH_URI			= "data/graphics.json";
var GET_GRAPHICS_URI				= "data/dummy_success.html";
var ADD_GRAPHICS_URI				= "data/dummy_success.html";
var UPDATE_GRAPHICS_URI				= "data/dummy_success.html";
var DELETE_GRAPHICS_URI				= "data/dummy_success.html";
var UPLOAD_GRAPHICS_URI				= "upload.php";
