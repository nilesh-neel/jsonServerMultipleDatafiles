var LOGIN_URL						= "";
var LOGOUT_URL						= "logout.html";
	
var GET_CITIES_URI					= "Master/GetMaster/?type=1";
var GET_STATES_URI					= "Master/GetMaster/?type=3";
var GET_COUNTRIES_URI				= "Master/GetMaster/?type=2";
var GET_ROLES_URI					= "Master/GetMaster/?type=5";
var GET_LANGUAGES_URI				= "Master/GetMaster/?type=4";
var GET_TIMEZONES_URI				= "Master/GetMaster/?type=6";
var GET_COMPANIES_URI				= "Master/GetCompany";
var GET_SESSIONCONTEXT_URI			= "Login/LoggedOnUserInfo";

var GET_PANEL_LIBS_URI				= "Panel/GetPanleLibrary";
var ADD_PANEL_LIB_URI				= "Panel/AddPanelibrary";
var UPDATE_PANEL_LIB_URI			= "data/dummy_success.html?action=update";
var DELETE_PANEL_LIB_URI			= "data/dummy_success.html";

var GET_PANEL_CATEGORIES_URI 		= "Panel/GetCategory";
var ADD_PANEL_CATEGORIES_URI 		= "Panel/AddPanelCatetory";
var UPDATE_PANEL_CATEGORIES_URI		= "data/dummy_success.html";
var DELETE_PANEL_CATEGORIES_URI		= "data/dummy_success.html";

var GET_MESSAGE_LIBS_URI			= "Library/GetLibraries?type=2";
var ADD_MESSAGE_LIB_URI				= "Library/AddLibrary?type=2";
var UPDATE_MESSAGE_LIB_URI			= "Library/UpdateLibraries?type=2";
var DELETE_MESSAGE_LIB_URI			= "Library/DeleteLibrary?type=2";

var GET_MESSAGE_CATEGORIES_URI		= "Library/GetLibraryCategories?type=2";
var ADD_MESSAGE_CATEGORIES_URI		= "Library/AddLibraryCategory?type=2";
var UPDATE_MESSAGE_CATEGORIES_URI	= "Library/UpdateLibraryCategories?type=2";
var DELETE_MESSAGE_CATEGORIES_URI	= "Library/DeleteLibraryCategory?type=2";
	
var GET_GRAPHICS_LIBS_URI			= "Library/GetLibraries?type=4";
var ADD_GRAPHICS_LIB_URI			= "Library/AddLibrary?type=4";
var UPDATE_GRAPHICS_LIB_URI			= "data/dummy_success.html";
var DELETE_GRAPHICS_LIB_URI			= "data/dummy_success.html";

var GET_GRAPHICS_CATEGORIES_URI		= "Library/GetLibraryCategories?type=4";
var ADD_GRAPHICS_CATEGORIES_URI		= "Library/AddLibraryCategory?type=4";
var UPDATE_GRAPHICS_CATEGORIES_URI	= "data/dummy_success.html";
var DELETE_GRAPHICS_CATEGORIES_URI	= "data/dummy_success.html";

var GET_SURVEYS_URI					= "Survey/MySurveys";
var UPDATE_SURVEY_URI				= "data/updateUsers.json";

var GET_PANELSEARCH_URI				= "Panel/SearchPanelList";
var GET_PANEL_URI					= "Panel/SearchPanelList";
var ADD_PANEL_URI					= "Panel/AddPanel";
var UPDATE_PANEL_URI				= "Panel/UpdatePanel";
var DELETE_PANEL_URI				= "Panel/DeletePanel";

var ADD_PANEL_MEMBER_URI			= "Panel/AddMember";
var UPDATE_PANEL_MEMBER_URI			= "Panel/UpdateMember";
var DELETE_PANEL_MEMBER_URI			= "Panel/DeleteMember";
	
var GET_USERSEARCH_URI				= "User/SearchUsers";
var GET_USER_URI					= "User/GetUsers";
var ADD_USER_URI					= "User/AddUser";
var UPDATE_USER_URI					= "User/UpdateUser";
var DELETE_USER_URI					= "User/DeleteUser";
	
var GET_COMPANYSEARCH_URI			= "Customer/SearchCustomer";
var GET_COMPANY_URI					= "data/dummy_success.html";
var ADD_COMPANY_URI					= "Customer/AddCustomer";
var UPDATE_COMPANY_URI				= "Customer/UpdateCustomer";
var DELETE_COMPANY_URI				= "Customer/DeleteCustomer";
	
var GET_QUESTIONNAIRE_URI			= "data/questionnaire.json";
var GET_QUESTION_URI				= "data/dummy_success.html";
var ADD_QUESTION_URI				= "data/dummy_success.html";
var UPDATE_QUESTION_URI				= "data/dummy_success.html";
var DELETE_QUESTION_URI				= "data/dummy_success.html";
	
var GET_MESSAGESEARCH_URI			= "Library/SearchLibrary";
var GET_MESSAGE_URI					= "data/dummy_success.html";
var ADD_MESSAGE_URI					= "Library/SaveLibraryDetails";
var UPDATE_MESSAGE_URI				= "Library/SaveLibraryDetails";
var DELETE_MESSAGE_URI				= "Library/DeleteLibraryDetails";
	
var GET_GRAPHICSSEARCH_URI			= "Library/SearchLibrary";
var GET_GRAPHICS_URI                = "Library/EditLibrary";
var ADD_GRAPHICS_URI				= "Library/SaveGraphicFile";
//var UPDATE_GRAPHICS_URI				= "data/dummy_success.html";
var DELETE_GRAPHICS_URI				= "data/dummy_success.html";
var UPLOAD_GRAPHICS_URI				= "Library/SaveGraphicFile?type=4";