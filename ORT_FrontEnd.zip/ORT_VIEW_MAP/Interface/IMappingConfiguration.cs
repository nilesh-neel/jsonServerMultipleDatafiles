﻿namespace ORT_VIEW_MAP.Interface
{
    public interface IMappingConfiguration
    {
        void Configure();
    }

}
