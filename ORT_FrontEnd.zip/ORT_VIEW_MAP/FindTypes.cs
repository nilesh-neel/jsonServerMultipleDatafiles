﻿using System.Reflection;

namespace ORT_VIEW_MAP
{
    public class FindTypes
    {
        public static AssemblyNavigator InAssembly(Assembly assembly)
        {
            return new AssemblyNavigator(assembly);
        }
    }
}
