﻿using ORT_CORE.Class.SurveyClasses;
namespace ORT_VIEW_MAP.MapClasses
{
   public class CustomerViewModel
    {
       public string id { get; set; }
       public string abbreviation { get; set; }
       public string name { get; set; }
       public string contactPerson { get; set; }
       public string address { get; set; }
       public string addressLine1 { get; set; }
       public string addressLine2 { get; set; }
       public string zipCode { get; set; }
       public string city { get; set; }
       public string state { get; set; }
       public string country { get; set; }
       public string phone1 { get; set; }
       public string phone2 { get; set; }
       public string email { get; set; }
       public string website { get; set; }
       public string status { get; set; }
       public User createdBy { get; set; }
       public string createdOn { get; set; }
       public User modifiedBy { get; set; }
       public string modifiedOn { get; set; }

    }
}
