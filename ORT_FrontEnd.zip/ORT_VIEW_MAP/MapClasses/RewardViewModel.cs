﻿namespace ORT_VIEW_MAP.MapClasses
{
   public class RewardViewModel
    {
        public string RewardId { get; set; }
        public string Customer { get; set; }
        public string Fees { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ApproxValue { get; set; }
        public string EndDate { get; set; } 
    }
}
