﻿namespace ORT_VIEW_MAP.MapClasses
{
  public class SkipLogicViewModel
    {
        public string LogicExpression { get; set; }
        public string TrueAction { get; set; }
        public string FalseAction { get; set; }
    }
}
