﻿using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using System.Collections.Generic;
using ORT_VIEW_MAP.MapClasses.Library;
namespace ORT_VIEW_MAP.MapClasses
{
    public class SurveyViewModel
    {
        public string surveyId { get; set; }
        public string title { get; set; }
        public bool done { get; set; }
        public int responses { get; set; }
        public int requiredSamples { get; set; }
        public string modifedOn { get; set; }
        public string createdOn { get; set; }
        public string status { get; set; }
        public string surveyEndDate { get; set; }

        public List<question> Questions { get; set; }
        //public QuotaViewModel Quota { get; set; }
        //public RewardViewModel Reward { get; set; }
        public List<SettingViewModel> Settings { get; set; }
    }
}
