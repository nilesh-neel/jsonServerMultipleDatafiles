﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ORT_VIEW_MAP.MapClasses
{
    public class UserViewModule
    {
        public string code { get; set; }
        public string name { get; set; }
        public string password { get; set; }
        public string loginId { get; set; }
        public string role { get; set; }
        public string radioStation{ get; set; }
        public bool status { get; set; }
        public string email { get; set; }


    }
}
