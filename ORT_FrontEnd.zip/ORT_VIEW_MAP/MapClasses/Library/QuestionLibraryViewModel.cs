﻿using System.Collections.Generic;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class QuestionLibraryViewModel
    {
        public string questionLibraryId { get; set; }
        public List<question> question { get; set; }
        public string questionLibraryName { get; set; }
        public string category { get; set; }
        public string library { get; set; }            

    }
}
