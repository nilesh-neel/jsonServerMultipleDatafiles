﻿namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class MyQuestionLibrary
    {
        public string QuestionLibraryId { get; set; }
        //public MyQuestion QuestionInLibrary { get; set; }
        public string QuestionLibraryName { get; set; }
        public string Category { get; set; }
    }
}
