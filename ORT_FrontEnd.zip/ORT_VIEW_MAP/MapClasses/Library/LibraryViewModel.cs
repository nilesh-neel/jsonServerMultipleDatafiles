﻿using ORT_CORE.Class.SurveyClasses;

namespace ORT_VIEW_MAP.MapClasses.Library
{
    public class LibraryViewModel
    {
        public string id { get; set; }
        public string type { get; set; }
        public string name { get; set; }
        public Customer Customer { get; set; }
    }
    
}
