﻿namespace ORT_VIEW_MAP.MapClasses.Library
{
    public class MessageLibraryViewModel
    {
        public string id { get; set; }
        public string mailType { get; set; }
        public string description { get; set; }
        public string name { get; set; }       
        //public string FilePath { get; set; }
        public string category { get; set; }
        public string library { get; set; }
    }
}
