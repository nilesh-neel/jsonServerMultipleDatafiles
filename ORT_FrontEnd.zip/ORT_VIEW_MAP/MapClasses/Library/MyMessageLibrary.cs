﻿using AutoMapper;
using ORT_CORE.Class.LibraryClasses;
using ORT_VIEW_MAP.Interface;
using ORT_VIEW_MAP.MapClasses;
using System.ComponentModel;

namespace ORT_VIEW_MAP.MapClasses
{
    public class MyMessageLibrary 
    {
        public enum MessageType
        {
            [Description("END OF SURVEY")]
            EndOfSurvey = 1,
            [Description("GENERAL")]
            General,
            [Description("INACTIVE SURVEY")]
            InactiveSurvey,
            [Description("INVITE")]
            Invite,
            [Description("REMINDER")]
            Reminder,
            [Description("THANK YOU")]
            ThankYou
        }

        public string MessageLibraryId { get; set; }
        public MessageType MailType { get; set; }
        public string MessageDescription { get; set; }
        public string MessageText { get; set; }
        public string Category { get; set; }
    }
}
