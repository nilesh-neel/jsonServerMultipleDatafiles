﻿using System.ComponentModel;

namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class FileLibraryViewModel :LibraryViewModel
    {
       public enum FileType
       {
           [Description("Mp3")]
           Mp3 = 1,
           [Description("Mp4")]
           Mp4,
           [Description("Wma")]
           Wma,
           [Description("Aac")]
           Aac
       }

       public string FileLibraryId { get; set; }
       public string FileLibraryName { get; set; }
       public string CategoryId { get; set; }
       public string CategoryName { get; set; }
       public string FileName { get; set; }
       public FileType Extension { get; set; }
       public SoundClipViewModel SoundClip { get; set; }

    }
}
