﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ORT_VIEW_MAP.MapClasses.Library.DetailsLibrary
{
    public class questionDetails
    {
        public string id { get; set; }
        public string no { get; set; }
        public string isPiped { get; set; }
        public string hidden { get; set; }
        public string hasMedia { get; set; }
        public string text { get; set; }
        public string type { get; set; }
        //public QuestionTypes questiontype { get; set; }
        // public List<answer> Answers { get; set; }
        // public answer defaultanswer { get; set; }
        public string mediaFileName { get; set; }
        public string mediaTrackTitle { get; set; }
    }
}
