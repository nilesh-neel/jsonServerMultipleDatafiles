﻿using ORT_VIEW_MAP.MapClasses.Library;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class MediaViewModel
    {
       public FileLibraryViewModel FileInfo { get; set; }
        public string Customer { get; set; }
        public string Randomize { get; set; }
        public string AutoAdvance { get; set; }
        public string ShowTitle { get; set; }
        public string AutoPlay { get; set; }
        public int HideForSeconds { get; set; }
    }
}
