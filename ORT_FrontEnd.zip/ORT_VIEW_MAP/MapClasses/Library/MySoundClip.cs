﻿namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class MySoundClip
    {
        public string Title { get; set; }
        public string Artist { get; set; }
        public string Year { get; set; }
        public string FilePath { get; set; }
    }
}
