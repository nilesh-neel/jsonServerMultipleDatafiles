﻿using System.ComponentModel;
using System;
namespace ORT_VIEW_MAP.MapClasses
{
    public class MyGraphicLibrary
    {
        public enum ImageType
        {
            [Description("Gif")]
            Gif = 1,
            [Description("Jpg")]
            Jpg,
            [Description("Png")]
            Png
        }

        public string GraphicLibraryId { get; set; }
        public string GraphicLibraryName { get; set; }
        public string Category { get; set; }
        public string GraphicFileName { get; set; }
        public ImageType Extension { get; set; }
        public DateTime UploadedOn { get; set; }
    }
}
