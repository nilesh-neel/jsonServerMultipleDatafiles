﻿namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class LibraryCategoryViewModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string library { get; set; }
    }
}
