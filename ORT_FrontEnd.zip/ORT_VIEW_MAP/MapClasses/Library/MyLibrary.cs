﻿using System.ComponentModel;
namespace ORT_VIEW_MAP.MapClasses
{
    public class MyLibrary 
    {
        public enum LibraryType
        {
            [Description("SurveyLibraryRepository")]
            Survey = 1,
            [Description("QuestionLibraryRepository")]
            Question,
            [Description("GraphicLibraryRepository")]
            Graphic,
            [Description("FileLibraryRepository")]
            File,
            [Description("MessageLibraryRepository")]
            Message
        }

        public string LibraryId { get; set; }
        public LibraryType LibType { get; set; }
        public string LibraryName { get; set; }
        //public Customer Customer { get; set; }
    }
}
