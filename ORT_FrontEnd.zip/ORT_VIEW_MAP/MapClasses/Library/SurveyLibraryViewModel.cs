﻿using System.Collections.Generic;
namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class SurveyLibraryViewModel:LibraryViewModel
    {
        public string surveyLibraryId { get; set; }
        public List<SurveyViewModel> surveyInLibrary { get; set; }
        public string surveyLibraryName { get; set; }
        public string category { get; set; }
        public string library { get; set; }      
    }
}
