﻿namespace ORT_VIEW_MAP.MapClasses.Library
{
   public class MySurveyLibrary
    {
        public string SurveyLibraryId { get; set; }
        public MySurvey SurveyInLibrary { get; set; }
        public string SurveyLibraryName { get; set; }
        public string Category { get; set; }
    }
}
