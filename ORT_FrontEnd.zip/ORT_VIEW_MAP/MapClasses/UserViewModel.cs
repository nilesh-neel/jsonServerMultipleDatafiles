﻿namespace ORT_VIEW_MAP.MapClasses
{
    public class UserViewModel
    {
        public string code { get; set; }
        public string name { get; set; }
        public string password { get; set; }
        public string loginId { get; set; }
        public string role { get; set; }
        public string company{ get; set; }
        public string status { get; set; }
        public string email { get; set; }
        public string phone1 { get; set; }
        public string phone2 { get; set; }
        //public string phone3 { get; set; }
        public string department{ get; set; }
        public string language{ get; set; }
        public string timezone { get; set; }
        public string id { get; set; }
        public string createdBy { get; set; }
        public string createdOn { get; set; }
        public string modifiedBy { get; set; }
        public string modifiedOn { get; set; }
    }
}
