﻿
namespace ORT_VIEW_MAP.MapClasses.Panel
{
   public class PanelRespondent
    {
        public string id { get; set; }
        public string panel { get; set; }
        public string code { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string emailId { get; set; }
        public string gender { get; set; }
        public string birthDate { get; set; }
        public string age { get; set; }
        public string town { get; set; }
        public string userDefindField1 { get; set; }
        public string userDefindField2 { get; set; }
        public string userDefindField3 { get; set; }
        public string userDefindField4 { get; set; }
        public string userDefindField5 { get; set; }
        public string createdBy { get; set; }
        public string modifiedBy { get; set; }
        public string isDeleted { get; set; }
        public string status { get; set; }
    }
}
