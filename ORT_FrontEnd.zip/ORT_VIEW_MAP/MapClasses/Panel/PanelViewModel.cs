﻿using System.Collections.Generic;
namespace ORT_VIEW_MAP.MapClasses.Panel
{
   public class PanelViewModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string category { get; set; }
        public List<PanelRespondent> members { get; set; }
        public string customer { get; set; }
        public string lastUsed { get; set; }
        public string status { get; set; }
        public string createdBy { get; set; }
        public string modifiedBy { get; set; }
        public string library { get; set; }
        public string type { get; set; } 
       
    }
}
