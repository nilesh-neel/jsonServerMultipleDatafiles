﻿namespace ORT_VIEW_MAP.MapClasses
{
    public class MySurvey
    {
        public string surveyId { get; set; }
        public string title { get; set; }
        public bool done { get; set; }
        public int responses { get; set; }
        public int requiredSamples { get; set; }
        public string modifedOn { get; set; }
        public string createdOn { get; set; }
        public string status { get; set; }

    }
}
