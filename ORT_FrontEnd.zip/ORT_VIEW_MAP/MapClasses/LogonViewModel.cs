﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ORT_VIEW_MAP.MapClasses
{
    public class LogonViewModel
    {
        [Required(ErrorMessage = "Please enter User ID.")]
        [DisplayName("User Name")]
        public string UserName { get; set; }

        public string Password { get; set; }

        public string HdnPassword { get; set; }
        public string ChalString { get; set; }

        public string HdnErrorMessage { get; set; }

        public string RelativePath { get; set; }
    }
}
