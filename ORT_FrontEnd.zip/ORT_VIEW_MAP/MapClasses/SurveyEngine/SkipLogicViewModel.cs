﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
  public class SkipLogicViewModel
    {
        public string LogicExpression { get; set; }
        public string TrueAction { get; set; }
        public string FalseAction { get; set; }
    }
}
