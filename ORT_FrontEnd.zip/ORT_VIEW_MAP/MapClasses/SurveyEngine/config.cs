﻿
namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class config
    {
       public string logo { get; set; }
       
       public string background { get; set; }

       public bool autoAdvance { get; set; }

       public bool allowBackButton { get; set; }
       
       public bool allowContinueLater { get; set; }

       public bool nextBackTextLink { get; set; }

       public bool annoymousAllowed { get; set; }

       public bool passwordProtected { get; set; }

       public bool repeatReponses { get; set; }

       public bool endMessageFromLibrary { get; set; }

       public string messageFromLibrary { get; set; }

       public string messageTextFromLibrary { get; set; }

       public bool redirection { get; set; }

       public string redirectionUrl { get; set; }

       public bool additionalEmail { get; set; }

       public string additionalEmailFromLibrary { get; set; }

       public string surveyTemplateName { get; set; }

       public string surveyWelcomePage { get; set; }

       public string surveyThankuPage { get; set; }

       public string surveyExpiredPage { get; set; }

       public string surveyRewardPage { get; set; }

       public string answerFont { get; set; }

       public string answerFontColor { get; set; }

       public string answerFontSize { get; set; }

       public string headerFont { get; set; }

       public string headerFontSize { get; set; }

       public string headerFontColor { get; set; }

       public string questionFont { get; set; }

       public string questionFontColor { get; set; }

       public string questionFontSize { get; set; }

       public bool byInvite { get; set; }

       public bool showDateTime { get; set; }

       public bool pipedInResponse { get; set; }

       public bool pippedOutResponse { get; set; }

       public bool validateResponses { get; set; }

       public bool checkQuotas { get; set; }

       public bool checkEndOfSurvey { get; set; }

       public bool rewardApplicable { get; set; }

       public string followUpMtbQuestion { get; set; }

       public string verificationQuestion { get; set; }

       public bool responseCodeValidation { get; set; }

       public bool verifySkipLogic { get; set; }
    }
}
