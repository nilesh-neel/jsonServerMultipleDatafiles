﻿using System.ComponentModel;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
    
   public class logic
    {
       public enum criteria
       {
           [Description("AND")]
           And=1,
           [Description("OR")]
           Or
       }
       public criteria criteriatype { get; set; }
       public predicate predicate { get; set; }
    }

    public class predicate
    {
        public string verb { get; set; }
        public object Object { get; set; }
    }
}
