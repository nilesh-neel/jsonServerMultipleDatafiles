﻿using System;


namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class QuotaViewModel
    {
        public string QuotaId { get; set; }
        public string QuotaLimit { get; set; }
    }
}
