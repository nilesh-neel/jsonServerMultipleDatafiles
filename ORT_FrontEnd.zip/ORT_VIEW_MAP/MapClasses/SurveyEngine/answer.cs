﻿namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
    public class answer
    {
        public string id { get; set; }
        public string key { get; set; }
        public string value { get; set; }
        public bool domainset { get; set; }
    }
}
