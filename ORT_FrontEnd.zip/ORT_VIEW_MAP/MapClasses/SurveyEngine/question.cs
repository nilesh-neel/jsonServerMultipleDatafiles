﻿using System;
using System.Collections.Generic;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
    public class question
    {
        
        public string id { get; set; }
        public string no { get; set; }
        public Boolean isPiped { get; set; }
        public Boolean hidden { get; set; }
        public Boolean hasMedia { get; set; }
        public string text { get; set; }
        public string type { get; set; }
        public List<answer> Answers { get; set; }
        public answer defaultanswer { get; set; }
        public surveyaction action { get; set; }
        public response capturedResponse { get; set; }
        public string mediaFileName { get; set; }
        public string mediaTrackTitle { get; set; }
        public string songId { get; set; }
        public publishedSkipLogic mediaSkipLogic { get; set; }
    }
}
