﻿using System;
namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
    public class SettingViewModel
    {
        public string SettingId { get; set; }
        public string SettingName { get; set; }
        public string DisplayText { get; set; }
        public string Customer { get; set; }
        public string Value { get; set; }
        public bool IsAassigned { get; set; }
    }
}
