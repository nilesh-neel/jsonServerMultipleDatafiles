﻿using System.Collections.Generic;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
  public class card
    {
      public List<question> questions { get; set; }
      public string pageNumber { get; set; }
      public card cardobj { get; set; }
    }
}
