﻿using System.Collections.Generic;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class PublishedSurvey
    {
       public string id { get; set; }
       public string name { get; set; }
       public string company { get; set; }
       public config config { get; set; }
       public card cardobj { get; set; }
       public string surveyEndDate { get; set; }
       public List<publishedSkipLogic> skipLogic { get; set; }
    }
}
