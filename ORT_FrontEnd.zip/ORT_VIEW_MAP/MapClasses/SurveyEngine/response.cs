﻿using System.Collections.Generic;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class response
    {
       public string surveyId { get; set; }
       public string respondentId { get; set; }
       public string questionId { get; set; }
       public List<answer> selectedAnwers { get; set; }
    }
}
