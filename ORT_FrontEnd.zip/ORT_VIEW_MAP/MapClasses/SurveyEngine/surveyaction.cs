﻿using System.Collections.Generic;

namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class surveyaction
    {
       public List<logic> Logic { get; set; }
    }
}
