﻿namespace ORT_VIEW_MAP.MapClasses.SurveyEngine
{
   public class publishedSkipLogic
    {
        public string trueAction { get; set; }
        public string falseAction { get; set; }
        public string checkQuestionId { get; set; }
        public string expectedAnswerId { get; set; }
        public string expectedAnswerText { get; set; }
        public string evalOperator { get; set; }
    }
}
