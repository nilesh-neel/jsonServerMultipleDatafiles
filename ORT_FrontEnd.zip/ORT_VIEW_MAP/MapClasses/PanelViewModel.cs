﻿namespace ORT_VIEW_MAP.MapClasses
{
   public class PanelViewModel
    {
        public string PanelId { get; set; }
        public string PanelName { get; set; }
        public string PanelCategory { get; set; }
        public string Members { get; set; }
        public string Customer { get; set; }
        public string LastUsed { get; set; }
        public string IsPanelActive { get; set; }
        public string RespondentId { get; set; }
        public string RespondentCode { get; set; }
        public string RespondentFirstName { get; set; }
        public string RespondentLastName { get; set; }
        public string RespondentEmailId { get; set; }
        public string RespondentGender { get; set; }
        public string BirthDate { get; set; }
        public string Town { get; set; }
        public string UserDefineColumn1 { get; set; }
        public string UserDefineColumn2 { get; set; }
        public string UserDefineColumn3 { get; set; }
        public string UserDefineColumn4 { get; set; }
        public string UserDefineColumn5 { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string IsRespondentDeleted { get; set; }
        public string IsRespondentActive { get; set; }
    }
}
