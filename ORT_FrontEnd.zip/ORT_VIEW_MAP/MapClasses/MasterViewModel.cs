﻿namespace ORT_VIEW_MAP.MapClasses
{
   public class MasterViewModel
    {
       public string id { get; set; }
       public string name { get; set; }
       public string description { get; set; }
    }
}
