﻿using System;
using AutoMapper;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using ORT_VIEW_MAP.Interface;

namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
   public class RewardMap: IMappingConfiguration
    {
       public void Configure()
       {
           Mapper.CreateMap<Reward, RewardViewModel>()
             .ForMember(m => m.RewardId, o => o.MapFrom(s => s.RewardId))
             .ForMember(m => m.Name, o => o.MapFrom(s => s.Name))
             .ForMember(m => m.Fees, o => o.MapFrom(s => s.Fees))
             .ForMember(m => m.Description, o => o.MapFrom(s => s.Description))
             .ForMember(m => m.ApproxValue, o => o.MapFrom(s => s.ApproxValue))
             .ForMember(m => m.EndDate, o => o.MapFrom(s => s.EndDate))
             .ForMember(m => m.Customer, o => o.MapFrom(s => s.Customer))
                ;

           Mapper.CreateMap<RewardViewModel, Reward>()
            .ForMember(m => m.RewardId, o => o.MapFrom(s => s.RewardId))
            .ForMember(m => m.Name, o => o.MapFrom(s => s.Name))
            .ForMember(m => m.Fees, o => o.MapFrom(s => s.Fees))
            .ForMember(m => m.Description, o => o.MapFrom(s => s.Description))
            .ForMember(m => m.ApproxValue, o => o.MapFrom(s => s.ApproxValue))
            .ForMember(m => m.EndDate, o => o.MapFrom(s =>Convert.ToDateTime(s.EndDate)))
            .ForMember(m => m.Customer, o => o.MapFrom(s => new Customer { CustomerId = s.Customer }))
               ;
       }
    }
}
