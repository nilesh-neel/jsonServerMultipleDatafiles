﻿using ORT_VIEW_MAP.Interface;
using AutoMapper;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using ORT_CORE.Class.SurveyClasses;
namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
    public class AnswerMap : IMappingConfiguration
    {

        #region IMappingConfiguration Members

        public void Configure()
        {
            Mapper.CreateMap<answer, Answer>()
               .ForMember(m => m.AnswerId, o => o.MapFrom(s => s.id))
               .ForMember(m => m.AnswerText, o => o.MapFrom(s => s.value))
               .ForMember(m => m.AnswerDesc, o => o.MapFrom(s => s.key))              
              ;


            Mapper.CreateMap<Answer, answer>()
              .ForMember(m => m.id, o => o.MapFrom(s => s.AnswerId))
               .ForMember(m => m.value, o => o.MapFrom(s => s.AnswerText))
               .ForMember(m => m.key, o => o.MapFrom(s => s.AnswerDesc))    
             ;
        }

        #endregion
    }
}
