﻿using AutoMapper;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.Interface;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
    public class ConfigMap : IMappingConfiguration
    {
        #region Implementation of IMappingConfiguration

        public void Configure()
        {
            Mapper.CreateMap<SurveyConfig, config>()
                .ForMember(m => m.logo, o => o.MapFrom(s => s.LogoFileName))
                .ForMember(m => m.background, o => o.MapFrom(s => s.BackgroundColor))
                .ForMember(m => m.allowBackButton, o => o.MapFrom(s => s.AllowBackButton))
                .ForMember(m => m.allowContinueLater, o => o.MapFrom(s => s.AllowContinueLater))
                .ForMember(m => m.nextBackTextLink, o => o.MapFrom(s => s.NextBackTextLink))
                .ForMember(m => m.annoymousAllowed, o => o.MapFrom(s => s.AnnoymousAllowed))
                .ForMember(m => m.passwordProtected, o => o.MapFrom(s => s.PasswordProtected))
                .ForMember(m => m.repeatReponses, o => o.MapFrom(s => s.RepeatReponses))
                .ForMember(m => m.endMessageFromLibrary, o => o.MapFrom(s => s.EndMessageFromLibrary))
                .ForMember(m => m.messageTextFromLibrary, o => o.MapFrom(s => s.MessageTextFromLibrary))
                .ForMember(m => m.redirection, o => o.MapFrom(s => s.Redirection))
                .ForMember(m => m.redirectionUrl, o => o.MapFrom(s => s.RedirectionUrl))
                .ForMember(m => m.additionalEmail, o => o.MapFrom(s => s.AdditionalEmail))
                .ForMember(m => m.additionalEmailFromLibrary, o => o.MapFrom(s => s.AdditionalEmailFromLibrary))
                .ForMember(m => m.surveyTemplateName, o => o.MapFrom(s => s.SurveyTemplateName))
                .ForMember(m => m.surveyWelcomePage, o => o.MapFrom(s => s.SurveyWelcomePage))
                .ForMember(m => m.surveyThankuPage, o => o.MapFrom(s => s.SurveyThankuPage))
                .ForMember(m => m.surveyExpiredPage, o => o.MapFrom(s => s.SurveyExpiredPage))
                .ForMember(m => m.surveyRewardPage, o => o.MapFrom(s => s.SurveyRewardPage))
                .ForMember(m => m.answerFont, o => o.MapFrom(s => s.AnswerFont))
                .ForMember(m => m.answerFontColor, o => o.MapFrom(s => s.AnswerFontColor))
                .ForMember(m => m.answerFontSize, o => o.MapFrom(s => s.AnswerFontSize))
                .ForMember(m => m.headerFont, o => o.MapFrom(s => s.HeaderFont))
                .ForMember(m => m.headerFontSize, o => o.MapFrom(s => s.HeaderFontSize))
                .ForMember(m => m.questionFont, o => o.MapFrom(s => s.QuestionFont))
                .ForMember(m => m.questionFontColor, o => o.MapFrom(s => s.QuestionFontColor))
                .ForMember(m => m.questionFontSize, o => o.MapFrom(s => s.QuestionFontSize))
                .ForMember(m => m.headerFontColor, o => o.MapFrom(s => s.HeaderFontColor))
                .ForMember(m => m.byInvite, o => o.MapFrom(s => s.ByInvite))
                .ForMember(m => m.showDateTime, o => o.MapFrom(s => s.ShowDateTime))
                .ForMember(m => m.pipedInResponse, o => o.MapFrom(s => s.PipedInResponse))
                .ForMember(m => m.pippedOutResponse, o => o.MapFrom(s => s.PippedOutResponse))
                .ForMember(m => m.validateResponses, o => o.MapFrom(s => s.ValidateResponses))
                .ForMember(m => m.checkQuotas, o => o.MapFrom(s => s.CheckQuotas))
                .ForMember(m => m.checkEndOfSurvey, o => o.MapFrom(s => s.CheckEndOfSurvey))
                .ForMember(m => m.rewardApplicable, o => o.MapFrom(s => s.RewardApplicable))
                .ForMember(m => m.followUpMtbQuestion, o => o.MapFrom(s => s.FollowUpMtbQuestion))
                .ForMember(m => m.verificationQuestion, o => o.MapFrom(s => s.VerificationQuestion))
                .ForMember(m => m.responseCodeValidation, o => o.MapFrom(s => s.ResponseCodeValidation))
                .ForMember(m => m.verifySkipLogic, o => o.MapFrom(s => s.VerifySkipLogic));

        }

        #endregion
    }
}
