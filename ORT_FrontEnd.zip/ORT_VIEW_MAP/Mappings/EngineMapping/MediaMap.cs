﻿using ORT_VIEW_MAP.Interface;
using AutoMapper;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using System;
namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
    public class MediaMap : IMappingConfiguration
    {
        public void Configure()
        {
          Mapper.CreateMap<Media, MediaViewModel>()
                   //.ForMember(m => m.FileInfo, o => o.MapFrom(s => s.FileInfo))
                   .ForMember(m => m.Customer, o => o.MapFrom(s => s.Customer.CustomerId))
                   .ForMember(m => m.Randomize, o => o.MapFrom(s => s.Randomize))
                   .ForMember(m => m.ShowTitle, o => o.MapFrom(s => s.ShowTitle))
                   .ForMember(m => m.AutoAdvance, o => o.MapFrom(s => s.AutoAdvance))
                   .ForMember(m => m.AutoPlay, o => o.MapFrom(s => s.AutoPlay))
                   .ForMember(m => m.HideForSeconds, o => o.MapFrom(s => s.HideForSeconds))
                   ;

          Mapper.CreateMap<MediaViewModel, Media>()
                 //.ForMember(m => m.FileInfo, o => o.MapFrom(s => s.FileInfo))
                 .ForMember(m => m.Customer, o => o.MapFrom(s => new Customer { CustomerId = s.Customer }))
                 .ForMember(m => m.Randomize, o => o.MapFrom(s =>Convert.ToBoolean(s.Randomize)))
                 .ForMember(m => m.ShowTitle, o => o.MapFrom(s => Convert.ToBoolean(s.ShowTitle)))
                 .ForMember(m => m.AutoAdvance, o => o.MapFrom(s =>Convert.ToBoolean(s.AutoAdvance)))
                 .ForMember(m => m.AutoPlay, o => o.MapFrom(s => Convert.ToBoolean(s.AutoPlay)))
                 .ForMember(m => m.HideForSeconds, o => o.MapFrom(s =>Convert.ToInt32(s.HideForSeconds)))
                 ;


        }
    }
}
