﻿using ORT_VIEW_MAP.Interface;
using AutoMapper;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
using ORT_CORE.Class.SurveyClasses;

namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
    public class QuestionMap : IMappingConfiguration
    {
        #region IMappingConfiguration Members

        public void Configure()
        {
            Mapper.CreateMap<question, Question>()
                .ForMember(m => m.QuestionId, o => o.MapFrom(s => s.id))
                .ForMember(m => m.QuestionText, o => o.MapFrom(s => s.text))
                .ForMember(m => m.QuestionType, o => o.MapFrom(s => s.type))
                .ForMember(m => m.CapturedResponses, o => o.MapFrom(s => s.capturedResponse))
                .ForMember(m => m.HasMedia, o => o.MapFrom(s => s.hasMedia))
                .ForMember(m => m.Answers, o => o.MapFrom(s => s.Answers))
                .ForMember(m=>m.MediaSkipLogic,o=>o.MapFrom(s=>s.mediaSkipLogic));


            Mapper.CreateMap<Question, question>()
                .ForMember(m => m.id, o => o.MapFrom(s => s.QuestionId))
                .ForMember(m => m.text, o => o.MapFrom(s => s.QuestionText))
                .ForMember(m => m.type, o => o.MapFrom(s => s.QuestionType))
                .ForMember(m => m.capturedResponse, o => o.MapFrom(s => s.CapturedResponses))
                .ForMember(m => m.hasMedia, o => o.MapFrom(s => s.HasMedia))
                .ForMember(m => m.Answers, o => o.MapFrom(s => s.Answers))
                .ForMember(m=>m.mediaSkipLogic,o=>o.MapFrom(s=>s.MediaSkipLogic));

        }

        #endregion
    }
}

