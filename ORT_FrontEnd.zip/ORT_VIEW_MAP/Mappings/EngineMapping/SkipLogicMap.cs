﻿using ORT_VIEW_MAP.Interface;
using AutoMapper;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
   public class SkipLogicMap: IMappingConfiguration
    {
       public void Configure()
       {
           Mapper.CreateMap<SkipLogic, SkipLogicViewModel>()
                   .ForMember(m => m.LogicExpression, o => o.MapFrom(s => s.LogicExpression))
                   .ForMember(m => m.FalseAction, o => o.MapFrom(s => s.FalseAction))
                   .ForMember(m => m.TrueAction, o => o.MapFrom(s => s.TrueAction))
                   ;

           Mapper.CreateMap<SkipLogicViewModel, SkipLogic>()
                   .ForMember(m => m.LogicExpression, o => o.MapFrom(s => s.LogicExpression))
                   .ForMember(m => m.FalseAction, o => o.MapFrom(s => s.FalseAction))
                   .ForMember(m => m.TrueAction, o => o.MapFrom(s => s.TrueAction))
                   ;

           Mapper.CreateMap<SkipLogic, publishedSkipLogic>()
                   .ForMember(m => m.falseAction, o => o.MapFrom(s => s.FalseAction))
                   .ForMember(m => m.trueAction, o => o.MapFrom(s => s.TrueAction))
                   .ForMember(m => m.checkQuestionId, o => o.MapFrom(s => s.CheckQuestionId))
                   .ForMember(m => m.expectedAnswerId, o => o.MapFrom(s => s.ExpectedAnswerId))
                   .ForMember(m => m.expectedAnswerText, o => o.MapFrom(s => s.ExpectedAnswerText))
                   .ForMember(m => m.evalOperator, o => o.MapFrom(s => s.EvalOperator))
                   ;

       }
    }
}
