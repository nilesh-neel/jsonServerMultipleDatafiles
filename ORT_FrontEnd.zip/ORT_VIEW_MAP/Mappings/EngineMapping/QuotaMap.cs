﻿using System;
using ORT_VIEW_MAP.Interface;
using AutoMapper;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;
namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
   public class QuotaMap: IMappingConfiguration
    {
        public void Configure()
        {
            Mapper.CreateMap<Quota, QuotaViewModel>()
                 .ForMember(m => m.QuotaId, o => o.MapFrom(s => s.QuotaId))
                .ForMember(m => m.QuotaLimit, o => o.MapFrom(s => s.QuotaLimit))
                ;

            Mapper.CreateMap<QuotaViewModel, Quota>()
                .ForMember(m => m.QuotaId, o => o.MapFrom(s => s.QuotaId))
               .ForMember(m => m.QuotaLimit, o => o.MapFrom(s => s.QuotaLimit))
               ;
        }
   
    }
}
