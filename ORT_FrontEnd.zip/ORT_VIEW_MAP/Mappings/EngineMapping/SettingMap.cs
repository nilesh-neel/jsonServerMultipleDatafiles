﻿using System;
using AutoMapper;
using ORT_VIEW_MAP.Interface;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.MapClasses;
using ORT_VIEW_MAP.MapClasses.SurveyEngine;

namespace ORT_VIEW_MAP.Mappings.EngineMapping
{
   public class SettingMap: IMappingConfiguration
    {
       public void Configure()
       {
           Mapper.CreateMap<Setting, SettingViewModel>()
           .ForMember(m => m.SettingId, o => o.MapFrom(s => s.SettingId))
           .ForMember(m => m.SettingName, o => o.MapFrom(s => s.SettingName))
           .ForMember(m => m.DisplayText, o => o.MapFrom(s => s.DisplayText))
           .ForMember(m => m.Customer, o => o.MapFrom(s => s.Customer))
           .ForMember(m => m.IsAassigned, o => o.MapFrom(s => s.IsAassigned))
           .ForMember(m => m.Value, o => o.MapFrom(s => s.Value))
           ;

           Mapper.CreateMap<SettingViewModel, Setting>()
           .ForMember(m => m.SettingId, o => o.MapFrom(s => s.SettingId))
           .ForMember(m => m.SettingName, o => o.MapFrom(s => s.SettingName))
           .ForMember(m => m.DisplayText, o => o.MapFrom(s => s.DisplayText))
           .ForMember(m => m.Customer, o => o.MapFrom(s => new Customer { CustomerId = s.Customer }))
           .ForMember(m => m.IsAassigned, o => o.MapFrom(s => Convert.ToBoolean(s.IsAassigned)))
           .ForMember(m => m.Value, o => o.MapFrom(s => s.Value))
           ;
       }
    }
}
