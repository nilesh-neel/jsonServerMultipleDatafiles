﻿using AutoMapper;
using ORT_CORE.Class.LibraryClasses;
using ORT_VIEW_MAP.Interface;
using ORT_VIEW_MAP.MapClasses.Library;

namespace ORT_VIEW_MAP.Mappings.LibraryMapping
{
    public class GraphicLibraryMap : IMappingConfiguration
    {
        public void Configure()
        {
            Mapper.CreateMap<GraphicLibrary, GraphicLibraryViewModel>()
                 .ForMember(m => m.library, o => o.MapFrom(s => s.LibraryId))
                .ForMember(m => m.id, o => o.MapFrom(s => s.GraphicLibraryId))
                .ForMember(m => m.name, o => o.MapFrom(s => s.GraphicFileName))
                .ForMember(m => m.type, o => o.MapFrom(s => s.FileType))
                .ForMember(m => m.url, o => o.MapFrom(s => s.RelativePath + "/" + s.GraphicFileName))
                .ForMember(m => m.NoOfFiles, o => o.MapFrom(s => s.NoOfFiles))
                 .ForMember(m => m.category, o => o.MapFrom(s => s.Category.CategoryId))


                ;



            Mapper.CreateMap<GraphicLibraryViewModel, GraphicLibrary>()
                .ForMember(m => m.LibraryId, o => o.MapFrom(s => s.library))
                 .ForMember(m => m.Category, o => o.MapFrom(s => new LibraryCategory
                 {
                     CategoryId = s.category,
                 }
                ))
                .ForMember(m => m.NoOfFiles, o => o.MapFrom(s => s.NoOfFiles))
                .ForMember(m => m.GraphicLibraryId, o => o.MapFrom(s => s.id))
                .ForMember(m => m.GraphicFileName, o => o.MapFrom(s => s.name))
                .ForMember(m => m.FileType, o => o.MapFrom(s => s.type ?? GraphicLibrary.ImageType.Gif.ToString()))
                .ForMember(m => m.RelativePath, o => o.MapFrom(s => s.url))
                ;


        }
    }
}
