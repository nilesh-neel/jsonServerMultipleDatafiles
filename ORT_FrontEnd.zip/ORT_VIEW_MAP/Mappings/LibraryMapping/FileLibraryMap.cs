﻿using AutoMapper;
using ORT_CORE.Class.LibraryClasses;
using ORT_VIEW_MAP.Interface;
using ORT_VIEW_MAP.MapClasses.Library;

namespace ORT_VIEW_MAP.Mappings.LibraryMapping
{
    public class FileLibraryMap :IMappingConfiguration
    {
        public void Configure()
        {
            Mapper.CreateMap<FileLibrary, FileLibraryViewModel>()
                .ForMember(m => m.FileLibraryId, o => o.MapFrom(s => s.FileLibraryId))
                .ForMember(m => m.FileLibraryName, o => o.MapFrom(s => s.FileLibraryName))
                .ForMember(m => m.FileName, o => o.MapFrom(s => s.FileName))
                .ForMember(m => m.Extension, o => o.MapFrom(s => s.Extension))
                .ForMember(m => m.CategoryId, o => o.MapFrom(s => s.Category.CategoryId))
                .ForMember(m => m.CategoryName, o => o.MapFrom(s => s.Category.CategoryName))
                .ForMember(m => m.SoundClip, o => o.MapFrom(s => s.SoundClip));

            Mapper.CreateMap<FileLibraryViewModel, FileLibrary>()
               .ForMember(m => m.FileLibraryId, o => o.MapFrom(s => s.FileLibraryId))
               .ForMember(m => m.FileLibraryName, o => o.MapFrom(s => s.FileLibraryName))
               .ForMember(m => m.FileName, o => o.MapFrom(s => s.FileName))
               .ForMember(m => m.Extension, o => o.MapFrom(s => s.Extension))
               .ForMember(m => m.Category, o => o.MapFrom(s => new LibraryCategory 
               { CategoryId = s.CategoryId,CategoryName=s.CategoryName }))
               .ForMember(m => m.SoundClip, o => o.MapFrom(s => s.SoundClip));
            ;
        }
    }
}
