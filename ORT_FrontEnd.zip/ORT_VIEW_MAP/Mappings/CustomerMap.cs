﻿using AutoMapper;
using ORT_CORE.Class.SurveyClasses;
using ORT_VIEW_MAP.Interface;
using ORT_VIEW_MAP.MapClasses;
using System;
namespace ORT_VIEW_MAP.Mappings
{
    public class CustomerMap : IMappingConfiguration
    {
        #region Implementation of IMappingConfiguration

        public void Configure()
        {
            Mapper.CreateMap<Customer, CustomerViewModel>()
                .ForMember(m => m.id, o => o.MapFrom(s => s.CustomerId))
                .ForMember(m => m.abbreviation, o => o.MapFrom(s => s.Abbreviation))
                .ForMember(m => m.addressLine1, o => o.MapFrom(s => s.Address1))
                .ForMember(m => m.addressLine2, o => o.MapFrom(s => s.Address2))
                .ForMember(m => m.city, o => o.MapFrom(s => s.CityCode))
                .ForMember(m => m.contactPerson, o => o.MapFrom(s => s.ContactPerson))
                .ForMember(m => m.country, o => o.MapFrom(s => s.CountryCode))
                .ForMember(m => m.email, o => o.MapFrom(s => s.Email))
                .ForMember(m => m.name, o => o.MapFrom(s => s.CustomerName))
                .ForMember(m => m.phone1, o => o.MapFrom(s => s.Phone1))
                .ForMember(m => m.phone2, o => o.MapFrom(s => s.Phone2))
                .ForMember(m => m.website, o => o.MapFrom(s => s.WebSite))
                .ForMember(m => m.zipCode, o => o.MapFrom(s => s.ZipCode))
                .ForMember(m => m.state, o => o.MapFrom(s => s.StateCode))
                .ForMember(m => m.status, o => o.MapFrom(s => s.IsActive))
                .ForMember(m => m.createdBy, o => o.MapFrom(s => s.CreatedBy))
                .ForMember(m => m.createdOn, o => o.MapFrom(s => s.CreatedOn))
                .ForMember(m => m.modifiedBy, o => o.MapFrom(s => s.ModifiedBy))
                .ForMember(m => m.modifiedOn, o => o.MapFrom(s => s.ModifiedOn));


            Mapper.CreateMap<CustomerViewModel, Customer>()
               .ForMember(m => m.CustomerId, o => o.MapFrom(s => s.id))
               .ForMember(m => m.Abbreviation, o => o.MapFrom(s => s.abbreviation))
               .ForMember(m => m.Address1, o => o.MapFrom(s => s.addressLine1))
               .ForMember(m => m.Address2, o => o.MapFrom(s => s.addressLine2))
               .ForMember(m => m.CityCode, o => o.MapFrom(s => s.city))
               .ForMember(m => m.ContactPerson, o => o.MapFrom(s => s.contactPerson))
               .ForMember(m => m.CountryCode, o => o.MapFrom(s => s.country))
               .ForMember(m => m.Email, o => o.MapFrom(s => s.email))
               .ForMember(m => m.CustomerName, o => o.MapFrom(s => s.name))
               .ForMember(m => m.Phone1, o => o.MapFrom(s => s.phone1))
               .ForMember(m => m.Phone2, o => o.MapFrom(s => s.phone2))
               .ForMember(m => m.WebSite, o => o.MapFrom(s => s.website))
               .ForMember(m => m.ZipCode, o => o.MapFrom(s => s.zipCode))
               .ForMember(m => m.StateCode, o => o.MapFrom(s => s.state))
               .ForMember(m => m.IsActive, o => o.MapFrom(s => Convert.ToBoolean(string.IsNullOrEmpty(s.status.Trim()) || Convert.ToBoolean(s.status))))
               .ForMember(m => m.CreatedBy, o => o.MapFrom(s => s.createdBy))
               .ForMember(m => m.CreatedOn, o => o.MapFrom(s => s.createdOn))
               .ForMember(m => m.ModifiedBy, o => o.MapFrom(s => s.modifiedBy))
               .ForMember(m => m.ModifiedOn, o => o.MapFrom(s => s.modifiedOn));




           Mapper.CreateMap<Customer, MasterViewModel>()
                .ForMember(m => m.id, o => o.MapFrom(s => s.CustomerId))
                .ForMember(m => m.name, o => o.MapFrom(s => s.CustomerName))
                .ForMember(m => m.description, o => o.MapFrom(s => s.WebSite));
            
        }

        #endregion
    }
}
