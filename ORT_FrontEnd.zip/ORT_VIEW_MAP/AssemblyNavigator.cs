﻿using System.Linq;
using System.Reflection;

namespace ORT_VIEW_MAP
{
    public class AssemblyNavigator
    {
        private readonly Assembly _assembly;

        public AssemblyNavigator(Assembly assembly)
        {
            _assembly = assembly;
        }

        public TypeList<T> Implementing<T>() where T : class
        {
            var listOfTypesImplementingInterface = from type in _assembly.GetTypes()
                                                   where typeof(T).IsAssignableFrom(type) && type.IsClass
                                                   select type;

            return new TypeList<T>(listOfTypesImplementingInterface);
        }
    }
}
