﻿using ORT_VIEW_MAP.Interface;
using ORT_VIEW_MAP.Mappings;

namespace ORT_VIEW_MAP
{
   public static class Configuration
    {
       public static void Run()
       {
           FindTypes.InAssembly(typeof(SurveyMap).Assembly)
                .Implementing<IMappingConfiguration>()
                .Execute(a => a.Configure());
       }
    }
}
