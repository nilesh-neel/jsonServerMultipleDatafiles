﻿using Heathrow.BPM.Business.Configuration;
using Heathrow.BPM.Business.SettingsModule;
using Heathrow.BPM.Core.Class.SettingsClasses;
using Heathrow.BPM.Core.Interface.SettingsInterface;
using Heathrow.BPM.Web.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Unity;
using Unity.Extension;
using Unity.Lifetime;
using Unity.Mvc5;
using Unity.RegistrationByConvention;

namespace Heathrow.BPM.Web.Configuration
{
    public class Bootstrap
    {

        public static void Initialise()
        {
            var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();

            //container.RegisterType<ICourseService, CourseService>();
            //container.RegisterType<IInstitutionService, InstitutionService>();

            //  container.LoadConfiguration();
            container.AddNewExtension<ChildDependencyExtension>();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

    }

}