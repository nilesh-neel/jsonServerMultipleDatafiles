/*datatables code*/
$(function(){
  $('table.display').dataTable({
     "pagingType": "full_numbers",
     "ordering": false,
     "info":     false,
     "bLengthChange": false,
     "searching": false,
     "oLanguage": {
         "oPaginate": {
             "sFirst": "First",
             "sNext": '<img class="Next" src="" />',
             "sPrevious": '<img class="Previous" src="" />',
             "sLast": "Last"
         }
     }
 });

  $('.hamburger').click(function(event) {
      $('#homeNavigationBar').toggleClass('active');
  });
  $('.filter').click(function(event) {
    $('#FiltersideNavBar').css('display','block');
});

$('#tabs a[href="#configureAlerts"]').click(function(event) {
  $('#congigureNewAlertBtn').css('display','block');
  $("#configureAlertsTable,.dataTables_paginate").css('display','block');
});

$('#tabs a[href="#alertSettings"],#tabs a[href="#todaysAlerts"]').click(function(event) {
    $('#congigureNewAlertBtn').css('display','none');
    $('#congigureNewAlertBtn').css('display','none');
});



  $(".configureEditIcon").click(function(){
    $("#configureAlertsTable,.dataTables_paginate").css('display','none');
    $('#congigureNewAlertBtn').css('display','none');
    $('#configureBackBtn').css('display','block');
    $('.configureAlertForm').css('display','block');
  });

  $('#configureBackBtn').click(function(event) {
    $('#configureBackBtn').css('display','none');
    $('.configureAlertForm').css('display','none');
    $("#configureAlertsTable,.dataTables_paginate").css('display','block');
});

});

$(document).ready(function(){
    $(".logout").click(function(){
        $("#exampleModalCenter").modal('show');
    });

      /**logout toggle***/
    $("#dropDownIcon").click(function(event){
      event.stopPropagation();
    $(".settingsLogout").toggle();
    });

    $(document).click( function(){
    
    $(".settingsLogout").hide();
    });

    /*$(".defaultIcons").parent().click(function(){
    
    //$("#defaultIcon").hide();
    console.log($(this).children().trigger('mouseover'));

     $(this).children().trigger('hover');

    });*/

     $(".defaultIcons").parent().hover(function(){
        console.log( $(this).children());
        $(this).children().hover();
        /*}, function(){
        $(this).css("background-color", "pink");*/
    });
    /**logout toggle ends***/

});
// Example starter JavaScript for disabling form submissions if there are invalid fields
/***Date Range Picker***/

$(function() {
   
    $('input[name="daterange"]').daterangepicker(
{
    locale: {
      format: 'YYYY-MM-DD'
    },
    startDate: '2013-02-01',
    endDate: '2013-03-31'
});
});
/*** Date Range Picker End ***/



/*** Form validation***/
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();


/****Form Validation End ***/


/* Range slider */

$(function() {

  // function to create slider ticks
  var setSliderTicks = function() {
    // slider element
    var $slider = $('.slider');
    var max = $slider.slider("option", "max");
    var min = $slider.slider("option", "min");
    var step = $slider.slider("option", "step");
    var spacing = 100 / (max - min);
    // tick element
    var ticks = $slider.find('div.ticks');

    // remove all ticks if they exist
    $slider.find('.ui-slider-tick-mark-main').remove();
    $slider.find('.ui-slider-tick-mark-text').remove();
    $slider.find('.ui-slider-tick-mark-side').remove();

    // generate ticks          
    for (var i = min; i <= max; i = i + step) {

      // main ticks (whole number)
      if (i % 1 === 0) {
        $('<span class="ui-slider-tick-mark-main"></span>').css('left', (spacing * i) + '%').appendTo(ticks);
        $('<span class="ui-slider-tick-mark-text">' + i + '</span>').css('left', (spacing * i) + '%').appendTo(ticks);
      }
      // side ticks
      else {
        $('<span class="ui-slider-tick-mark-side"></span>').css('left', (spacing * i) + '%').appendTo(ticks);
      }
    }
  };

  // create slider  
  $('#slider').slider({
    // set min and maximum values
    // day hours in this example
    min: 0,
    max: 24,
    // step
    // quarter of an hour in this example
    step: 6,
    // range
    range: false,
    // show tooltips
    tooltips: true,
    // current data
    handles: [{
      value: 7,
      type: "wake"
    },  {
      value: 22,
      type: "sleep"
    }],
    // display type names
    showTypeNames: true,
    typeNames: {
      'wake': 'Wake Up',
      'sleep': 'Sleep'
    },
    // main css class (of unset data)
    mainClass: 'sleep',
    // slide callback
    slide: function(e, ui) {
      console.log(e, ui);
    },
    // handle clicked callback
    handleActivated: function(event, handle) {
      // get select element
      var select = $(this).parent().find('.slider-controller select');
      // set selected option
      select.val(handle.type);
    }

  });

  // // button for adding new ranges                        
  // $('.slider-controller button.add').click(function(e) {
  //     e.preventDefault();
  //     // get slider
  //     var $slider = $('#slider');
  //     // trigger addHandle event
  //     $slider.slider('addHandle', {
  //       value: 12,
  //       type: $('.slider-controller select').val()
  //     });
  //     return false;
  //   });

  // button for removing currently selected handle
  // $('.slider-controller button.remove').click(function(e) {
  //     e.preventDefault();
  //     // get slider
  //     var $slider = $('#slider');
  //     // trigger removeHandle event on active handle
  //     $slider.slider('removeHandle', $slider.find('a.ui-state-active').attr('data-id'));

  //     return false;
  //   });

  // when clicking on handler
  $(document).on('click', '.slider a', function() {
    var select = $('.slider-controller select');
    // enable if disabled
    //select.attr('disabled', false);
    alert($(this).attr('data-type'));
    select.val($(this).attr('data-type'));
    /*if ($(this).parent().find('a.ui-state-active').length)
      $(this).toggleClass('ui-state-active');*/
  });
});

/*range slider end*/







