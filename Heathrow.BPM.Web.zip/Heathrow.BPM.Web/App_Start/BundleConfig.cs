﻿using System.Web;
using System.Web.Optimization;

namespace Heathrow.BPM.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/vendor").Include(
                 "~/Scripts/jquery-{version}.js",
                         "~/Scripts/jquery-ui.min.js",


                 "~/Scripts/jquery.validate.unobtrusive.min",
                        "~/Scripts/validator.js",


                "~/Scripts/bootstrap.min.js",
                       "~/Scripts/jquery.dataTables.min.js",
                       "~/Scripts/moment.min.js",
                        "~/Scripts/daterangepicker.js",
                         "~/Scripts/slider.js",
                         "~/Scripts/script.js"
                         ));

            bundles.Add(new ScriptBundle("~/bundles/appJS").IncludeDirectory(
                   "~/Scripts/App/", "*.js", true));

            //bundles.Add(new StyleBundle("~/bundles/CSS").Include(
            //          "~/CSS/jquery-ui.min.css",
            //          "~/CSS/bootstrap.min.css",
            //          "~/CSS/jquery.dataTables.min.css",
            //          "~/CSS/daterangepicker.css",
            //          "~/CSS/style.css"));

            bundles.Add(new StyleBundle("~/bundles/Content").IncludeDirectory(
                     "~/Content/", "*.css", true));
            // BundleTable.EnableOptimizations = true;
#if DEBUG
            BundleTable.EnableOptimizations = false;
#else
            BundleTable.EnableOptimizations = true;
#endif

        }
    }
}
