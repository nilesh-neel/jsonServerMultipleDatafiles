﻿using Heathrow.BPM.Business.SettingsModule;
using Heathrow.BPM.Core.Interface.SettingsInterface;
using Heathrow.BPM.Web.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{

    [CompressFilter]
    public class SettingsController : Controller
    {

        private static AlertsModule _alertModule;
        private static NotificationModule _notifyModule;

        public SettingsController(IAlerts alerts, INotification notify)
        {
            _alertModule = new AlertsModule(alerts);
            _notifyModule = new NotificationModule(notify);
        }
        // GET: Settinges
        public ActionResult Index()
        {
            var data = _alertModule.GetData();
            return View();
        }

        // GET: Settinges/Details/5
        public ActionResult TodaysAlert()
        {
            return PartialView("_TodaysAlert");
        }

        // GET: Settinges/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Settinges/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Settinges/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Settinges/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Settinges/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Settinges/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
