﻿using Heathrow.BPM.Core.Interface.SettingsInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business.SettingsModule
{
    public class NotificationModule
    {
        private static INotification _notifyRepository;


        public NotificationModule(INotification notification)
        {
            _notifyRepository = notification;
        }
    }
}
