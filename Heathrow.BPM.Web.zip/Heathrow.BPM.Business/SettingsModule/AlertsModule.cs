﻿using Heathrow.BPM.Core.Class.SettingsClasses;
using Heathrow.BPM.Core.Interface.SettingsInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business.SettingsModule
{
    public class AlertsModule
    {
        private static IAlerts _alertsRepository;

        public AlertsModule(IAlerts alert)
        {
            _alertsRepository = alert;
        }

        public IEnumerable<Alerts> GetData()
        {
            return _alertsRepository.GetAll();
        }
    }
}
