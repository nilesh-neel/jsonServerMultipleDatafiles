﻿using Heathrow.BPM.Core.Interface.SettingsInterface;
using Heathrow.BPM.DataAccess.SettingsRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity.Extension;
using Unity;

namespace Heathrow.BPM.Business.Configuration
{
    public class ChildDependencyExtension : UnityContainerExtension
    {
        protected override void Initialize()
        {
            Container.RegisterType<IAlerts, AlertsRepository>();
            Container.RegisterType<INotification, NotificationRepository>();
        }
    }
}
