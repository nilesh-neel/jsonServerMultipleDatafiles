﻿using Heathrow.BPM.Core.Class.SettingsClasses;
using Heathrow.BPM.Core.Interface.SettingsInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.DataAccess.SettingsRepository
{
    public class AlertsRepository : IAlerts
    {
        public AlertsRepository() { }
        public Alerts GetAlertsById(string _alertId)
        {
            return new Alerts { AlterId = "ALT_01", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" };
        }

        public IEnumerable<Alerts> GetAll()
        {
            return new List<Alerts> {
                new Alerts { AlterId = "ALT_01", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" },
                new Alerts { AlterId = "ALT_02", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" },
                new Alerts { AlterId = "ALT_03", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" },
                new Alerts { AlterId = "ALT_04", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" },
                new Alerts { AlterId = "ALT_05", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" },
                new Alerts { AlterId = "ALT_06", Title = "Lorem ipsum", Topic = "perspiciates unde", Location = "All" }
            };
        }
    }
}
