﻿using Heathrow.BPM.Core.Interface.SettingsInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.DataAccess.SettingsRepository
{
    public class NotificationRepository : INotification
    {
        public NotificationRepository() { }
    }
}
