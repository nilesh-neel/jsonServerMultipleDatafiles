﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Class.SettingsClasses
{
    public class Alerts
    {
        public string AlterId { get; set; }
        public string Title { get; set; }
        public string Topic { get; set; }

        public string Location { get; set; }
    }
}
