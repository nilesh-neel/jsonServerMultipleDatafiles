﻿/****************************************************************************************************************
Class Name   : AppSettingsConstants.cs 
Purpose      : Used to define appSettings KEYS of web.config
Created By   : Ravi Kant Shivhare 
Created Date : 26/Sep/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"
using System.Diagnostics.CodeAnalysis;
#endregion

namespace RGICL.MC.Common.Constants
{
    public static class AppSettingsConstants
    {
        #region Public Variables

        #region Supress Example
        //[SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Staffware", Justification = "FxCop doesn't know that Staffware is a software name")]
        //public const string StaffwareQueryClosureProcedureName = "SW_QC_ProcName";
        #endregion

        #region Connection String
        //public static string RGICL_MC_ConnectionString = "RGICL_MC_ConnectionString";
        #endregion

        #region Audit Vulnerabilities
        public const string SqlCharacters = "SqlCharacters",
                            SqlInjectionEnabled = "SqlInjectionEnabled",
                            SkipParameters = "SkipParameters",
                            SkipPagesSqlInjection = "SkipPagesSqlInjection",

                            URLEncryptionEnabled = "URLEncryptionEnabled",
                            SkipPagesURLEncryption = "SkipPagesURLEncryption",
                            AnchorHRefEncryptionEnabled = "AnchorHRefEncryptionEnabled",
                            SkipPagesAnchorHRefEncryption = "SkipPagesAnchorHRefEncryption",

                            EnableCSRFProtection = "EnableCSRFProtection",
                            SkipCSRFProtection = "SkipCSRFProtection",
                            CSRFAttackRedirectPage = "CSRFAttackRedirectPage",

                            FileTypeGenericHandlersEnabled = "FileTypeGenericHandlersEnabled",
                            SkipExtensionsFileTypeGenericHandlers = "SkipExtensionsFileTypeGenericHandlers",

                            LFIDownloadInvalidExtensions = "LFIDownloadInvalidExtensions",
                            DORInvalidExtensions = "DORInvalidExtensions",

                            AuthorizationEnabled = "AuthorizationEnabled",
                            SkipPagesAuthorization = "SkipPagesAuthorization",
                            CustomAuthorizationEnabled = "CustomAuthorizationEnabled";
        #endregion

        #region Error/StackTrace
        public const string StackTraceLogEnabled = "StackTraceLogEnabled",
                            ErrorLogType = "ErrorLogType",
                            ErrorLogEnabled = "ErrorLogEnabled";
        #endregion

        #region EmailSMS
        public const string SMTP = "SMTP",
                            SMTPAuthenticate = "SMTPAuthenticate",
                            EnableSsl = "EnableSsl",
                            MailFromEmailID = "MailFromEmailID",
                            MailUserName = "MailUserName",
                            MailPassword = "MailPassword",
                            //IncomingMailServerType = "IncomingMailServerType",
                            //IncomingMailServer = "IncomingMailServer",
                            //IncomingMailServerPort = "IncomingMailServerPort",
                            OutgoingMailServerPort = "OutgoingMailServerPort",
                            MailAttachmentMaxSize = "MailAttachmentMaxSize",
                            MailAttachmentMaxSizeMessage = "MailAttachmentMaxSizeMessage",
                            EmailSchedulerEnabled = "EmailSchedulerEnabled",
                            SMSSchedulerEnabled = "SMSSchedulerEnabled";

        public const string SMSUserName = "SMSUserName",
                            SMSPassword = "SMSPassword";
        #endregion

        public const string ADSDomain = "ADSDomain";
        public const string RightClickEnabled = "RightClickEnabled";
        public const string CAPTCHAVALUE = "CaptchaValue";

        #region Path KEYS
        public const string UploadFolderPath = "UploadFolderPath",
                            LogsFolderPath = "LogsFolderPath",
                            XMLFolderPath = "XMLFolderPath",
                            XMLConfigFileName = "XMLConfigFileName",
                            EmailAttachmentFolderPath = "EmailAttachmentFolderPath",
                            UploadChequeFolderPath = "UploadChequeFolderPath";

        #endregion

        public const string ECSUrl = "ECSURL";
        public const string UserPicsFolderPath = "UserPicsFolderPath";//"../UserPics/";
        #endregion
    }
}
