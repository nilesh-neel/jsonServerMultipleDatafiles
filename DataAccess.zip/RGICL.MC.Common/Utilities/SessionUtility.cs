﻿/****************************************************************************************************************
Class Name   : SessionUtility.cs 
Purpose      : Used to define utility functions for Sessions. 
Created By   : Ravi Kant Shivhare
Created Date : 26/Sep/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Web;
using System.Web.SessionState;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class SessionUtility
    {
        #region Private Member Variables
        
        #endregion

        #region Public Functions

        #region Get & Set Functions
        #region "Get & Set Functions For Generic Type Value"
        /// <summary>
        /// Used to get the value of session irrespective of return type.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int, DataSet etc.</typeparam>
        /// <param name="strKey">Session Key</param>
        /// <returns>Generic Value; it can either be string, int, DataSet etc.</returns>
        public static T Get<T>(string strKey)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session[strKey] == null)
            {
                if (typeof(T) == typeof(String))
                    return (T)(object)String.Empty;
                return default(T);
            }
            else
                return (T)(HttpContext.Current != null ? HttpContext.Current.Session[strKey] : string.Empty);
        }
        
        /// <summary>
        /// Used to set the value of session irrespective of the type of value.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int, DataSet etc.</typeparam>
        /// <param name="strKey">Session Key</param>
        /// <param name="value">Generic Value; it can either be string, int, DataSet etc.</param>
        public static void Set<T>(string strKey, T value)
        {
            if(value != null) //null values not allowed as it makes no sense to assign null value; instead use Remove function.
                HttpContext.Current.Session[strKey] = value;
        }
        #endregion

        #region "Temporarily changed the access type to private, will convert it to public later"
        #region "Get & Set Functions Specific For String Type Value"
        /// <summary>
        /// Used to get the value of session of return type String.
        /// </summary>
        /// <param name="strKey">Session Key</param>
        /// <returns>String Type Value</returns>
        private static string GetString(string strKey)
        {
            string strValue = Get<string>(strKey);
            return strValue == null ? string.Empty : strValue;
        }

        /// <summary>
        /// Used to get the value of session of return type String
        /// and if the return value is "" then specified default value will be returned.
        /// </summary>
        /// <param name="strKey">Session Key</param>
        /// <param name="strDefaultValue">default value to return if the session value is "".</param>
        /// <returns></returns>
        private static string GetString(string strKey, string strDefaultValue)
        {
            string strValue = Get<string>(strKey);
            return String.IsNullOrEmpty(strValue) ? (strDefaultValue == null ? string.Empty : strDefaultValue) : strValue;
        }

        /// <summary>
        /// Used to set the value of session of type String.
        /// </summary>
        /// <param name="strKey">Session Key</param>
        /// <param name="strValue">String Type Value</param>
        private static void SetString(string strKey, string strValue)
        {
            Set<string>(strKey, strValue);
        }
        #endregion

        #region "Get & Set Functions Specific For Int Type Value"
        /// <summary>
        /// Used to get the value of session of return type Int.
        /// </summary>
        /// <param name="strKey">Session Key</param>
        /// <returns>Int Type Value</returns>
        private static int GetInt(string strKey)
        {
            return Get<int>(strKey);
        }

        /// <summary>
        /// Used to get the value of session of return type Int 
        /// and if the return value is 0 then specified default value will be returned.
        /// </summary>
        /// <param name="strKey">Session Key</param>
        /// <param name="intDefaultValue">default value to return if the session value is 0</param>
        /// <returns>Int Type Value</returns>
        private static int GetInt(string strKey, int intDefaultValue)
        {
            int intValue = Get<int>(strKey);
            return intValue == 0 ? intDefaultValue : intValue;
        }

        /// <summary>
        /// Used to set the value of session of type Int.
        /// </summary>
        /// <param name="strKey">Session Key</param>
        /// <param name="intValue">Int Type Value</param>
        private static void SetInt(string strKey, int intValue)
        {
            Set<int>(strKey, intValue);
        }
        #endregion

        #endregion
        #endregion

        #region Other Utility Function
        /// <summary>
        /// Used to check whether session key exist or not.
        /// </summary>
        /// <param name="strSessionKey">Session Key</param>
        /// <returns>boolean value</returns>
        public static bool IsKeyExist(string strSessionKey)
        {
            return HttpContext.Current.Session[strSessionKey] != null;
        }

        #region Wrapper Functions - Wrapped Common Functions from HttpContext.Current.Session Class
        public static void RemoveItem(string strSessionKey)
        {
            HttpContext.Current.Session.Remove(strSessionKey);
        }
        public static void RemoveAllItems()
        {
            HttpContext.Current.Session.RemoveAll();
        }
        public static void Clear()
        {
            HttpContext.Current.Session.Clear();
        }
        public static void Abandon()
        {
            HttpContext.Current.Session.Abandon();
        }
        #endregion
        #endregion

        #endregion
    }
}
