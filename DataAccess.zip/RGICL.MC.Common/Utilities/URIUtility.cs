﻿/****************************************************************************************************************
Class Name   : URIUtility.cs 
Purpose      : Used to define utility functions for URL.
Created By   : Ravi Kant Shivhare
Created Date : 10/Dec/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Web;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class URIUtility
    {
        public static string GetPageName()
        {
            return HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.ToUpper();
        }

        public static string GetPageName(string strURL)
        {
            int intEndIndex = strURL.IndexOf('?');
            if (intEndIndex == -1)
            {
                intEndIndex = strURL.Length;
            }
            int intStartIndex = strURL.Substring(0, intEndIndex).LastIndexOf('/') + 1;
            return strURL.Substring(intStartIndex, (intEndIndex - intStartIndex));
        }

        public static string GetURLWithoutQS()
        {
            return HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Path);
        }
        public static string GetURLWithoutQS(string strURL)
        {
            if (strURL.Contains("?"))
                return strURL.Substring(0, strURL.IndexOf("?"));
            return strURL;
        }
        public static string GetQS(string strURL)
        {
            return strURL.Substring(strURL.IndexOf("?") + 1);
        }
    }
}
