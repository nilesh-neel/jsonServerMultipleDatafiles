﻿/****************************************************************************************************************
Class Name   : LogUtility.cs 
Purpose      : Used to define common utility functions for Controls, etc.
Created By   : Ravi Kant Shivhare
Created Date : 10/Dec/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using RGICL.MC.Common.Constants;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class CommonUtility
    {
        public static string LoggedInUserName
        {
            get { return HttpContext.Current != null ? HttpContext.Current.User.Identity.Name : string.Empty; }//Thread.CurrentPrincipal.Identity.Name
        }
        public static string LoggedInUserID
        {
            get
            {
                try
                {
                    return SessionUtility.Get<string>(SessionConstants.LoggedInUserID) ?? string.Empty;
                }
                catch
                {
                    return string.Empty;
                }
            }
        }

        #region "Common Function for Controls"
        public static void DisableControls(Control ctrl, bool bIsDisable = true)
        {
            if (ctrl.HasControls())
            {
                foreach (Control c in ctrl.Controls)
                {
                    DisableControls(c, bIsDisable);
                }
            }
            else
            {
                //if (ctrl is IPostBackDataHandler && !(ctrl is IPostBackEventHandler))
                {
                    if (ctrl is WebControl)
                        ((WebControl)ctrl).Enabled = bIsDisable;
                    else if (ctrl is HtmlControl)
                        ((HtmlControl)ctrl).Disabled = !bIsDisable;
                }
            }
        }
        public static void DisableControls(Control ctrl, bool bIsDisable = true, params Control[] paramSkipControls)
        {
            if (ctrl.HasControls())
            {
                foreach (Control c in ctrl.Controls)
                {
                    DisableControls(c, bIsDisable);
                }
            }
            else
            {
                //if (ctrl is IPostBackDataHandler && !(ctrl is IPostBackEventHandler))
                {
                    Boolean bSkipControl = false;
                    if (paramSkipControls != null)
                    {
                        foreach (Control ctrlSkipControl in paramSkipControls)
                        {
                            if (ctrlSkipControl.GetType() == ctrl.GetType() && ctrlSkipControl.ID == ctrl.ID)
                                bSkipControl = true;
                        }
                    }

                    if (bSkipControl)
                        return;

                    if (ctrl is WebControl)
                        ((WebControl)ctrl).Enabled = bIsDisable;
                    else if (ctrl is HtmlControl)
                        ((HtmlControl)ctrl).Disabled = !bIsDisable;
                }
            }
        }
        public static void ResetControls(Control ctrl, params Control[] paramSkipControls)
        {
            if (ctrl.HasControls())
            {
                foreach (Control c in ctrl.Controls)
                {
                    ResetControls(c, null);
                }
            }
            else
            {
                //if (ctrl is IPostBackDataHandler && !(ctrl is IPostBackEventHandler))
                {
                    Boolean bSkipControl = false;
                    if (paramSkipControls != null)
                    {
                        foreach (Control ctrlSkipControl in paramSkipControls)
                        {
                            if (ctrlSkipControl.GetType() == ctrl.GetType() && ctrlSkipControl.ID == ctrl.ID)
                                bSkipControl = true;
                        }
                    }

                    if (bSkipControl)
                        return;

                    switch (ctrl.GetType().ToString())
                    {
                        case "System.Web.UI.WebControls.TextBox":
                            ((TextBox)ctrl).Text = string.Empty;
                            break;
                        case "System.Web.UI.WebControls.CheckBox":
                            ((CheckBox)ctrl).Checked = false;
                            break;
                        case "System.Web.UI.WebControls.RadioButton":
                            ((RadioButton)ctrl).Checked = false;
                            break;
                        case "System.Web.UI.WebControls.DropDownList":
                            ((DropDownList)ctrl).SelectedIndex = -1;
                            break;
                    }
                }
            }

        }
        public static Boolean IsAllTextBoxBlank(Control ctrl)
        {
            Boolean bIsAllTextBoxBlank = true;
            if (ctrl.HasControls())
            {
                foreach (Control c in ctrl.Controls)
                {
                    if (!IsAllTextBoxBlank(c))
                    {
                        bIsAllTextBoxBlank = false;
                        break;
                    }
                }
            }
            else
            {
                if (ctrl.GetType().ToString() == "System.Web.UI.WebControls.TextBox")
                {
                    if (!string.IsNullOrWhiteSpace(((TextBox)ctrl).Text))
                    {
                        bIsAllTextBoxBlank = false;
                    }
                }
            }
            return bIsAllTextBoxBlank;
        }
        #endregion

        public static bool IsSkipPages(string strCSVSkipPages)
        {
            if (HttpContext.Current == null)
                return false;

            //string strPageName = URIUtility.GetPageName(HttpContext.Current.Request.Url.ToString());
            string strRelativePath = HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.ToLower();
            strRelativePath = strRelativePath.Replace(@"~/", "");
            bool bIsSkipPage = false;
            if (strCSVSkipPages.Trim() != "")
            {
                string[] arrsSkipPages = strCSVSkipPages.Split(new char[] { ',' });
                foreach (string strSkipPageName in arrsSkipPages)
                {
                    if (strSkipPageName.ToLower().Trim() == strRelativePath.ToLower().Trim())
                    {
                        bIsSkipPage = true;
                        break;
                    }
                }
            }
            return bIsSkipPage;
        }

        #region "Extension Methods"
        public static List<string> ToListFromCSV<T>(this string sCSV) 
        {
            if(!string.IsNullOrWhiteSpace(sCSV)) 
                return sCSV.Split(',').ToList<string>();
            return null;
        }

        //Start : Functions added by Ravi Kant Shivhare to 'Convert DataTable to Entity and Entity to DataTable' on 22/Jan/2014
        #region "Convert DataTable to Entity and Entity to DataTable"
        public static List<T> ToEntityList<T>(this DataTable dtSource) where T : new()
        {
            List<T> lstEntity = new List<T>();

            foreach (DataRow drSource in dtSource.Rows)
            {
                lstEntity.Add(drSource.ToEntity<T>());
            }
            return lstEntity;
        }
        public static T ToEntity<T>(this DataRow drSource) where T : new()
        {
            var tEntity = new T();
            var arrEntityProperties = typeof(T).GetProperties();
            string sColName = string.Empty;

            foreach (var oPropertyInfo in arrEntityProperties)
            {
                sColName = oPropertyInfo.GetColumnName();

                if (drSource.Table.Columns.Contains(sColName))
                {
                    oPropertyInfo.SetValue(tEntity, drSource[sColName].GetType().Name.Equals(typeof(DBNull).Name) ? null : drSource[sColName], null);
                }
            }
            return tEntity;
        }

        public static DataTable ToDataTable<T>(this T tEntity, DataTable dtStructure = null)
        {
            DataTable dtReturn = new DataTable();
            if (tEntity == null)
                return dtReturn;
            var tEntityList = new List<T>();
            tEntityList.Add(tEntity);

            return tEntityList.ToDataTable<T>(dtStructure);
        }
        public static DataTable ToDataTable<T>(this T tEntity, List<string> lstColumnName)
        {
            return tEntity.ToDataTable<T>().GetFilteredDataTable(lstColumnName);
        }
        public static DataTable ToDataTable<T>(this IEnumerable<T> tEntityList, DataTable dtStructure = null)
        {
            string sColName = string.Empty;
            DataTable dtReturn = new DataTable();
            if (tEntityList == null)
                return dtReturn;

            var arrEntityProperties = ((Type)tEntityList.First<T>().GetType()).GetProperties();

            if (dtStructure != null)
                dtReturn = dtStructure;
            else
                dtReturn = tEntityList.First<T>().ToDataTableStructure();

            foreach (T tEntity in tEntityList)
            {
                DataRow dr = dtReturn.NewRow();
                foreach (var oPropertyInfo in arrEntityProperties)
                {
                    sColName = oPropertyInfo.GetColumnName();

                    if (dr.Table.Columns.Contains(sColName))
                    {
                        dr[sColName] = oPropertyInfo.GetValue(tEntity, null) == null ? DBNull.Value : oPropertyInfo.GetValue(tEntity, null);
                    }
                }

                dtReturn.Rows.Add(dr);
            }
            return dtReturn;
        }
        public static DataTable ToDataTable<T>(this IEnumerable<T> tEntityList, List<string> lstColumnName)
        {
            return tEntityList.ToDataTable<T>().GetFilteredDataTable(lstColumnName);
        }
        public static DataTable GetFilteredDataTable(this DataTable dtData, List<string> lstColumnName)
        {
            if (dtData == null || dtData.Columns.Count == 0)
                return dtData;
            if (lstColumnName == null || lstColumnName.Count() == 0)
                return dtData;

            string sColumnName = string.Empty;
            DataTable dtStructure = dtData.Clone();
            for (int iIndex = 0; iIndex < dtStructure.Columns.Count; iIndex++)
            {
                sColumnName = dtStructure.Columns[iIndex].ColumnName;
                if (!lstColumnName.Contains(sColumnName))
                    dtData.Columns.Remove(sColumnName);
            }

            //Arranging columns in order of list
            if (dtData.Columns.Count.Equals(lstColumnName.Count))
            {
                for (int iIndex = 0; iIndex < lstColumnName.Count; iIndex++)
                {
                    dtData.Columns[lstColumnName[iIndex]].SetOrdinal(iIndex);
                }
            }
            return dtData;
        }

        private static DataTable ToDataTableStructure<T>(this T tEntity)
        {
            string sColName = string.Empty;
            DataTable dtReturn = new DataTable();
            var arrEntityProperties = ((Type)tEntity.GetType()).GetProperties();
            foreach (var oPropertyInfo in arrEntityProperties)
            {
                Type colType = oPropertyInfo.PropertyType;
                if ((colType.IsGenericType) && (colType.GetGenericTypeDefinition() == typeof(Nullable<>)))
                {
                    colType = colType.GetGenericArguments()[0];
                }

                sColName = oPropertyInfo.GetColumnName();

                dtReturn.Columns.Add(new DataColumn(sColName, colType));
            }
            return dtReturn;
        }

        private static string GetColumnName(this System.Reflection.PropertyInfo oPropertyInfo)
        {
            ///////////////////////////
            //Note: To use DescriptionAttribute : Add Description attribute on top of entity property. Ex: [Description("Salary")]
            //DescriptionAttribute is used to specify the column name corresponding to specific entity property.
            //////////////////////////

            string sColName = string.Empty;
            var oDescriptionAttribute = (DescriptionAttribute)oPropertyInfo.GetCustomAttributes(typeof(DescriptionAttribute), true).SingleOrDefault();
            //if (oDescriptionAttribute == null)
            //    continue;
            if (oDescriptionAttribute == null || string.IsNullOrEmpty(oDescriptionAttribute.Description))
                sColName = oPropertyInfo.Name;
            else
                sColName = oDescriptionAttribute.Description;
            return sColName;
        }
        //How to use: typeof(MyTestClass).GetColumnName("Name")
        public static string GetColumnName(this Type oType, string sPropertyName)
        {
            try
            {
                //
                //return ((DescriptionAttribute)typeof(tEntity).GetProperty(sPropertyName).GetCustomAttributes(typeof(DescriptionAttribute), true).SingleOrDefault()).Description;
                return ((DescriptionAttribute)oType.GetProperty(sPropertyName).GetCustomAttributes(typeof(DescriptionAttribute), true).SingleOrDefault()).Description;
            }
            catch
            {
                return sPropertyName;
            }
        }

        #region NotUsed - DataTable.AsEnumerable
        //private List<EmailEnt> GetEmailDetailsToSend(DataSet dsData)
        //{
        //    return (from dr in dsData.Tables[0].AsEnumerable() select BindDataToEmailEnt(dr)).ToList();
        //}
        //private EmailEnt BindDataToEmailEnt(DataRow dr)
        //{
        //    return new EmailEnt
        //    {
        //        CommEmailID = Convert.ToInt32(dr["CommEmailID"]),
        //        CommEmailFrom = Convert.ToString(dr["CommEmailFrom"]),
        //        CommEmailTo = Convert.ToString(dr["CommEmailTo"]),
        //        CommEmailCC = Convert.ToString(dr["CommEmailCC"]),
        //        CommEmailSubject = Convert.ToString(dr["CommEmailSubject"]),
        //        CommEmailMessage = Convert.ToString(dr["CommEmailMessage"])
        //    };
        //}
        #endregion
        #endregion
        //End : Function added by Ravi Kant Shivhare to 'Convert DataTable to Entity and Entity to DataTable' on 22/Jan/2014

        #endregion
    }
}
