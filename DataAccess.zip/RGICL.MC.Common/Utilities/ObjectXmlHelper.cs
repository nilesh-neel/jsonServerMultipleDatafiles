﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace RGICL.MC.Common.Utilities
{
    public static class ObjectXmlHelper
    {
        public static string ToXml(object oSource)
        {
            try
            {
                MemoryStream oMemoryStream = new MemoryStream();
                StreamWriter oWriter = new StreamWriter(oMemoryStream, Encoding.Unicode);

                var ns = new XmlSerializerNamespaces();
                ns.Add("", "");

                var oXmlSerializer = new XmlSerializer(oSource.GetType());
                oXmlSerializer.Serialize(oWriter, oSource, ns);

                int iStreamLength = (int)oMemoryStream.Length;

                byte[] arrStream = new byte[iStreamLength];
                oMemoryStream.Seek(0, SeekOrigin.Begin);

                //Copy stream contents in byte array
                oMemoryStream.Read(arrStream, 0, iStreamLength);

                var oEncoding = new UnicodeEncoding(); //Convert byte array to string
                return oEncoding.GetString(arrStream).Trim();
            }
            catch (Exception)
            {

                throw;
            }
        }

        /* public static string CreateXml(Object yourClassObject)
         {
             var xmlDoc = new XmlDocument();
             var xmlSerializer = new XmlSerializer(yourClassObject.GetType());

             using (var xmlStream = new MemoryStream())
             {
                 xmlSerializer.Serialize(xmlStream, yourClassObject);
                 xmlStream.Position = 0;
                 xmlDoc.Load(xmlStream);
                 return xmlDoc.InnerXml;
             }
         }
         */

        /* public static Object CreateObject(string xmlString, Object yourClassObject)
         {
             var oXmlSerializer = new XmlSerializer(yourClassObject.GetType());
             yourClassObject = oXmlSerializer.Deserialize(new StringReader(xmlString));
             return yourClassObject;
         }
         */

        public static List<T> RetrieveFromXml<T>(string strFilename, string strRoot)
        {
            // Declare an object variable of the type to be deserialized.
            List<T> lstT;
            using (var oFileStream = new FileStream(strFilename, FileMode.Open, FileAccess.ReadWrite))
            {
                var oXmlSerializer = new XmlSerializer(typeof(List<T>), new XmlRootAttribute(strRoot));
                lstT = (List<T>)oXmlSerializer.Deserialize(oFileStream);
            }

            return lstT;
        }
        public static string GetValueFromXmlElement(this XElement oRootXElement, string strElementName)
        {
            string strParseXml = Convert.ToString(oRootXElement.Element(strElementName));
            if (string.IsNullOrEmpty(strParseXml))
                return string.Empty;
            var oXElement = XElement.Parse(strParseXml);
            return oXElement.Value;
        }
        
        public static object DeSerializeObject(string strXml, Type oType)
        {
            var strReader = new StringReader(strXml);
            var oXmlSerializer = new XmlSerializer(oType);
            return oXmlSerializer.Deserialize(strReader);
        }
        public static T Deserialize<T>(String strFilename)
        {
            if (string.IsNullOrEmpty(strFilename))
                return default(T);
            try
            {
                XmlSerializer _xmlSerializer = new XmlSerializer(typeof(T));
                Stream oStream = new FileStream(strFilename, FileMode.Open, FileAccess.Read);
                var tResult = (T)_xmlSerializer.Deserialize(oStream);
                oStream.Close();
                return tResult;
            }
            catch (Exception ex)
            {
                return default(T);
            }
        }
        public static List<T> DeserializeParams<T>(this XDocument oXDocument)
        {
            XmlSerializer oXmlSerializer = new XmlSerializer(typeof(List<T>));
            XmlReader oXmlReader = oXDocument.CreateReader();
            List<T> lstTResult = (List<T>)oXmlSerializer.Deserialize(oXmlReader);
            oXmlReader.Close();
            return lstTResult;
        }
        public static void SerializeParams<T>(XDocument oXDocument, List<T> lstParams)
        {
            XmlSerializer oXmlSerializer = new System.Xml.Serialization.XmlSerializer(lstParams.GetType());
            XmlWriter oXmlWriter = oXDocument.CreateWriter();
            oXmlSerializer.Serialize(oXmlWriter, lstParams);
            oXmlWriter.Close();
        }
    }

}