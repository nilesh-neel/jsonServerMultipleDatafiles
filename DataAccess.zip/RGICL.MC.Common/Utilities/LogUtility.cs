﻿/****************************************************************************************************************
Class Name   : LogUtility.cs 
Purpose      : Used to define utility functions for Logs and Exceptions
Created By   : Ravi Kant Shivhare
Created Date : 10/Dec/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;
using System.Web;
using System.Xml;

using RGICL.MC.Common.Constants;
using System.Collections.Generic;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class LogUtility
    {
        #region Private Const Members
        private const string strKeyValueFormat = "{0} - {1}\n",
                     strIPHeader = "\n IP: ",
                     strDateTimeHeader = "\n Date Time: ",
                     strUserIdHeader = "\n User Id: ",
                     strUserNameHeader = "\n User Name: ",
                     strPageNameHeader = "\n Page Name: ",
                     strMethodNameHeader = "\n Method Name: ",
                     strMessageHeader = "\n Message: ",
                     strStackTraceHeader = "\n Stack Trace: ",
                     strInnerExHeader = "\n Inner Exception: ";

        private const string strSeperator = "----------------------------------------------------------------------------------------------------";
        private const string strFileNameSeperator = "_";
        #endregion

        public enum LogMode : int
        {
            Email = 0,
            Save = 1
        }
        public enum LogType : int
        {
            Logs = 0,
            ExceptionLog = 1,
            StringLog = 2,
            StackTraceLog = 3,
            EmailLog = 4,
            SMSLog = 5
        }

        static Dictionary<string, string> LogFileNamePrefix = null;
        static Dictionary<string, string> LogFolderName = null;
        
        static LogUtility()
        {
            LogFileNamePrefix = new Dictionary<string, string>();
            LogFileNamePrefix.Add(LogType.ExceptionLog.ToString(), "ErrorLog");
            LogFileNamePrefix.Add(LogType.StringLog.ToString(), "StringLog");
            LogFileNamePrefix.Add(LogType.StackTraceLog.ToString(), "StackTraceLog");
            LogFileNamePrefix.Add(LogType.EmailLog.ToString(), "EmailLog");
            LogFileNamePrefix.Add(LogType.SMSLog.ToString(), "SMSLog");

            LogFolderName = new Dictionary<string, string>();
            LogFolderName.Add(LogType.ExceptionLog.ToString(), "ErrorLog");
            LogFolderName.Add(LogType.StringLog.ToString(), "StringLog");
            LogFolderName.Add(LogType.StackTraceLog.ToString(), "StackTraceLog");
            LogFolderName.Add(LogType.EmailLog.ToString(), "EmailLog");
            LogFolderName.Add(LogType.SMSLog.ToString(), "SMSLog");
        }

        public static void WriteExceptionLog(Exception ex, LogUtility.LogMode enLogMode = LogUtility.LogMode.Save)
        {
            WriteExceptionLog(ex, null, LogUtility.LogMode.Save);
        }
        public static void WriteExceptionLog(Exception ex, string strMethodName, LogUtility.LogMode enLogMode = LogUtility.LogMode.Save)
        {
            try
            {
                if (!AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.ErrorLogEnabled))
                    return;

                if (AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ErrorLogType).ToUpper() == "XML")
                {
                    ExceptionXmlUtility.WriteExceptionLogXml(ex, strMethodName);
                    return;
                }

                StringBuilder sbLog = new StringBuilder(strSeperator);
                sbLog.AppendLine(GetExceptionDetails(ex, strMethodName));

                switch (enLogMode)
                {
                    case LogUtility.LogMode.Email:
                        //Call Email method and send strExceptionDetails
                        break;
                    case LogUtility.LogMode.Save:
                        LogUtility.WriteLog(sbLog.ToString(), LogType.ExceptionLog);
                        break;
                }
            }
            catch (Exception exInner)
            {
                throw exInner;
            }
        }
        public static void WriteStringLog(string strInput)
        {
            try
            {
                StringBuilder sbLog = new StringBuilder();
                sbLog.AppendLine(strSeperator);
                sbLog.AppendLine(DateTime.Now + " : " + strInput);

                WriteLog(sbLog.ToString(), LogType.StringLog);
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex);
            }
        }
        public static void WriteStackTraceLog(string strProcName)
        {
            try
            {
                if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.StackTraceLogEnabled))
                {
                    System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(true);

                    string strFolderPath = GetLogsFolderPath(LogType.StackTraceLog);
                    strFolderPath = GetAppAbsolutePath(strFolderPath);
                    if (!Directory.Exists(strFolderPath))
                        Directory.CreateDirectory(strFolderPath);

                    string strFileName = GetCustomFileName(LogFileNamePrefix[LogType.StackTraceLog.ToString()]);
                    string strFilePathAndName = strFolderPath + strFileName;

                    using (StreamWriter swStackTraceLogMain = new StreamWriter(strFilePathAndName, true, Encoding.ASCII))
                    {
                        swStackTraceLogMain.WriteLine(strSeperator);
                        swStackTraceLogMain.WriteLine(strProcName + " : " + DateTime.Now + " : " + "User ID: " + LoggedInUserID + " : ");
                        swStackTraceLogMain.Flush();
                    }

                    string strStackIndent = "\t";
                    for (int i = 0; i < st.FrameCount; i++)
                    {
                        System.Diagnostics.StackFrame sf = st.GetFrame(i);
                        StringBuilder sbLineToWrite = new StringBuilder();
                        sbLineToWrite.AppendLine(String.Format("Method: {0}", sf.GetMethod()));
                        sbLineToWrite.AppendLine(String.Format(strStackIndent + "File: {0}", sf.GetFileName()));
                        sbLineToWrite.AppendLine(String.Format(strStackIndent + "Line Number: {0}", sf.GetFileLineNumber()));
                        using (StreamWriter swStackTraceLog = new StreamWriter(strFilePathAndName, true, Encoding.ASCII))
                        {
                            swStackTraceLog.WriteLine("");
                            swStackTraceLog.WriteLine(sbLineToWrite.ToString());
                            swStackTraceLog.Flush();
                        }
                    }
                }
            }
            catch (IOException ioex)
            {
                LogUtility.WriteExceptionLog(ioex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }

        public static void WriteLog(string strLog, string strFileNamePrefix)
        {
            WriteLog(strLog, LogType.Logs, strFileNamePrefix);
        }
        public static void WriteLog(string strLog, LogType oLogType, string strFileNamePrefix = "")
        {
            string strFolderPath = GetLogsFolderPath(oLogType);
            string strFileName = GetCustomFileName(oLogType, strFileNamePrefix: strFileNamePrefix);
            WriteLog(strLog, strFolderPath, strFileName);
        }
        private static void WriteLog(string strLog, string strLogFolderRelativePath, string strFileName)
        {
            try
            {
                string strFolderPath = GetAppAbsolutePath(strLogFolderRelativePath);
                if (!Directory.Exists(strFolderPath))
                    Directory.CreateDirectory(strFolderPath);

                string strFilePathAndName = strFolderPath + strFileName;

                using (FileStream fsLog = new FileStream(strFilePathAndName, FileMode.Append, FileAccess.Write))
                {
                    using (StreamWriter swLog = new StreamWriter(fsLog))
                    {
                        swLog.WriteLine(strLog);
                        swLog.Flush();
                    }
                }
            }
            catch (UnauthorizedAccessException uaex)
            {
                LogUtility.WriteExceptionLog(uaex);
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex);
            }
        }

        private static string GetExceptionDetails(Exception ex, string strMethodName)
        {
            StringBuilder sbException = new StringBuilder();
            foreach (DictionaryEntry item in ex.Data)
            {
                sbException.AppendFormat(strKeyValueFormat, item.Key, item.Value);
            }
            sbException.AppendLine(strSeperator);

            sbException.AppendLine(strDateTimeHeader + DateTime.Now.ToString());
            sbException.AppendLine(strIPHeader + LogUtility.UserHostAddress);
            sbException.AppendLine(strUserIdHeader + LogUtility.LoggedInUserID);
            sbException.AppendLine(strUserNameHeader + LogUtility.LoggedInUserName);

            sbException.AppendLine(strPageNameHeader + LogUtility.PageName);

            if (strMethodName != null)
                sbException.AppendLine(strMethodNameHeader + strMethodName);

            sbException.AppendLine(strMessageHeader);
            sbException.AppendLine(ex.Message);

            sbException.AppendLine(strStackTraceHeader);
            sbException.AppendLine(ex.StackTrace);

            return sbException.ToString();
        }
        private static string GetCustomFileName(string strFileNamePrefix, string strExtension = ".txt")
        {
            return strFileNamePrefix + strFileNameSeperator + DateTime.Now.ToString(DateTimeUtility.DefaultDateFormat) + strExtension;
        }
        private static string GetCustomFileName(LogType oLogType, string strExtension = ".txt", string strFileNamePrefix = null)
        {
            if (oLogType != LogType.Logs)
                strFileNamePrefix += LogFileNamePrefix[oLogType.ToString()];
            
            return GetCustomFileName(strFileNamePrefix, strExtension);
        }
        private static string GetLogsFolderPath(LogType oLogType)
        {
            string strRelativePath = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.LogsFolderPath);
            if (oLogType != LogType.Logs)
                strRelativePath += LogFolderName[oLogType.ToString()] + "\\";
            
            return strRelativePath;
        }
        private static string GetAppAbsolutePath(string strRelativePath)
        {
            //return HttpContext.Current.Server.MapPath(strRelativePath);
            return System.Web.Hosting.HostingEnvironment.MapPath(strRelativePath) ?? strRelativePath;
        }

        public class ExceptionXmlUtility
        {
            public ExceptionXmlUtility() { }

            private static void CreateExceptionXml(Exception ex, string strMethodName, string strFilePathAndName)
            {
                using (XmlTextWriter xtwLog = new XmlTextWriter(strFilePathAndName, System.Text.Encoding.UTF8))
                {
                    xtwLog.WriteStartDocument();
                    xtwLog.WriteStartElement("Errors");
                    xtwLog.WriteStartElement("Error");
                    xtwLog.WriteElementString("SNo", "1");

                    xtwLog.WriteElementString("DateTime", DateTime.Now.ToString());
                    xtwLog.WriteElementString("IP", LogUtility.UserHostAddress);
                    xtwLog.WriteElementString("UserId", LogUtility.LoggedInUserID);
                    xtwLog.WriteElementString("UserName", LogUtility.LoggedInUserName);

                    xtwLog.WriteElementString("PageName", LogUtility.PageName);
                    if (strMethodName != null)
                        xtwLog.WriteElementString("MethodName", strMethodName);
                    else
                        xtwLog.WriteElementString("MethodName", "");

                    if (ex != null)
                    {
                        xtwLog.WriteElementString("Message", ex.Message);
                        xtwLog.WriteElementString("StackTrace", ex.StackTrace);
                    }
                    else
                    {
                        xtwLog.WriteElementString("Message", "");
                        xtwLog.WriteElementString("StackTrace", "");
                    }
                    xtwLog.WriteEndElement();
                    xtwLog.WriteEndElement();
                    xtwLog.WriteEndDocument();
                }
            }
            public static void WriteExceptionLogXml(Exception ex, string strMethodName)
            {
                try
                {
                    string strFolderPath = LogUtility.GetLogsFolderPath(LogUtility.LogType.ExceptionLog);
                    strFolderPath = LogUtility.GetAppAbsolutePath(strFolderPath);
                    if (!Directory.Exists(strFolderPath))
                        Directory.CreateDirectory(strFolderPath);

                    string strFileName = LogUtility.GetCustomFileName(LogUtility.LogFileNamePrefix[LogType.ExceptionLog.ToString()], ".config");
                    string strFilePathAndName = strFolderPath + strFileName;
                    
                    int iSNo = 1;
                    XmlDocument xdException = new XmlDocument();
                    if (File.Exists(strFilePathAndName))
                    {
                        xdException.Load(strFilePathAndName);
                        iSNo = xdException.DocumentElement.ChildNodes.Count + 1;
                    }
                    else
                    {
                        ExceptionXmlUtility.CreateExceptionXml(ex, strMethodName, strFilePathAndName);
                        return;
                    }

                    XmlElement xeNodeException = xdException.CreateElement("Error");
                    XmlElement xeNodeErrorSNo = xdException.CreateElement("SrNo");
                    XmlElement xeNodeDateTime = xdException.CreateElement("DateTime");
                    XmlElement xeNodeIP = xdException.CreateElement("IP");
                    XmlElement xeNodeUserId = xdException.CreateElement("UserId");
                    XmlElement xeNodeUserName = xdException.CreateElement("UserName");

                    XmlElement xeNodePageName = xdException.CreateElement("PageName");
                    XmlElement xeNodeMethodName = xdException.CreateElement("MethodName");

                    XmlElement xeNodeMessage = xdException.CreateElement("Message");
                    XmlElement xeNodeStackTrace = xdException.CreateElement("StackTrace");

                    xeNodeErrorSNo.InnerText = iSNo.ToString();
                    xeNodeDateTime.InnerText = DateTime.Now.ToString();
                    xeNodeIP.InnerText = LogUtility.UserHostAddress;
                    xeNodeUserId.InnerText = LogUtility.LoggedInUserID;
                    xeNodeUserName.InnerText = LogUtility.LoggedInUserName;

                    xeNodePageName.InnerText = LogUtility.PageName;
                    xeNodeMethodName.InnerText = strMethodName;

                    xeNodeMessage.InnerText = ex.Message;
                    xeNodeStackTrace.InnerText = ex.StackTrace;

                    xeNodeException.AppendChild(xeNodeErrorSNo);
                    xeNodeException.AppendChild(xeNodeDateTime);
                    xeNodeException.AppendChild(xeNodeIP);
                    xeNodeException.AppendChild(xeNodeUserId);
                    xeNodeException.AppendChild(xeNodeUserName);

                    xeNodeException.AppendChild(xeNodePageName);
                    xeNodeException.AppendChild(xeNodeMethodName);

                    xeNodeException.AppendChild(xeNodeMessage);
                    xeNodeException.AppendChild(xeNodeStackTrace);

                    xdException.DocumentElement.InsertBefore(xeNodeException, xdException.DocumentElement.FirstChild);
                    xdException.Save(strFilePathAndName);
                }
                catch (UnauthorizedAccessException uaex)
                {
                    throw uaex;
                }
            }
            public static DataTable ReadExceptionLogXml(string strErrorLogDate)
            {
                if (!string.IsNullOrEmpty(strErrorLogDate))
                {
                    string strFilePathAndName = LogUtility.GetLogsFolderPath(LogUtility.LogType.ExceptionLog) + LogUtility.LogFileNamePrefix[LogType.ExceptionLog.ToString()] + strFileNameSeperator + strErrorLogDate + ".config";
                    if (File.Exists(strFilePathAndName))
                    {
                        DataSet ds = new DataSet();
                        ds.ReadXml(strFilePathAndName);
                        return ds.Tables[0];
                    }
                }
                return null;
            }
        }

        #region Private Properties
        private static string UserHostAddress
        {
            get { return HttpContext.Current != null ? HttpContext.Current.Request.UserHostAddress.ToString() : string.Empty; }
        }
        private static string PageName
        {
            get { return HttpContext.Current != null ? HttpContext.Current.Request.Url.PathAndQuery : string.Empty; }
        }
        private static string LoggedInUserID
        {
            get { return CommonUtility.LoggedInUserID; }
        }
        private static string LoggedInUserName
        {
            get { return CommonUtility.LoggedInUserName; }
        }
        #endregion
    }
}
