﻿/****************************************************************************************************************
Class Name   : DateTimeUtility.cs 
Purpose      : Used to define date & time utility functions and constants. (including IFormatProvider)
Created By   : Ravi Kant Shivhare 
Created Date : 26/Sep/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Globalization;
using System.Threading;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class DateTimeUtility
    {
        #region Public Member Variables
        /// <summary>
        /// Default date format used in full application
        /// </summary>
        public const string DefaultDateFormat = "dd-MMM-yyyy";
        #endregion

        #region Public Functions
        /// <summary>
        /// Used to convert DateTime to string in default date format
        /// </summary>
        /// <param name="dtValue">DateTime Value</param>
        /// <returns></returns>
        public static string GetFormattedDate(DateTime dtValue)
        {
            return GetFormattedDate(dtValue, DefaultDateFormat);
        }
        /// <summary>
        /// Used to convert DateTime to string in specified format
        /// </summary>
        /// <param name="dtValue">DateTime Value</param>
        /// <param name="strDateFormat">Date format in which the date need to be converted.</param>
        /// <returns></returns>
        public static string GetFormattedDate(DateTime dtValue, string strDateFormat)
        {
            IFormatProvider ifpDateFormatInfo = new CultureInfo("en-US").DateTimeFormat;
            //return String.Format("{0:dd-MM-yyyy}", dtDate);
            return String.Format(ifpDateFormatInfo, "{0:" + strDateFormat + "}", dtValue);
        }
        #endregion

    }
}
