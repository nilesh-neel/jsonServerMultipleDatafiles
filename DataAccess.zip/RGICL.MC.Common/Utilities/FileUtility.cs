﻿/****************************************************************************************************************
Class Name   : FileUtility.cs 
Purpose      : Used to define file utility functions.
Created By   : Ravi Kant Shivhare 
Created Date : 30/Oct/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Web;
using System.IO;
using System.Collections.Generic;

using RGICL.MC.Common.Utilities;
using RGICL.MC.Common.Constants;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using FileTypeGenericHandlers.FileChecker;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class FileUtility
    {
        #region Private Member Variables
        private const string strFileNameSeperator = "_";
        #endregion

        public static void DownloadFile(string strAbsolutePath, string strFileName)
        {
            try
            {
                string strFilePathAndName = strAbsolutePath + strFileName;
                if (File.Exists(strFilePathAndName) && IsValidFileExtensionLFIDownload(strFileName))
                {
                    using (FileStream fStream = new FileStream(strFilePathAndName, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
                    {
                        Byte[] arrByte = new Byte[fStream.Length];

                        HttpContext.Current.Response.Clear();
                        HttpContext.Current.Response.ClearContent();
                        HttpContext.Current.Response.ClearHeaders();

                        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + strFileName);
                        HttpContext.Current.Response.AddHeader("Content-Length", fStream.Length.ToString());
                        HttpContext.Current.Response.ContentType = "application/octet-stream";

                        //HttpContext.Current.Response.ContentType = "application/unknown";
                        //HttpContext.Current.Response.ContentType = "application/x-msdownload";
                        //HttpContext.Current.Response.ContentType = "application/excel";

                        fStream.Read(arrByte, 0, int.Parse(fStream.Length.ToString()));
                        HttpContext.Current.Response.BinaryWrite(arrByte);
                    }

                    HttpContext.Current.Response.End();

                    DisplayMessage(MessageConstants.FileDownloadedSuccessfully);
                }
                else
                {
                    DisplayMessage(MessageConstants.FileNotFound);
                }
            }
            catch(Exception ex)
            {
                
            }
        }
        #region Public Functions
        //LFI(Local File Inclusion) Vulnerability
        public static bool IsValidFileExtensionLFIDownload(string strRelativeFilePathAndName)
        {
            if (strRelativeFilePathAndName.ToLower().Contains(@"../"))
                return false;
            string strFileExtension = Path.GetExtension(strRelativeFilePathAndName);
            string[] strInvalidExtensions = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.LFIDownloadInvalidExtensions).Split(',');
            foreach (string strInvalidExtension in strInvalidExtensions)
            {
                if (strFileExtension.ToLower() == strInvalidExtension.ToLower())
                    return false;
            }
            return true;
        }

        //DOR(Direct Object Reference) Vulnerability
        public static bool IsValidFileExtensionForDOR(string strRelativeFilePathAndName)
        {
            string strFileExtension = Path.GetExtension(strRelativeFilePathAndName);
            string[] strInvalidExtensions = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.DORInvalidExtensions).Split(',');
            foreach (string strInvalidExtension in strInvalidExtensions)
            {
                if (strFileExtension.ToLower() == strInvalidExtension.ToLower())
                    return false;
            }
            return true;
        }

        //File Upload Vulnerability
        #region File Upload Vulnerability - FileTypeGenericHandlers
        public static bool IsValidFileExtensionForUpload(FileUpload oFileUploader)
        {
            return IsValidFileExtensionForUpload_Generic(oFileUploader);
        }
        public static bool IsValidFileExtensionForUpload(HtmlInputFile oFileUploader)
        {
            return IsValidFileExtensionForUpload_Generic(oFileUploader);
        }
        public static bool IsValidFileExtensionForUpload(HttpPostedFile oHttpPostedFile)
        {
            return IsValidFileExtensionForUpload_Generic(oHttpPostedFile);
        }
        private static bool IsValidFileExtensionForUpload_Generic(object tFileUploader)
        {
            if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.FileTypeGenericHandlersEnabled))
            {
                try
                {
                    string sTempFolderPath = HttpContext.Current.Server.MapPath("~") + "\\temp_filechecker";
                    if (!Directory.Exists(sTempFolderPath))
                        Directory.CreateDirectory(sTempFolderPath);
                    sTempFolderPath += "\\";

                    string sFileName = string.Empty;
                    if (tFileUploader.GetType() == typeof(FileUpload))
                    {
                        sFileName = Path.GetFileName(((FileUpload)tFileUploader).PostedFile.FileName);
                        ((FileUpload)tFileUploader).SaveAs(sTempFolderPath + sFileName);
                    }
                    else if (tFileUploader.GetType() == typeof(HtmlInputFile))
                    {
                        sFileName = Path.GetFileName(((HtmlInputFile)tFileUploader).PostedFile.FileName);
                        ((HtmlInputFile)tFileUploader).PostedFile.SaveAs(sTempFolderPath + sFileName);
                    }
                    else if (tFileUploader.GetType() == typeof(HttpPostedFile))
                    {
                        sFileName = Path.GetFileName(((HttpPostedFile)tFileUploader).FileName);
                        ((HttpPostedFile)tFileUploader).SaveAs(sTempFolderPath + sFileName);
                    }

                    bool bIsValid = false;
                    FileInfo oFileInfo = new FileInfo(sTempFolderPath + sFileName);
                    FileTypes oFileType = (FileTypes)Enum.Parse(typeof(FileTypes), oFileInfo.Extension.Substring(1));
                    bIsValid = FileChecker.CheckFileType(oFileType, sTempFolderPath + sFileName);

                    if (System.IO.File.Exists(sTempFolderPath + sFileName))
                        System.IO.File.Delete(sTempFolderPath + sFileName);
                    if (!bIsValid)
                        DisplayMessage(MessageConstants.ExtensionGenericHandlerMessage);
                    return bIsValid;
                }
                catch
                {
                    DisplayMessage(MessageConstants.ExtensionGenericHandlerMessage);
                    return false;
                }
            }
            else
            {
                return true;
            }

        }

        //To get HexValue of file
        //Find HexValue of a file and put it in web.config under extensionToFind tag
        public static string GetFileHexValue(FileUpload oFileUploader)
        {
            BinaryReader oReader = new BinaryReader(new FileStream(oFileUploader.PostedFile.FileName, FileMode.Open, FileAccess.Read, FileShare.None));

            oReader.BaseStream.Position = 0x0;   //The offset you are reading from the data
            byte[] data = oReader.ReadBytes(0x8);//Read 16 bytes into an array
            oReader.Close();

            string strDataAsString = System.Text.Encoding.Default.GetString(data);

            string strDataAsHex = BitConverter.ToString(data);//Output: Ex: 74-68-65-72-77-69-73-65-20-69-73-20-69-74-63-68
            strDataAsHex = strDataAsHex.Replace("-", "");
            return strDataAsHex;
        }
        #endregion

        public static string GetCustomFileName(string strFileNamePrefix, string strExtension = ".txt")
        {
            return strFileNamePrefix + strFileNameSeperator + DateTime.Now.ToString(DateTimeUtility.DefaultDateFormat) + strExtension;
        }
        private static void DisplayMessage(string strMessage, string strKey = "Message")
        {
            /*
            strMessage = strMessage.Replace("\r\n", "\\n");
            strMessage = strMessage.Replace("\n", "\\n");
            //strMsg = strMsg.Replace(@"\", "\\\\");
            strMessage = strMessage.Replace("'", "");
            string strScript = "alert('" + strMessage + "');";

            ((System.Web.UI.Page)HttpContext.Current.Handler).ClientScript.RegisterStartupScript(this.GetType(), strKey, strScript,true);
            */
        }

        #endregion

    }
}
