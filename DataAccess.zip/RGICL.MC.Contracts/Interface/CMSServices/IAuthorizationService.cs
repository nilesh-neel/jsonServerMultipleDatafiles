﻿using System.ServiceModel;

using RGICL.MC.Contracts.Entity;
using System.Collections.Generic;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    [ServiceContract]
    public interface IAuthorizationService
    {
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<UserAuthorizationEnt> GetAuthorizationPages(string strLoginID);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        bool IsAuthorizedPage(string strRelativePageURL, string strLoginID);

        [OperationContract(Name="IsAuthorizedPageFromList")]
        [FaultContract(typeof(CustomExceptionEnt))]
        bool IsAuthorizedPage(string strRelativePageURL, List<UserAuthorizationEnt> lstAuthorizedPages);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        bool IsValidUser(string loginID, string roleName);
    }
}
