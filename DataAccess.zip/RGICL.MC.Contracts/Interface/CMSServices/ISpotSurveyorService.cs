﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ISpotSurveyorService" in both code and config file together.
    [ServiceContract]
    public interface ISpotSurveyorService
    {

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        void SetSpotSurveyDetail(SpotSurveyEnt objSpotSurvey, CommertialVehicalEnt objCommVehical);

    }
}
