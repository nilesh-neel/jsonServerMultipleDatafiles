﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    [ServiceContract]
    public interface IServiceRequestService
    {
        [OperationContract]
        ClaimEnt GetClaimFromClaimRefNo(string ClaimRefNo);
        [OperationContract]
        int SetClosureDetails(ServiceRequestClosureEnt oClosureEnt);
        [OperationContract]
        List<ServiceRequestClosureEnt> GetClosureDetails(string ClaimRefNo, string ClosureID);
        [OperationContract]
        bool IsApprover(string ClaimRefNo, string ProductID, string UserID, int RequestType);
        [OperationContract]
        int SetReopenDetails(ServiceRequestReopenEnt oReopenEnt);
        [OperationContract]
        List<ServiceRequestReopenEnt> GetReOpenDetails(string ClaimRefNo, string ReOpenID);
        [OperationContract]
        int SetRecoveryDetails(ServiceRequestRecoveryEnt oRecoveryEnt);
        [OperationContract]
        List<ServiceRequestRecoveryEnt> GetRecoverDetails(string ClaimRefNo, string RecoveryID);
        [OperationContract]
        List<ServiceRequestStopPaymentEnt> GetStopPaymentDetails(string ClaimRefNo, string StopPaymentID);
        [OperationContract]
        List<PaymentEnt> GetPaymentDetails(string ClaimRefNo, string PaymentID);
        [OperationContract]
        string CheckAccountclearanceStatus(string ClaimRefNo, string PaymentID, string PaymentTypeID, int RequestType);
        [OperationContract]
        int SetStopPaymentRQDetails(ServiceRequestStopPaymentEnt oStopPaymentEnt);
        [OperationContract]
        List<ServiceRequestReIssueEnt> GetReIssueDetails(string ClaimRefNo, string ReIssueID);
        [OperationContract]
        int SetReIssueSRDetails(ServiceRequestReIssueEnt oReIssueEnt);
        [OperationContract]
        int InsertSRApprovalReject(ServiceRequestEnt oServiceRequestEnt);
        [OperationContract]
        List<CVMApprovalEnt> GetCVMLst(string ClaimRefNo, string CVMID);

        [OperationContract]
        int SetCVMApprovalDetails(CVMApprovalEnt oCVMApprovalEnt);

    }
}
