﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICommon" in both code and config file together.
    [ServiceContract]
    public interface ICommonService
    {
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<MasterEnt> GetTableData(string TableName, string ColumnName, string whereCondition = "", string orderBy = "", string TextField = "", string valueField = "");

        //[OperationContract]
        //[FaultContract(typeof(CustomExceptionEnt))]
        //int SaveEmailData(EmailEnt objEmailEnt);

        //[OperationContract]
        //[FaultContract(typeof(CustomExceptionEnt))]
        //EmailEnt GetEmailTemplate(EmailEnt objEmailEnt);
    }
}
