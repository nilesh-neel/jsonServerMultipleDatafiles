﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    [ServiceContract]
    public interface ICommunicationService
    {
        [OperationContract(Name = "SendCommunication")]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SendCommunication(string sEventCode, string sClaimRefNo);

        [OperationContract(Name = "SendCommunicationWithPassword")]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SendCommunication(string sEventCode, int iUserID, string sPassword);

        [OperationContract(Name = "SendCommunicationForMaster")]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SendCommunication(string sEventCode, int iMasterID);

        [OperationContract(Name = "SendCommunicationEmail")]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SendCommunication(EmailEnt oComm);

        [OperationContract(Name = "SendCommunicationSMS")]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SendCommunication(SMSEnt oComm);
    }
}
