﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class ApprovalEnt
    {
        [DataMember]
        public ClaimEnt ClaimEnt { get; set; }

        [DataMember]
        public string WorkStepName { get; set; }

        [DataMember]
        public string ProcessInstanceName { get; set; }

        [DataMember]
        public string Action { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
      
       
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public string ApprovalType { get; set; }
        [DataMember]
        public string MethodName { get; set; }
        [DataMember]
        public string ServiceName { get; set; }

        [DataMember]
        public string ActionType { get; set; }

        [DataMember]
        public int RoleId { get; set; }

        [DataMember]
        public string ServiceType { get; set; }

        [DataMember]
        public string ExpectedInputParameter { get; set; }

        [DataMember]
        public string ExpectedOuputParameter { get; set; }

        [DataMember]
        public string SavvionResonseCode { get; set; }

        [DataMember]
        public string SavvionErrorMassage { get; set; }


        [DataMember]
        public string PageName { get; set; }

        [DataMember]
        public int SavvionWorkFlowId { get; set; }

        [DataMember]
        public decimal ToleranceAmount { get; set; }
    }
}
