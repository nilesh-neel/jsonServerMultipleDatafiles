﻿
namespace RGICL.MC.Contracts.Entity
{
    public class CMSMenuEnt
    {
        public int MenuID { get; set; }
        public string MenuName { get; set; }
        public string MenuLocation { get; set; }
        public int ParentID { get; set; }
        public int OrderNumber { get; set; }        
        public bool IsReadOnly { get; set; }
        
    }
}
