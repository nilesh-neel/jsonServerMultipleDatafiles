﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class PolicyEnt
    {       
        [DataMember]        
        public string PolicyNo { get; set; }
        [DataMember]        
        public string CoverNote { get; set; }
        [DataMember]
        public int LobId { get; set; }
        [DataMember]
        public string LobDesc { get; set; }        
        [DataMember]
        public string ProductCode { get; set; }
        [DataMember]
        public string ProductDesc { get; set; }        
        [DataMember]
        public DateTime PolicyStartDate { get; set; }
        [DataMember]
        public DateTime PolicyEndDate { get; set; }
        [DataMember]
        public decimal SumInsured { get; set; }
        [DataMember]
        public decimal NetPremium { get; set; }
        [DataMember]
        public decimal TotalPremium { get; set; }
        [DataMember]
        public string InsuredName { get; set; }        
        [DataMember]
        public int PolicyIssuingOffice { get; set; }        
        [DataMember]
        public string YearOfMFG { get; set; }        
        [DataMember]
        public string PreinspectionLinkId { get; set; }        
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }
        [DataMember]
        public string VehicleNo {get;set;}
        [DataMember]        
        public string ChasisNo { get; set; }
        [DataMember]
        public string EngineNo { get; set; }
        [DataMember]
        public int MakeId {get;set;}
        [DataMember]
        public int ModelId {get;set;}
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public bool PaymentAcceptance { get; set; }
        [DataMember]
        public bool PremiumClearance { get; set; }
        [DataMember]
        public string RPasData { get; set; }
        [DataMember]
        public bool IsPolicyFromDealer { get; set; }

        [DataMember]
        public string NumberofClaim { get; set; }

        [DataMember]
        public DateTime DepApplicableDate { get; set; }

        [DataMember]
        public DateTime RegistrationDate { get; set; }

        [DataMember]
        public string NilDepApplicableFromPolicy { get; set; }

        [DataMember]
        public bool NilDepApplicableFromClaim { get; set; }

        [DataMember]
        public string OptedClaims { get; set; }
        [DataMember]
        public string DailyAllowance { get; set; }
        [DataMember]
        public string DaysCovered { get; set; }
        [DataMember]
        public string NCBRetention { get; set; }
        [DataMember]
        public string TowingAmount { get; set; }
        [DataMember]
        public string TowingIDV { get; set; }
        [DataMember]
        public string ElectronicElectricAccessories { get; set; }
        [DataMember]
        public string NonElectricAccessories { get; set; }
        [DataMember]
        public string CNGLPGIDV { get; set; }
        [DataMember]
        public string BodyIDV { get; set; }
        [DataMember]
        public string ChassisIDV { get; set; }
        [DataMember]
        public string Trailer { get; set; }
        [DataMember]
        public string PersonalAccidentIDV { get; set; }
        [DataMember]
        public string ConfinedSiteDiscount { get; set; }
        [DataMember]
        public string CoverageofAddParts { get; set; }
        [DataMember]
        public string OverTurn { get; set; }
        [DataMember]
        public string Hypothication { get; set; }

    }
}
