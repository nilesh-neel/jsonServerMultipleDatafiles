﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class VictimEnt
    {
        [DataMember] 
        public int VictimId { get; set; }
        [DataMember]
        public int VictimCategoryId { get; set; }        
        [DataMember]
        public int NatureOfInjuryId { get; set; }        
        [DataMember]
        public string VictimName { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }


    }
}
