﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace RGICL.MC.RestService.Entity.JsonEnt
{
    public class JsonMasterData
    {
        public List<JsonProductCategoryEnt> ProductCategory { get; set; }
        public List<JsonTaxType> TaxType { get; set; }
        public List<JsonTypeOfLicense> TypeOfLicense { get; set; }
        public List<JsonPermitType> PermitType { get; set; }
        public List<JsonDriverRelationship> DriverRelationship { get; set; }
        public List<JsonDocumentEnt> DocumentType { get; set; }
    }

    public class JsonPartMasterData
    {
        public List<JsonMakeEnt> Make { get; set; }
        public List<JsonPart> PartDetails { get; set; }
    }

    public class JsonLocationMasterData
    {
        public List<JsonStateEnt> State { get; set; }
        public List<JsonDistrictEnt> District { get; set; }
        public List<JsonCityEnt> City { get; set; }
        public List<JsonLocationEnt> Location { get; set; }
    }


    public class JsonProductCategoryEnt
    {
        [DataMember]
        public int CategoryId { get; set; }
        [DataMember]
        public string CategoryName { get; set; }

        //[DataMember]
        //public decimal CatMinLimit { get; set; }
        //[DataMember]
        //public decimal CatMaxLimit { get; set; }
        //[DataMember]
        //public bool MapToUser { get; set; }
        //[DataMember]
        //public List<ProductEnt> Product { get; set; }
        //[DataMember]
        //public List<NatureOfLossEnt> TypeOfLoss { get; set; }
        //[DataMember]
        //public List<GradeApproval> GradeApproval { get; set; }
        //[DataMember]
        //public GradeEnt ProdCategoryGrades { get; set; }
    }

    public class JsonMakeEnt
    {
        [DataMember]
        public int MakeId { get; set; }
        [DataMember]
        public string MakeName { get; set; }
        [DataMember]
        public List<JsonModelEnt> Model { get; set; }

    }

    public class JsonModelEnt
    {
        [DataMember]
        public int ModelId { get; set; }
        [DataMember]
        public string ModelName { get; set; }
        [DataMember]
        public int MakeId { get; set; }
    }

    public class JsonPart
    {
        [DataMember]
        public int PartId { get; set; }
        [DataMember]
        public string PartName { get; set; }
        [DataMember]
        public List<JsonSubPart> SubPartDetails { get; set; }
    }

    public class JsonSubPart
    {
        [DataMember]
        public int SubPartId { get; set; }
        [DataMember]
        public string SubPartName { get; set; }

    }

    public class JsonTaxType
    {
        [DataMember]
        public int TaxTypeId { get; set; }
        [DataMember]
        public string TaxTypeName { get; set; }
    }

    public class JsonPartType
    {
        [DataMember]
        public int PartTypeId { get; set; }
        [DataMember]
        public string PartTypeName { get; set; }
    }
    public class JsonTypeOfLicense
    {
        [DataMember]
        public int LicenseTypeId { get; set; }
        [DataMember]
        public string LicenseTypeName { get; set; }
    }
    public class JsonPermitType
    {
        [DataMember]
        public int PermitTypeId { get; set; }
        [DataMember]
        public string PermitTypeName { get; set; }
    }
    public class JsonDriverRelationship
    {
        [DataMember]
        public int DriverRelationshipId { get; set; }
        [DataMember]
        public string DriverRelationshipName { get; set; }
    }

    public class JsonStateEnt
    {
        [DataMember]
        public int StateId { get; set; }
        [DataMember]
        public string StateName { get; set; }
    }

    public class JsonDistrictEnt
    {
        [DataMember]
        public int DistrictId { get; set; }
        [DataMember]
        public int StateId { get; set; }
        [DataMember]
        public string DistrictName { get; set; }
    }

    public class JsonCityEnt
    {
        [DataMember]
        public int CityId { get; set; }
        [DataMember]
        public int DistrictId { get; set; }
        [DataMember]
        public string CityName { get; set; }
    }

    public class JsonLocationEnt
    {
        [DataMember]
        public int LocationId { get; set; }
        [DataMember]
        public int CityId { get; set; }
        [DataMember]
        public string LocationName { get; set; }
    }
    public class JsonDocumentEnt
    {
        [DataMember]
        public int DocId { get; set; }
        [DataMember]
        public string DocDescription { get; set; }
    }
}