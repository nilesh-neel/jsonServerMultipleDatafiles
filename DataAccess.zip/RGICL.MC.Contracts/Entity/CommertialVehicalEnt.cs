﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
   public class CommertialVehicalEnt
    {
        [DataMember]
        public int CommercialVehicalID { get; set; }
        [DataMember]
        public string LoadChallanLoadPerKG { get; set; }
        [DataMember]
        public string LoadChallanNo { get; set; }
        [DataMember]
        public DateTime LoadChallanDate { get; set; }
        [DataMember]
        public string RoutePermitNo { get; set; }
        [DataMember]
        public string PermitType { get; set; }
        [DataMember]
        public DateTime RoutePeriodTo { get; set; }
        [DataMember]
        public DateTime RoutePeriodFrom { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
      
        [DataMember]
        public int UpdatedBy { get; set; }
        
        [DataMember]
        public int AuthorizationNo { get; set; }
        [DataMember]
        public DateTime AuthorizationDateTo { get; set; }
        [DataMember]
        public DateTime AuthorizationDateFrom { get; set; }
        [DataMember]
        public string FitnessNo { get; set; }
        [DataMember]
        public DateTime FitnessCertificateTo { get; set; }
        [DataMember]
        public DateTime FitnessCertificateFrom { get; set; }
        [DataMember]
        public string RoadTaxNo { get; set; }
        [DataMember]
        public DateTime RoadTaxTo { get; set; }
        [DataMember]
        public DateTime RoadTaxFrom { get; set; }
        [DataMember]      
        public string ClaimRefNo { get; set; }


    }
}
