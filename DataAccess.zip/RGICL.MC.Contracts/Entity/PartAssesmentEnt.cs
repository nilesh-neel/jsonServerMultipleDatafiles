﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class PartAssesmentEnt
    {
        [DataMember]
        public int AssessmentID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string PolicyNo { get; set; }
        [DataMember]
        public string PartName { get; set; }
        [DataMember]
        public string SubPartName { get; set; }
        [DataMember]
        public int PartType { get; set; }
        [DataMember]
        public decimal PartRate { get; set; }
        [DataMember]
        public decimal QtyUnits { get; set; }
        [DataMember]
        public decimal Discount { get; set; }
        [DataMember]
        public int GrossPartAmount { get; set; }
        [DataMember]
        public bool IMT23 { get; set; }
        [DataMember]
        public bool KeptOpen { get; set; }
        [DataMember]
        public bool VatChargedOnLabour { get; set; }
        [DataMember]
        public int TaxTypeID { get; set; }
        [DataMember]
        public string TaxType { get; set; }
        [DataMember]
        public decimal TaxRatePer { get; set; }
        [DataMember]
        public decimal TaxOnPart { get; set; }
        [DataMember]
        public decimal PartAmount { get; set; }
        [DataMember]
        public decimal Depthper { get; set; }
        [DataMember]
        public decimal DepthAmount { get; set; }
        [DataMember]
        public decimal NetPartAmount { get; set; }
        [DataMember]
        public decimal PartAmountWithTax { get; set; }
        [DataMember]
        public int RemoveAndRiffiting { get; set; }
        [DataMember]
        public int Denting { get; set; }
        [DataMember]
        public int TotalLabour { get; set; }
        [DataMember]
        public decimal BifurcationPer { get; set; }
        [DataMember]
        public decimal LabourMaterialAmount { get; set; }
        [DataMember]
        public decimal LabourAmount { get; set; }
        [DataMember]
        public string LabourMaterialDepType { get; set; }
        [DataMember]
        public decimal LabourMaterialDepAmount { get; set; }
        [DataMember]
        public decimal LabourMaterialVat { get; set; }
        [DataMember]
        public decimal NetLabourMaterialAmount { get; set; }
        [DataMember]
        public decimal ServiceTaxAmount { get; set; }
        [DataMember]
        public decimal GrossLabourAmount { get; set; }
        [DataMember]
        public decimal PaintingAmount { get; set; }
        [DataMember]
        public decimal PaintMaterialAmount { get; set; }
        [DataMember]
        public decimal PaintingLabourAmount { get; set; }
        [DataMember]
        public string PaintMaterialDepType { get; set; }
        [DataMember]
        public decimal NetPaintDepAmount { get; set; }
        [DataMember]
        public decimal NetPaintVat { get; set; }
        [DataMember]
        public decimal NetPaintAmount { get; set; }
        [DataMember]
        public bool ServiceTax { get; set; }
        [DataMember]
        public int TypeofLossID { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }

    }
}
