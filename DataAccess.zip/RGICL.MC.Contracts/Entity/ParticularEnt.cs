﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
   public  class ParticularEnt
    {
        //[DataMember]
        //public int MakeId { get; set; }
        //[DataMember]
        //public int ModelId { get; set; }
        //[DataMember]
        //public string YearOfManufacture { get; set; }
        //[DataMember]
        //public string EngineNo { get; set; }
        //[DataMember]
        //public string ChasisNo { get; set; }
        //[DataMember]
        //public string VehicleNo { get; set; }
        //[DataMember]
        //public decimal SumInsured { get; set; }
        //[DataMember]
        //public int CreatedBy { get; set; }
        //[DataMember]
        //public int ElectronicElectricIDV { get; set; }
        //[DataMember]
        //public int CNGEndorsementIDV { get; set; }
        //[DataMember]
        //public string CubicCapacity { get; set; }
        //[DataMember]
        //public int SeatingCapacity { get; set; }
        //[DataMember]
        //public string GVW { get; set; }
        //[DataMember]
        //public int CompulsoryExcess { get; set; }
        //[DataMember]
        //public int VoluntaryExcess { get; set; }
        //[DataMember]
        //public int ImposedExcess { get; set; }
        //[DataMember]
        //public string Hypothecation { get; set; }
        //[DataMember]
        //public string NCB { get; set; }
        //[DataMember]
        //public string KM { get; set; }

       [DataMember]
       public int ParticularID { get; set; }
       [DataMember]
       public string ParticularName { get; set; }
       [DataMember]
       public string ParticularValueAsPerPolicy { get; set; }
       [DataMember]
       public string ParticularsAsPerSurvey { get; set; }
       [DataMember]
       public string Remarks { get; set; }
       [DataMember]
       public bool IsParticularAsPerSurvey { get; set; }
       [DataMember]      
       public int CreatedBy { get; set; }



    }
}
