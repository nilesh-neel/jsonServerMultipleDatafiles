﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class InsuredEnt
    {
        [DataMember]
        [Description("InsuredID")]
        public int InsuredID { get; set; }

        [DataMember]
        [Description("ClaimRefNo")]
        public string ClaimRefNo { get; set; }

        [DataMember]
        [Description("AddressCategory")]
        public int AddressCategory { get; set; }

        [DataMember]
        [Description("InsuredName")]
        public string InsuredName { get; set; }

        [DataMember]
        [Description("AddressLine1")]
        public string InsuredAddressLine1 { get; set; }

        [DataMember]
        [Description("AddressLine2")]
        public string InsuredAddressLine2 { get; set; }

        [DataMember]
        [Description("InsuredState")]
        public int InsuredState { get; set; }

        [DataMember]
        public string InsuredStateName { get; set; }

        [DataMember]
        [Description("InsuredCity")]
        public int InsuredCity { get; set; }

        [DataMember]
        public string InsuredCityName { get; set; }

        [DataMember]
        [Description("InsuredPinCode")]
        public int InsuredPinCode { get; set; }

        [DataMember]
        [Description("InsuredPhoneNumber")]
        public string InsuredPhoneNumber { get; set; }

        [DataMember]
        [Description("InsuredMobileNumber")]
        public string InsuredMobileNumber { get; set; }

        [DataMember]
        [Description("EmailId")]
        public string InsuredEmailId { get; set; }

        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }

        [DataMember]
        public string AverageMonthlyIncome { get; set; }

        [DataMember]
        public string InsuredProfession { get; set; }

        [DataMember]
        public int CustId { get; set; }

        [DataMember]
        public string AccountHolderName { get; set; }

        [DataMember]
        public string CustAccNo { get; set; }

        [DataMember]
        public string ConfirmAccNo { get; set; }

        [DataMember]
        public string ISFCCode { get; set; }

        [DataMember]
        public string BankName { get; set; }

        [DataMember]
        public string BranchName { get; set; }

        [DataMember]
        public int StateId { get; set; }

        [DataMember]
        public int CityId { get; set; }

        [DataMember]
        public string CancelledChequeNo { get; set; }

        [DataMember]
        public string MICR { get; set; }

    }
}
