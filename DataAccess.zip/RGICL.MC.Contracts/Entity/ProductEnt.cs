﻿using System.Runtime.Serialization;
using System.Collections.Generic;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class ProductEnt:ParentDetails
    {
        #region Public Properties

        [DataMember]
        public int ProductId { get; set; }
        [DataMember]
        public string ProductCode { get; set; }
        [DataMember]
        public string ProductName { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public List<MakeEnt> Make { get; set; }
        [DataMember]
        public int VehicleTypeId { get; set; }
        [DataMember]
        public string VehicleTypeName { get; set; }
        [DataMember]
        public int ProductMinGrade { get; set; }
        [DataMember]
        public int ProductMaxGrade { get; set; }
        #endregion

    }
}
