﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class CustomExceptionEnt
    {
        #region Public Properties
        [DataMember]
        public string ErrorCode { get; set; }
        [DataMember]
        public string ExceptionDetail { get; set; }
        [DataMember]
        public string CustomMessage { get; set; }
        #endregion
    }
}
