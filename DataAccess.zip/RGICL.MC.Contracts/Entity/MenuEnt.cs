﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGICL.MC.Contracts.Entity
{
    public class Menu
    {
        public int Id { get; set; }
        public string DisplayName { get; set; }
        public string PageUrl { get; set; }
        public int ParentId { get; set; }
        public int OrderNo { get; set; }
    }
}
