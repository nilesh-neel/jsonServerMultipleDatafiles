﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class DriverEnt
    {

        [DataMember]
        [Description("DriverID")]
        public int DriverID { get; set; }

        [DataMember]
        [Description("ClaimRefNo")]
        public string ClaimRefNo { get; set; }

        [DataMember]
        [Description("DriverName")]
        public string DriverName { get; set; }

        [DataMember]
        [Description("Age")]
        public int Age { get; set; }

        [DataMember]
        [Description("VehicleAuthorizedDriver")]
        public bool VehicleAuthorizedDriver { get; set; }

        [DataMember]
        [Description("Gender")]
        public string Gender { get; set; }


        [DataMember]
        [Description("DriverRelationship")]
        public string DriverRelationship { get; set; }

        [DataMember]
        [Description("DLIssueDate")]
        public DateTime DLIssueDate { get; set; }

        [DataMember]
        [Description("DLExpiryDate")]
        public DateTime DLExpiryDate{ get; set; }        

        [DataMember]
        [Description("LicensingAuthority")]
        public string LicensingAuthority { get; set; }

        [DataMember]
        [Description("LicenseNumber")]
        public string LicenseNumber { get; set; }

        [DataMember]
        [Description("DateOfBirth")]
        public DateTime DateOfBirth { get; set; }

        [DataMember]
        [Description("IsAlcohol")]
        public bool IsAlcohol { get; set; }

        [DataMember]
        [Description("TypeOfLicence")]
        public string TypeOfLicence { get; set; }

        [DataMember]
        [Description("Occupation")]
        public string Occupation { get; set; }
         
        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }

        [DataMember]
        [Description("VehicleAuthorizedToDrive")]
        public int VehicleAuthorizedToDrive { get; set; }
    }
}
