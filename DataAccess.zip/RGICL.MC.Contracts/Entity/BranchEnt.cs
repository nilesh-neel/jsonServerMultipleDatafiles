﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class BranchEnt
    {
        [DataMember]
        public string BranchId { get; set; }
        [DataMember]
        public string BranchCode { get; set; }
        [DataMember]
        public string BranchName { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string Pincode { get; set; }
        [DataMember]
        public CityEnt CityOrVillage { get; set; }
        [DataMember]
        public string District { get; set; }
        [DataMember]
        public StateEnt State { get; set; }
        [DataMember]
        public CountryEnt Country { get; set; }        
        [DataMember]
        public string PickupLocation { get; set; }
        [DataMember]
        public string PickupPoint { get; set; }
        [DataMember]
        public string BankACCId { get; set; }
        [DataMember]
        public string BusinessArea { get; set; }
        [DataMember]
        public string StdCode { get; set; }
        [DataMember]
        public string Phone { get; set; }
        [DataMember]
        public string FaxStdCode { get; set; }
        [DataMember]
        public string Fax { get; set; }
        [DataMember]
        public string ProfitCenter { get; set; }
        [DataMember]
        public string CreatedDate { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public string Branch_Region_Id { get; set; }//Need to Veriy 
        [DataMember]
        public string Parent_Branch_Id { get; set; }//Need to Veriy 
        [DataMember]
        public string Functional_Parent_Branch_Id { get; set; }//Need to verify
        [DataMember]
        public string System_Branch_ID { get; set; }
        [DataMember]
        public string Region_Code { get; set; } //Prepare Class
        [DataMember]
        public string Zone_Code { get; set; } //Prepare Class
        [DataMember]
        public string Branch_Type_Name { get; set; }
        [DataMember]
        public int New_Branch_Code { get; set; }
    }
}
