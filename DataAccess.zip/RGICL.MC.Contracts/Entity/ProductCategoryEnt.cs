﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class ProductCategoryEnt : ParentDetails
    {
        [DataMember]
        public int CategoryId { get; set; }
        [DataMember]
        public string CategoryName { get; set; }
        [DataMember]
        public decimal CatMinLimit { get; set; }
        [DataMember]
        public decimal CatMaxLimit { get; set; }
        [DataMember]
        public bool MapToUser { get; set; }
        [DataMember]
        public List<ProductEnt> Product { get; set; }
        [DataMember]
        public List<NatureOfLossEnt> TypeOfLoss { get; set; }
        [DataMember]
        public List<GradeApproval> GradeApproval { get; set; }
        [DataMember]
        public GradeEnt ProdCategoryGrades { get; set; }
    }
}
