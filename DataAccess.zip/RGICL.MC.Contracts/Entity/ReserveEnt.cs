﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public  class ReserveEnt
    {
        [DataMember]
        public string ClaimRefNo { get; set; }

        [DataMember]
        public int ReserveId { get; set; }

        [DataMember]
        public double ReserveAmount { get; set; }

        [DataMember]
        public int ReserveType { get; set; }

        [DataMember]
        public int ReserveEventId { get; set; }

        [DataMember]
        public int CreatedBy { get; set; }

        [DataMember]
        public int UpdatedBy { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public DateTime UpdatedDate { get; set; }
    }
}
