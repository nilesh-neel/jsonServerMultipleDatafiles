﻿using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class LookupEnt
    {
        [DataMember]
        public int LookupID 
        {
            get;
            set;
        }
        [DataMember]
        public int LookupTypeID
        {
            get;
            set;
        }

        [DataMember]
        public string LookupTypeName
        {
            get;
            set;
        }
        [DataMember]
        public string LookupName
        {
            get;
            set;
        }

        [DataMember]
        public bool IsActive
        {
            get;
            set;
        }
    }
}
