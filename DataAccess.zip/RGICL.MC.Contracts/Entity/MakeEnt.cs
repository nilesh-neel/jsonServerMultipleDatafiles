﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class MakeEnt
    {
        [DataMember]
        public int MakeId { get; set; }      
        
        [DataMember]
        public string MakeName { get; set; }       
        
        [DataMember]
        public string MakeProductID {get;set;}
        
        [DataMember]
        public List<ModelEnt> Model { get; set; }
    }
}
