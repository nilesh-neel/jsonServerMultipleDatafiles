﻿using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Entity.Entity
{
    [DataContract]
    public class Product
    {
        #region Public Properties
       
        [DataMember]
        public int ProductID { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public int LobID { get; set; }
        [DataMember]
        public decimal DefaultReserve { get; set; }
        [DataMember]
        public decimal DefaultSPFees { get; set; }
        [DataMember]
        public bool VehicalType { get; set; }
        [DataMember]
        public int MotorType { get; set; }
        [DataMember]
        public int MOMID { get; set; }
        [DataMember]
        public bool Status { get; set; }
        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public int VehTypeId { get; set; }
        [DataMember]
        public bool ECSRouterFlag { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }

        #endregion

    }
}
