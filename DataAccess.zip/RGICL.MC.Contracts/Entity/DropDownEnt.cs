﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class DropDownEnt
    {
        [DataMember]
        public int DropDownValue
        {
            get;
            set;
        }
        [DataMember]
        public string DropDownText
        {
            get;
            set;
        }

    }
}
