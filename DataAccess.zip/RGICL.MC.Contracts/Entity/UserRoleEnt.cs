﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    public class UserRoleEnt : ParentDetails
    {
        public int RoleId { get; set; }
        public string RoleCode { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
    }
}
