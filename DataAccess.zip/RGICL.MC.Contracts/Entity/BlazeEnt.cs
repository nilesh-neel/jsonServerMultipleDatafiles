﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class BlazeEnt
    {
        [DataMember]
        public string CurrClaimRefNo { get; set; } 

        [DataMember]
        public string CurrClaimIntimationDate { get; set; }

        [DataMember]
        public string CurrDateOfLoss { get; set; }

        [DataMember]
        public string PrevCaimRefNo { get; set; }

        [DataMember]
        public string PrevClaimSettlemetDate { get; set; } 

        [DataMember]
        public string AllPrevClaims { get; set; }

        [DataMember]
        public string PrevClaimStatus { get; set; }

        [DataMember]
        public string IsIRDAComplaint { get; set; }

        [DataMember]        
        public string PolicyNo { get; set; }

        [DataMember]
        public string CoverNoteNo { get; set; }

        [DataMember]
        public int ClaimCount { get; set; }

        [DataMember]
        public string PrevClaimIntimationDate { get; set; }

        [DataMember]
        public string InputXML { get; set; }

        [DataMember]
        public string OutputXML { get; set; }

        [DataMember]
        public double ScoreCount { get; set; }

        [DataMember]
        public int NoOfRules { get; set; }

        [DataMember]
        public string Rules { get; set; }

        [DataMember]
        public string ErrorCode { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }

        [DataMember]
        public int CreatedBy { get; set; }
       
    }
}
