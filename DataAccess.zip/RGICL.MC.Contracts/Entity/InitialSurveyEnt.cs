﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class InitialSurveyEnt
    {
        [DataMember]
        public int InitialSurveyID {get;set;}

        [DataMember]
        public string ClaimRefNo {get;set;}

        [DataMember]
        public bool VehicleReportedToGarage { get; set; }

        [DataMember]
        public DateTime SurveyDate { get; set; }

        [DataMember]
        public double EstimatedLoss { get; set; }

        [DataMember]
        public DateTime TentativeRepairDate { get; set; }

        [DataMember]
        public int ImpacttOfLoss { get; set; }

        [DataMember]
        public bool CatastrophicEventOfLoss { get; set; }

        [DataMember]
        public int LossEventID { get; set; } 

        [DataMember]
        public bool NegativeCustomer { get; set; }

        [DataMember]
        public string Remark { get; set; }

        [DataMember]
        public List<ReserveEnt> Reserve { get; set; }

        [DataMember]
        public int SettlementType { get; set; }

        [DataMember]
        public int CreatedBy { get; set; }

        [DataMember]
        public int UpdatedBy { get; set; }
    }
}
