﻿using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
   public class UserAuthorizationEnt
    {
        #region Public Properties

        [DataMember]
        public string PageID { get; set; }
        [DataMember]
        public string PageURL { get; set; }
        [DataMember]
        public bool IsReadOnly { get; set; }
       
        #endregion
    }
}
