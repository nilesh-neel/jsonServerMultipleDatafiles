﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class UserDetails
    {
        [DataMember]
        public List<UserRoleEnt> Role { get; set; }
        [DataMember]
        public List<ProductCategoryEnt> ProductCategory { get; set; }
        [DataMember]
        public List<ZoneEnt> Zone { get; set; }
        [DataMember]
        public List<MakerCheckerEnt> MakerChecker { get; set; }
        [DataMember]
        public List<NatureOfLossEnt> TypeOfLoss { get; set; }

    }
    [Serializable]
    [DataContract] 
    public class ParentDetails
    {
        [DataMember]
        public bool IsSelected { get; set; }
    }

    [DataContract]
    public class MakerCheckerEnt
    {
        [DataMember]
        public int MakerId { get; set; }
        [DataMember]
        public bool IsMaker { get; set; }
        [DataMember]
        public bool IsChecker { get; set; }
        [DataMember]
        public string PageId { get; set; }
        [DataMember]
        public string PageName { get; set; }
    }
}
