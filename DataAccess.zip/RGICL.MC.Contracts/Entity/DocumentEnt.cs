﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{

    public class FileEnt
    {
        [DataMember]
        public int DocID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public int? Type { get; set; }//0 for Spot and 1 for reinspection
        [DataMember]
        public string DocumentTypeName { get; set; } 
        [DataMember]
        public int? RQTYPE { get; set; }

    }
    public class DocumentEnt
    {
        [DataMember]
        public int DocClaimID { get; set; }
        [DataMember]
        public int DocID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public List<FileEnt> FileName { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public bool IsExternal { get; set; }
        [DataMember]
        public int NoOfDocument { get; set; }
        [DataMember]
        public DateTime RecievedDate { get; set; }
        [DataMember]
        public DateTime UploadDate { get; set; }
        [DataMember]
        public string DocDescription { get; set; }

        [DataMember]
        public int SubCategoryID { get; set; }
        [DataMember]
        public string DocumentTypeName { get; set; } 
    }
}
 