﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class LossEnt
    {       

        [DataMember]
        [Description("LossID")]
        public int LossId { get; set; }

        //[DataMember]
        //[Description("ClaimRefNo")]
        //public string ClaimRefNo { get; set; }

        [DataMember]
        [Description("DateOfLoss")]
        public DateTime DateOfLoss { get; set; }

        [DataMember]
        [Description("HourOfLoss")]
        public int HH { get; set; }

        [DataMember]
        [Description("MinOfLoss")]
        public int MM { get; set; }

        [DataMember]
        [Description("ReasonForDelayInIntimation")]
        public string ReasonForDelayInIntimation { get; set; }

        [DataMember]
        [Description("PrimaryTypeOfLoss")]
        public int PrimaryTypeOfLoss { get; set; }

        [DataMember]
        [Description("IsInjury")]
        public bool IsInjury { get; set; }

        [DataMember]
        [Description("IsSpotSurvey")]
        public bool IsSpotSurvey { get; set; }

        [DataMember]
        [Description("SecondaryTypeOfLoss")]
        public int SecondaryTypeOfLoss { get; set; }

        [DataMember]
        public string SecondaryLossDesc { get; set; }

        [DataMember]
        [Description("VehicleType")]
        public int VehicleType { get; set; }

        [DataMember]
        [Description("CurrentVehicleLocation")]
        public int CurrentVehicleLocation { get; set; }

        [DataMember]
        [Description("LossEvent")]
        public int LossEvent { get; set; }

        [DataMember]
        [Description("NatureOfLoss")]
        public string NatureOfLoss { get; set; }

        [DataMember]
        [Description("DescriptionOfLoss")]
        public string DescriptionOfLoss { get; set; }

        [DataMember]
        [Description("EstimatedLoss")]
        public double EstimatedLoss { get; set; }
        
        [DataMember]
        [Description("RelevantInformation")]
        public string RelevantInformation { get; set; }

        [DataMember]
        [Description("LocationOfLoss")]
        public int LocationOfLoss { get; set; }

        [DataMember]
        [Description("State_ID_PK")]
        public int State { get; set; }

        [DataMember]
        [Description("City_or_Village_ID_PK")]
        public int City { get; set; }

        [DataMember]
        [Description("IsTerrorism")]
        public bool IsTerrorism { get; set; }

        [DataMember]        
        [Description("IsGroupCompanyClaim")]
        public bool IsGroupCompanyClaim { get; set; }
        
        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }

        [DataMember]
        [Description("LocationOfSpot")]
        public int LocationOfSpot {get;set;}

        [DataMember]
        [Description("NearestLandmarkForSpot")]
        public string NearestLandmarkForSpot { get; set; }

        [DataMember]
        [Description("SpotContactPersonName")]
        public string SpotContactPersonName { get; set; }

        [DataMember]
        [Description("SpotContactPersonNumber")]
        public string SpotContactPersonNumber { get; set; }

        [DataMember]
        public string TimeOfLoss { get; set; }

        [DataMember]
        public string LocationName { get; set; }

        [DataMember]
        public string StateName { get; set; }
    }
}
