﻿using System;

namespace RGICL.MC.Contracts.Entity
{
    public class SampleEnt
    {
        #region Private Variables
        private int iEmpId = 0;
        private string sEmpName = string.Empty;
        private bool bIsActive = false;
        #endregion

        #region Public Properties
        public int EmpId 
        { 
            get { return iEmpId; }
            set { iEmpId = value; } 
        }
        public string EmpName 
        {
            get { return sEmpName; }
            set { sEmpName = value; }
        }
        public string Description { get; set; }
        public Boolean IsActive 
        {
            get { return bIsActive; }
            set { bIsActive = value; } 
        }
        #endregion
    }
}
