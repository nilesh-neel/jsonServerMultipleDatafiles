﻿using System;
using System.Collections.Generic;
namespace RGICL.MC.Contracts.Entity
{
    public class RemarksDetailsEnt
    {
        public int RemarkID { get; set; }
       
        public string RemarkDescription { get; set; }
        public ClaimEnt ClaimRefNo { get; set; }
        public UserInformationEnt CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}
