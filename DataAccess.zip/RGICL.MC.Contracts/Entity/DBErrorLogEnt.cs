﻿using System;

namespace RGICL.MC.Contracts.Entity
{
    public class DBErrorLogEnt
    {
        public string UserName { get; set; }
        public string ErrorProcedure { get; set; }
        public int ErrorLine { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime ErrorDate { get; set; }
    }
}
