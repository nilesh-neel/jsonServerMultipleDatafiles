﻿
using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class NatureOfLossEnt : ParentDetails
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string LossName { get; set; }
        [DataMember]
        public bool MapToUser { get; set; }

    }
}
