﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class PartsEnt
    {
        [DataMember]
        public int PartID
        {
            get;
            set;
        }
        [DataMember]
        public string PartDescription
        {
            get;
            set;
        }
        [DataMember]
        public bool ISActive
        {
            get;
            set;

        }
        [DataMember]
        public string VehicalCategory
        {
            get;
            set;

        }
        [DataMember]
        public int SubPartID
        {
            get;
            set;
        }
        [DataMember]
        public string SubPartDescription
        {
            get;
            set;
        }


    }
}
