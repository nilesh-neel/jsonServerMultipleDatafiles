﻿using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class LevelEnt
    {
        [DataMember]
        public int LevelId { get; set; }
        [DataMember]
        public string LevelName { get; set; }
        [DataMember]
        public double MinLevel { get; set; }
        [DataMember]
        public double MaxLevel { get; set; }
    }
}

