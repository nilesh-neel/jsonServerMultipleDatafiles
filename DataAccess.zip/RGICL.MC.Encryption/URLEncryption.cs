/****************************************************************************************************************
Class Name   : URLEncryption.cs 
Purpose      : Used to define utility functions for URL encryption.
Created By   : Ravi Kant Shivhare 
Created Date : 03/Oct/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"
using RGICL.MC.Common.Constants;
using RGICL.MC.Common.Utilities;
#endregion

namespace RGICL.MC.Encryption
{
    public static class URLEncryption
    {
        public const string EncyptionPrefix = "enc=";

        public static string EncryptURL(string strURL)
        {
            return EncryptURL(strURL, CustomEncryption.UniqueKey);
        }
        public static string EncryptURL(string strURL, string strUniqueKey)
        {
            if (string.IsNullOrEmpty(strURL))
                return string.Empty;
            if (!URLEncryption.IsURLEncryptionEnabled)
                return strURL;
            return URIUtility.GetURLWithoutQS(strURL) + "?" + EncryptQS(URIUtility.GetQS(strURL), strUniqueKey);
        }

        public static string EncryptQS(string strQS)
        {
            return EncryptQS(strQS, CustomEncryption.UniqueKey);
        }
        public static string EncryptQS(string strQS, string strUniqueKey)
        {
            if (string.IsNullOrEmpty(strQS))
                return string.Empty;
            if (!URLEncryption.IsURLEncryptionEnabled)
                return strQS;
            if (strQS.StartsWith("?"))
                strQS = strQS.Substring(1);
            strQS = strQS.Replace("%20", " ").Replace("%2f", "/").Replace("%3d", "=").Replace("%3f", "?");
            if (strQS.ToLower().StartsWith(EncyptionPrefix))
            {
                if (strQS.Contains("&"))//strQS contains Encrypted + NonEncrypted Query String
                {
                    strQS = strQS.Substring(strQS.IndexOf("=") + 1);
                    string strFirstPart = strQS.Substring(0, strQS.IndexOf("&"));
                    string strSecondPart = strQS.Substring(strQS.IndexOf("&"));
                    strQS = CustomEncryption.Decrypt(strFirstPart, strUniqueKey) + strSecondPart;
                }
                else
                {
                    return strQS;
                }
            }
            return EncyptionPrefix + CustomEncryption.Encrypt(strQS, strUniqueKey);
        }

        public static string DecryptURL(string strURL)
        {
            return DecryptURL(strURL, CustomEncryption.UniqueKey);
        }
        public static string DecryptURL(string strURL, string strUniqueKey)
        {
            if (string.IsNullOrEmpty(strURL))
                return string.Empty;
            if (!URLEncryption.IsURLEncryptionEnabled)
                return strURL;
            string strQS = URIUtility.GetQS(strURL);
            if (!strQS.ToLower().StartsWith(EncyptionPrefix))
                return strURL;
            return URIUtility.GetURLWithoutQS(strURL) + "?" + DecryptQS(strQS, strUniqueKey);
        }

        public static string DecryptQS(string strQS)
        {
            return DecryptQS(strQS, CustomEncryption.UniqueKey);
        }
        public static string DecryptQS(string strQS, string strUniqueKey)
        {
            if (string.IsNullOrEmpty(strQS))
                return string.Empty;
            if (!URLEncryption.IsURLEncryptionEnabled)
                return strQS;
            if (strQS.StartsWith("?"))
                strQS = strQS.Substring(1);
            if (!strQS.ToLower().StartsWith(EncyptionPrefix))
                return strQS;
            strQS = strQS.Substring(strQS.IndexOf("=") + 1);
            if (strQS.Contains("&"))
            {
                string strFirstPart = strQS.Substring(0, strQS.IndexOf("&"));
                string strSecondPart = strQS.Substring(strQS.IndexOf("&"));
                return CustomEncryption.Decrypt(strFirstPart, strUniqueKey) + strSecondPart;
            }
            else
            {
                return CustomEncryption.Decrypt(strQS, strUniqueKey);
            }
        }

        public static bool IsURLEncryptionEnabled
        {
            get { return AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.URLEncryptionEnabled); }
        }
    }

}
