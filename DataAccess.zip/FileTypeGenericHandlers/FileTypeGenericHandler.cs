﻿namespace FileTypeGenericHandlers
{
    using FileTypeGenericHandlers.Configuration;
    using FileTypeGenericHandlers.Log;
    using System;
    using System.Configuration;
    using System.IO;
    using System.Text;
    using System.Threading;
    using System.Web;

    public class FileTypeGenericHandler : IHttpHandler
    {
        public static ConfigExtension ConfigExtension;

        static FileTypeGenericHandler()
        {
            object obj3;
            ConfigExtension = null;
            object obj2 = new object();
            Monitor.Enter(obj3 = obj2);
            try
            {
                if (ConfigExtension == null)
                {
                    ConfigExtension = new ConfigExtension();
                    ConfigExtension = ConfigurationManager.GetSection("HandlerConfiguration") as ConfigExtension;
                }
            }
            catch (Exception exception)
            {
                Logger.Info("Exception thrown while trying to configure- " + exception.Message + "\n Stack Trace-" + exception.StackTrace);
            }
            finally
            {
                Monitor.Exit(obj3);
            }
        }

        private string GetContentType(string fileExtension, ConfigCollection configCollection)
        {
            string contentType = string.Empty;
            foreach (ConfigElement element in configCollection)
            {
                if (element.ElementValue.ToUpper() == fileExtension.ToUpper())
                {
                    contentType = element.ContentType;
                    Logger.Info("Got the content Type as " + contentType);
                    return contentType;
                }
            }
            return contentType;
        }

        private bool isExceptionalPage(string PageUrl)
        {
            bool flag = false;
            bool result = false;
            bool.TryParse(ConfigExtension.IsDBEnable.ElementValue, out result);
            Logger.Info("Page Url is -" + PageUrl);
            if (!result)
            {
                foreach (ConfigElement element in ConfigExtension.ExceptionPage)
                {
                    if (element.ElementValue.ToUpper() == PageUrl.ToUpper())
                    {
                        flag = true;
                        Logger.Info("Page found in exception List");
                        return flag;
                    }
                }
            }
            return flag;
        }

        private void RedirectToPage(string ContentType, HttpContext context)
        {
            context.Response.ContentType = ContentType;
            context.Response.ContentEncoding = Encoding.UTF8;
            if (File.Exists(context.Request.PhysicalPath))
            {
                Logger.Info("File present at path -" + context.Request.PhysicalPath);
                Logger.Info("Content Type for File is - " + ContentType);
                string s = File.ReadAllText(context.Request.PhysicalPath);
                context.Response.Write(s);
            }
            else
            {
                Logger.Info("File not Found, returned with status Code 404");
                context.Response.StatusCode = 0x194;
            }
        }

        void IHttpHandler.ProcessRequest(HttpContext context)
        {
            try
            {
                if ((context != null) && (ConfigExtension != null))
                {
                    string filePath = context.Request.FilePath;
                    string extension = VirtualPathUtility.GetExtension(filePath);
                    Logger.Info("Request From Host- " + context.Request.Url.Host + "\nFor page URL- " + context.Request.Url.AbsoluteUri);
                    Logger.Info("Processing context for File Path-" + filePath);
                    Logger.Info("Checking if Extension is in Serve List");
                    string contentType = this.GetContentType(extension, ConfigExtension.ExtensionToServe);
                    if (!string.IsNullOrEmpty(contentType))
                    {
                        this.RedirectToPage(contentType, context);
                    }
                    else
                    {
                        Logger.Info("Checking if Extension is in Blocked List");
                        string str4 = this.GetContentType(extension, ConfigExtension.ExtensionToBlock);
                        if (!string.IsNullOrEmpty(str4))
                        {
                            Logger.Info("Checking if file Path is exception -" + filePath);
                            if (this.isExceptionalPage(filePath))
                            {
                                this.RedirectToPage(str4, context);
                            }
                            else
                            {
                                Logger.Info("Blocking the Page-" + filePath);
                                if (File.Exists(context.Request.PhysicalPath))
                                {
                                    Logger.Info("Physicaly Page Exist");
                                    context.Response.Write("<html  xmlns=http://www.w3.org/1999/xhtml><head><title>Access Forbidden</title></head><body align='center'><h1>Access To Page is Forbidden.</h1></body></html>");
                                }
                                else
                                {
                                    Logger.Info("Physicaly Page does not Exist");
                                    context.Response.StatusCode = 0x194;
                                }
                            }
                        }
                        else
                        {
                            context.Response.StatusCode = 0x194;
                            Logger.Info("Extension neither in serve List nor in blocked List- " + filePath + "/n");
                            this.RedirectToPage("text/html", context);
                        }
                    }
                }
                else
                {
                    Logger.Info("Configuration failed");
                    if (context != null)
                    {
                        context.Response.Write("Handler Configuration returned null.");
                    }
                }
            }
            catch (Exception exception)
            {
                if (context != null)
                {
                    context.Response.Write("Exception occured-" + exception.Message + "\n Stack Trace-" + exception.StackTrace);
                }
            }
        }

        bool IHttpHandler.IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}

