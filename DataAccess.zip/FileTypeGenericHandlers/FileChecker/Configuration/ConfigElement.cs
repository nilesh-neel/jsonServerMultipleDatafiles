﻿namespace FileTypeGenericHandlers.FileChecker.Configuration
{
    using System;
    using System.Configuration;

    public class ConfigElement : ConfigurationElement
    {
        [ConfigurationProperty("value", IsRequired=true)]
        public string ElementValue
        {
            get
            {
                return (string) base["value"];
            }
            set
            {
                base["value"] = value;
            }
        }

        [ConfigurationProperty("HexValue", IsRequired=true)]
        public string HexValue
        {
            get
            {
                return (string) base["HexValue"];
            }
            set
            {
                base["HexValue"] = value;
            }
        }

        [ConfigurationProperty("Offset", IsRequired=false)]
        public long Offset
        {
            get
            {
                return (long) base["Offset"];
            }
            set
            {
                base["Offset"] = value;
            }
        }
    }
}

