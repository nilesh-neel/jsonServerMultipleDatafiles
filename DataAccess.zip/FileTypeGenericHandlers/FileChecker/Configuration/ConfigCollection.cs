﻿namespace FileTypeGenericHandlers.FileChecker.Configuration
{
    using System;
    using System.Configuration;

    public class ConfigCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new ConfigElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ConfigElement) element).ElementValue;
        }

        public string GetValueByIndex(int index)
        {
            string elementValue = string.Empty;
            try
            {
                if (base.BaseGet(index) != null)
                {
                    ConfigElement element = (ConfigElement) base.BaseGet(index);
                    elementValue = element.ElementValue;
                }
            }
            catch (Exception)
            {
                elementValue = "";
            }
            return elementValue;
        }

        public ConfigElement GetValuebyIndex(string index)
        {
            ConfigElement element = null;
            try
            {
                if (base.BaseGet(index) != null)
                {
                    element = (ConfigElement)base.BaseGet(index);
                }
            }
            catch (Exception)
            {
                element = null;
            }
            return element;
        }
    }
}

