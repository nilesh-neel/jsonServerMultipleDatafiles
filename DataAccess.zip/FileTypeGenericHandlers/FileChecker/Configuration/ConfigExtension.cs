﻿namespace FileTypeGenericHandlers.FileChecker.Configuration
{
    using System.Configuration;

    public class ConfigExtension : ConfigurationSection
    {
        [ConfigurationProperty("extensionToFind", IsDefaultCollection=false)]
        public ConfigCollection ExtensionToFind
        {
            get
            {
                return (ConfigCollection) base["extensionToFind"];
            }
        }
    }
}

