﻿namespace FileTypeGenericHandlers.Configuration
{
    using System.Configuration;

    public class ConfigExtension : ConfigurationSection
    {
        [ConfigurationProperty("connectionStringName")]
        public ConfigElement ConnectionStringName
        {
            get
            {
                return (ConfigElement) base["connectionStringName"];
            }
        }

        [ConfigurationProperty("exceptionalPages", IsDefaultCollection=false)]
        public ConfigCollection ExceptionPage
        {
            get
            {
                return (ConfigCollection) base["exceptionalPages"];
            }
        }

        [ConfigurationProperty("extensionToBlock", IsDefaultCollection=false)]
        public ConfigCollection ExtensionToBlock
        {
            get
            {
                return (ConfigCollection) base["extensionToBlock"];
            }
        }

        [ConfigurationProperty("extensionToServe", IsDefaultCollection=false)]
        public ConfigCollection ExtensionToServe
        {
            get
            {
                return (ConfigCollection) base["extensionToServe"];
            }
        }

        [ConfigurationProperty("isDBEnable")]
        public ConfigElement IsDBEnable
        {
            get
            {
                return (ConfigElement) base["isDBEnable"];
            }
        }

        [ConfigurationProperty("isLogEnable")]
        public ConfigElement IsLogEnable
        {
            get
            {
                return (ConfigElement) base["isLogEnable"];
            }
        }
    }
}

