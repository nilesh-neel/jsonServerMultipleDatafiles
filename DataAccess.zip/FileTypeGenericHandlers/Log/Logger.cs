﻿namespace FileTypeGenericHandlers.Log
{
    using FileTypeGenericHandlers;
    using System;
    using System.IO;

    internal static class Logger
    {
        private static string filePath = "C:/TEMP/HANDLER_LOG.txt";

        public static void Info(string message)
        {
            bool result = false;
            if (FileTypeGenericHandler.ConfigExtension != null)
            {
                bool.TryParse(FileTypeGenericHandler.ConfigExtension.IsLogEnable.ElementValue, out result);
            }
            if (result)
            {
                try
                {
                    StreamWriter writer;
                    if (!File.Exists(filePath))
                    {
                        writer = new StreamWriter(filePath);
                    }
                    else
                    {
                        writer = File.AppendText(filePath);
                    }
                    writer.WriteLine(DateTime.Now);
                    writer.WriteLine(message);
                    writer.WriteLine();
                    writer.Close();
                }
                catch
                {
                }
            }
        }
    }
}

