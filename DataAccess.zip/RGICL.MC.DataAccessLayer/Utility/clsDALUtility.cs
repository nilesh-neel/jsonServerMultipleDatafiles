﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace RGICL.MC.DataAccessLayer
{
    class clsDALUtility
    {
        protected DataSet DataReaderToDataSet(SqlDataReader sdr)
        {
            DataSet ds = new DataSet();
            DataTable schemaTable = sdr.GetSchemaTable();
            DataTable dataTable = new DataTable();
            for (int i = 0; i < schemaTable.Rows.Count; i++)
            {
                DataRow dataRow = schemaTable.Rows[i];

                string columnName = (string)dataRow["ColumnName"];

                DataColumn column = new DataColumn(columnName, (Type)dataRow["DataType"]);
                dataTable.Columns.Add(column);
            }

            ds.Tables.Add(dataTable);
            while (sdr.Read())
            {
                DataRow dataRow = dataTable.NewRow();

                for (int i = 0; i < sdr.FieldCount; i++)
                    dataRow[i] = sdr.GetValue(i);

                dataTable.Rows.Add(dataRow);
            }
            return ds;
        }

        protected DataTable DataReaderToDataTable(SqlDataReader sdr, string strTableName)
        {
            DataTable schemaTable = sdr.GetSchemaTable();
            DataTable dataTable = new DataTable(strTableName);
            for (int i = 0; i < schemaTable.Rows.Count; i++)
            {
                DataRow dataRow = schemaTable.Rows[i];

                string columnName = (string)dataRow["ColumnName"];

                DataColumn column = new DataColumn(columnName, (Type)dataRow["DataType"]);
                dataTable.Columns.Add(column);
            }
            while (sdr.Read())
            {
                DataRow dataRow = dataTable.NewRow();

                for (int i = 0; i < sdr.FieldCount; i++)
                    dataRow[i] = sdr.GetValue(i);

                dataTable.Rows.Add(dataRow);
            }
            return dataTable;
        }
    }
}
