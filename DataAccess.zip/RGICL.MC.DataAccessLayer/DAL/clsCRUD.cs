﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace RGICL.MC.DataAccessLayer
{
    public class clsCRUD : clsCommand
    {
        #region Select
        public int Select(string strCommand, out DataSet ds)
        {
            return ExecuteDataSet<IDataParameter>(strCommand, out ds, null);
        }
        public int Select(string strCommand, out DataSet ds, params IDataParameter[] idataParams)
        {
            return ExecuteDataSet<IDataParameter>(strCommand, out ds, idataParams);
        }
        public int Select(string strCommand, out DataSet ds, params SqlParameter[] oParams)
        {
            return ExecuteDataSet<SqlParameter>(strCommand, out ds, oParams);
        }
        public int Select(string strCommand, out DataSet ds, SqlParameterCollection oParamCollection)
        {
            return ExecuteDataSet<object>(strCommand, out ds, null, oParamCollection);//Note: object is used as generic datatype coz 2nd argiment is null
        }
        public int Select(string strCommand, out DataSet ds, DataTable dtData)
        {
            return ExecuteDataSet<object>(strCommand, out ds, null, null, dtData);//Note: object is used as generic datatype coz 2nd argiment is null
        }

        public int SelectXML(string strXMLFileName, out DataSet dsSelect, string strSearchKeyword)
        {
            return this.ExecuteXMLDataSet(strXMLFileName, out dsSelect, strSearchKeyword);
        }
        public int SelectXML(string strXMLFileName, out DataSet dsSelect, string strSearchKeyword, int iParentId)
        {
            return this.ExecuteXMLDataSet(strXMLFileName, out dsSelect, strSearchKeyword, iParentId);
        }
        public int SelectXML(string strXMLFileName, out DataSet dsSelect, string strSearchKeyword, int iParentId, string strXMLFolderPath)
        {
            return this.ExecuteXMLDataSet(strXMLFileName, out dsSelect, strSearchKeyword, iParentId, strXMLFolderPath);
        }
        #endregion

        #region Insert
        public int Insert(string strCommand, params IDataParameter[] idataParams)
        {
            return ExecuteNonQuery<IDataParameter>(strCommand, idataParams);
        }
        public int Insert(string strCommand, params SqlParameter[] oParams)
        {
            return ExecuteNonQuery<SqlParameter>(strCommand, oParams);
        }
        public int Insert(string strCommand, SqlParameterCollection oParamCollection)
        {
            return ExecuteNonQuery<object>(strCommand, null, oParamCollection);//Note: object is used as generic datatype coz 2nd argument is null
        }
        public int Insert(string strCommand, DataTable dtData)
        {
            return ExecuteNonQuery<object>(strCommand, null, null, dtData);//Note: object is used as generic datatype coz 2nd argument is null
        }

        public int Insert(string strCommand, out DataSet ds, params IDataParameter[] idataParams)
        {
            return ExecuteDataSet<IDataParameter>(strCommand, out ds, idataParams);
        }
        public int Insert(string strCommand, out DataSet ds, params SqlParameter[] oParams)
        {
            return ExecuteDataSet<SqlParameter>(strCommand, out ds, oParams);
        }
        public int Insert(string strCommand, out DataSet ds, SqlParameterCollection oParamCollection)
        {
            return ExecuteDataSet<object>(strCommand, out ds, null, oParamCollection);//Note: object is used as generic datatype coz 2nd argiment is null
        }
        public int Insert(string strCommand, out DataSet ds, DataTable dtData)
        {
            return ExecuteDataSet<object>(strCommand, out ds, null, null, dtData);//Note: object is used as generic datatype coz 2nd argiment is null
        }
        #endregion

        #region Update
        public int Update(string strCommand, params IDataParameter[] idataParams)
        {
            return ExecuteNonQuery<IDataParameter>(strCommand, idataParams);
        }
        public int Update(string strCommand, params SqlParameter[] oParams)
        {
            return ExecuteNonQuery<SqlParameter>(strCommand, oParams);
        }
        public int Update(string strCommand, SqlParameterCollection oParamCollection)
        {
            return ExecuteNonQuery<object>(strCommand, null, oParamCollection);//Note: object is used as generic datatype coz 2nd argument is null
        }
        public int Update(string strCommand, DataTable dtData)
        {
            return ExecuteNonQuery<object>(strCommand, null, null, dtData);//Note: object is used as generic datatype coz 2nd argument is null
        }

        public int Update(string strCommand, out DataSet ds, params IDataParameter[] idataParams)
        {
            return ExecuteDataSet<IDataParameter>(strCommand, out ds, idataParams);
        }
        public int Update(string strCommand, out DataSet ds, params SqlParameter[] oParams)
        {
            return ExecuteDataSet<SqlParameter>(strCommand, out ds, oParams);
        }
        public int Update(string strCommand, out DataSet ds, SqlParameterCollection oParamCollection)
        {
            return ExecuteDataSet<object>(strCommand, out ds, null, oParamCollection);//Note: object is used as generic datatype coz 2nd argiment is null
        }
        public int Update(string strCommand, out DataSet ds, DataTable dtData)
        {
            return ExecuteDataSet<object>(strCommand, out ds, null, null, dtData);//Note: object is used as generic datatype coz 2nd argiment is null
        }
        #endregion

        #region Delete
        public void Delete()
        {
        }
        #endregion

    }
}
