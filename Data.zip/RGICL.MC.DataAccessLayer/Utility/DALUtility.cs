﻿/****************************************************************************************************************
Class Name   : DALUtility.cs 
Purpose      : Used to define utility functions for DAL.
Created By   : Ravi Kant Shivhare 
Created Date : 03/Oct/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
#endregion

namespace DataAccessLayer
{
    class DALUtility
    {
        protected DataSet DataReaderToDataSet(SqlDataReader sdr)
        {
            DataSet ds = new DataSet();
            DataTable schemaTable = sdr.GetSchemaTable();
            DataTable dataTable = new DataTable();
            for (int i = 0; i < schemaTable.Rows.Count; i++)
            {
                DataRow dataRow = schemaTable.Rows[i];

                string columnName = (string)dataRow["ColumnName"];

                DataColumn column = new DataColumn(columnName, (Type)dataRow["DataType"]);
                dataTable.Columns.Add(column);
            }

            ds.Tables.Add(dataTable);
            while (sdr.Read())
            {
                DataRow dataRow = dataTable.NewRow();

                for (int i = 0; i < sdr.FieldCount; i++)
                    dataRow[i] = sdr.GetValue(i);

                dataTable.Rows.Add(dataRow);
            }
            return ds;
        }

        protected DataTable DataReaderToDataTable(SqlDataReader sdr, string strTableName)
        {
            DataTable schemaTable = sdr.GetSchemaTable();
            DataTable dataTable = new DataTable(strTableName);
            for (int i = 0; i < schemaTable.Rows.Count; i++)
            {
                DataRow dataRow = schemaTable.Rows[i];

                string columnName = (string)dataRow["ColumnName"];

                DataColumn column = new DataColumn(columnName, (Type)dataRow["DataType"]);
                dataTable.Columns.Add(column);
            }
            while (sdr.Read())
            {
                DataRow dataRow = dataTable.NewRow();

                for (int i = 0; i < sdr.FieldCount; i++)
                    dataRow[i] = sdr.GetValue(i);

                dataTable.Rows.Add(dataRow);
            }
            return dataTable;
        }
    }
}
