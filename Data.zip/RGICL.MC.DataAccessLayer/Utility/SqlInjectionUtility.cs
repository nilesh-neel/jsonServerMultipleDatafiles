﻿/****************************************************************************************************************
Class Name   : SqlInjectionUtility.cs 
Purpose      : Used to define utility functions for SQL Injection.
Created By   : Ravi Kant Shivhare 
Created Date : 03/Oct/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"
using System;
using System.Web;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;

using RGICL.MC.Common.Utilities;
using RGICL.MC.Common.Constants;
#endregion

namespace DataAccessLayer
{
    public static class SqlInjectionUtility
    {
        #region ExtractSqlCharacters
        public static String ExtractSqlCharacters(String pInString)
        {
            string returnValue = pInString;
            try
            {
                String[] BadChars = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.SqlCharacters).ToString().Replace(" ", "").Split(",".ToCharArray());
                returnValue = String.Join("", pInString.Split(BadChars, StringSplitOptions.None));

                return returnValue;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
                return returnValue;
            }
        }

        public static void ExtractSqlCharacters(SqlCommand oCommand)
        {
            try
            {
                LogUtility.WriteStackTraceLog(oCommand.CommandText);

                if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.SqlInjectionEnabled))
                {
                    //if (oCommand.CommandText == "USP_GetSPName")
                    //    return;

                    if (IsSkipPagesSqlInjection())
                        return;

                    bool bFound = false;
                    string sParamValueBeforeFilterApplied = string.Empty;
                    string[] arrsSkipParameters = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.SkipParameters).ToString().Trim().Split(new char[] { ',' });
                    foreach (SqlParameter oParam in oCommand.Parameters)
                    {
                        if (oParam.Direction == ParameterDirection.Output)
                            continue;

                        //Need to handle all DataTable and DataSet as well

                        LogUtility.WriteStringLog(oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(oParam.Value));

                        if (oParam.SqlDbType.ToString().ToLower().IndexOf("char") > -1)
                        {
                            bFound = false;
                            foreach (string strParam in arrsSkipParameters)
                            {
                                if (strParam.ToLower() == oParam.ToString().ToLower())
                                {
                                    bFound = true;
                                    break;
                                }
                            }
                            if (!bFound)
                            {
                                sParamValueBeforeFilterApplied = Convert.ToString(oParam.Value);
                                oParam.Value = SqlInjectionUtility.ExtractSqlCharacters(Convert.ToString(oParam.Value));

                                if (sParamValueBeforeFilterApplied != Convert.ToString(oParam.Value))
                                {
                                    LogUtility.WriteStringLog("After SQL Injection Filter Applied : " + oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(oParam.Value));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }

        }

        #region "Commented - Oracle"
        /*
        public static void ExtractSqlCharacters(System.Data.OracleClient.OracleCommand oCommand)
        {
            try
            {
                LogUtility.WriteStackTraceLog(oCommand.CommandText);

                if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.SqlInjectionEnabled))
                {
                    if (oCommand.CommandText == "USP_GetSPName")
                        return;

                    if (IsSkipPagesSqlInjection())
                        return;

                    bool bFound = false;
                    string sParamValueBeforeFilterApplied = string.Empty;
                    string[] arrsSkipParameters = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.SkipParameters).ToString().Trim().Split(new char[] { ',' });
                    foreach (System.Data.OracleClient.OracleParameter oParam in oCommand.Parameters)
                    {
                        if (oParam.Direction == ParameterDirection.Output)
                            continue;

                        LogUtility.WriteStringLog(oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(oParam.Value));

                        if (oParam.OracleType.ToString().ToLower().IndexOf("char") > -1)
                        {
                            bFound = false;
                            foreach (string strParam in arrsSkipParameters)
                            {
                                if (strParam.ToLower() == oParam.ToString().ToLower())
                                {
                                    bFound = true;
                                    break;
                                }
                            }
                            if (!bFound)
                            {
                                sParamValueBeforeFilterApplied = Convert.ToString(oParam.Value);
                                oParam.Value = c_SqlInjection.ExtractSqlCharacters(Convert.ToString(oParam.Value));

                                if (sParamValueBeforeFilterApplied != Convert.ToString(oParam.Value))
                                {
                                    LogUtility.WriteStringLog("After SQL Injection Filter Applied : " + oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(oParam.Value));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }
        */
        /*
        public static void ExtractSqlCharacters(Oracle.DataAccess.Client.OracleCommand oCommand)
        {
            try
            {
                if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.SqlInjectionEnabled))
                {
                    if (oCommand.CommandText == "USP_GetSPName")
                        return;
         
                    if (IsSkipPagesSqlInjection())
                        return;
         
                    bool bFound = false;
                    string sParamValueBeforeFilterApplied = string.Empty;
                    string[] arrsSkipParameters = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.SkipParameters).ToString().Trim().Split(new char[] { ',' });
                    foreach (Oracle.DataAccess.Client.OracleParameter oParam in oCommand.Parameters)
                    {
                        if (oParam.Direction == ParameterDirection.Output)
                            continue;
                        
                        if (oParam.CollectionType != Oracle.DataAccess.Client.OracleCollectionType.PLSQLAssociativeArray)
                        {
                            LogUtility.WriteStringLog(oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(oParam.Value));
                        }
                        if (oParam.OracleDbType.ToString().ToLower().IndexOf("char") > -1)
                        {
                            bFound = false;
                            foreach (string strParam in arrsSkipParameters)
                            {
                                if (strParam.ToLower() == oParam.ToString().ToLower())
                                {
                                    bFound = true;
                                    break;
                                }
                            }
                            if (!bFound)
                            {
                                if (oParam.CollectionType == Oracle.DataAccess.Client.OracleCollectionType.PLSQLAssociativeArray)
                                {
                                    string[] arrParam = new string[((string[])oParam.Value).Length];
                                    arrParam = ((string[])(oParam.Value));
                                    string[] arrParamNew = new string[arrParam.Length];
                                    for (int iParamIndex = 0; iParamIndex < arrParam.Length; iParamIndex++)
                                    {
                                        LogUtility.WriteStringLog(oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(arrParamNew[iParamIndex]));
                                        
                                        sParamValueBeforeFilterApplied = Convert.ToString(arrParamNew[iParamIndex]);
                                        arrParamNew[iParamIndex] = c_SqlInjection.ExtractSqlCharacters(Convert.ToString(arrParam[iParamIndex]));
                                        
                                        if (sParamValueBeforeFilterApplied != Convert.ToString(arrParamNew[iParamIndex]))
                                        {
                                            LogUtility.WriteStringLog("After SQL Injection Filter Applied : " + oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(arrParamNew[iParamIndex]));
                                        }
                                    }
                                    oParam.Value = arrParamNew;
                                }
                                else
                                {
                                    sParamValueBeforeFilterApplied = Convert.ToString(oParam.Value);
                                    oParam.Value = c_SqlInjection.ExtractSqlCharacters(Convert.ToString(oParam.Value));
          
                                    if (sParamValueBeforeFilterApplied != Convert.ToString(oParam.Value))
                                    {
                                        LogUtility.WriteStringLog("After SQL Injection Filter Applied : " + oCommand.CommandText + "-" + oParam.ToString() + "-" + Convert.ToString(oParam.Value));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }
        */
        #endregion
        #endregion

        private static bool IsSkipPagesSqlInjection()
        {
            return CommonUtility.IsSkipPages(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.SkipPagesSqlInjection));
        }

        private static string GetPageName(string strURL)
        {
            int intEndIndex = strURL.IndexOf('?');
            if (intEndIndex == -1)
            {
                intEndIndex = strURL.Length;
            }
            int intStartIndex = strURL.Substring(0, intEndIndex).LastIndexOf('/') + 1;
            return strURL.Substring(intStartIndex, (intEndIndex - intStartIndex));
        }
    }
}
