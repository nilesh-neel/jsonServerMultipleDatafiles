﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.IO;

using RGICL.MC.DataAccessLayer;
using RGICL.MC.Common.Utilities;
using RGICL.MC.Common.Constants;

namespace RGICL.MC.DataAccessLayer
{
    public class clsCommand : clsParams
    {
        #region Private Members
        private long _sErrorNumber;
        private string _sErrorDescription;
        int _iErrorNo = -9999;
        private const string P_ERROR_NO = "@P_ERROR_NO";
        #endregion

        #region Constructor
        public clsCommand()
        {
            ClearErrors();
        }
        #endregion

        //Protected fn(inherited by clsCRUD) - ExecuteNonQuery, ExecuteDataSet(adapter.fill), ExecuteXMLDataSet(read XML and return dataset)
        #region Functions
        #region Common Functions
        protected void ClearErrors()
        {
            _sErrorNumber = 0;
            _sErrorDescription = "";
        }
        protected int ReturnErrorNo(string sErrorNum)
        {
            if (!string.IsNullOrEmpty(sErrorNum))
                return int.Parse(sErrorNum);
            return _iErrorNo;
        }
        #endregion

        #region ExecuteNonQuery
        //private int ExecuteNonQuery(string strCommand, DataTable dtData, object[] objParams,  string[] strParams, SqlParameter[] sqlParams, IDataParameter[] idataParams)
        protected int ExecuteNonQuery<T>(string strCommand, T[] tParams, SqlParameterCollection oParamCollection = null, DataTable dtData = null)
        {
            this.ClearErrors();
            clsConnection objConn = null;

            try
            {
                if (!string.IsNullOrEmpty(strCommand))
                {
                    objConn = new clsConnection();
                    //using (SqlConnection connection = new SqlConnection(clsConnection.ConnectionString))
                    using (SqlConnection connection = objConn.OpenConnection())
                    {
                        //connection.Open();

                        using (SqlCommand command = new SqlCommand(strCommand, connection))
                        {
                            command.CommandType = CommandType.StoredProcedure;

                            if (tParams != null)
                            {
                                if (typeof(T) == typeof(IDataParameter) || typeof(T) == typeof(SqlParameter))
                                    command.Parameters.AddRange(tParams);
                            }
                            else if (oParamCollection != null)
                            {
                                AttachParameters(command, oParamCollection);
                            }
                            else if (dtData != null)
                            {
                                command.Parameters.AddWithValue("@TableVar", dtData);
                            }
                            command.Parameters.Add(CreateParameterError(P_ERROR_NO));
                            
                            clsSqlInjection.ExtractSqlCharacters(command);

                            using (SqlTransaction transaction = objConn.BeginTransaction(connection))
                            {
                                try
                                {
                                    command.Transaction = transaction;

                                    command.ExecuteNonQuery();

                                    objConn.CommitTransaction(transaction);
                                    
                                    return ReturnErrorNo(command.Parameters[P_ERROR_NO].Value.ToString());
                                }
                                catch (Exception ex1)
                                {
                                    try
                                    {
                                        objConn.RollBackTransaction(transaction);
                                    }
                                    catch (Exception ex2)
                                    {
                                        //"Rollback Exception Type: {0}", ex2.GetType()
                                    }
                                    //throw ex1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    ErrorNumber = -1;
                    ErrorDescription = "Command was not set for SqlCommand.";
                    return 0;
                }
            }
            catch (Exception ex)
            {
                ErrorNumber = -1;
                ErrorDescription = ex.Message;
            }
            return 1;
        }

        /*
        protected int ExecuteNonQuery(string strCommand, string[] sParams)
        {
            return 0;
        }
        protected int ExecuteNonQuery(string strCommand, params object[] oParams)
        {
            return 0;
        }
        */
        #region Not Used - Without Generic
        /*
        protected int ExecuteNonQuery(string strCommand, params IDataParameter[] idataParams)
        {
            this.ClearErrors();
            clsConnection objConn = null;
            //int iReturnErrorNum = 0;

            try
            {
                if (!string.IsNullOrEmpty(strCommand))
                {
                    objConn = new clsConnection();
                    //using (SqlConnection connection = new SqlConnection(clsConnection.ConnectionString))
                    using (SqlConnection connection = objConn.OpenConnection())
                    {
                        //connection.Open();

                        using (SqlCommand command = new SqlCommand(strCommand, connection))
                        {
                            command.CommandType = CommandType.StoredProcedure;

                            if (idataParams != null)
                            {
                                command.Parameters.AddRange(idataParams);
                            }

                            command.Parameters.Add(CreateParameterError(P_ERROR_NO));

                            using (SqlTransaction transaction = objConn.BeginTransaction(connection))
                            {
                                try
                                {
                                    command.Transaction = transaction;

                                    clsSqlInjection.ExtractSqlCharacters(command);
                                    //iReturnErrorNum = command.ExecuteNonQuery();
                                    command.ExecuteNonQuery();

                                    objConn.CommitTransaction(transaction);
                                    //return iReturnErrorNum;

                                    return ReturnErrorNo(command.Parameters[P_ERROR_NO].Value.ToString());
                                }
                                catch (Exception ex1)
                                {
                                    try
                                    {
                                        objConn.RollBackTransaction(transaction);
                                    }
                                    catch (Exception ex2)
                                    {
                                        //"Rollback Exception Type: {0}", ex2.GetType()
                                    }
                                    //throw ex1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    ErrorNumber = -1;
                    ErrorDescription = "Command was not set for SqlCommand.";
                    return 0;
                }
            }
            catch (Exception ex)
            {
                ErrorNumber = -1;
                ErrorDescription = ex.Message;
            }
            return 1;
        }
        */
        #endregion
        #region Not Used - Explictly Open & Close Connection
        /*
        protected int ExecuteNonQuery(string strCommand, ref DataSet ds, params IDataParameter[] procParams)
        {
            this.ClearErrors();
            clsConnection objConn = null;
            //int iReturnErrorNum = 0;

            try
            {
                if (!string.IsNullOrEmpty(strCommand))
                {
                    objConn = new clsConnection();
                    SqlConnection connection = objConn.OpenConnection();

                    using (SqlCommand command = new SqlCommand(strCommand, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        if (procParams != null)
                        {
                            command.Parameters.AddRange(procParams);
                        }
                        
                        clsSqlInjection.ExtractSqlCharacters(command);

                        SqlTransaction transaction = objConn.BeginTransaction(connection);
                        try
                        {
                            command.Transaction = transaction;

                            //iReturnErrorNum = command.ExecuteNonQuery();
                            command.ExecuteNonQuery();

                            objConn.CommitTransaction(transaction);
                            
                            //return iReturnErrorNum;
                            return ReturnErrorNo(command.Parameters[P_ERROR_NO].Value.ToString());
                        }
                        catch (Exception ex1)
                        {
                            try
                            {
                                objConn.RollBackTransaction(transaction);
                            }
                            catch (Exception ex2)
                            {
                                //"Rollback Exception Type: {0}", ex2.GetType()
                            }
                            //throw ex1;
                        }
                        finally
                        {
                            objConn.CloseConnection();
                        }
                    }
                }
                else
                {
                    ErrorNumber = -1;
                    ErrorDescription = "Command was not set for SqlCommand.";
                    return 0;
                }
            }
            catch (Exception ex)
            {
                ErrorNumber = -1;
                ErrorDescription = ex.Message;
            }
            finally
            {
                objConn.CloseConnection();
            }
            return 1;
        }
        */
        #endregion
        #endregion

        #region ExecuteDataSet
        protected int ExecuteDataSet<T>(string strCommand, out DataSet ds, T[] tParams, SqlParameterCollection oParamCollection = null, DataTable dtData = null)
        {
            int iReturnValue = 0;
            ds = new DataSet();
            try
            {
                using (SqlConnection connection = new SqlConnection(clsConnection.ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(strCommand, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            if (tParams != null)
                            {
                                if (typeof(T) == typeof(IDataParameter) || typeof(T) == typeof(SqlParameter))
                                    command.Parameters.AddRange(tParams);
                            }
                            else if (oParamCollection != null)
                            {
                                AttachParameters(command, oParamCollection);
                            }
                            else if (dtData != null)
                            {
                                command.Parameters.AddWithValue("@TableVar", dtData);
                            }
                            command.Parameters.Add(CreateParameterError(P_ERROR_NO));

                            clsSqlInjection.ExtractSqlCharacters(command);

                            ds = new DataSet();
                            adapter.Fill(ds);

                            return ReturnErrorNo(command.Parameters[P_ERROR_NO].Value.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                iReturnValue = 0x65;
            }
            return iReturnValue;
        }

        #region Not Used - Without Generic
        /*
        protected int ExecuteDataSet(string strCommand, ref DataSet ds, params IDataParameter[] procParams)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(clsConnection.ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(strCommand, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            if (procParams != null)
                            {
                                command.Parameters.AddRange(procParams);
                            }
                            command.Parameters.Add(CreateParameterError(P_ERROR_NO));

                            clsSqlInjection.ExtractSqlCharacters(command);

                            ds = new DataSet();
                            adapter.Fill(ds);

                            return ReturnErrorNo(command.Parameters[P_ERROR_NO].Value.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return 0;
        }*/
        #endregion
        #endregion

        #region ExecuteXMLDataSet
        protected int ExecuteXMLDataSet(string strXMLFileName, out DataSet ds, string strSearchKeyword, int iParentId = -1, string strXMLFolderPath = "")
        {
            int iReturnValue = 0;
            ds = new DataSet();
            try
            {
                if (string.IsNullOrEmpty(strXMLFileName))
                    return 1;
                else
                {
                    string strFilePathAndName = "";
                    if (strXMLFolderPath == "")
                        strXMLFolderPath = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.XMLFolderPath);
                    strFilePathAndName = strXMLFolderPath + strXMLFileName;

                    using (DataSet dsTemp = new DataSet())
                    {
                        //Note: BeginLoadData and EndLoadData will increase performance
                        foreach (DataTable dtTemp in dsTemp.Tables)
                            dtTemp.BeginLoadData();

                        dsTemp.ReadXml(strFilePathAndName);

                        foreach (DataTable dtTemp in dsTemp.Tables)
                            dtTemp.EndLoadData();

                        if (dsTemp.Tables.Count > 0)
                        {
                            using (DataView dvDefault = new DataView(dsTemp.Tables[0]))
                            {
                                //dvDefault = dsTemp.Tables[0].DefaultView;
                                if (iParentId != -1 && strSearchKeyword != null)
                                    dvDefault.RowFilter = string.Concat(new object[] { "PARENTID =", iParentId, "and DESC like '", strSearchKeyword, "%'" });
                                else if (iParentId != -1)
                                    dvDefault.RowFilter = "PARENTID=" + iParentId;
                                else
                                    dvDefault.RowFilter = "DESC like '" + strSearchKeyword + "%'";
                                ds.Tables.Add(dvDefault.ToTable());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.GetType() != typeof(FileNotFoundException))
                {
                    throw;
                }
                iReturnValue = 0x65;
            }
            return iReturnValue;
        }
        #endregion
        #endregion

        #region Properties
        public long ErrorNumber
        {
            get { return _sErrorNumber; }
            set { _sErrorNumber = value; }
        }

        public string ErrorDescription
        {
            get { return _sErrorDescription; }
            set { _sErrorDescription = value; }
        }
        #endregion
    }
}
