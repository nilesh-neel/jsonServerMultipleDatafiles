﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Configuration;

using RGICL.MC.Common.Constants;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.DataAccessLayer
{
    public class clsConnection
    {
        private static string sConnString = ConfigurationManager.ConnectionStrings["RGICL_MC_ConnectionString"].ToString();

        #region Connection Properties
        private SqlConnection _sqlConn;
        private static string _sConnName;
        public static string ConnectionString
        {
            get
            {
                if (!String.IsNullOrEmpty(ConnName))
                {
                    return ConfigurationManager.ConnectionStrings[ConnName].ToString();
                }
                return sConnString;
            }
        }
        public static string ConnName
        {
            get { return _sConnName; }
            set { _sConnName = value; }
        }
        #endregion

        public clsConnection() { }

        #region Connection Functions
        public SqlConnection OpenConnection()
        {
            try
            {
                if (_sqlConn != null)
                {
                    if (_sqlConn.State == ConnectionState.Closed)
                    {
                        if (_sqlConn.ConnectionString == "")
                            _sqlConn = new SqlConnection(sConnString);
                        _sqlConn.Open();
                        return _sqlConn;
                    }
                    else
                    {
                        //return _sqlConn;
                        SqlConnection oNewConn = new SqlConnection(sConnString);
                        oNewConn.Open();
                        return oNewConn;
                    }
                }
                else
                {
                    _sqlConn = new SqlConnection(sConnString);
                    _sqlConn.Open();
                    return _sqlConn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SqlConnection OpenConnection(SqlConnection oConnection)
        {
            try
            {
                if (oConnection != null)
                {
                    if (oConnection.State == ConnectionState.Closed)
                    {
                        if (oConnection.ConnectionString == "")
                            oConnection = new SqlConnection(sConnString);
                        oConnection.Open();
                        return oConnection;
                    }
                    else
                    {
                        return oConnection;
                    }
                }
                else
                {
                    _sqlConn = new SqlConnection(sConnString);
                    _sqlConn.Open();
                    return _sqlConn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SqlConnection OpenConnection(string sConnectionString)
        {
            try
            {
                SqlConnection oConnection = new SqlConnection(sConnectionString);
                oConnection.Open();
                return oConnection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CloseConnection()
        {
            CloseConnection(_sqlConn);
        }
        public void CloseConnection(SqlConnection oConnection)
        {
            try
            {
                if (oConnection != null)
                {
                    if (oConnection.State == ConnectionState.Open)
                    {
                        if (oConnection.Equals(_sqlConn))
                            oConnection.Close();
                        else
                        {
                            oConnection.Close();
                            oConnection.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Transaction Functions
        public SqlTransaction BeginTransaction(SqlConnection oConnection)
        {
            try
            {
                SqlTransaction oTrans;
                oTrans = oConnection.BeginTransaction();
                return oTrans;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void CommitTransaction(SqlTransaction oTrans)
        {
            try
            {
                oTrans.Commit();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void RollBackTransaction(SqlTransaction oTrans)
        {
            try
            {
                oTrans.Rollback();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}
