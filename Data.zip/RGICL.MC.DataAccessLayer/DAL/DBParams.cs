﻿/****************************************************************************************************************
Class Name   : DBParams.cs 
Purpose      : Used to define utility functions for DB params(SQL/Oracle).
Created By   : Ravi Kant Shivhare 
Created Date : 03/Oct/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
#endregion

namespace DataAccessLayer
{
    public class DBParams
    {
        protected object CheckParamValue<T>(T paramValue)
        {
            if ((typeof(T) == typeof(string) && paramValue.Equals(NullConstants.NullString))
                || (typeof(T) == typeof(int) && paramValue.Equals(NullConstants.NullInt))
                || (typeof(T) == typeof(long) && paramValue.Equals(NullConstants.NullLong))
                || (typeof(T) == typeof(decimal) && paramValue.Equals(NullConstants.NullDecimal))
                || (typeof(T) == typeof(double) && paramValue.Equals(NullConstants.NullDouble))
                || (typeof(T) == typeof(float) && paramValue.Equals(NullConstants.NullFloat))
                || (typeof(T) == typeof(DateTime) && paramValue.Equals(NullConstants.NullDateTime))
                || (typeof(T) == typeof(Guid) && paramValue.Equals(NullConstants.NullGuid))
                )
            {
                return DBNull.Value;
            }
            return paramValue;
        }

        private SqlDbType DbTypeToSqlDbType(DbType oDbType)
        {
            SqlParameter oSqlParam = new SqlParameter();
            try
            {
                oSqlParam.DbType = oDbType;
            }
            catch (Exception ex)
            {
                // can't map
            }
            return oSqlParam.SqlDbType;
        }

        public SqlParameter CreateParameter(string paramName, DbType paramType, object paramValue = null, ParameterDirection direction = ParameterDirection.Input, int? size = null, byte? precision = null)
        {
            SqlParameter parameter = new SqlParameter();
            parameter.ParameterName = paramName;

            if (paramValue != DBNull.Value)
            {
                switch (paramType)
                {
                    case DbType.Int32:
                        paramValue = this.CheckParamValue<int>(Convert.ToInt32(paramValue));
                        break;

                    case DbType.String:
                        paramValue = this.CheckParamValue<string>(Convert.ToString(paramValue));
                        break;

                    case DbType.Double:
                        paramValue = this.CheckParamValue<double>(Convert.ToDouble(paramValue));//double
                        break;

                    case DbType.DateTime:
                        paramValue = this.CheckParamValue<DateTime>((DateTime)paramValue);
                        break;
                }
            }
            parameter.SqlDbType = DbTypeToSqlDbType(paramType);
            parameter.Value = paramValue;
            parameter.Direction = direction;
            if (size != null)
                parameter.Size = Convert.ToInt32(size);
            if (precision != null)
                parameter.Precision = Convert.ToByte(precision);
            return parameter;
        }

        public SqlParameter CreateParameterError(string strParamName)
        {
            SqlParameter oParam = new SqlParameter();
            oParam.ParameterName = strParamName;
            oParam.SqlDbType = SqlDbType.Int;
            oParam.Direction = ParameterDirection.Output;
            oParam.Value = DBNull.Value;
            return oParam;
        }

        /// <summary>
        /// This method is used to attach array of SqlParameters to a SqlCommand.
        /// This method will assign a value of DbNull to any parameter with a direction of
        /// InputOutput and a value of null.  
        /// 
        /// This behavior will prevent default values from being used, but
        /// this will be the less common case than an intended pure output parameter (derived as InputOutput)
        /// where the user provided no input value.
        /// </summary>
        /// <param name="command">The command to which the parameters will be added</param>
        /// <param name="commandParameters">An array of SqlParameters to be added to command</param>
        private void AttachParameters(SqlCommand command, SqlParameter[] commandParameters)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput ||
                            p.Direction == ParameterDirection.Input) &&
                            (p.Value == null))
                        {
                            p.Value = DBNull.Value;
                        }
                        command.Parameters.Add(p);
                    }
                }
            }
        }

        public void AttachParameters(SqlCommand command, SqlParameterCollection oParamCollection)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (oParamCollection != null)
            {
                foreach (SqlParameter p in oParamCollection)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput ||
                            p.Direction == ParameterDirection.Input) &&
                            (p.Value == null))
                        {
                            p.Value = DBNull.Value;
                        }
                        command.Parameters.Add(p);
                    }


                    /*
                    SqlParameter oParam = new SqlParameter();
                    oParam.ParameterName = p.ParameterName;
                    oParam.SqlDbType = p.SqlDbType;
                    oParam.Direction = p.Direction;
                    oParam.Size = p.Size;
                    command.Parameters.Add(oParam);
                    oParam.Value = p.Value;
                     */
                }
            }
        }

        /// <summary>
        /// This method assigns dataRow column values to an array of SqlParameters
        /// </summary>
        /// <param name="commandParameters">Array of SqlParameters to be assigned values</param>
        /// <param name="dataRow">The dataRow used to hold the stored procedure's parameter values</param>
        private static void AssignParameterValues(SqlParameter[] commandParameters, DataRow dataRow)
        {
            if ((commandParameters == null) || (dataRow == null))
            {
                // Do nothing if we get no data
                return;
            }

            int i = 0;
            // Set the parameters values
            foreach (SqlParameter commandParameter in commandParameters)
            {
                // Check the parameter name
                if (commandParameter.ParameterName == null ||
                    commandParameter.ParameterName.Length <= 1)
                    throw new Exception(
                        string.Format(
                            "Please provide a valid parameter name on the parameter #{0}, the ParameterName property has the following value: '{1}'.",
                            i, commandParameter.ParameterName));
                if (dataRow.Table.Columns.IndexOf(commandParameter.ParameterName.Substring(1)) != -1)
                    commandParameter.Value = dataRow[commandParameter.ParameterName.Substring(1)];
                i++;
            }
        }

        /// <summary>
        /// This method assigns an array of values to an array of SqlParameters
        /// </summary>
        /// <param name="commandParameters">Array of SqlParameters to be assigned values</param>
        /// <param name="parameterValues">Array of objects holding the values to be assigned</param>
        private static void AssignParameterValues(SqlParameter[] commandParameters, object[] parameterValues)
        {
            if ((commandParameters == null) || (parameterValues == null))
            {
                // Do nothing if we get no data
                return;
            }

            // We must have the same number of values as we pave parameters to put them in
            if (commandParameters.Length != parameterValues.Length)
            {
                throw new ArgumentException("Parameter count does not match Parameter Value count.");
            }

            // Iterate through the SqlParameters, assigning the values from the corresponding position in the 
            // value array
            for (int i = 0, j = commandParameters.Length; i < j; i++)
            {
                // If the current array value derives from IDbDataParameter, then assign its Value property
                if (parameterValues[i] is IDbDataParameter)
                {
                    IDbDataParameter paramInstance = (IDbDataParameter)parameterValues[i];
                    if (paramInstance.Value == null)
                    {
                        commandParameters[i].Value = DBNull.Value;
                    }
                    else
                    {
                        commandParameters[i].Value = paramInstance.Value;
                    }
                }
                else if (parameterValues[i] == null)
                {
                    commandParameters[i].Value = DBNull.Value;
                }
                else
                {
                    commandParameters[i].Value = parameterValues[i];
                }
            }
        }
    }

    public sealed class NullConstants
    {
        public static string NullString = string.Empty;
        public static int NullInt = -2147483648;
        public static long NullLong = -9223372036854775808L;
        public static decimal NullDecimal = -79228162514264337593543950335M;
        public static double NullDouble = double.MinValue;
        public static float NullFloat = float.MinValue;
        public static DateTime NullDateTime = DateTime.MinValue;
        public static Guid NullGuid = Guid.Empty;
        public static DateTime DbMaxDate = new DateTime(0xfa0, 1, 1, 0x17, 0x3b, 0x3b);
        public static DateTime DbMinDate = new DateTime(0x76c, 1, 1, 0, 0, 0);
    }
}
