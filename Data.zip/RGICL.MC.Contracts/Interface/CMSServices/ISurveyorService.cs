﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ISurveyor" in both code and config file together.
    [ServiceContract]
    public interface ISurveyorService
    {
        [OperationContract]
        string GetLicenceNumber(int iSurveyorID);

        [OperationContract]
        List<SurveyorEnt> GetSurveyorName(string strSurveyorType);

        [OperationContract]
        List<HubEnt> GetHubDetails(string strClaimRefNumber);

        [OperationContract]
        List<GarageEnt> GetGarageName(string iClaimRefNo);
        [OperationContract]
        void UpdateSurveyorAppointmentStatus(SurveyorEnt obj);
        [OperationContract]
        List<SurveyorEnt> GetManualSurveyDetails();

        [OperationContract]
        int SetManualSurveyAppointment(List<SurveyorEnt> lstSurveyAppointmentEnt);
    }
}
