﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    [ServiceContract]
    public interface IDashboardService
    {
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<DashboardEnt> GetDashboardDataByHubAndUserId(int iHubId, int iUserID, int iLossId);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<DashboardEnt> GetSurveyorDashboardDataByUserId(int iUserID);
    }
}
