﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    [ServiceContract]
    public interface ICOProxyManagementService
    {

    }
}
