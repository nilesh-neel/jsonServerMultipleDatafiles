﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IUserManagementService" in both code and config file together.
    [ServiceContract]
    public interface IUserManagementService
    {
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        void GetUsersRole();

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        UserInformationEnt GetUserDetails(string strUserID);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<Menu> GetMenuList(string strLoginID);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<EmployeeEnt> GetEmployeeList(string strSapCode, string fName, string lName);

        [OperationContract(Name = "GetUserLoginInfo1")]
        [FaultContract(typeof(CustomExceptionEnt))]
        UserInformationEnt GetUserLoginInfo(string strLoginID);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<UserInformationEnt> GetUsersList(string strLoginID, string strFName, string strLName);

        [OperationContract(Name = "GetUserLoginInfo2")]
        [FaultContract(typeof(CustomExceptionEnt))]
        UserInformationEnt GetUserLoginInfo(string strLoginID, string strSAPCode);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        void UpdateIPAddress(string strLoginID, string strIPAddress, string strSessionID);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int UpdateIsLocked(string strUserID, bool bIsLocked);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<ProductCategoryEnt> GetProductCategory();

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        UserInformationEnt GetUserDetailsByUserId(int iUserID);

        //[OperationContract]
        //[FaultContract(typeof(CustomExceptionEnt))]
        //Dictionary<string, object> GetUserByUserId(int iUserId);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        UserMaser GetUserMasterByUserId(int iUserId);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        string GetHubLocationMapping(string strHubIds);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        string GetLocationGarageDetails(string strLocationId);

        #region  "SaveUser"
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SaveUserDetails(UserInformationEnt oUser);

        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SaveUserZoneHubTeamMapping(string strZoneHubXml);
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SaveUserProductCategoryMapping(string strProductCatXml);
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SaveUserHubLocationMapping(UserInformationEnt oUser);
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SaveUserLocationGarageMapping(UserInformationEnt oUser);
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        int SaveUserMackerCheckerRights(UserInformationEnt oUser);

        #endregion
    }
}
