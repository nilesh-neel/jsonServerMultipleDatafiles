﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRegionService" in both code and config file together.
     [ServiceContract]
    public interface IRegionService
    {
        [OperationContract]
        List<StateEnt> GetAllState();

        [OperationContract]
        List<DistrictEnt> GetAllDistrict();

        [OperationContract]
        List<CityEnt> GetAllCity();    

    }
}
