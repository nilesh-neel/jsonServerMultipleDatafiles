﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IApprovalService" in both code and config file together.
    [ServiceContract]
    public interface IApprovalService
    {
        [OperationContract]
        List<ClaimEnt> GetTehnicalApprovalList(UserInformationEnt objUserInformationEnt);

        [OperationContract]
        List<ClaimEnt> GetFinancialApprovalList(UserInformationEnt objUserInformationEnt);

        [OperationContract]
        int CreateWorkFlowForTechnicalApproval(ApprovalEnt objApprovalEnt);

        [OperationContract]
        int SaveClaimApprovalMatrix(ApprovalEnt objApprovalEnt);

        [OperationContract]
        int UpdateClaimApprovalMatrix(ApprovalEnt objApprovalEnt);

        [OperationContract]
        int SaveSavvionServiceErrorLog(ApprovalEnt objApprovalEnt);

        [OperationContract]
        int UpdateClaimStatus(ClaimEnt objClaimEnt);
    }
}
