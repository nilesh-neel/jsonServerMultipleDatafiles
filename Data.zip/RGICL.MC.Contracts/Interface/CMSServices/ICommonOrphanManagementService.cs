﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICommonOrphanManagementService" in both code and config file together.
    [ServiceContract]
    public interface ICommonOrphanManagementService
    {
        [OperationContract]
        int InsertAcquireOCClaim(List<COClaimEnt> objCOClaimEnt);
        [OperationContract]
        List<COUserEnt> GetCOUserEntDetails(string ClaimRefNo, string UserID);
    }
}
