﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IClaimService" in both code and config file together.
    [ServiceContract]
    public interface IClaimService
    {
        [OperationContract]
        bool IsECSClaim(int productId);

        [OperationContract]
        bool IsExistingCase(string caseNo);

        [OperationContract]
        List<ClaimEnt> DisplayClaimDetails(string ClaimNo);
        [OperationContract]
        List<ClaimEnt> GetOrphanCommonClaimDetails(Int32 UserID);

        [OperationContract]
        List<ProductEnt> GetProductMakeModel();

        [OperationContract]
        List<ClaimEnt> GetClaimDetails(ClaimEnt objClaimEnt);

        [OperationContract]
        List<ClaimEnt> GetICEDetails(string caseNo);

        [OperationContract]
        void UpdateICEDetails(string caseNo, bool insertFlag, string remark);

        [OperationContract]
        List<ClaimEnt> GetClaimByPolicyId(string strPolicyno);

        [OperationContract]
        List<ClaimEnt> IntimateClaim(ClaimEnt objClaim);

        [OperationContract]
        List<BlazeEnt> GetBlazeInputParameters(string policyNo);

        [OperationContract]
        string SaveBlazeScoreCardDetails(BlazeEnt objBlaze);

        [OperationContract]
        bool ProcessClaim(string claimRefNo, int createdBy);

        [OperationContract]
        List<ClaimEnt> GetInboxDetailsForCM_HM_ZM_CO_VH(int userId);

        [OperationContract]
        List<ClaimEnt> GetCIInputParamsForSavvion(string claimRefNo);

        [OperationContract]
        bool IsExistingCMSClaim(string policyNo, string coverNoteNo, DateTime dateOfLoss, int PrimaryTypeofLoss, string insuredName);

        [OperationContract]
        List<ClaimEnt> GetInboxDetailsForBSM();

        [OperationContract]
        List<ClaimEnt> GetInboxDetailsForRAM();

        [OperationContract]
        List<ClaimEnt> GetInboxDetailsForRCU();

        [OperationContract]
        List<ClaimEnt> GetInboxDetailsForCVM();

        [OperationContract]
        List<ClaimEnt> GetInboxDetailsForSurveyor(int userId);

        [OperationContract]
        ClaimEnt GetInsuredDetails(string claimRefNo);

        [OperationContract]
        int SaveInsuredDetails(InsuredEnt objInsured);
        
    }
}
