﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IDocumentDetailServioce" in both code and config file together.
    [ServiceContract]
    public interface IDocumentDetailServioce
    {
        [OperationContract]
        List<SurveyorEnt> GetDocumentType();

        [OperationContract]
        List<DocumentEnt> GetUplodedDocumentlst(string ClaimRefNo);

        [OperationContract]
        int InsertDocumentDetails(List<DocumentEnt> objDocumentEnt, List<FileEnt> objFileEnt);

    }
}
