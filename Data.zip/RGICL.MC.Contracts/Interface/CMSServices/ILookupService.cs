﻿using System.Collections.Generic;
using System.ServiceModel;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface ILookupService
    {
        [OperationContract]
        void SetLookupDetails(LookupEnt obj);

        [OperationContract]
        List<LookupEnt> GetLookupType();

        [OperationContract]
        List<LookupEnt> GetLookupDetailsById(int iLookupTypeID);

        [OperationContract]
        int TestAsynOne(int msec);

        [OperationContract]
        int TestAsynTwo(int msec);
       
        [OperationContract]
        List<LookupEnt> GetLookups();
    }
}