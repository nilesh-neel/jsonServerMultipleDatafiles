﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Contracts.Interface.CMSServices
{
    [ServiceContract]
    public interface IAuditTrailService
    {
        [OperationContract]
        [FaultContract(typeof(CustomExceptionEnt))]
        List<AuditTrailEventEnt> GetAuditTrailList(string strClaimRefNo);
    }
}
