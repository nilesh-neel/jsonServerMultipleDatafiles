﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using RGICL.MC.Contracts.Entity;
using System.IO;
using System.ServiceModel.Channels;

namespace RGICL.MC.Contracts.Interface.RestFull
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ILogin" in both code and config file together.
    [ServiceContract]
    public interface ILogin
    {
        [OperationContract]
        [WebInvoke(Method = "GET",
          ResponseFormat = WebMessageFormat.Json,
          BodyStyle = WebMessageBodyStyle.Wrapped,
          UriTemplate = "Login?id={id}&pwd={pwd}&deviceNo={deviceNo}")]
        //UriTemplate = "Login/{id}")]
        Stream DoLogin(string id, string pwd, string deviceNo);

        [OperationContract]
        Message TestLogin(string id);
    }
}
