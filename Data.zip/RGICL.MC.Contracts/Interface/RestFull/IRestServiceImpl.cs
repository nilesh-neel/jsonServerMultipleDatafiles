﻿using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;
using RGICL.MC.Contracts.Entity;
namespace RGICL.MC.Contracts.Interface.RestFull
{
    #region IRESTService Interface
    [ServiceContract]
    public interface IRestServiceImpl
    {
        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Bare,UriTemplate = "xml/{id}")]
        string XMLData(string id);

        [OperationContract]
        [WebInvoke(Method = "GET",ResponseFormat = WebMessageFormat.Json,BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "json/{id}")]
        string JSONData(string id);

        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "ErrorThrowToUI/{id}")]
        int GetError(string id);

        //POST operation
        [OperationContract]
        [WebInvoke(Method = "PUT", ResponseFormat = WebMessageFormat.Json, UriTemplate = "/CreatePerson")]
        string CreatePerson(Person createPerson);

        //Get Operation
        [OperationContract]
        [WebGet(UriTemplate = "GetAllPersonXML")]
        List<Person> GetAllPersonXML();

        //Get Operation
        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "GetAllPersonJson")]
        List<Person> GetAllPersonJson();

        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "GetXMLPersonById/{id}")]
        Person GetAPerson(string id);

        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "GetJsonPersonById/{id}")]
        Person GetAPersonJson(string id);

        //PUT Operation
        [OperationContract]
        [WebInvoke(Method = "POST",ResponseFormat = WebMessageFormat.Json, UriTemplate = "UpdatePerson/{id}")]
        Person UpdatePerson(string id, Person updatePerson);

        //DELETE Operation
        [OperationContract]
        [WebInvoke(UriTemplate = "DeletePerson/{id}", Method = "DELETE")]
        void DeletePerson(string id);
    }
    #endregion
}