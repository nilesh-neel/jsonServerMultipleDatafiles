﻿using System.ServiceModel;
using System.ServiceModel.Web;
using System.IO;

namespace RGICL.MC.Contracts.Interface.RestFull
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IMasterData" in both code and config file together.
    [ServiceContract]
    public interface IMasterData
    {
        [OperationContract]
        [WebInvoke(Method = "GET",
          ResponseFormat = WebMessageFormat.Json,
          BodyStyle = WebMessageBodyStyle.Wrapped,
           UriTemplate = "GetMaster")]
        Stream GetAllMaster();

        [OperationContract]
        [WebInvoke(Method = "GET",
          ResponseFormat = WebMessageFormat.Json,
          BodyStyle = WebMessageBodyStyle.Wrapped,
           UriTemplate = "GetLocationMaster")]
        Stream GetLocationMasterData();

        [OperationContract]
        [WebInvoke(Method = "GET",
          ResponseFormat = WebMessageFormat.Json,
          BodyStyle = WebMessageBodyStyle.Wrapped,
           UriTemplate = "GetPartMaster")]
        Stream GetPartMasterData();
    }
}
