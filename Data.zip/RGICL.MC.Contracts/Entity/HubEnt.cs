﻿using System.Runtime.Serialization;
using System;
using System.Collections.Generic;

namespace RGICL.MC.Contracts.Entity
{
   [Serializable]
   [DataContract]
   public class HubEnt : ParentDetails
    {
        #region Public Properties
       
        [DataMember]
        public int HubID	 { get; set; }
        [DataMember]
        public string HubName { get; set; }
        [DataMember]
        public string HubDesc { get; set; }
        [DataMember]
        public List<TeamEnt> Teams { get; set; }
        [DataMember]
        public List<LocationEnt> Location { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
       
       
  #endregion

    }
}
