﻿using System;
using System.Collections.Generic;
namespace RGICL.MC.Contracts.Entity
{
    public class AuditTrailDetailsEnt
    {
        public int AuditTrailId { get; set; }
        public ClaimEnt ClaimRefNo { get; set; }
        public string CaseDescription { get; set; }
        public string Remarks { get; set; }
        public string EventTime { get; set; }
        public string SavvionResponse { get; set; }
        public UserInformationEnt ReleasedBy { get; set; }
        public bool IsReleased { get; set; }
    }
}
