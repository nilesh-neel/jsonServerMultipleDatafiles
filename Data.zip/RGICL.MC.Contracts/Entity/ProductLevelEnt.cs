﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGICL.MC.Contracts.Entity
{
    public class ProductLevelEnt
    {
        public int LevelId { get; set; }
        public string LevelName { get; set; }
        public int MinLevel { get; set; }
        public int MaxLevel { get; set; }
    }
}

