﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class AssesmentEnt
    {
    }
    public class TotalLossEnt
    {

        [DataMember]
        public int Total_Loss_id { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string YearofManufacturing { get; set; }
        [DataMember]
        public string LiabilityonRepair { get; set; }
        [DataMember]
        public string ReasonNonStandardClaim { get; set; }
        [DataMember]
        public bool IsSalvageRealised { get; set; }
        [DataMember]
        public string InsuredDeclaredValue { get; set; }
        [DataMember]
        public string NonStandardSettlement { get; set; }
        [DataMember]
        public string InsuredAgreedValue { get; set; }
        [DataMember]
        public string SalvageRealisedby { get; set; }
        [DataMember]
        public bool IsRCbookCancelled { get; set; }
        [DataMember]
        public string SalvageAmount { get; set; }
        [DataMember]
        public string FinalLiability { get; set; }
        [DataMember]
        public string SalvageRelPer { get; set; }
        [DataMember]
        public string SalvageRelPerIDV { get; set; }
        [DataMember]
        public int DocumentId { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }
        [DataMember]
        public List<BuyerEnt> BuyerEntlst { get; set; }
        [DataMember]
        public  decimal ParkingCharges { get; set; }
        [DataMember]
        public  string UploadRCcancellationDocument { get; set; }
    }


    public class BuyerEnt
    {
        [DataMember]
        public int BuyersID { get; set; }
        [DataMember]
        public int ID { get; set; }
        [DataMember]
        public int TotalLossID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string BuyerName { get; set; }
        [DataMember]
        public string BuyerContactNo { get; set; }
        [DataMember]
        public decimal AmountQuoted { get; set; }
        [DataMember]
        public int StatusID { get; set; }
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int Type { get; set; }
        
    }


    public class NetOfSalvageEnt
    {

        [DataMember]
        public int NetOfSalvageID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string YearofManufacturing { get; set; }
        [DataMember]
        public string LiabilityonRepair { get; set; }
        [DataMember]
        public string ReasonNonStandardClaim { get; set; }
        [DataMember]
        public bool IsSalvageRealised { get; set; }
        [DataMember]
        public string InsuredDeclaredValue { get; set; }
        [DataMember]
        public string NonStandardSettlement { get; set; }
        [DataMember]
        public string InsuredAgreedValue { get; set; }
        [DataMember]
        public string SalvageRealisedby { get; set; }
        [DataMember]
        public bool IsRCbookCancelled { get; set; }
        [DataMember]
        public string SalvageAmount { get; set; }
        [DataMember]
        public string FinalLiability { get; set; }
        [DataMember]
        public string SalvageRelPer { get; set; }
        [DataMember]
        public string SalvageRelPerIDV { get; set; }
        [DataMember]
        public int DocumentId { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }
        [DataMember]
        public List<BuyerEnt> BuyerEntlst { get; set; }
        [DataMember]
        public decimal ParkingCharges { get; set; }
        [DataMember]
        public string UploadRCcancellationDocument { get; set; }
    }

}
