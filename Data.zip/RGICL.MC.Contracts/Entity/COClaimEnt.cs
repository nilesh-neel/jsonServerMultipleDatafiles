﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class COClaimEnt
    {
        [Description("ClaimRefNo")]
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        [Description("IsOrphan")]
        public bool IsOrphan { get; set; }
        [DataMember]
        [Description("NatureOfLoss")]
        public string NatureOfLoss { get; set; }
        [DataMember]
        [Description("NatureOfLossID")]
        public int NatureOfLossID { get; set; }

        [DataMember]
        [Description("IsValidToAcquire")]
        public bool IsValidToAcquire { get; set; }

        [DataMember]
        [Description("IsCommon")]
        public bool IsCommon { get; set; }

        [DataMember]
        [Description("ProductId")]
        public int ProductId { get; set; }

        [DataMember]
        [Description("Product")]
        public string Product { get; set; }

        [DataMember]
        [Description("HubId")]
        public int HubId { get; set; }

        [DataMember]
        [Description("HubName")]
        public string HubName { get; set; }
        [DataMember]
        [Description("CMID")]
        public int CMId { get; set; }

        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }
        [DataMember]
        public REQUESTTYPE eREQUESTTYPE { get; set; }
    }

    [DataContract]
    public class COUserEnt
    {
        [Description("UserID")]
        [DataMember]
        public int UserID { get; set; }
        [DataMember]
        [Description("DisplayName")]
        public string DisplayName { get; set; }
        [DataMember]
        [Description("NatureOfLoss")]
        public string NatureOfLoss { get; set; }
        [DataMember]
        [Description("NatureOfLossID")]
        public int NatureOfLossID { get; set; }

        [DataMember]
        [Description("RoleId")]
        public int RoleID { get; set; }


        [DataMember]
        [Description("RoleName")]
        public string RoleName { get; set; }


        [DataMember]
        [Description("ProductCode")]
        public string ProductCode { get; set; }

        [DataMember]
        [Description("ProductName")]
        public string ProductName { get; set; }

        [DataMember]
        [Description("HubId")]
        public int HubId { get; set; }

        [DataMember]
        [Description("HubName")]
        public string HubName { get; set; }

        [DataMember]
        [Description("CMID")]
        public int CMId { get; set; }

        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }

      

       
    }
    public enum REQUESTTYPE
    {
        Aquire = 0,
        Assign = 1,
        Transfer = 2
    }
}
