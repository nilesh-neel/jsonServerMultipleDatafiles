﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
   public class FinalSurveyEnt
    {
        [DataMember]
        public List<ParticularEnt> ListParticular { get; set; }
        [DataMember]
        public VehicalEnt Vehical { get; set; }
        [DataMember]
        public CommertialVehicalEnt CommertialVehical { get; set; }
        [DataMember]
        public DriverEnt Driver { get; set; }
        [DataMember]
        public bool IsSkipDriversInfo { get; set; }
        [DataMember]
        [Description("CauseofLoss")]
        public string CauseOfLoss { get; set; }
        [DataMember]
        public string LossDescription { get; set; }
        [DataMember]
        public string NatureOfLoss { get; set; }
        [DataMember]
        public bool IsPassengerList { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]        
        public string ClaimRefNo { get; set; }

        [DataMember]
        public int FIRNo { get; set; }
        [DataMember]
        public DateTime FIRDate { get; set; }
        [DataMember]
        public string FIRDesciption { get; set; }

        [DataMember]
        public int PanchNamaNo { get; set; }
        [DataMember]
        public DateTime PanchNamaDate { get; set; }
        [DataMember]
        public string PanchNamaDesciption { get; set; }

        [DataMember]
        public int ChargeSheetNo { get; set; }
        [DataMember]
        public DateTime ChargeSheetDate { get; set; }
        [DataMember]
        public string ChargeSheetDesciption { get; set; }
       
    }
}
