﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class CustomHeaderEnt
    {
        private bool _IsAutoLogin = false;
        [DataMember]
        public string WebUserId { get; set; }
        [DataMember]
        public string WebUserPwd { get; set; }
        [DataMember]
        public string WebSessionId { get; set; }
        [DataMember]
        public string IpAddress { get; set; }
        [DataMember]
        public string UserType { get; set; }
        [DataMember]
        public bool IsAutoLogin
        {
            get { return _IsAutoLogin; } 
            set { value = _IsAutoLogin; }
        }
        [DataMember]
        public string FormName { get; set; }
    }
}
