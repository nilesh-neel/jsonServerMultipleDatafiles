﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class StateEnt 
    {
        [DataMember]
        public int StateId { get; set; }
        
        [DataMember]
        public string StateCode { get; set; }
        
        [DataMember]
        public string StateName { get; set; }
        
        [DataMember]
        public string State_ARC { get; set; }
        
        [DataMember]
        public List<DistrictEnt> District { get; set; }
        
        [DataMember]
        public bool IsActive { get; set; }
    }
}
