﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class LocationEnt : ParentDetails
    {
        [DataMember]
        public int LocationId { get; set; }
        [DataMember]
        public string LocationName { get; set; }
        [DataMember]
        public List<GarageEnt> Garage { get; set; }
    }
}
