﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    public class CityEnt
    {
        [DataMember]
        public int CityId { get; set; }
        [DataMember]
        public string CityName { get; set; }
        [DataMember]
        public int CityStateId { get; set; }
        [DataMember]
        public int CityDistrictId { get; set; }
    }
}
