﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class GarageClaimMappingEnt
    {
        [DataMember]
        public string GarageName { get; set; }      
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string LocationName { get; set; }
        [DataMember]
        public string StateName { get; set; }
        [DataMember]
        public int ClaimGarageMapId { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public int GarageID { get; set; }
        [DataMember]
        public bool ServiceTaxApplicable { get; set; }
        [DataMember]
        public string ServiceTaxNumber { get; set; }
        [DataMember]
        public bool ApplyExcess { get; set; }
        [DataMember]
        public decimal CompulsoryExcess { get; set; }
        [DataMember]
        public decimal VoluntaryExcess { get; set; }
        [DataMember]
        public decimal AdditionalExcess { get; set; }
        [DataMember]
        public bool WCTonLabourApplicable { get; set; }
        [DataMember]
        public bool WCTonPaintApplicable { get; set; }

        [DataMember]
        public bool VATOnPaintApplicable { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public List<GarageClaimTAXMappingEnt> listGarageClaimTAXMappingEnt { get; set; }

    }
}
