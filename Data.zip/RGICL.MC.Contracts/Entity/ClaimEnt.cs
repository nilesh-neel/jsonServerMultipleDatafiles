﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class ClaimEnt
    {
        [DataMember]
        [Description("ClaimRefNo")]
        public string ClaimRefNo { get; set; }

        [DataMember]
        [Description("PolicyNo")]
        public string PolicyNo { get; set; }

        [DataMember]
        [Description("IntimaterName")]
        public string IntimatorName { get; set; }

        [DataMember]
        [Description("IntimaterAddress")]
        public string IntimatorAddress { get; set; }

        [DataMember]
        [Description("IntimaterPhoneNo")]
        public string IntimatorPhoneNo { get; set; }

        [DataMember]
        [Description("IntimaterMobileNo")]
        public string IntimatorMobileNo { get; set; }

        //[DataMember]        
        //public string ItemAffectedInsuries { get; set; }

        [DataMember]
        [Description("CoverNote")]
        public string CoverNoteNo { get; set; }

        [DataMember]
        public int Claim_Status { get; set; }

        [DataMember]
        [Description("Lob")]
        public int Lob { get; set; }

        [DataMember]
        [Description("ProductId")]
        public int ProductId { get; set; }

        [DataMember]
        [Description("MakeID")]
        public int MakeId { get; set; }

        [DataMember]
        [Description("ModelID")]
        public int ModelId { get; set; }

        [DataMember]
        [Description("VehicleNo")]
        public string VehicleNo { get; set; }

        [DataMember]
        [Description("IntimatedBy")]
        public string IntimatedBy { get; set; }

        [DataMember]
        [Description("YearOfMFG")]
        public string YearOfMFG { get; set; }

        [DataMember]
        public bool IsVehicleAvlAtWrkshop { get; set; }

        [DataMember]
        public int HubId { get; set; }

        [DataMember]
        [Description("CallerIsNotGarage")]
        public bool CallerIsNotGarage { get; set; }

        [DataMember]
        [Description("VehicleNotInGarage")]
        public bool VehicleNotInGarage { get; set; }

        [DataMember]
        [Description("PolicyNotFromDealer")]
        public bool PolicyNotFromDealer { get; set; }

        [DataMember]
        public int RiskScore { get; set; }

        [DataMember]
        public bool IsInvestigationRequired { get; set; }

        [DataMember]
        public int CMId { get; set; }

        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }

        [DataMember]
        public string CaseNo { get; set; }

        [DataMember]
        public string BranchId { get; set; }

        [DataMember]
        public string EmpId { get; set; }

        [DataMember]
        public string RedirectionFlag { get; set; }
        [DataMember]
        public string ClaimStatusMsg { get; set; }

        [DataMember]

        public bool IsValidForApproval { get; set; }
        [DataMember]
        public string VehicleNumber { get; set; }
        [DataMember]
        public string ClaimOwner { get; set; }
        [DataMember]

        public bool IsValidForClosure { get; set; }
        [DataMember]
        public bool IsValidForReOpen { get; set; }
        [DataMember]
        public bool IsValidForReIssue { get; set; }
        [DataMember]
        public bool IsValidForRecovery { get; set; }
        [DataMember]
        public bool IsValidForStopPayment { get; set; }
        [DataMember]
        public bool IsServiceRequestRaised { get; set; }
        [DataMember]
        public string SR_RaisedFor { get; set; }
        [DataMember]
        public string VB64Status { get; set; }
        [DataMember]
        public int ClaimRegionId { get; set; }



        [DataMember]
        public string GarageName { get; set; }
        [DataMember]
        public string intimationDate { get; set; }
        [DataMember]
        public string DateOfLoss { get; set; }
        [DataMember]
        public string PaymentDetails { get; set; }
        [DataMember]
        public string HubName { get; set; }

        [DataMember]
        public int PrimaryTypeOfLoss { get; set; }

        [DataMember]
        public string DOIFromDate { get; set; }

        [DataMember]
        public string DOITODate { get; set; }
        //[DataMember]
        //public int ProductID { get; set; }

        [DataMember]
        public string GarageLoc { get; set; }

        [DataMember]
        public string InsuredName { get; set; }

        [DataMember]
        public string Product { get; set; }

        [DataMember]
        public string OldClaimRefNo { get; set; }


        [DataMember]
        public int ClaimProcessingRegion { get; set; }

        [DataMember]
        public int GarageID { get; set; }


        [DataMember]
        public string ClaimRegionName { get; set; }

        [DataMember]
        public double EstimatedLoss { get; set; }

        [DataMember]
        public string LOBName { get; set; }

        [DataMember]
        public string NatureOfLoss { get; set; }
        [DataMember]
        public int NatureOfLossID { get; set; }

        [DataMember]
        public int ZoneID { get; set; }

        [DataMember]
        public string RoleName { get; set; }

        [DataMember]
        public int ClaimOwnerID { get; set; }

        [DataMember]
        public decimal MinLimit { get; set; }

        [DataMember]
        public decimal MaxLimit { get; set; }

        [DataMember]
        public string DocumentName { get; set; }

        [DataMember]
        public string WorkStepName { get; set; }

        [DataMember]
        public string ProcessInstanceName { get; set; }

        [DataMember]
        public int RoleId { get; set; }

        [DataMember]
        public bool IsOrphan { get; set; }

        [DataMember]
        public bool IsValidToAcquire { get; set; }
        [DataMember]
        public bool IsValidForHM { get; set; }

        [DataMember]
        public bool IsCommon { get; set; }

        [DataMember]
        public string RequestType { get; set; }

        [DataMember]
        public string RequestSubType { get; set; }

        [DataMember]
        public int Aging { get; set; }

        [DataMember]
        public string UserName { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public LossEnt Loss { get; set; }
        [DataMember]
        public DriverEnt Driver { get; set; }
        [DataMember]
        public List<PolicyEnt> PolicyList { get; set; }
        [DataMember]
        public List<InsuredEnt> InsuredList { get; set; }
        [DataMember]
        public List<VictimEnt> VictimList { get; set; }
        [DataMember]
        public GarageEnt Garage { get; set; }
        [DataMember]
        public List<GarageEnt> GarageList { get; set; }

        [DataMember]
        public bool IsPolicyVerificationRequired { get; set; }
        [DataMember]
        public bool IsAccountVerificationRequired { get; set; }
        [DataMember]
        public string TypeOfSurvey { get; set; }
        [DataMember]
        public string SurveyorType { get; set; }
        [DataMember]
        public int CutOffScore { get; set; }
        [DataMember]
        public bool IsSpotSurveyRequired { get; set; }
        [DataMember]
        public int SurveyorId { get; set; }
        [DataMember]
        public int SurveyId { get; set; }
        [DataMember]
        public string ExtSurveyorName { get; set; }
        [DataMember]
        public int NoOfCM { get; set; }
        [DataMember]
        
        public string SpotSurveyorName { get; set; }
        [DataMember]
        public string TimeOfIntimation { get; set; }
        [DataMember]
        public string PolicyIssuingSystem { get; set; }
        [DataMember]
        public int InitialSurveyId { get; set; }
        [DataMember]
        public string MappedGarage { get; set; }

        [DataMember]
        public bool DepApplicable { get; set; }

        [DataMember]
        public DateTime DepApplicableDate { get; set; }

        [DataMember]
        public int ClaimStatusID { get; set; }

        [DataMember]
        public int ClaimActionID { get; set; }

        [DataMember]
        public int RiskScoreLimitFA { get; set; }
        [DataMember]
        public int RiskScoreLimitCA { get; set; }

		[DataMember]
        public decimal AmountLimitFA { get; set; }
        [DataMember]
        public decimal AmountLimitCA  { get; set; }
		[DataMember]
        public decimal JobAmountLimitFA  { get; set; }
        [DataMember]
        public decimal JobAmountLimitCA { get; set; }

        [DataMember]
        public int lastTechnicalApproverRoleId { get; set; }

        [DataMember]
        public string lastTechnicalApproverRoleName { get; set; }

        [DataMember]
        public string IsRequiredFAForUser { get; set; }
    }
}
