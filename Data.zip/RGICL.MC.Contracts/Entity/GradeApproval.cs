﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class GradeApproval : ParentDetails
    {
        [DataMember]
        public int ApprovalId { get; set; }
        [DataMember]
        public string ApprovalName { get; set; }
    }
}
