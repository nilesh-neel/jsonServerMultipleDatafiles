﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class DashboardEnt
    {
        [DataMember]
        public int TotalNew { get; set; }
        [DataMember]
        public int TotalWIP { get; set; }
        [DataMember]
        public int TotalCommon { get; set; }
        [DataMember]
        public int TotalOrphan { get; set; }
        [DataMember]
        public int TATBusting { get; set; }
        [DataMember]
        public int SurveyAssignedByOthers { get; set; }
        [DataMember]
        public int TotalHUB { get; set; }
        [DataMember]
        public int RCUPending { get; set; }
        [DataMember]
        public int RCUSubmitted { get; set; }
        [DataMember]
        public int SpotSurveyorAppointmentPending { get; set; }
        [DataMember]
        public int GarageAddition { get; set; }
        [DataMember]
        public int FinalSurveyNew { get; set; }
        [DataMember]
        public int FinalSurveyWIP { get; set; }
        [DataMember]
        public int FinalSurveyTotalSubmitted { get; set; }
        [DataMember]
        public int SpotSurveyNew { get; set; }
        [DataMember]
        public int SpotSurveyWIP { get; set; }
        [DataMember]
        public int SpotSurveyTotalSubmitted { get; set; }
        [DataMember]
        public int ReInspectionNew { get; set; }
        [DataMember]
        public int ReInspectionWIP { get; set; }
        [DataMember]
        public int ReInspectionTotalSubmitted { get; set; }
        [DataMember]
        public int CRMInbox { get; set; }

    }
}
