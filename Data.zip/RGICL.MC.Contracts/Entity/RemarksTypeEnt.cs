﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGICL.MC.Contracts.Entity
{
    public class RemarksTypeEnt
    {
        public int RemarkTypeID { get; set; }
        public string RemarkTypeName { get; set; }
        public List<RemarksDetailsEnt> RemarkDetail { get; set; }
        public UserInformationEnt CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
