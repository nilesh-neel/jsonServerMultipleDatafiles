﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class SurveyorEnt
    {       
        [DataMember]
        [Description("ClaimSurveyorMapID")]
        public int ClaimSurveyorMapID
        {
            get;
            set;
        }
        [DataMember]
        [Description("ClaimRefNo")]
        public string ClaimRefNo { get; set; }

        [DataMember]
        [Description("PolicyNo")]
        public string PolicyNo { get; set; }

        [DataMember]
        [Description("GarageID")]
        public int GarageID
        {
            get;
            set;
        }

        [DataMember]
        [Description("SurveyorType")]
        public string SurveyorType
        {
            get;
            set;
        }
        [DataMember]
        public int HubID
        {
            get;
            set;
        }       
        [DataMember]
        [Description("SurveyorID")]
        public int SurveyorID
        {
            get;
            set;
        }
        [DataMember]
        [Description("TypeOfSurvey")]
        public string TypeOfSurvey
        {
            get;
            set;
        }
        [DataMember]
        [Description("ReasonForExtSurveyor")]
        public string ReasonforExtSurvey
        {
            get;
            set;

        }
        
        [DataMember]
        [Description("ApprovedBy")]
        public string ApprovedBy
        {
            get;
            set;

        }

        [DataMember]
        [Description("Category")]
        public string Category
        {
            get;
            set;
        }
        [DataMember]
        [Description("Status")]
        public string SurveyorStatus
        {
            get;
            set;

        }
        [DataMember]
        [Description("DateOfAppointment")]
        public DateTime AppointmentDate
        {
            get;
            set;
        }
        [DataMember]
        public int LicenseNo
        {
            get;
            set;
        }
        [DataMember]
        public string Remarks
        {
            get;
            set;
        }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        
        [DataMember]
        public string GarageName
        {
            get;
            set;
        }
        [DataMember]       
        public string SurveyorName
        {
            get;
            set;
        }     

       
        [DataMember]
        public string HubName
        {
            get;
            set;
        }
        [DataMember]
        public string AppointmentStatus
        {
            get;
            set;
        }
        [DataMember]
        public string AppointmentStatusID
        {
            get;
            set;
        }       
        [DataMember]
        public List<LookupEnt> lookupEntList { get; set; }
        [DataMember]
        public List<GarageEnt> GarageEntList { get; set; }
        [DataMember]
        public List<HubEnt> HubEntList { get; set; }
        [DataMember]
        public int DocID { get; set; }
        [DataMember]
        public string DocumentDescription { get; set; }

    }
}
