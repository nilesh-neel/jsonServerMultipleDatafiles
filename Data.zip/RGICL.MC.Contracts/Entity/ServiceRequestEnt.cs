﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class ServiceRequestClosureEnt : ClaimEnt
    {

        [DataMember]
        public string ClosureID { get; set; }
        [DataMember]
        public int SRID { get; set; }
        [DataMember]
        public string GeneratedBy { get; set; }

        [DataMember]
        public string ClosureType { get; set; }
        [DataMember]
        public string ClosureReason { get; set; }
        [DataMember]
        public int ClosureReasonID { get; set; }
        [DataMember]
        public string ClosureRemarks { get; set; }
        [DataMember]
        public string SRAction { get; set; }
        [DataMember]
        public int SRActionID { get; set; }
        [DataMember]
        public DateTime GeneratedDate { get; set; }
        [DataMember]
        public List<ClosureLetterEnt> ClosureLetterEntlst { get; set; }
        [DataMember]
        public ClosureLetterEnt ClosureLetterEnt { get; set; }

    }
    [DataContract]
    public class ClosureLetterEnt
    {
        [DataMember]
        public string LetterNumber { get; set; }
        [DataMember]
        public string LetterType { get; set; }//same as closure type
        [DataMember]
        public DateTime GeneratedDate { get; set; }
        [DataMember]
        public string GeneratedBy { get; set; }
        [DataMember]
        public DateTime LetterDispatchedDate { get; set; }
        [DataMember]
        public string AirwayBillNumber { get; set; }


    }
    [DataContract]
    public class ServiceRequestReopenEnt : ClaimEnt
    {
        [DataMember]
        [Description("SRID")]
        public int SRID { get; set; }
        [DataMember]
        public string ReopenBy { get; set; }
        [DataMember]
        public DateTime ReopenDate { get; set; }
        [DataMember]
        public string ReOpenID { get; set; }
        [DataMember]
        public int ReOpenReasonID { get; set; }
        [DataMember]
        public string ReOpenReason { get; set; }
        [DataMember]
        public string ReOpenRemarks { get; set; }
        [DataMember]
        public string AdditionalPayment { get; set; }
        [DataMember]
        public string SRAction { get; set; }
        [DataMember]
        public int SRActionID { get; set; }

    }
    [DataContract]
    public class ServiceRequestRecoveryEnt : ClaimEnt
    {
        [DataMember]
        [Description("SRID")]
        public int SRID { get; set; }
        [DataMember]
        public string GeneratedBy { get; set; }
        [DataMember]
        public DateTime GeneratedDate { get; set; }
        [DataMember]
        public string RecoveryID { get; set; }

        [DataMember]
        public int SRActionID { get; set; }
        [DataMember]
        public string PAN { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string Contact { get; set; }
        [DataMember]
        public string RecoveryReason { get; set; }
        [DataMember]
        public string RecoveryType { get; set; }
        [DataMember]
        public string RecoveryFor { get; set; }
        [DataMember]
        public string RecoveryMode { get; set; }
        [DataMember]
        public string RecoveryFrom { get; set; }
        [DataMember]
        public string InstrumentNumber { get; set; }
        [DataMember]
        public DateTime InstrumentDate { get; set; }

        [DataMember]
        public string InstrumentName { get; set; }
        [DataMember]
        public string InstrumentAmount { get; set; }
        [DataMember]
        public string IsTDSApplicable { get; set; }
        [DataMember]
        public string TotalLossPayment { get; set; }
        [DataMember]
        public string LossPaymentRecovered { get; set; }
        [DataMember]
        public string ExpensePayment { get; set; }
        [DataMember]
        public string ExpensePaymentRecovered { get; set; }
        [DataMember]
        public string MainReasonRecovery { get; set; }
        [DataMember]
        public string SubReasonRecovery { get; set; }
        [DataMember]
        public int MainReasonRecoveryID { get; set; }
        [DataMember]
        public int SubReasonRecoveryID { get; set; }
        [DataMember]
        public string RecoveryRemarks { get; set; }
        [DataMember]
        public string SRAction { get; set; }
    }
    [DataContract]
    public class ServiceRequestStopPaymentEnt : ClaimEnt
    {
        [DataMember]
        [Description("SRID")]
        public int SRID { get; set; }
        [DataMember]
        public int PaymentID { get; set; }
        [DataMember]
        public int SRActionID { get; set; }
        [DataMember]
        public string GeneratedBy { get; set; }
        [DataMember]
        public DateTime GeneratedDate { get; set; }
        [DataMember]
        public string StopPaymentID { get; set; }
        [DataMember]
        public string Reason { get; set; }
        [DataMember]
        public int ReasonID { get; set; }
        [DataMember]
        public int RequestTypeID { get; set; }
        [DataMember]
        public string Remarks { get; set; }
        [DataMember]
        public string StopPaymentType { get; set; }
        [DataMember]
        public string RequestType { get; set; }
        [DataMember]
        public string SRAction { get; set; }
        [DataMember]
        public string FilePath { get; set; }
        [DataMember]
        public List<PaymentEnt> LossPayment { get; set; }
        [DataMember]
        public List<PaymentEnt> OnAccountPayment { get; set; }
        [DataMember]
        public List<PaymentEnt> ExpensePayment { get; set; }
    }
    [DataContract]
    public class PaymentEnt
    {

        [DataMember]
        public string PaymentID { get; set; }


        [DataMember]
        public string PaymentType { get; set; }
        [DataMember]
        public string PaymentTo { get; set; }
        [DataMember]
        public string PayeeName { get; set; }
        [DataMember]
        public string NameChange { get; set; }
        [DataMember]
        public string SettlementType { get; set; }
        [DataMember]
        public string Amount { get; set; }



        [DataMember]
        public string TotalAmount { get; set; }
        [DataMember]
        public string RecoveredAmount { get; set; }



        [DataMember]
        public string ModeOfSettlement { get; set; }
        [DataMember]
        public DateTime InstrumentDate { get; set; }
        [DataMember]
        public string Number { get; set; }
        [DataMember]
        public DateTime InstrumentRealizationDate { get; set; }
        [DataMember]
        public string Status { get; set; }
    }
    [DataContract]
    public class ServiceRequestReIssueEnt : ClaimEnt
    {
        [DataMember]
        [Description("SRActionID")]
        public int SRActionID { get; set; }
        [DataMember]
        [Description("SRID")]
        public int SRID { get; set; }
        [DataMember]
        [Description("ReIssueID")]
        public int ReIssueID { get; set; }
        [DataMember]
        [Description("PaymentID")]
        public int PaymentID { get; set; }

        [DataMember]
        [Description("PaymentType")]
        public int PaymentType { get; set; }

        [DataMember]
        [Description("TypeOfRequestID")]
        public int TypeOfRequestID { get; set; }

        [DataMember]
        [Description("RequestTypeID")]
        public int RequestTypeID { get; set; }

        [DataMember]
        [Description("RequestSubTypeID")]
        public int RequestSubTypeID { get; set; }

        [DataMember]
        [Description("ModeOfPaymentID")]
        public int ModeOfPaymentID { get; set; }

        [DataMember]
        [Description("ReIssueReasonID")]
        public int ReIssueReasonID { get; set; }

        [DataMember]
        [Description("TypeOfRequest")]
        public string TypeOfRequest { get; set; }

        [DataMember]
        [Description("RequestType")]
        public string RequestType { get; set; }

        [DataMember]
        [Description("RequestSubType")]
        public string RequestSubType { get; set; }

        [DataMember]
        [Description("ModeOfPayment")]
        public string ModeOfPayment { get; set; }

        [DataMember]
        [Description("ReIssueReason")]
        public string ReIssueReason { get; set; }

        [DataMember]
        [Description("Remarks")]
        public string Remarks { get; set; }

        [DataMember]
        [Description("NameChange")]
        public string NameChange { get; set; }
        [DataMember]
        [Description("AmountChange")]
        public decimal AmountChange { get; set; }

        [DataMember]
        [Description("IsPysicalChequeAvble")]
        public bool IsPysicalChequeAvble { get; set; }

        [DataMember]
        [Description("GeneratedBy")]
        public string GeneratedBy { get; set; }
        [DataMember]
        [Description("SRAction")]
        public string SRAction { get; set; }
        [DataMember]
        [Description("GeneratedByID")]
        public int GeneratedByID { get; set; }

        [DataMember]
        [Description("GeneratedDate")]
        public DateTime GeneratedDate { get; set; }

    }
    [DataContract]
    public class ServiceRequestEnt : ClaimEnt
    {
        [DataMember]
        [Description("ID")]
        public int ID { get; set; }


        [DataMember]
        [Description("SR_TypeID")]
        public EnumSR_TypeID SR_TypeID { get; set; }
        [DataMember]
        [Description("ActorID")]
        public int ActorID { get; set; }
        [DataMember]
        [Description("SR_ID")]
        public int SR_ID { get; set; }
        [DataMember]
        [Description("SUB_SR_ID")]
        public int SUB_SR_ID { get; set; }
        [Description("SavvionID")]
        public int SavvionID { get; set; }
        [DataMember]
        [Description("CreatedDate")]
        public DateTime GeneratedDate { get; set; }
        [DataMember]
        [Description("Action")]
        public string Action { get; set; }
        [DataMember]
        [Description("Remarks")]
        public string Remarks { get; set; }
        [DataMember]
        [Description("SRStatus")]
        public string SRStatus { get; set; }


    }






    [DataContract]
    public class CVMApprovalEnt
    {
        [DataMember]
        [Description("PK_ID")]
        public int PK_ID { get; set; }
        [DataMember]
        [Description("SRTYPE")]
        public EnumSR_TypeID SRTYPE { get; set; }
        [DataMember]
        [Description("CreatedBy")]
        public int CreatedBy { get; set; }
        [DataMember]
        [Description("CreatedByName")]
        public string CreatedByName { get; set; }
        [DataMember]
        [Description("UpdatedByName")]
        public string UpdatedByName { get; set; }

        [DataMember]
        [Description("UpdatedBy")]
        public int UpdatedBy { get; set; }

        [DataMember]
        [Description("SRID")]
        public int SRID { get; set; }

        [DataMember]
        [Description("SUB_SRID")]
        public int SUB_SRID { get; set; }

        [DataMember]
        [Description("SavvionID")]
        public int SavvionID { get; set; }

        [DataMember]
        [Description("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        [Description("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }
        [DataMember]
        [Description("ClaimRefNo")]
        public string ClaimRefNo { get; set; }
        [DataMember]
        [Description("Remarks")]
        public string Remarks { get; set; }
        [DataMember]
        [Description("StatusID")]
        public int StatusID { get; set; }
        [DataMember]
        [Description("SRStatus")]
        public string SRStatus { get; set; }


    }








    public enum EnumSR_TypeID
    {

        Closure = 2,
        ReOpen = 1,
        Reissue = 3,
        Recovery = 4,
        StopPayment = 6,
        NoRequest = 5

    }
}
