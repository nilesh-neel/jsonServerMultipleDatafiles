﻿using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    public class GradeEnt
    {
        
        [DataMember]
        public int GradeId { get; set; }
        [DataMember]
        public string GradeName { get; set; }
        [DataMember]
        public double MinLevel { get; set; }
        [DataMember]
        public double MaxLevel { get; set; }
    }
}

