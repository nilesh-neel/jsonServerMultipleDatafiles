﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
   public class VehicalEnt
    {
        [DataMember]
        public int VehicleID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string PolicyNo { get; set; }
        [DataMember]
        public DateTime RegistrationDate { get; set; }
        [DataMember]
        public string Color { get; set; }
        [DataMember]
        public string TypeOfPaint { get; set; }
        [DataMember]
        public string TypeOfEngine { get; set; }
        [DataMember]
        public string EngineFuelType { get; set; }
        [DataMember]
        public string AverageReading { get; set; }
        [DataMember]
        public bool IsParked { get; set; }
        [DataMember]
        public string OdoMeterReading { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }

    }
}
