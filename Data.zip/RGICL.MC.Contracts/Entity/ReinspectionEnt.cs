﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
   public class ReinspectionEnt
    {
        [DataMember]
        public int ReInsID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public bool  ReinspectionChecked { get; set; }
        [DataMember]
        public bool IsReinsDone { get; set; }
        [DataMember]
        public DateTime ReinsDate { get; set; }
        [DataMember]
        public DateTime ReinsTIme { get; set; }
        [DataMember]
        public string Remarks { get; set; }
        [DataMember]
        public string ReinDoneBy { get; set; }
        [DataMember]
        public int ContactNo { get; set; }
        [DataMember]
        public string GarageAddress { get; set; }
        [DataMember]
        public string ReinsDoneOnAddress { get; set; }
        [DataMember]
        public int DocID { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
       
        
    }
}
