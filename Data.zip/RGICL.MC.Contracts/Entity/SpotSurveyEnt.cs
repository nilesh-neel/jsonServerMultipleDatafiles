﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class SpotSurveyEnt
    {
        [DataMember]
        public int SpotSurveyID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string PolicyNo { get; set; }
        [DataMember]
        public string CoverNoteNo { get; set; }
        [DataMember]
        public bool IsSpotSurveyDone { get; set; }
        [DataMember]
        public string SpotSurveyDoneBy { get; set; }
        [DataMember]
        public string CauseOfLoss { get; set; }
        [DataMember]
        public string ContactNumber { get; set; }
        [DataMember]
        public string OdometerReading { get; set; }
        [DataMember]
        public string PoliceStationLocation { get; set; }
        [DataMember]
        public bool IsVehicleOverloaded { get; set; }
        [DataMember]
        public string VehicleOverSeated { get; set; }

        [DataMember]
        public bool DocumentsAvailable { get; set; }
        [DataMember]
        public int DocID { get; set; }
        [DataMember]
        public string PhotoID { get; set; }


        //[DataMember]
        //public string LossLocation { get; set; }


        [DataMember]
        public bool ReportedToPolice { get; set; }
        [DataMember]
        public string DamagesSides { get; set; }

        [DataMember]
        public string FIRComplaintNo { get; set; }
        [DataMember]
        public string EngineNo { get; set; }
        [DataMember]
        public string ChassisNo { get; set; }
        [DataMember]
        public string SpotSurveyLocation { get; set; }
        [DataMember]
        public DateTime FIRDate { get; set; }
        [DataMember]
        public string FIRUnderSection { get; set; }
        [DataMember]
        public bool InjuryPA { get; set; }
        [DataMember]
        public bool TP { get; set; }
        [DataMember]
        public bool TPPD { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public string UpdatedDate { get; set; }

        //drivers
        [DataMember]
        public int DriverID { get; set; }
        [DataMember]
        public string DriverName { get; set; }
        [DataMember]
        public string DriverRelationship { get; set; }
        [DataMember]
        public DateTime DLExpiryDate { get; set; }
        [DataMember]
        public string LicenseNumber { get; set; }
        [DataMember]
        public bool IsAlcohol { get; set; }
        [DataMember]
        public string TypeOfLicence { get; set; }









    }

 


}
