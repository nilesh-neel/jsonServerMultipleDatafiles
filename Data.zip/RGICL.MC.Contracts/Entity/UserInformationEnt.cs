﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Data;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class UserInformationEnt
    {
        [DataMember]
        public string UserID { get; set; }
        [DataMember]
        public string LoginID { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Password { get; set; }
        [DataMember]
        public string DisplayName { get; set; }
        [DataMember]
        public string EmailID { get; set; }
        [DataMember]
        public string ContactNumber { get; set; }
        [DataMember]
        public string MobileNumber { get; set; }
        [DataMember]
        public string UserType { get; set; }
        [DataMember]
        public string SAPCode { get; set; }
        [DataMember]
        public int LevelID { get; set; }
        [DataMember]
        public DateTime LastLoginDate { get; set; }
        [DataMember]
        public string IPAddress { get; set; }
        [DataMember]
        public string SessionID { get; set; }
        private bool _IsAutoLogin = false;
        [DataMember]
        public bool IsAutoLogin
        {
            get { return _IsAutoLogin; }
            set { value = _IsAutoLogin; }
        }
        [DataMember]
        public bool IsMultiLogin { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public int MaxInActiveDays { get; set; }
        [DataMember]
        public List<UserAuthorizationEnt> AuthorizedPages { get; set; }
        [DataMember]
        public UserRoleEnt Role { get; set; }
        [DataMember]
        public HubEnt Hub { get; set; }
        [DataMember]
        public ProductEnt Product { get; set; }
        [DataMember]
        public ProductCategoryEnt ProductCategory { get; set; }
        [DataMember]
        public NatureOfLossEnt TypeOfLoss { get; set; }
        [DataMember]
        public string PhotoName { get; set; }
        [DataMember]
        public string Signature { get; set; }
        [DataMember]
        public GradeEnt Grade { get; set; }
        [DataMember]
        public UserDetails UserDetail { get; set; }
        [DataMember]
        public bool IsWebUser { get; set; }
        [DataMember]
        public bool IsMobileUser { get; set; }
        [DataMember]
        public bool IsLocked { get; set; }
        [DataMember]
        public string DeviceId { get; set; }
        [DataMember]
        public UserInformationEnt CreatedBy { get; set; }
    }


    [DataContract]
    public class UserMaser
    {
        [DataMember]
        public string UserDetails { get; set; }
        [DataMember]
        public string DTZHT { get; set; }
        [DataMember]
        public string DTProduct { get; set; }
        [DataMember]
        public string UserProductCatMapping { get; set; }
    }
}
