﻿using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class TeamEnt : ParentDetails
    {
        [DataMember]
        public int TeamId { get; set; }
        [DataMember]
        public string TeamName { get; set; }
    }
}
