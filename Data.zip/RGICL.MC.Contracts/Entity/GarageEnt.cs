﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class GarageEnt:ParentDetails
    {
        [DataMember]
        public int GarageID { get; set; }
        [DataMember]
        public DistrictEnt District { get; set; }
        [DataMember]
        public CityEnt City { get; set; }
        [DataMember]
        public StateEnt State { get; set; }
        [DataMember]
        public LocationEnt Location { get; set; }
        [DataMember]
        public MakeEnt Make { get; set; }
        [DataMember]
        public string GarageFullName { get; set; }
        [DataMember]
        public string GarageName { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string Multicar { get; set; }
        [DataMember]
        public string ContactPerson { get; set; }
        [DataMember]
        public string ContactNo { get; set; }
        [DataMember]
        public string TelephoneNo { get; set; }
        [DataMember]
        public bool FastTrackFacility { get; set; }
        [DataMember]
        public string SapCode { get; set; }
        [DataMember]
        public string PaymentKey { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public DateTime TieUpdate { get; set; }
        [DataMember]
        public string PrintLocation { get; set; }
        [DataMember]
        public bool PreferredGarage { get; set; }
        [DataMember]
        public string DiscountAgreed { get; set; }
        [DataMember]
        public bool Approved { get; set; }
        [DataMember]
        public int ApprovedBy { get; set; }
        [DataMember]
        public int NetworkScore { get; set; }
        [DataMember]
        public int ParentID { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int UpdatedBy { get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }
        //[DataMember]
        //public LookupEnt GarageStatus { get; set; }
        [DataMember]
        public int GarageStatusId { get; set; }
        [DataMember]
        public string GarageStatus { get; set; }
        [DataMember]
        public string GaragePinCode { get; set; }
        //[DataMember]
        //public LookupEnt GarageType { get; set; }

        [DataMember]
        public string GarageTypeName { get; set; }
        [DataMember]
        public int GarageTypeId { get; set; }
        [DataMember]
        public UserInformationEnt UserInfo { get; set; }
        [DataMember]
        public bool IsDeleted { get; set; }
    }
}
