
namespace RGICL.MC.Contracts.Entity.Extensions
{
    public static class ClientCustomHeaderContext
    {
        public static CustomHeaderEnt HeaderInformation;

        static ClientCustomHeaderContext()
        {
            HeaderInformation = new CustomHeaderEnt();
        }
    }
}