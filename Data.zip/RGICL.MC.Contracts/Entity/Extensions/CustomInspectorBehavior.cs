﻿using System;
using System.Collections.ObjectModel;
using System.ServiceModel;
using RGICL.MC.Common.Utilities;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using RGICL.MC.Common.Constants;
using System.Web;
using System.ServiceModel.Web;
using System.Collections.Generic;


namespace RGICL.MC.Contracts.Entity.Extensions
{

    [AttributeUsage(AttributeTargets.Class)]
    public class CustomInspectorBehavior : Attribute, IDispatchMessageInspector,
        IClientMessageInspector, IEndpointBehavior, IServiceBehavior
    {
        #region IDispatchMessageInspector

        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            //Retrieve Inbound Object from Request
            if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.CustomAuthorizationEnabled))
            {
                var header = request.Headers.GetHeader<CustomHeaderEnt>("custom-header", "s");

                if (header != null)
                {
                    //CustomHeaderEntServerContextExtension.Current.CustomHeaderEnt = header;
                    OperationContext.Current.IncomingMessageProperties.Add("CustomHeaderEnt", header);
                }
            }
            return null;
        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
            //No need to do anything else

        }

        #endregion

        #region IClientMessageInspector

        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            //Instantiate new HeaderObject with values from ClientContext;

            var dataToSend = new CustomHeaderEnt
            {
                WebUserPwd = ClientCustomHeaderContext.HeaderInformation.WebUserPwd,
                WebSessionId = ClientCustomHeaderContext.HeaderInformation.WebSessionId,
                WebUserId = ClientCustomHeaderContext.HeaderInformation.WebUserId,
                IpAddress = ClientCustomHeaderContext.HeaderInformation.IpAddress,
                IsAutoLogin = ClientCustomHeaderContext.HeaderInformation.IsAutoLogin,
                UserType = ClientCustomHeaderContext.HeaderInformation.UserType
            };

            var typedHeader = new MessageHeader<CustomHeaderEnt>(dataToSend);
            var untypedHeader = typedHeader.GetUntypedHeader("custom-header", "s");

            request.Headers.Add(untypedHeader);

            return null;
        }

        private List<string> WcfUrl = new List<string>()
        {

        };

        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
            //No need to do anything else
        }

        #endregion

        #region IEndpointBehavior

        public void Validate(ServiceEndpoint endpoint)
        {

        }

        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {

        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            var channelDispatcher = endpointDispatcher.ChannelDispatcher;
            if (channelDispatcher == null) return;
            foreach (var ed in channelDispatcher.Endpoints)
            {
                var inspector = new CustomInspectorBehavior();
                ed.DispatchRuntime.MessageInspectors.Add(inspector);
            }
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            var inspector = new CustomInspectorBehavior();
            clientRuntime.MessageInspectors.Add(inspector);
        }

        #endregion

        #region IServiceBehaviour

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
        }

        public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            foreach (ChannelDispatcher cDispatcher in serviceHostBase.ChannelDispatchers)
            {
                foreach (var eDispatcher in cDispatcher.Endpoints)
                {
                    eDispatcher.DispatchRuntime.MessageInspectors.Add(new CustomInspectorBehavior());
                }
            }
        }

        #endregion

    }
}