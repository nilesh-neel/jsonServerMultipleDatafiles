using System;
using System.ServiceModel.Configuration;

namespace RGICL.MC.Contracts.Entity.Extensions
{
    public class CustomInspectorBehaviorExtension : BehaviorExtensionElement
    {
        protected override object CreateBehavior()
        {
            return new CustomInspectorBehavior();
        }

        public override Type BehaviorType
        {
            get { return typeof (CustomInspectorBehavior); }
        }
    }
}