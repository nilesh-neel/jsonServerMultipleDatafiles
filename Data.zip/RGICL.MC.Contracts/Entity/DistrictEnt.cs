﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class DistrictEnt
    {
        [DataMember]
        public int DistrictId { get; set; }
        [DataMember]
        public string DistrictName { get; set; }
        [DataMember]
        public string District_ARC { get; set; }
        [DataMember]
        public int DistrictStateID { get; set; }
        [DataMember]
        public List<CityEnt> City { get; set; }

    }
}
