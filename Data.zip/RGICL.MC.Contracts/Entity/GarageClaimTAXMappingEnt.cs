﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
   public class GarageClaimTAXMappingEnt
    {
        public int ID { get; set; }
        [DataMember]
       public int  TAXType{ get; set; }
        [DataMember]
       public int TAXCategory { get; set; }
        [DataMember]
        public decimal Value { get; set; }
        [DataMember]
        public int ClaimGarageMapID { get; set; }
        [DataMember]
        public bool IsActive{ get; set; }
        [DataMember]
        public int CreatedBy{ get; set; }
        [DataMember]
        public DateTime CreatedDate{ get; set; }
        [DataMember]
        public int UpdatedBy{ get; set; }
        [DataMember]
        public DateTime UpdatedDate { get; set; }
       
    }
}
