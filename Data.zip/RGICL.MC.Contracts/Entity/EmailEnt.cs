﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    public class EmailEnt
    {
        [DataMember]
        public int CommMappingID { get; set; }
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public int EMailID { get; set; }
        [DataMember]
        public string EmailFrom { get; set; }
        [DataMember]
        public string EmailTo { get; set; }
        [DataMember]
        public string EmailCC { get; set; }
        [DataMember]
        public string EmailSubject { get; set; }
        [DataMember]
        public string EmailMessage { get; set; }
        [DataMember]
        public int CreatedBy { get; set; }
        [DataMember]
        public string EventName { get; set; }
        [DataMember]
        public int RoleId { get; set; }
    }
}
