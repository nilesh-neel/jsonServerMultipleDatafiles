﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGICL.MC.Contracts.Entity
{
    public class CountryEnt
    {
        public int CountryId { get; set; }
        public int CountryCode { get; set; }
        public string CountryName { get; set; }
        public List<StateEnt> State { get; set; }
        public bool isActive { get; set; }
    }
}
