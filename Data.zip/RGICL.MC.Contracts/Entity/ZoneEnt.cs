﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System;

namespace RGICL.MC.Contracts.Entity
{
    [Serializable]
    [DataContract]
    public class ZoneEnt : ParentDetails
    {
        [DataMember]
        public int ZoneId { get; set; }
        [DataMember]
        public string ZoneName { get; set; }
        [DataMember]
        public List<HubEnt> Hub { get; set; }
    }
}
