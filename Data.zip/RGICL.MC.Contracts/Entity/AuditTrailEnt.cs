﻿using System;
using System.Collections.Generic;
namespace RGICL.MC.Contracts.Entity
{
   public class AuditTrailEventEnt
    {
       public int EnventId { get; set; }
       public string EventName { get; set; }
       public string EventDescription { get; set; }
       public string DisplayText { get; set; }
       public List<AuditTrailDetailsEnt> AuditEventDetail { get; set; }
       public int CreatedBy { get; set; }
       public DateTime CreatedDate { get; set; }
    }
}
