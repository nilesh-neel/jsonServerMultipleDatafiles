﻿using System;
using System.Runtime.Serialization;

namespace RGICL.MC.Contracts.Entity
{
    [DataContract]
    public class CommunicationEnt
    {
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public string EventCode { get; set; }
    }

    [DataContract]
    public class EmailEnt
    {
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public int EmailID { get; set; }
        [DataMember]
        public string EmailFrom { get; set; }
        [DataMember]
        public string EmailTo { get; set; }
        [DataMember]
        public string EmailCC { get; set; }
        [DataMember]
        public string EmailSubject { get; set; }
        [DataMember]
        public string EmailMessage { get; set; }
        [DataMember]
        public string EmailAttachmentFileName { get; set; }
        [DataMember]
        public bool SentStatus { get; set; }
        [DataMember]
        public DateTime SentDate { get; set; }
        [DataMember]
        public string CommFailureReason { get; set; }
    }

    [DataContract]
    public class SMSEnt
    {
        [DataMember]
        public string ClaimRefNo { get; set; }
        [DataMember]
        public int SMSID { get; set; }
        [DataMember]
        public string SMSFrom { get; set; }
        [DataMember]
        public string SMSTo { get; set; }
        [DataMember]
        public string SMSMessage { get; set; }
        [DataMember]
        public bool SentStatus { get; set; }
        [DataMember]
        public DateTime SentDate { get; set; }
        [DataMember]
        public string CommFailureReason { get; set; }
    }
}

