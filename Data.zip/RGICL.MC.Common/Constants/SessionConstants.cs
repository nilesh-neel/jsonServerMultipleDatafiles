﻿/****************************************************************************************************************
Class Name   : SessionConstants.cs 
Purpose      : Used to define constants/names for all Sessions. 
Created By   : Ravi Kant Shivhare 
Created Date : 14/Sep/2012
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion

namespace RGICL.MC.Common.Constants
{
    public static class SessionConstants
    { 
        #region Public Variables
        public const string LoggedInUserID = "LoggedInUser",
                            UserID = "UserID",
                            EncryptionUniqueKey = "ENCRYPTION_UNIQUE_KEY",
                            CaptchaCode = "CaptchaCode",
                            AuthorizedPages = "AuthorizedPages",
                            LOGGEDINUSERINFO = "LoggedInUserInfo";
                            

        public const string ClaimRefNo = "ClaimRefNo";
        public const string CaseNo = "CaseNo";
        public const string ICEEmpId = "ICEEmpId";
        public const string BranchId = "BranchId";
        public const string PolicyNo = "PolicyNo";
        public const string CoverNoteNo = "CoverNoteNo";        
        public const string ProductId = "ProductId";
        public const string RedirectFlag = "RedirectFlag";

        public const string oCustomHeader = "CustomHeader";
        public const string ProductCategoryList = "ProductCategoryList";
        public const string InboxDetails = "InboxDetails";
        public const string DashboardDetails = "DashboardDetails";
        public const string InboxDetails_BSM = "InboxDetails_BSM";
        public const string InboxDetails_RAM = "InboxDetails_RAM";
        public const string InboxDetails_RCU = "InboxDetails_RCU";
        public const string InboxDetails_CVM = "InboxDetails_CVM";
        public const string InboxDetails_Surveyor = "InboxDetails_Surveyor";
        public const string ClaimDocList = "ClaimDocList";

        public const string BlazeRuleDesc = "BlazeRuleDesc";

        public const string SurveyorType = "SurveyorType";

        #endregion
    }
}
