﻿/****************************************************************************************************************
Class Name   : MessageConstants.cs 
Purpose      : Used to define constants for common messages (for all validations).
Created By   : Ravi Kant Shivhare 
Created Date : 26/Sep/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion

namespace RGICL.MC.Common.Constants
{
    public static class MessageConstants
    {
        #region Public Variables
        public const string DataSavedSuccessfully = "Data Saved Successfully";
        public const string QueryStringFormatException = "Query String '{0}' was not in a correct format OR the delegate type conversion is incorrect.";
        public const string ExtensionGenericHandlerMessage = "Please Upload File With Valid Extension.";
        public const string FileNotFound = "File Not Found.";
        public const string FileDownloadedSuccessfully = "File Downloaded Successfully.";
        public const string InvalidCredentials = "Username/Password/Image Code invalid. Please try again with correct details.";
        public const string InvalidCredentialsWOImageCode = "Username/Password invalid. Please try again with correct details.";
        public const string IncorrectCaptchaCode = "Captcha code is incorrect!!";
        public const string AccountLocked = "Your account has been locked. Please contact your system administrator";
        public const string AccessDenied = "Access Denied. You are not authorized user.";
        public const string RightClickNotAllowed = "Right Click not allowed.";
        #endregion
    }
}
