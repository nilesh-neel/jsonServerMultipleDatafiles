﻿/****************************************************************************************************************
Class Name   : CacheConstants.cs 
Purpose      : Used to define constants/names for all Cache. 
Created By   : Ravi Kant Shivhare 
Created Date : 14/Sep/2012
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion

namespace RGICL.MC.Common.Constants
{
    public static class CacheConstants
    {
        #region Public Variables
        public const string TestCache = "TestCache";
        public const string LookupsDetails = "Lookups";
        public const string lstCOUserEnt = "lstCOUserEnt";

        #endregion
    }
}
