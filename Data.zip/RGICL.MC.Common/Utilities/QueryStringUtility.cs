﻿/****************************************************************************************************************
Class Name   : QueryStringUtility.cs 
Purpose      : Used to define utility functions for Query String. 
Created By   : Ravi Kant Shivhare 
Created Date : 21/Sep/2012
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Web;

using RGICL.MC.Common.Constants;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public static class QueryStringUtility
    {
        #region Private Member Variables
        /// <summary>
        /// Alias for HttpContext.Current.Request
        /// </summary>
        //private static HttpRequest Request = HttpContext.Current.Request;
        #endregion

        #region Public Functions

        #region Get Functions
        #region "Get Functions For Generic Type Value"
        /// <summary>
        /// Used to get the value of Query String value irrespective of return type.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int etc.</typeparam>
        /// <param name="strKey">Query String Key</param>
        /// <returns>Generic Value; it can either be string, int etc.</returns>
        public static T Get<T>(string strKey)
        {
            return Get<T>(strKey, default(T));
        }

        /// <summary>
        /// Used to get the value of Query String value irrespective of return type.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int etc.</typeparam>
        /// <param name="strKey">Query String Key</param>
        /// <param name="defaultValue">default value to return if the Query String value is "".</param>
        /// <returns>Generic Value; it can either be string, int etc.</returns>
        public static T Get<T>(string strKey, T defaultValue)
        {
            T result = defaultValue;
            if (!String.IsNullOrEmpty(HttpContext.Current.Request.QueryString[strKey]))
            {
                string value = HttpContext.Current.Request.QueryString[strKey];
                try
                {
                    result = (T)Convert.ChangeType(value, typeof(T));
                }
                catch (FormatException)
                {
                    //Could not convert.  Pass back default value...
                    //result = default(T);
                    throw new FormatException(String.Format(MessageConstants.QueryStringFormatException, strKey));
                }
            }
            else if (result == null && typeof(T) == typeof(String) && HttpContext.Current.Request.QueryString[strKey] == String.Empty)
            {
                result = (T)(object)String.Empty;
            }
            return result;
        }
        #endregion

        #endregion

        #region Other Utility Function
        /// <summary>
        /// Used to check whether Query String key exist or not.
        /// </summary>
        /// <param name="strQueryStringKey">Query String Key</param>
        /// <returns>boolean value</returns>
        public static bool IsKeyExist(string strQueryStringKey)
        {
            return HttpContext.Current.Request.QueryString[strQueryStringKey] != null;
        }
        #endregion

        #endregion
    }
}
