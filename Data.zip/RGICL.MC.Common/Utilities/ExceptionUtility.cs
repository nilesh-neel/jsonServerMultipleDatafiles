﻿using System;
using System.Text;
using System.IO;
using System.Web;
using System.Collections;
using System.Xml;
using System.Threading;

using RGICL.MC.Common.Constants;
using System.Data;

namespace RGICL.MC.Common.Utilities
{
    public static class ExceptionUtility
    {
        #region Private Const Members
        private const string strKeyValueFormat = "{0} - {1}\n",
                     strIPHeader = "\n IP: ",
                     strDateTimeHeader = "\n Date Time: ",
                     strUserIdHeader = "\n User Id: ",
                     strUserNameHeader = "\n User Name: ",
                     strPageNameHeader = "\n Page Name: ",
                     strMethodNameHeader = "\n Method Name: ",
                     strMessageHeader = "\n Message: ",
                     strStackTraceHeader = "\n Stack Trace: ",
                     strInnerExHeader = "\n Inner Exception: ";
                     
        private const string strSeparator = "----------------------------------------------------------------------------------------------------";
        private static readonly string strErrorLogFolderPath = GetAppAbsolutePath(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ErrorLogFolderPath));
        private const string strFileNameSeparator = "_";
        #endregion

        public enum LogMode : int
        {
            Email = 0,
            Save = 1
        }
        public class LogType
        {
            public const string ErrorLog = "ErrorLog";
            public const string StringLog = "StringLog";
            public const string StackTraceLog = "StackTraceLog";
        }

        public static void RaiseException(Exception ex, LogMode enLogMode = LogMode.Save)
        {
            RaiseException(ex, null, LogMode.Save);
        }
        public static void RaiseException(Exception ex, string strMethodName, LogMode enLogMode = LogMode.Save)
        {
            try
            {
                if (!AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.ErrorLogEnabled))
                    return;

                if (AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ErrorLogType).ToUpper() == "XML")
                {
                    ExceptionXmlUtility.WriteExceptionLogXml(ex, strMethodName);
                    return;
                }
                
                string strExceptionDetails = GetExceptionDetails(ex, strMethodName);

                switch (enLogMode)
                {
                    case LogMode.Email:
                        //Call Email method and send strExceptionDetails
                        break;
                    case LogMode.Save:
                        string strFolderPath = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ErrorLogFolderPath).ToString();
                        string strFileName = GetCustomFileName(LogType.ErrorLog, ".txt");
                        WriteLog(strExceptionDetails, strFolderPath, strFileName);
                        break;
                }
            }
            catch (Exception exInner)
            {
                throw exInner;
            }
        }
        public static void WriteStringLog(string strInput)
        {
            try
            {
                StringBuilder sbException = new StringBuilder();
                sbException.AppendLine(strSeparator);
                sbException.AppendLine(DateTime.Now + " : " + strInput);

                string strFolderPath = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.StringLogFolderPath).ToString();
                string strFileName = GetCustomFileName(LogType.StringLog, ".txt");
                WriteLog(sbException.ToString(), strFolderPath, strFileName);
            }
            catch (Exception ex)
            {
                RaiseException(ex);
            }
        }

        private static string GetExceptionDetails(Exception ex, string strMethodName)
        {
            StringBuilder sbException = new StringBuilder();
            foreach (DictionaryEntry item in ex.Data)
            {
                sbException.AppendFormat(strKeyValueFormat, item.Key, item.Value);
            }
            sbException.AppendLine(strSeparator);

            sbException.AppendLine(strDateTimeHeader + DateTime.Now.ToString());
            sbException.AppendLine(strIPHeader + UserHostAddress);
            sbException.AppendLine(strUserIdHeader + LoggedInUserID);
            sbException.AppendLine(strUserNameHeader + LoggedInUserName);

            sbException.AppendLine(strPageNameHeader + PageName);

            if (strMethodName != null)
                sbException.AppendLine(strMethodNameHeader + strMethodName);

            sbException.AppendLine(strMessageHeader);
            sbException.AppendLine(ex.Message);

            sbException.AppendLine(strStackTraceHeader);
            sbException.AppendLine(ex.StackTrace);

            return sbException.ToString();
        }
        private static void WriteLog(string strLog, string strLogFolderRelativePath, string strFileName)
        {
            try
            {
                string strFolderPath = GetAppAbsolutePath(strLogFolderRelativePath);
                if (!Directory.Exists(strFolderPath))
                    Directory.CreateDirectory(strFolderPath);

                string strFilePathAndName = strFolderPath + "\\" + strFileName;

                using (FileStream fsLog = new FileStream(strFilePathAndName, FileMode.Append, FileAccess.Write))
                {
                    using (StreamWriter swLog = new StreamWriter(fsLog))
                    {
                        swLog.WriteLine(strLog);
                        swLog.Flush();
                    }
                }
            }
            catch (UnauthorizedAccessException uaex)
            {
                RaiseException(uaex);
            }
            catch (Exception ex)
            {
                RaiseException(ex);
            }
        }
        private static string GetCustomFileName(string strFileNamePrefix, string strExtension)
        {
            return strFileNamePrefix + strFileNameSeparator + DateTime.Now.ToString(DateTimeUtility.DefaultDateFormat) + strExtension;
        }
        public static string GetAppAbsolutePath(string strRelativePath)
        {
            //return HttpContext.Current.Server.MapPath(strRelativePath);
            return System.Web.Hosting.HostingEnvironment.MapPath(strRelativePath) ?? strRelativePath;
        }

        #region Stack Trace
        public static void WriteStackTraceLog(string strProcName)
        {
            try
            {
                if (AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.StackTraceLogEnabled))
                {
                    System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(true);

                    string strFolderPath = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.StackTraceLogFolderPath);
                    string strFileName = GetCustomFileName(LogType.StackTraceLog, ".txt");
                    string strFilePathAndName = strFolderPath + "\\" + strFileName;

                    strFolderPath = GetAppAbsolutePath(strFolderPath);
                    if (!Directory.Exists(strFolderPath))
                        Directory.CreateDirectory(strFolderPath);

                    using (StreamWriter swStackTraceLogMain = new StreamWriter(strFilePathAndName, true, Encoding.ASCII))
                    {
                        swStackTraceLogMain.WriteLine(strSeparator);
                        swStackTraceLogMain.WriteLine(strProcName + " : " + DateTime.Now + " : " + "User ID: " + LoggedInUserID + " : ");
                        swStackTraceLogMain.Flush();
                    }

                    string strStackIndent = "\t";
                    for (int i = 0; i < st.FrameCount; i++)
                    {
                        System.Diagnostics.StackFrame sf = st.GetFrame(i);
                        StringBuilder sbLineToWrite = new StringBuilder();
                        sbLineToWrite.AppendLine(String.Format("Method: {0}", sf.GetMethod()));
                        sbLineToWrite.AppendLine(String.Format(strStackIndent + "File: {0}", sf.GetFileName()));
                        sbLineToWrite.AppendLine(String.Format(strStackIndent + "Line Number: {0}", sf.GetFileLineNumber()));
                        using (StreamWriter swStackTraceLog = new StreamWriter(strFilePathAndName, true, Encoding.ASCII))
                        {
                            swStackTraceLog.WriteLine("");
                            swStackTraceLog.WriteLine(sbLineToWrite.ToString());
                            swStackTraceLog.Flush();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionUtility.RaiseException(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion

        public class ExceptionXmlUtility
        {
            public ExceptionXmlUtility() { }

            public static void WriteExceptionLogXml(Exception ex, string strMethodName)
            {
                try
                {
                    int iSNo = 1;
                    if (!Directory.Exists(strErrorLogFolderPath))
                        Directory.CreateDirectory(strErrorLogFolderPath);
                    string strLogFileName = GetCustomFileName(LogType.ErrorLog, ".config");

                    XmlDocument xdException = new XmlDocument();
                    if (File.Exists(strErrorLogFolderPath + strLogFileName))
                    {
                        xdException.Load(strErrorLogFolderPath + strLogFileName);
                        iSNo = xdException.DocumentElement.ChildNodes.Count + 1;
                    }
                    else
                    {
                        ExceptionXmlUtility.CreateExceptionXml(ex, strMethodName, strErrorLogFolderPath + strLogFileName);
                        return;
                    }

                    XmlElement xeNodeException = xdException.CreateElement("Error");
                    XmlElement xeNodeErrorSNo = xdException.CreateElement("SrNo");
                    XmlElement xeNodeDateTime = xdException.CreateElement("DateTime");
                    XmlElement xeNodeIP = xdException.CreateElement("IP");
                    XmlElement xeNodeUserId = xdException.CreateElement("UserId");
                    XmlElement xeNodeUserName = xdException.CreateElement("UserName");

                    XmlElement xeNodePageName = xdException.CreateElement("PageName");
                    XmlElement xeNodeMethodName = xdException.CreateElement("MethodName");

                    XmlElement xeNodeMessage = xdException.CreateElement("Message");
                    XmlElement xeNodeStackTrace = xdException.CreateElement("StackTrace");

                    xeNodeErrorSNo.InnerText = iSNo.ToString();
                    xeNodeDateTime.InnerText = DateTime.Now.ToString();
                    xeNodeIP.InnerText = UserHostAddress;
                    xeNodeUserId.InnerText = LoggedInUserID;
                    xeNodeUserName.InnerText = LoggedInUserName;

                    xeNodePageName.InnerText = PageName;
                    xeNodeMethodName.InnerText = strMethodName;

                    xeNodeMessage.InnerText = ex.Message;
                    xeNodeStackTrace.InnerText = ex.StackTrace;

                    xeNodeException.AppendChild(xeNodeErrorSNo);
                    xeNodeException.AppendChild(xeNodeDateTime);
                    xeNodeException.AppendChild(xeNodeIP);
                    xeNodeException.AppendChild(xeNodeUserId);
                    xeNodeException.AppendChild(xeNodeUserName);

                    xeNodeException.AppendChild(xeNodePageName);
                    xeNodeException.AppendChild(xeNodeMethodName);

                    xeNodeException.AppendChild(xeNodeMessage);
                    xeNodeException.AppendChild(xeNodeStackTrace);

                    xdException.DocumentElement.InsertBefore(xeNodeException, xdException.DocumentElement.FirstChild);
                    xdException.Save(strErrorLogFolderPath + strLogFileName);
                }
                catch (UnauthorizedAccessException uaex)
                {
                    throw uaex;
                }
            }

            private static void CreateExceptionXml(Exception ex, string strMethodName, string strFileName)
            {
                using (XmlTextWriter xtwLog = new XmlTextWriter(strFileName, System.Text.Encoding.UTF8))
                {
                    xtwLog.WriteStartDocument();
                    xtwLog.WriteStartElement("Errors");
                    xtwLog.WriteStartElement("Error");
                    xtwLog.WriteElementString("SNo", "1");

                    xtwLog.WriteElementString("DateTime", DateTime.Now.ToString());
                    xtwLog.WriteElementString("IP", UserHostAddress);
                    xtwLog.WriteElementString("UserId", LoggedInUserID);
                    xtwLog.WriteElementString("UserName", LoggedInUserName);

                    xtwLog.WriteElementString("PageName", PageName);
                    if (strMethodName != null)
                        xtwLog.WriteElementString("MethodName", strMethodName);
                    else
                        xtwLog.WriteElementString("MethodName", "");

                    if (ex != null)
                    {
                        xtwLog.WriteElementString("Message", ex.Message);
                        xtwLog.WriteElementString("StackTrace", ex.StackTrace);
                    }
                    else
                    {
                        xtwLog.WriteElementString("Message", "");
                        xtwLog.WriteElementString("StackTrace", "");
                    }
                    xtwLog.WriteEndElement();
                    xtwLog.WriteEndElement();
                    xtwLog.WriteEndDocument();
                }
            }

            public static System.Data.DataTable ReadExceptionLogXml(string strErrorLogDate)
            {
                if (!string.IsNullOrEmpty(strErrorLogDate))
                {
                    string strFilePathAndName = strErrorLogFolderPath + LogType.ErrorLog + strFileNameSeparator + strErrorLogDate + ".config";
                    if (File.Exists(strFilePathAndName))
                    {
                        DataSet ds = new DataSet();
                        ds.ReadXml(strFilePathAndName);
                        return ds.Tables[0];
                    }
                }
                return null;
            }
        }

        #region Private Properties
        private static string UserHostAddress
        {
            get { return HttpContext.Current != null ? HttpContext.Current.Request.UserHostAddress.ToString() : string.Empty; }
        }
        private static string PageName
        {
            get { return HttpContext.Current != null ? HttpContext.Current.Request.Url.PathAndQuery : string.Empty; }
        }
        private static string LoggedInUserID
        {
            get { return CommonUtility.LoggedInUserID; }
        }
        private static string LoggedInUserName
        {
            get { return CommonUtility.LoggedInUserName; }
        }
        #endregion
    }
}
