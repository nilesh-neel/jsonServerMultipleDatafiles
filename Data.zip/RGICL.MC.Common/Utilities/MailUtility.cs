﻿/****************************************************************************************************************
Class Name   : MailUtility.cs 
Purpose      : Used to define utility functions for sending mail
Created By   : Ravi Kant Shivhare
Created Date : 16/Jan/2014
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives
using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using RGICL.MC.Common.Constants;
#endregion

namespace RGICL.MC.Common.Utilities
{
    public class MailUtility
    {
        #region "Private Variables"
        private string SMTP = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.SMTP, "smtpout.secureserver.net");
        private bool SMTPAuthenticate = AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.SMTPAuthenticate);
        private bool EnableSsl = AppSettingsUtility.IsEnabledAppSettingsKeyValue(AppSettingsConstants.EnableSsl);
        private string MailFromEmailID = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.MailFromEmailID, "ravikant@test.com");
        private string MailUserName = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.MailUserName);
        private string MailPassword = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.MailPassword);
        //private string IncomingMailServerType = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.IncomingMailServerType);
        //private string IncomingMailServer = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.IncomingMailServer);
        //private string IncomingMailServerPort = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.IncomingMailServerPort, "0");
        private string OutgoingMailServerPort = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.OutgoingMailServerPort, "25");
        private string MailAttachmentMaxSize = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.MailAttachmentMaxSize, "0");//"3000000"
        private string MailAttachmentMaxSizeMessage = AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.MailAttachmentMaxSizeMessage);//"Mail attachment size exceeded. Maximum attachment size is '{0}' bytes.";

        private const string MailSentStatusSuccessMessage = "Success";
        private const string MailSentStatusFailMessage = "Fail";

        public enum MailSentStatus
        {
            Success = 0,
            Fail = 99
        }
        #endregion

        #region Properties
        private string MailFrom { get; set; }
        private string MailTo { get; set; }
        private string MailCC { get; set; }
        private string MailBCC { get; set; }
        public string MailSubject { get; set; }
        public string MailBody { get; set; }
        public List<string> MailAttachmentsFilePath { get; set; }
        public string MailSentStatusMessage { get; set; }
        //public string MailSentStatusMessage { get; set; }
        #endregion

        #region Constructors
        public MailUtility()
        { }
        public MailUtility(string sMailTo)
        {
            MailFrom = MailFromEmailID;//EmailId from config file
            if (!string.IsNullOrEmpty(sMailTo))
                MailTo = sMailTo;
        }
        public MailUtility(string sMailFrom, string sMailTo)
            : this(sMailTo)
        {
            if (!string.IsNullOrEmpty(sMailFrom))
                MailFrom = sMailFrom;
        }
        public MailUtility(string sMailFrom, string sMailTo, string sMailCC)
            : this(sMailFrom, sMailTo)
        {
            if (!string.IsNullOrEmpty(sMailCC))
                MailCC = sMailCC;
        }
        public MailUtility(string sMailFrom, string sMailTo, string sMailCC, string sMailBCC)
            : this(sMailFrom, sMailTo, sMailCC)
        {
            if (!string.IsNullOrEmpty(sMailBCC))
                MailBCC = sMailBCC;
        }
        #endregion

        #region "SendMail"
        public int SendMail(bool bIsSendMailUsingNetMail = false)
        {
            if (bIsSendMailUsingNetMail)
                return SendMailUsingNetMail();
            else
                return SendMailUsingWebMail();
        }

        #region "SendMail Using System.Net.Mail"
        private int SendMailUsingNetMail()
        {
            try
            {
                if (!IsValidAttachementSize(MailAttachmentsFilePath))
                {
                    this.MailSentStatusMessage = string.Format(MailAttachmentMaxSizeMessage, MailAttachmentMaxSize.ToString());
                    return (int)MailSentStatus.Fail;
                }

                System.Net.Mail.MailMessage oMail = new System.Net.Mail.MailMessage();
                oMail.Priority = System.Net.Mail.MailPriority.High;
                oMail.IsBodyHtml = true;
                oMail.BodyEncoding = System.Text.Encoding.UTF8;
                //oMail.Headers.Add("encoding", "utf-8");  

                System.Net.Mail.MailAddress oMailAddress_From = new System.Net.Mail.MailAddress(this.MailFrom);
                oMail.From = oMailAddress_From;
                if (!string.IsNullOrEmpty(this.MailTo))
                    oMail.To.Add(this.MailTo);
                if (!string.IsNullOrEmpty(this.MailCC))
                    oMail.CC.Add(this.MailCC);
                if (!string.IsNullOrEmpty(this.MailBCC))
                    oMail.Bcc.Add(this.MailBCC);
                oMail.Subject = this.MailSubject;
                oMail.Body = this.MailBody;

                if (MailAttachmentsFilePath != null)
                {
                    System.Net.Mail.Attachment oMailAttachment = null;
                    foreach (string sMailAttachmentFilePath in MailAttachmentsFilePath)
                    {
                        if (!string.IsNullOrEmpty(sMailAttachmentFilePath))
                        {
                            oMailAttachment = new System.Net.Mail.Attachment(HttpContext.Current.Server.MapPath(sMailAttachmentFilePath));
                            oMail.Attachments.Add(oMailAttachment);
                        }
                    }
                }

                System.Net.Mail.SmtpClient oSmtpClient = new System.Net.Mail.SmtpClient();
                oSmtpClient.Host = SMTP;
                oSmtpClient.Port = Convert.ToInt32(OutgoingMailServerPort);
                oSmtpClient.EnableSsl = EnableSsl;

                if (SMTPAuthenticate)
                {
                    oSmtpClient.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    oSmtpClient.UseDefaultCredentials = false;
                    oSmtpClient.Credentials = new System.Net.NetworkCredential(MailUserName, MailPassword);
                }
                else
                {
                    oSmtpClient.UseDefaultCredentials = true;
                }
                oSmtpClient.ServicePoint.MaxIdleTime = 1; /* this code prevent your message from terminated */

                oSmtpClient.Send(oMail);

                this.MailSentStatusMessage = MailSentStatusSuccessMessage;
                return (int)MailSentStatus.Success;
            }
            catch (Exception ex)
            {
                //HttpContext.Current.Response.Write("<br/>Error Sending Mail on SendMail function -- To: " + MailTo + " <br/>Error: " + e.ToString());
                //HttpContext.Current.Response.End();
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
                this.MailSentStatusMessage = MailSentStatusFailMessage;
                return (int)MailSentStatus.Fail;
            }
        }
        #endregion

        #region "SendMail Using System.Web.Mail - Obsolete"
        private int SendMailUsingWebMail()
        {
            try
            {
                if (!IsValidAttachementSize(MailAttachmentsFilePath))
                {
                    this.MailSentStatusMessage = string.Format(MailAttachmentMaxSizeMessage, MailAttachmentMaxSize.ToString());
                    return (int)MailSentStatus.Fail;
                }

                System.Web.Mail.MailMessage oMail = new System.Web.Mail.MailMessage();
                oMail.Priority = System.Web.Mail.MailPriority.High;
                oMail.BodyFormat = System.Web.Mail.MailFormat.Html;
                oMail.BodyEncoding = System.Text.Encoding.UTF8;
                //oMail.Headers.Add("encoding", "utf-8");

                oMail.From = this.MailFrom;
                oMail.To = this.MailTo;
                oMail.Cc = this.MailCC;
                oMail.Bcc = this.MailBCC;
                oMail.Subject = this.MailSubject;
                oMail.Body = this.MailBody;

                if (MailAttachmentsFilePath != null)
                {
                    System.Web.Mail.MailAttachment oMailAttachment = null;
                    foreach (string sMailAttachmentFilePath in MailAttachmentsFilePath)
                    {
                        if (!string.IsNullOrEmpty(sMailAttachmentFilePath))
                        {
                            oMailAttachment = new System.Web.Mail.MailAttachment(HttpContext.Current.Server.MapPath(sMailAttachmentFilePath));
                            oMail.Attachments.Add(oMailAttachment);
                        }
                    }
                }

                if (Convert.ToInt32(OutgoingMailServerPort) != 0)
                {
                    oMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpserverport", OutgoingMailServerPort);
                }

                if (SMTPAuthenticate)
                {
                    oMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", "1");// 'basic authentication
                    oMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", MailUserName);// 'set your username here
                    oMail.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", MailPassword);// 'set your password here
                }

                System.Web.Mail.SmtpMail.SmtpServer = SMTP;
                System.Web.Mail.SmtpMail.Send(oMail);

                this.MailSentStatusMessage = MailSentStatusSuccessMessage;
                return (int)MailSentStatus.Success;
            }
            catch (Exception ex)
            {
                //HttpContext.Current.Response.Write("<br/>Error Sending Mail on SendMail function -- To: " + MailTo + " <br/>Error: " + e.ToString());
                //HttpContext.Current.Response.End();
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
                this.MailSentStatusMessage = MailSentStatusFailMessage;
                return (int)MailSentStatus.Fail;
            }
        }
        #endregion
        #endregion

        public bool IsValidAttachementSize(HttpFileCollection oPostedFiles)
        {
            long lContentLength = 0;
            for (int i = 0; i < oPostedFiles.Count; i++)
            {
                if (oPostedFiles[i].ContentLength > 0)
                    lContentLength += oPostedFiles[i].ContentLength;
            }
            if (lContentLength <= Convert.ToInt64(MailAttachmentMaxSize))
                return true;
            return false;
        }
        public bool IsValidAttachementSize(List<string> lstMailAttachmentsFilePath)
        {
            long lContentLength = 0;
            if (lstMailAttachmentsFilePath != null)
            {
                FileInfo oFileInfo = null;
                foreach (string sMailAttachmentFilePath in lstMailAttachmentsFilePath)
                {
                    if (!string.IsNullOrEmpty(sMailAttachmentFilePath))
                    {
                        oFileInfo = new FileInfo(HttpContext.Current.Server.MapPath(sMailAttachmentFilePath));
                        if (oFileInfo.Length > 0)
                            lContentLength += oFileInfo.Length;
                    }
                }
            }

            if (lContentLength <= Convert.ToInt64(MailAttachmentMaxSize))
                return true;
            return false;
        }
    }
}
