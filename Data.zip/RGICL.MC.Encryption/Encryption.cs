using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

using RGICL.MC.Common.Constants;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Encryption
{
    public static class Encryption
    {
        private static string ENCRYPTION_KEY = string.Empty;
        private static byte[] SALT;

        public static string Encrypt(string strText)
        {
            return Encrypt(strText, UniqueKey);
        }
        public static string Encrypt(string strText, string strEncryptionUniqueKey)
        {
            try
            {
                string inputText = strText;
                if (string.IsNullOrEmpty(strText))
                    return "";

                RijndaelManaged rijndaelCipher = new RijndaelManaged();
                byte[] plainText = Encoding.Unicode.GetBytes(inputText);

                SALT = System.Text.Encoding.Default.GetBytes(strEncryptionUniqueKey);

                PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(strEncryptionUniqueKey, SALT);
                using (ICryptoTransform encryptor = rijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16)))
                {
                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                        {
                            cryptoStream.Write(plainText, 0, plainText.Length);
                            cryptoStream.FlushFinalBlock();
                            return Convert.ToBase64String(memoryStream.ToArray());
                        }
                    }
                }
            }
            catch(Exception ex)
            {
            }
            return string.Empty;
        }

        public static string Decrypt(string strText)
        {
            return Decrypt(strText, UniqueKey);
        }
        public static string Decrypt(string strText, string strEncryptionUniqueKey)
        {
            try
            {
                string inputText = strText;
                if (string.IsNullOrEmpty(inputText))
                    return "";

                RijndaelManaged rijndaelCipher = new RijndaelManaged();
                byte[] encryptedData = Convert.FromBase64String(inputText);

                SALT = System.Text.Encoding.Default.GetBytes(strEncryptionUniqueKey);

                PasswordDeriveBytes secretKey = new PasswordDeriveBytes(strEncryptionUniqueKey, SALT);
                using (ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
                {
                    using (MemoryStream memoryStream = new MemoryStream(encryptedData))
                    {
                        using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                        {
                            byte[] plainText = new byte[encryptedData.Length];
                            int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                            return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return string.Empty;
        }

        public static string UniqueKey
        {
            get { return SessionUtility.Get<string>(SessionConstants.EncryptionUniqueKey); }
        }
    }
}
