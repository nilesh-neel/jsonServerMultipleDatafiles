/****************************************************************************************************************
Class Name   : CustomEncryption.cs 
Purpose      : Used to define utility functions CustomEncryption.
Created By   : Ravi Kant Shivhare 
Created Date : 03/Oct/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

using RGICL.MC.Common.Constants;
using RGICL.MC.Common.Utilities;
#endregion

namespace RGICL.MC.Encryption
{
    public static class CustomEncryption
    {
        private static string ENCRYPTION_KEY = string.Empty;
        private static byte[] SALT;

        private static string DES_ENCRYPTION_KEY = "@.|*#A~^"; // The Key to encrypt or Decrypt
        private static byte[] DES_IV = { 0xAA, 41, 78, 96, 15, 0x12, 78, 0x11 }; // Initialization Vector of Encryption or Decryption

        public static string Encrypt(string strText, bool bDESCrypto = true)
        {
            if (bDESCrypto)
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(DES_ENCRYPTION_KEY);
                byte[] rgbIV = DES_IV;

                return Encrypt(strText, rgbKey, rgbIV, true);
            }
            return Encrypt(strText, UniqueKey);
        }
        public static string Encrypt(string strText, string strEncryptionUniqueKey)
        {
            try
            {
                if (string.IsNullOrEmpty(strText))
                    return string.Empty;

                SALT = System.Text.Encoding.Default.GetBytes(strEncryptionUniqueKey);
                PasswordDeriveBytes secretKey = new PasswordDeriveBytes(strEncryptionUniqueKey, SALT);
                byte[] rgbKey = secretKey.GetBytes(32);
                byte[] rgbIV = secretKey.GetBytes(16); // Initialization Vector of Encryption or Decryption 

                return Encrypt(strText, rgbKey, rgbIV, false);
            }
            catch(Exception ex)
            {
            }
            return string.Empty;
        }

        public static string Decrypt(string strText, bool bDESCrypto = true)
        {
            if (bDESCrypto)
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(DES_ENCRYPTION_KEY);
                byte[] rgbIV = DES_IV;

                return Decrypt(strText, rgbKey, rgbIV, true);
            }
            return Decrypt(strText, UniqueKey);
        }
        public static string Decrypt(string strText, string strEncryptionUniqueKey)
        {
            try
            {
                if (string.IsNullOrEmpty(strText))
                    return string.Empty;
                
                SALT = System.Text.Encoding.Default.GetBytes(strEncryptionUniqueKey);
                PasswordDeriveBytes secretKey = new PasswordDeriveBytes(strEncryptionUniqueKey, SALT);
                byte[] rgbKey = secretKey.GetBytes(32);
                byte[] rgbIV = secretKey.GetBytes(16);

                return Decrypt(strText, rgbKey, rgbIV, false);
            }
            catch (Exception ex)
            {
            }
            return string.Empty;
        }

        private static string Encrypt(string strText, byte[] rgbKey, byte[] rgbIV, bool bDESCrypto = true)
        {
            ICryptoTransform ICT = null;
            byte[] plainText = null;
            try
            {
                if (bDESCrypto)
                {
                    DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
                    ICT = DES.CreateEncryptor(rgbKey, rgbIV);
                    plainText = Encoding.UTF8.GetBytes(strText);
                }
                else
                {
                    RijndaelManaged RM = new RijndaelManaged();
                    ICT = RM.CreateEncryptor(rgbKey, rgbIV);
                    plainText = Encoding.Unicode.GetBytes(strText);
                }

                using (MemoryStream MS = new MemoryStream())
                {
                    using (CryptoStream CS = new CryptoStream(MS, ICT, CryptoStreamMode.Write))
                    {
                        CS.Write(plainText, 0, plainText.Length);
                        CS.FlushFinalBlock();
                        return Convert.ToBase64String(MS.ToArray());
                    }
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                ICT.Dispose();
            }
            return string.Empty;
        }
        private static string Decrypt(string strText, byte[] rgbKey, byte[] rgbIV, bool bDESCrypto = true)
        {
            ICryptoTransform ICT = null;
            try
            {
                if (bDESCrypto)
                {
                    DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
                    ICT = DES.CreateDecryptor(rgbKey, rgbIV);
                }
                else
                {
                    RijndaelManaged RM = new RijndaelManaged();
                    ICT = RM.CreateDecryptor(rgbKey, rgbIV);
                }

                byte[] encryptedData = Convert.FromBase64String(strText);
                using (MemoryStream MS = new MemoryStream(encryptedData))
                {
                    using (CryptoStream CS = new CryptoStream(MS, ICT, CryptoStreamMode.Read))
                    {
                        byte[] plainText = new byte[encryptedData.Length];
                        int iDecryptedCount = CS.Read(plainText, 0, plainText.Length);
                        if (bDESCrypto)
                            return Encoding.UTF8.GetString(plainText, 0, iDecryptedCount);
                        else
                            return Encoding.Unicode.GetString(plainText, 0, iDecryptedCount);
                    }
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                ICT.Dispose();
            }
            return string.Empty;
        }

        public static void SetUniqueKey()
        {
            SessionUtility.Set<string>(SessionConstants.EncryptionUniqueKey, Guid.NewGuid().ToString());
        }
        public static string UniqueKey
        {
            get { return SessionUtility.Get<string>(SessionConstants.EncryptionUniqueKey); }
        }
    }
}
