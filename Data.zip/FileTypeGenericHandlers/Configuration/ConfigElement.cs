﻿namespace FileTypeGenericHandlers.Configuration
{
    using System;
    using System.Configuration;

    public class ConfigElement : ConfigurationElement
    {
        [ConfigurationProperty("ContentType", IsRequired=false)]
        public string ContentType
        {
            get
            {
                return (string) base["ContentType"];
            }
            set
            {
                base["ContentType"] = value;
            }
        }

        [ConfigurationProperty("value", IsRequired=true)]
        public string ElementValue
        {
            get
            {
                return (string) base["value"];
            }
            set
            {
                base["value"] = value;
            }
        }
    }
}

