﻿namespace FileTypeGenericHandlers.FileChecker
{
    using FileTypeGenericHandlers.FileChecker.Configuration;
    using NLog;
    using System;
    using System.Configuration;
    using System.IO;
    using System.Runtime.InteropServices;

    public class FileChecker
    {
        private static ConfigExtension conf = new ConfigExtension();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        static FileChecker()
        {
            object obj2 = new object();
            lock (obj2)
            {
                conf = ConfigurationManager.GetSection("FileChecker") as ConfigExtension;
            }
        }

        private static bool ByteArrayCompare(byte[] a1, byte[] a2)
        {
            for (int i = 0; i < a1.Length; i++)
            {
                if (a1[i] != a2[i])
                {
                    return false;
                }
            }
            return true;
        }

        public static bool CheckFileType(FileTypes extension, string fileName)
        {
            byte[] buffer;
            string mimefromFile = string.Empty;
            using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
            {
                buffer = reader.ReadBytes(0x100);
                mimefromFile = GetMimefromFile(buffer);
            }
            if (mimefromFile == fileTypeToMimeType(extension))
            {
                logger.Info("Sucessfully determined type");
                return true;
            }
            return TryAlternateApproach(extension, fileName, buffer);
        }

        private static byte[] convertHexToByte(string hexvalue)
        {
            int length = hexvalue.Length;
            byte[] buffer = new byte[length / 2];
            for (int i = 0; i < length; i += 2)
            {
                buffer[i / 2] = Convert.ToByte(hexvalue.Substring(i, 2), 0x10);
            }
            return buffer;
        }

        private static string fileTypeToExtension(FileTypes fileTypes)
        {
            return ("." + fileTypes.ToString());
        }

        private static string fileTypeToMimeType(FileTypes fileTypes)
        {
            string str = string.Empty;
            switch (fileTypes)
            {
                case FileTypes.txt:
                    return "";

                case FileTypes.pdf:
                    return "application/pdf";

                case FileTypes.csv:
                    return str;

                case FileTypes.xlsx:
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                case FileTypes.xls:
                    return "application/vnd.ms-excel";

                case FileTypes.zip:
                    return "application/x-zip-compressed";

                case FileTypes.sevenz:
                    return "application/7-zip-compressed";

                case FileTypes.jpg:
                    return "image/jpeg";

                case FileTypes.img:
                    return str;

                case FileTypes.gif:
                    return "image/gif";

                case FileTypes.tif:
                    return "image/tiff";

                case FileTypes.rar:
                    return str;

                case FileTypes.bmp:
                    return "image/bmp";
            }
            return str;
        }

        private static bool FindFileTypefromMagicBytes(byte[] first256byte, bool retVal, FileTypes fileTypes)
        {
            byte[] buffer = convertHexToByte(conf.ExtensionToFind.GetValuebyIndex(fileTypeToExtension(fileTypes)).HexValue);
            if (conf.ExtensionToFind.GetValuebyIndex(fileTypeToExtension(fileTypes)).Offset <= 0L)
            {
                retVal = ByteArrayCompare(buffer, first256byte);
            }
            return retVal;
        }

        [DllImport("urlmon.dll", CharSet=CharSet.Auto)]
        private static extern uint FindMimeFromData(uint pBC, [MarshalAs(UnmanagedType.LPStr)] string pwzUrl, [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer, uint cbSize, [MarshalAs(UnmanagedType.LPStr)] string pwzMimeProposed, uint dwMimeFlags, out uint ppwzMimeOut, uint dwReserverd);
        private static string GetMimefromFile(byte[] buffer)
        {
            try
            {
                uint num;
                FindMimeFromData(0, null, buffer, 0x100, null, 0, out num, 0);
                IntPtr ptr = new IntPtr((long) num);
                string str = Marshal.PtrToStringUni(ptr);
                Marshal.FreeCoTaskMem(ptr);
                return str;
            }
            catch (Exception exception)
            {
                logger.ErrorException("Could not convert Mime Type ", exception);
                return "Unknown";
            }
        }

        private static byte[] StringToByteArray(string hex)
        {
            int length = hex.Length;
            byte[] buffer = new byte[length / 2];
            for (int i = 0; i < length; i += 2)
            {
                buffer[i / 2] = Convert.ToByte(hex.Substring(i, 2), 0x10);
            }
            return buffer;
        }

        private static bool TryAlternateApproach(FileTypes extension, string fileName, byte[] first256byte)
        {
            bool retVal = false;
            return FindFileTypefromMagicBytes(first256byte, retVal, extension);
        }
    }
}

