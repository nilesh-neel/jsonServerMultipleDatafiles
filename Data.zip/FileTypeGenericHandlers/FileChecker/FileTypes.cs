﻿namespace FileTypeGenericHandlers.FileChecker
{
    using System;

    public enum FileTypes
    {
        bmp = 13,
        csv = 3,
        gif = 10,
        img = 9,
        jpg = 8,
        pdf = 2,
        rar = 12,
        sevenz = 7,
        tif = 11,
        txt = 1,
        xls = 5,
        xlsx = 4,
        zip = 6
    }
}

