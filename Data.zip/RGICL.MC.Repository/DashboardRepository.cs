﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using System.Xml.Linq;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class DashboardRepository
    {
        int _iErrorno;

        public List<DashboardEnt> GetDashboardDataByHubAndUserId(int iHubId, int iUserId, int iLossId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDashboard = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.GetDashboardCountForCM, out dsDashboard,
                      oDAL.CreateParameter("@UserId", DbType.Int32, iUserId),
                      oDAL.CreateParameter("@HubId", DbType.Int32, iHubId),
                      oDAL.CreateParameter("@NatureOfLossId", DbType.Int32, iLossId));

                return this._iErrorno == 0 ? (dsDashboard.Tables[0].Rows.Count > 0 && dsDashboard.Tables[0] != null ?
                    GetDashboardData(dsDashboard) : null) : null;


                //GarageAddition = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Garage_Addition_Cases"]),
                //RCUPending = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["RCU_Pending"]),
                //SpotSurveyorAppointmentPending = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Spot_Surveyor_Appointment_Pending"]),
                //FinalSurveyNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_New"]),
                //FinalSurveyWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_WIP"]),
                //FinalSurveyTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_TotalSubmitted"]),
                //SpotSurveyNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_New"]),
                //SpotSurveyWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_WIP"]),
                //SpotSurveyTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_TotalSubmitted"]),
                //ReInspectionNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_New"]),
                //ReInspectionWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_WIP"]),
                //ReInspectionTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_TotalSubmitted"]),

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<DashboardEnt> GetDashboardData(DataSet dsDashboard)
        {
            return (from dr in dsDashboard.Tables[0].AsEnumerable() select BindDataToDashboardEnt(dr)).ToList();
        }

        public DashboardEnt BindDataToDashboardEnt(DataRow drDashboard)
        {
            return new DashboardEnt
            {
                TotalNew = Convert.ToInt32(drDashboard["Total_New"]),
                TotalWIP = Convert.ToInt32(drDashboard["Total_WIP"]),
                TotalCommon = Convert.ToInt32(drDashboard["Total_Common"]),
                TotalOrphan = Convert.ToInt32(drDashboard["Total_Orphan"]),
                SurveyAssignedByOthers = Convert.ToInt32(drDashboard["Survey_Assigned_By_Others"]),
                TotalHUB = Convert.ToInt32(drDashboard["Total_Hub"]),
                FinalSurveyNew = Convert.ToInt32(drDashboard["FinalSurvey_New"]),
                FinalSurveyWIP = Convert.ToInt32(drDashboard["FinalSurvey_WIP"]),
                FinalSurveyTotalSubmitted = Convert.ToInt32(drDashboard["FinalSurvey_TotalSubmitted"]),
                SpotSurveyNew = Convert.ToInt32(drDashboard["SpotSurvey_New"]),
                SpotSurveyWIP = Convert.ToInt32(drDashboard["SpotSurvey_WIP"]),
                SpotSurveyTotalSubmitted = Convert.ToInt32(drDashboard["SpotSurvey_TotalSubmitted"]),
                ReInspectionNew = Convert.ToInt32(drDashboard["ReinspectionSurvey_New"]),
                ReInspectionWIP = Convert.ToInt32(drDashboard["ReinspectionSurvey_WIP"]),
                ReInspectionTotalSubmitted = Convert.ToInt32(drDashboard["ReInspectionSurvey_TotalSubmitted"]),
                RCUPending=Convert.ToInt32(drDashboard["RCU_Pending"]),
                GarageAddition=Convert.ToInt32(drDashboard["Garage_Addition_Cases"])

            };
        }

        //public DashboardEnt GetDashboardDataByHubAndUserId(int iHubId, int iUserId)
        //{
        //    try
        //    {
        //        CRUD oDAL = new CRUD();
        //        DataSet dsDashboard = new DataSet();

        //        this._iErrorno = oDAL.Select(ProcedureConstants.GetDashboardCountForCM, out dsDashboard,
        //              oDAL.CreateParameter("@UserId", DbType.Int32, iUserId),
        //              oDAL.CreateParameter("@HubId", DbType.Int32, iHubId));

        //        if (this._iErrorno == 0)
        //        {
        //            return new DashboardEnt
        //            {
        //                TotalNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Total_New"]),
        //                TotalWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Total_WIP"]),
        //                TotalCommon = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Total_Common"]),
        //                TotalOrphan = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Total_Orphan"]),
        //                SurveyAssignedByOthers = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Survey_Assigned_By_Others"]),
        //                TotalHUB = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Total_Hub"]),

        //            };
        //        }
        //        else
        //            return null;
              


        //        //GarageAddition = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Garage_Addition_Cases"]),
        //        //RCUPending = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["RCU_Pending"]),
        //        //SpotSurveyorAppointmentPending = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Spot_Surveyor_Appointment_Pending"]),
        //        //FinalSurveyNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_New"]),
        //        //FinalSurveyWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_WIP"]),
        //        //FinalSurveyTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_TotalSubmitted"]),
        //        //SpotSurveyNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_New"]),
        //        //SpotSurveyWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_WIP"]),
        //        //SpotSurveyTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_TotalSubmitted"]),
        //        //ReInspectionNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_New"]),
        //        //ReInspectionWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_WIP"]),
        //        //ReInspectionTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_TotalSubmitted"]),

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //        //ex.DisplayCustomMessage("");
        //    }
        //}

        public List<DashboardEnt> GetSurveyorDashboardDataByUserId(int iUserId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDashboard = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.GetDashboardCountForSurveyor, out dsDashboard,
                      oDAL.CreateParameter("@UserId", DbType.Int32, iUserId));
                      
                return this._iErrorno == 0 ? (dsDashboard.Tables[0].Rows.Count > 0 && dsDashboard.Tables[0] != null ?
                    GetSurveyorDashboardData(dsDashboard) : null) : null;


                //GarageAddition = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Garage_Addition_Cases"]),
                //RCUPending = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["RCU_Pending"]),
                //SpotSurveyorAppointmentPending = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["Spot_Surveyor_Appointment_Pending"]),
                //FinalSurveyNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_New"]),
                //FinalSurveyWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_WIP"]),
                //FinalSurveyTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["FinalSurvey_TotalSubmitted"]),
                //SpotSurveyNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_New"]),
                //SpotSurveyWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_WIP"]),
                //SpotSurveyTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["SpotSurvey_TotalSubmitted"]),
                //ReInspectionNew = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_New"]),
                //ReInspectionWIP = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_WIP"]),
                //ReInspectionTotalSubmitted = Convert.ToInt32(dsDashboard.Tables[0].Rows[0]["ReInspectionSurvey_TotalSubmitted"]),

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<DashboardEnt> GetSurveyorDashboardData(DataSet dsDashboard)
        {
            return (from dr in dsDashboard.Tables[0].AsEnumerable() select BindDataToSurveyorDashboardEnt(dr)).ToList();
        }

        public DashboardEnt BindDataToSurveyorDashboardEnt(DataRow drDashboard)
        {
            return new DashboardEnt
            {               
                FinalSurveyNew = Convert.ToInt32(drDashboard["FinalSurvey_New"]),
                FinalSurveyWIP = Convert.ToInt32(drDashboard["FinalSurvey_WIP"]),
                FinalSurveyTotalSubmitted = Convert.ToInt32(drDashboard["FinalSurvey_TotalSubmitted"]),
                SpotSurveyNew = Convert.ToInt32(drDashboard["SpotSurvey_New"]),
                SpotSurveyWIP = Convert.ToInt32(drDashboard["SpotSurvey_WIP"]),
                SpotSurveyTotalSubmitted = Convert.ToInt32(drDashboard["SpotSurvey_TotalSubmitted"]),
                ReInspectionNew = Convert.ToInt32(drDashboard["ReinspectionSurvey_New"]),
                ReInspectionWIP = Convert.ToInt32(drDashboard["ReinspectionSurvey_WIP"]),
                ReInspectionTotalSubmitted = Convert.ToInt32(drDashboard["ReInspectionSurvey_TotalSubmitted"])               
            };
        }
    }
}
