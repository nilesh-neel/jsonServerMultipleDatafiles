﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;

namespace RGICL.MC.Repository
{
    public class RegionRepository
    {

        public static List<StateEnt> StateList { get; set; }

        public static List<DistrictEnt> DistictList { get; set; }

        public static List<CityEnt> CityList { get; set; }

        //int? Errorno;
       static int? ErrorCode = 0;


       public RegionRepository()
       {
           GetStateDistictCity();
       }

        //public static RegionRepository()
        //{
        //    GetStateDistictCity();
        //}

        /*
                /// <summary>
                /// Display he list of States to user.
                /// </summary>
                /// <returns></returns>
                public List<RegionEnt> GetAllState()
                {
                    RegionEnt objState = new RegionEnt();
                    List<RegionEnt> lstState = null;
            
                    try
                    {
                        CRUD oDAL = new CRUD();
                        DataSet dsState = new DataSet();

                        this.Errorno = oDAL.Select(ProcedureConstants.GetAllStates, out dsState);

                        if (this.Errorno == 0)
                        {

                            if (dsState.Tables[0].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsState.Tables[0].Rows)
                                {
                                    if (lstState == null)
                                        lstState = new List<RegionEnt>(); 
                                    objState = new RegionEnt();
                                    objState.StateId = Convert.ToInt32(dr["State_ID_PK"]);
                                    objState.StateName = Convert.ToString(dr["State_Name"]);                            
                                    lstState.Add(objState);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw;

                    }

                    return lstState;
                }

                /// <summary>
                /// Display the list of City based on selected state
                /// </summary>
                /// <param name="stateID"></param>
                /// <returns></returns>
                public List<RegionEnt> GetCityFromState(int stateID)
                {
                    RegionEnt objCity = new RegionEnt();
                    List<RegionEnt> lstCity = null;

                    try
                    {
                        CRUD oDAL = new CRUD();
                        DataSet dsCity = new DataSet();

                        this.Errorno = oDAL.Select(ProcedureConstants.GetCityFromState, out dsCity,oDAL.CreateParameter("@stateID", DbType.Int32, stateID));

                        if (this.Errorno == 0)
                        {

                            if (dsCity.Tables[0].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsCity.Tables[0].Rows)
                                {
                                    if (lstCity == null)
                                        lstCity = new List<RegionEnt>();
                                    objCity = new RegionEnt();
                                    objCity.CityId = Convert.ToInt32(dr["City_or_Village_ID_PK"]);
                                    objCity.CityName = Convert.ToString(dr["City_or_Village_Name"]);
                                    lstCity.Add(objCity);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw;

                    }

                    return lstCity;

                }

                /// <summary>
                /// Display the list of Location based on selected state
                /// </summary>
                /// <param name="stateID"></param>
                /// <returns></returns>
                public List<RegionEnt> GetLocationFromState(int stateID)
                {
                    RegionEnt objLoc = new RegionEnt();
                    List<RegionEnt> lstLoc = null;

                    try
                    {
                        CRUD oDAL = new CRUD();
                        DataSet dsLoc = new DataSet();

                        this.Errorno = oDAL.Select(ProcedureConstants.GetLocationFromState, out dsLoc, oDAL.CreateParameter("@stateID", DbType.Int32, stateID));

                        if (this.Errorno == 0)
                        {

                            if (dsLoc.Tables[0].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsLoc.Tables[0].Rows)
                                {
                                    if (lstLoc == null)
                                        lstLoc = new List<RegionEnt>();
                                    objLoc = new RegionEnt();
                                    objLoc.LocationId = Convert.ToInt32(dr["LocationId"]);
                                    objLoc.LocationName = Convert.ToString(dr["LocationName"]);
                                    lstLoc.Add(objLoc);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw;

                    }

                    return lstLoc;

                }

                /// <summary>
                /// Display the list of District based on state selected
                /// </summary>
                /// <param name="stateID"></param>
                /// <returns></returns>
                public List<RegionEnt> GetDistrictFromState(int stateID)
                {
            
                    RegionEnt objDist = new RegionEnt();
                    List<RegionEnt> lstDist = null;

                    try
                    {
                        CRUD oDAL = new CRUD();
                        DataSet dsDist = new DataSet();

                        this.Errorno = oDAL.Select(ProcedureConstants.GetDistrictFromState, out dsDist, oDAL.CreateParameter("@stateID", DbType.Int32, stateID));

                        if (this.Errorno == 0)
                        {

                            if (dsDist.Tables[0].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsDist.Tables[0].Rows)
                                {
                                    if (lstDist == null)
                                        lstDist = new List<RegionEnt>();
                                    objDist = new RegionEnt();
                                    objDist.DistrictId = Convert.ToInt32(dr["District_ID_PK"]);
                                    objDist.DistrictName = Convert.ToString(dr["District_Name"]);
                                    lstDist.Add(objDist);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw;

                    }

                    return lstDist;

                }

                /// <summary>
                /// Display the list of City based on selected district
                /// </summary>
                /// <param name="districtID"></param>
                /// <returns></returns>
                public List<RegionEnt> GetCityFromDistrict(int districtID) 
                {
                    RegionEnt objCity = new RegionEnt();
                    List<RegionEnt> lstCity = null;

                    try
                    {
                        CRUD oDAL = new CRUD();
                        DataSet dsCity = new DataSet();

                        this.Errorno = oDAL.Select(ProcedureConstants.GetCityFromDistrict, out dsCity, oDAL.CreateParameter("@stateID", DbType.Int32, districtID));

                        if (this.Errorno == 0)
                        {

                            if (dsCity.Tables[0].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsCity.Tables[0].Rows)
                                {
                                    if (lstCity == null)
                                        lstCity = new List<RegionEnt>();
                                    objCity = new RegionEnt();
                                    objCity.DistrictId = Convert.ToInt32(dr["District_ID_PK"]);
                                    objCity.DistrictName = Convert.ToString(dr["District_Name"]);
                                    lstCity.Add(objCity);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw;

                    }            

                    return lstCity;

                }

                */

        public static void GetStateDistictCity()
        {
            try
            {
                if (StateList == null || DistictList == null || CityList == null)
                {
                    CRUD oDAL = new CRUD();
                    DataSet dsCity = new DataSet();
                    ErrorCode = oDAL.Select(ProcedureConstants.GetAllStateDistrictCity, out dsCity);
                    if (ErrorCode == 0)
                    {
                        StateList = GetStateList(dsCity.Tables[0]);
                        DistictList = GetDistictList(dsCity.Tables[1]);
                        CityList = GetCityList(dsCity.Tables[2]);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        //public static List<DistrictEnt> GetDistictById(int stateId)
        //{
        //    return DistictList.Where(sr => sr.DistrictStateID == stateId).ToList();
        //}

        //private static void BindMasterDataToEntity(DataSet ds)
        //{
        //    StateList = GetStateList(ds.Tables["StatMaster"]);
        //    DistictList = GetDistictList(ds.Tables["DistMaster"]);

        //    //var distInState = distList.Where(s => s.DistrictStateID== 2).ToList();
        //}

        private static List<StateEnt> GetStateList(DataTable dsState)
        {
            return (from dr in dsState.AsEnumerable() select BindDataToStateEnt(dr)).ToList();
        }

        private static StateEnt BindDataToStateEnt(DataRow dr)
        {
            return new StateEnt
            {
                StateId = Convert.ToInt32(dr["State_ID_PK"]),
                StateName = Convert.ToString(dr["State_Name"]),
                District = null
            };
        }

        private static List<DistrictEnt> GetDistictList(DataTable dsDist)
        {
            return (from dr in dsDist.AsEnumerable() select BindDataToDistrictEnt(dr)).ToList();
        }

        private static DistrictEnt BindDataToDistrictEnt(DataRow dr)
        {
            return new DistrictEnt
            {
                DistrictId = Convert.ToInt32(dr["District_ID_PK"]),
                DistrictName = Convert.ToString(dr["District_Name"]),
                DistrictStateID = Convert.ToInt32(dr["District_State_FK"])
            };
        }

        private static List<CityEnt> GetCityList(DataTable dtCity)
        {
            return (from dr in dtCity.AsEnumerable() select BindDataToCityEnt(dr)).ToList();
        }

        private static CityEnt BindDataToCityEnt(DataRow dr)
        {
            return new CityEnt
            {
                CityId = Convert.ToInt32(dr["CityID"]),
                CityName = Convert.ToString(dr["CityName"]),
                CityDistrictId = Convert.ToInt32(dr["DistrictID"]),
                CityStateId = Convert.ToInt32(dr["StateId"])

            };
        }
    }
}
