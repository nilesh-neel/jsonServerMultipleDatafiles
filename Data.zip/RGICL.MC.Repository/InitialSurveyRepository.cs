﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class InitialSurveyRepository
    {
        public int iErrorno;

        public InitialSurveyEnt GetCIDetailsForISD(string claimRefNo)
        {
            InitialSurveyEnt objIS = null;           
            
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetCIDataForISD, out ds, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo));
                if (iErrorno == 0 && ds.Tables.Count>0)
                {
                    objIS = ds.Tables[0].Rows[0].ToEntity<InitialSurveyEnt>();
                    objIS.Reserve = ds.Tables[0].ToEntityList<ReserveEnt>();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return objIS;
        }

        public InitialSurveyEnt GetISDDetails(string claimRefNo)
        {
            InitialSurveyEnt objIS = null;

            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetISDDetails, out ds, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo));
                if (iErrorno == 0)
                {
                    objIS = ds.Tables[0].Rows[0].ToEntity<InitialSurveyEnt>();

                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return objIS;
        }

        public int UpdateISDDetails(InitialSurveyEnt objISD)
        {            
            try
            {
                CRUD oDAL = new CRUD();
                DataTable dtISD=null;
                DataTable dtReserve = null;
                DataSet ds=new DataSet();
              

                dtISD = objISD.ToDataTable<InitialSurveyEnt>(TableTypeConstants.InitialSurveyDetails);
                dtReserve = objISD.Reserve.ToDataTable<ReserveEnt>(TableTypeConstants.ReserveDetails);
                ds.Tables.Add(dtISD);
                ds.Tables.Add(dtReserve);

                iErrorno = oDAL.Insert(ProcedureConstants.UpdateISDDetails, ds);
               
                
            }
            catch (Exception ex)
            {
                throw ex;                
            }
            return iErrorno;
        }
    }
}
