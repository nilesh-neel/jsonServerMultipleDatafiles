﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{

    public class ApprovalRepository
    {
        public int iErrorno;
        public string result;

        public List<ClaimEnt> GetTehnicalApprovalList(UserInformationEnt objUserInformationEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetTehnicalApprovalList, out dsUserInfo,
                                   oDAL.CreateParameter("@piUserId", DbType.Int32, objUserInformationEnt.UserID));
                                    //oDAL.CreateParameter("@piRoleId", DbType.Int32, objUserInformationEnt.UserDetail.Role.FirstOrDefault().RoleId),//Where(r=>r.IsSelected==true).First().RoleId,
                                    //oDAL.CreateParameter("@piZoneId", DbType.Int32, objUserInformationEnt.UserDetail.Zone.FirstOrDefault().ZoneId),
                                    //oDAL.CreateParameter("@piHubId", DbType.Int32, objUserInformationEnt.UserDetail.Zone.FirstOrDefault().Hub.FirstOrDefault().HubID),
                                    //oDAL.CreateParameter("@piProducyId", DbType.Int32, objUserInformationEnt.UserDetail.Role.FirstOrDefault().RoleId),
                                    //oDAL.CreateParameter("@piProducyCategoryId", DbType.Int32, objUserInformationEnt.UserDetail.ProductCategory.FirstOrDefault().CategoryId),
                                    //oDAL.CreateParameter("@piTypeOfLoss", DbType.Int32, objUserInformationEnt.UserDetail.TypeOfLoss.FirstOrDefault().Id));
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     GetClaimData(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<ClaimEnt> GetFinancialApprovalList(UserInformationEnt objUserInformationEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetFinancialApprovalList, out dsUserInfo,
                                   oDAL.CreateParameter("@piUserId", DbType.Int32, objUserInformationEnt.UserID));
                //oDAL.CreateParameter("@piRoleId", DbType.Int32, objUserInformationEnt.UserDetail.Role.FirstOrDefault().RoleId),//Where(r=>r.IsSelected==true).First().RoleId,
                //oDAL.CreateParameter("@piZoneId", DbType.Int32, objUserInformationEnt.UserDetail.Zone.FirstOrDefault().ZoneId),
                //oDAL.CreateParameter("@piHubId", DbType.Int32, objUserInformationEnt.UserDetail.Zone.FirstOrDefault().Hub.FirstOrDefault().HubID),
                //oDAL.CreateParameter("@piProducyId", DbType.Int32, objUserInformationEnt.UserDetail.Role.FirstOrDefault().RoleId),
                //oDAL.CreateParameter("@piProducyCategoryId", DbType.Int32, objUserInformationEnt.UserDetail.ProductCategory.FirstOrDefault().CategoryId),
                //oDAL.CreateParameter("@piTypeOfLoss", DbType.Int32, objUserInformationEnt.UserDetail.TypeOfLoss.FirstOrDefault().Id));
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     GetClaimData(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public int CreateWorkFlowForTechnicalApproval(ApprovalEnt objApprovalEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Insert(
                                    ProcedureConstants.InsetUpdateWorkFlowDetails,
                                    oDAL.CreateParameter("@action", DbType.String, objApprovalEnt.Action),
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objApprovalEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@WorkStepName", DbType.String, objApprovalEnt.WorkStepName),
                                    oDAL.CreateParameter("@ProcessInstanceName", DbType.String, objApprovalEnt.ProcessInstanceName),
                                    oDAL.CreateParameter("@CreatedBy", DbType.Int32, objApprovalEnt.CreatedBy),
                                    oDAL.CreateParameter("@ActionType", DbType.String, objApprovalEnt.ActionType),
                                    oDAL.CreateParameter("@ApprovalType", DbType.String, objApprovalEnt.ApprovalType),
                                    oDAL.CreateParameter("@MethodName", DbType.String, objApprovalEnt.MethodName),
                                    oDAL.CreateParameter("@ServiceName", DbType.String, objApprovalEnt.ServiceName)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }

        public int CreateWorkFlowForTechnicalApprovalAudit(ApprovalEnt objApprovalEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Insert(
                                    ProcedureConstants.InsetWorkFlowDetailsAudit,
                                    oDAL.CreateParameter("@action", DbType.String, objApprovalEnt.Action),
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objApprovalEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@WorkStepName", DbType.String, objApprovalEnt.WorkStepName),
                                    oDAL.CreateParameter("@ProcessInstanceName", DbType.String, objApprovalEnt.ProcessInstanceName),
                                    oDAL.CreateParameter("@CreatedBy", DbType.Int32, objApprovalEnt.CreatedBy),
                                    oDAL.CreateParameter("@ActionType", DbType.String, objApprovalEnt.ActionType),
                                    oDAL.CreateParameter("@ApprovalType", DbType.String, objApprovalEnt.ApprovalType),
                                    oDAL.CreateParameter("@MethodName", DbType.String, objApprovalEnt.MethodName),
                                    oDAL.CreateParameter("@ServiceName", DbType.String, objApprovalEnt.ServiceName)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }


        public int SaveClaimApprovalMatrix(ApprovalEnt objApprovalEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Insert(
                                    ProcedureConstants.InsetClaimApprovalMatrix,
                                    oDAL.CreateParameter("@action", DbType.String, "I"),
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objApprovalEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@RoleID", DbType.Int32, objApprovalEnt.RoleId),
                                    oDAL.CreateParameter("@CreatedBy", DbType.Int32, objApprovalEnt.CreatedBy),
                                    oDAL.CreateParameter("@ActionType", DbType.String, objApprovalEnt.ActionType),
                                    oDAL.CreateParameter("@ApprovalType", DbType.String, objApprovalEnt.ApprovalType),
                                    oDAL.CreateParameter("@toleranceAmount", DbType.Decimal, objApprovalEnt.ToleranceAmount)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }

        public int UpdateClaimApprovalMatrix(ApprovalEnt objApprovalEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Insert(
                                    ProcedureConstants.InsetClaimApprovalMatrix,
                                    oDAL.CreateParameter("@action", DbType.String, "U"),
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objApprovalEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@RoleID", DbType.Int32, objApprovalEnt.RoleId),
                                    oDAL.CreateParameter("@PrevRoleID", DbType.Int32, objApprovalEnt.PrevRoleId),
                                    oDAL.CreateParameter("@ActionTakenBy", DbType.Int32, objApprovalEnt.CreatedBy),
                                    oDAL.CreateParameter("@ActionType", DbType.String, objApprovalEnt.ActionType),
                                    oDAL.CreateParameter("@ApprovalType", DbType.String, objApprovalEnt.ApprovalType),
                                    oDAL.CreateParameter("@toleranceAmount", DbType.Decimal, objApprovalEnt.ToleranceAmount)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }

        public int SaveSavvionServiceErrorLog(ApprovalEnt objApprovalEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Insert(
                                    ProcedureConstants.InsetSavvionServiceErrorLog,
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objApprovalEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@ServiceType", DbType.String, objApprovalEnt.ServiceType),
                                    oDAL.CreateParameter("@ServiceName", DbType.String, objApprovalEnt.ServiceName),
                                    oDAL.CreateParameter("@WorkStepName", DbType.String, objApprovalEnt.WorkStepName),
                                    oDAL.CreateParameter("@ProcessName", DbType.String, objApprovalEnt.ProcessInstanceName),
                                    oDAL.CreateParameter("@ExpectedInputParameter", DbType.String, objApprovalEnt.ExpectedInputParameter),
                                    oDAL.CreateParameter("@ExpectedOuputParameter", DbType.String, objApprovalEnt.ExpectedOuputParameter),
                                    oDAL.CreateParameter("@SavvionResonseCode", DbType.String, objApprovalEnt.SavvionResonseCode),
                                    oDAL.CreateParameter("@SavvionErrorMassage", DbType.String, objApprovalEnt.SavvionErrorMassage),
                                    oDAL.CreateParameter("@MethodName", DbType.String, objApprovalEnt.MethodName),
                                    oDAL.CreateParameter("@PageName", DbType.String, objApprovalEnt.PageName),
                                    oDAL.CreateParameter("@CreatedBy", DbType.String, objApprovalEnt.CreatedBy)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }

        public int UpdateClaimStatus(ClaimEnt objClaimEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Insert(
                                    ProcedureConstants.UpdateClaimStatus,
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objClaimEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@ClaimStatusID", DbType.String, objClaimEnt.ClaimStatusID),
                                    oDAL.CreateParameter("@ClaimActionID", DbType.String, objClaimEnt.ClaimActionID)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }
        public List<ClaimEnt> GetClaimData(DataSet dsClaim)
        {
           // List<ClaimEnt> lstClaimEnt = new List<ClaimEnt>();
           //return lstClaimEnt = dsClaim.Tables[0].ToEntityList<ClaimEnt>();
            return (from dr in dsClaim.Tables[0].AsEnumerable() select BindDataToClaimEnt(dr)).ToList();
        }


        public ClaimEnt BindDataToClaimEnt(DataRow drClaim)
        {
            return new ClaimEnt
            {
                ClaimRefNo = Convert.ToString(drClaim["ClaimRefNo"]),
                PolicyNo = Convert.ToString(drClaim["PolicyNo"]),
                InsuredName = Convert.ToString(drClaim["InsuredName"]),
                ClaimStatusMsg = Convert.ToString(drClaim["ClaimStatusDescription"]),
                VehicleNumber = Convert.ToString(drClaim["VehicleNumber"]),
                GarageName = Convert.ToString(drClaim["GarageName"]),
                intimationDate = Convert.ToString(drClaim["IntimationDate"]),
                DateOfLoss = Convert.ToString(drClaim["DateOfLoss"]),
                ClaimOwner = Convert.ToString(drClaim["ClaimOwnerName"]),
                LOBName = Convert.ToString(drClaim["LOB"]),
                NatureOfLoss = Convert.ToString(drClaim["NatureOfLoss"]),
                Product = Convert.ToString(drClaim["Description"]),
                HubName = Convert.ToString(drClaim["HubName"]),
                EstimatedLoss = Convert.ToDouble(drClaim["EstimatedLoss"]),
                ProductId = Convert.ToInt32(drClaim["ProductID"]),
                HubId = Convert.ToInt32(drClaim["hubID"]),
                ZoneID = Convert.ToInt32(drClaim["Zone_Code"]),
                RoleName = Convert.ToString(drClaim["RoleCode"]),
                MaxLimit = Convert.ToDecimal(drClaim["MaxLimit"]),
                WorkStepName = Convert.ToString(drClaim["WorkStepName"]),
                ProcessInstanceName = Convert.ToString(drClaim["ProcessInstanceName"]),
                RoleId = Convert.ToInt32(drClaim["RoleID"]),

                RiskScore = Convert.ToInt32(drClaim.Table.Columns.Contains("RiskScore") ? Convert.ToInt32(drClaim["RiskScore"]) : 0),
                RiskScoreLimitFA = Convert.ToInt32(drClaim.Table.Columns.Contains("RiskScoreLimitFA") ? Convert.ToInt32(drClaim["RiskScoreLimitFA"]) : 0),
                RiskScoreLimitCA = Convert.ToInt32(drClaim.Table.Columns.Contains("RiskScoreLimitCA") ? Convert.ToInt32(drClaim["RiskScoreLimitCA"]) : 0),
                AmountLimitFA = Convert.ToDecimal(drClaim.Table.Columns.Contains("AmountLimitFA") ? Convert.ToDecimal(drClaim["AmountLimitFA"]) : 0),
                AmountLimitCA = Convert.ToDecimal(drClaim.Table.Columns.Contains("AmountLimitCA") ? Convert.ToDecimal(drClaim["AmountLimitCA"]) : 0),
                JobAmountLimitFA = Convert.ToDecimal(drClaim.Table.Columns.Contains("JobAmountLimitFA") ? Convert.ToDecimal(drClaim["JobAmountLimitFA"]) : 0),
                JobAmountLimitCA = Convert.ToDecimal(drClaim.Table.Columns.Contains("JobAmountLimitCA") ? Convert.ToDecimal(drClaim["JobAmountLimitCA"]) : 0),
                lastTechnicalApproverRoleId = Convert.ToInt32(drClaim.Table.Columns.Contains("lastTechnicalApproverRoleId") ? Convert.ToInt32(drClaim["lastTechnicalApproverRoleId"]) : 0),
                lastTechnicalApproverRoleName = Convert.ToString(drClaim.Table.Columns.Contains("lastTechnicalApproverRoleName") ? Convert.ToString(drClaim["lastTechnicalApproverRoleName"]) : ""),
                IsRequiredFAForUser = Convert.ToString(drClaim.Table.Columns.Contains("IsRequiredFAForUser") ? Convert.ToString(drClaim["IsRequiredFAForUser"]) : "")
               
            };
        }
    }
}
