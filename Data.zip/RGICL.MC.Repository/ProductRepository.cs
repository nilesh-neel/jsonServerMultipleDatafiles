﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.IO;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class ProductRepository
    {
        int iErrorno;

        public List<ProductCategoryEnt> GetProductCategory()
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetProductCategoryAndProductList, out dsUser);

                return this.iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                   BindXmlToProdCatEnt(dsUser) : null) : null;
                //GetAllCategory(dsUser) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private List<ProductCategoryEnt> BindXmlToProdCatEnt(DataSet dsProdCat)
        {
            var xmlDoc = Convert.ToString(dsProdCat.Tables[0].Rows[0][0]);
            XDocument doc = XDocument.Parse(xmlDoc);
            return ObjectXmlUtility.DeserializeParams<ProductCategoryEnt>(doc);
        }

        public List<ProductEnt> GetProductList()
        {
            return null;
        }
        public List<ProductEnt> GetProductByCategory(int iCategoryId)
        {
            return null;
        }

        public List<GradeEnt> GetProductLevel()
        {
            return null;
        }


        private List<ProductCategoryEnt> GetAllCategory(DataSet dsData)
        {

            DataTable dtProdCat = dsData.Tables[0].DefaultView.ToTable(true, "Veh_Type_ID_PK", "Veh_Type_Name");

            return (from dr in dtProdCat.AsEnumerable()
                    select BindDataToCategoryEnt(dr, dsData)
                    ).ToList();
        }

        private ProductCategoryEnt BindDataToCategoryEnt(DataRow dr, DataSet dsProd)
        {
            return new ProductCategoryEnt
                {
                    CategoryId = Convert.ToInt32(dr["Veh_Type_ID_PK"]),
                    CategoryName = Convert.ToString(dr["Veh_Type_Name"]),
                    Product = (List<ProductEnt>)(from drProd in dsProd.Tables[0].AsEnumerable()
                                                 where drProd.Field<int>("Veh_Type_ID_PK") == Convert.ToInt32(dr["Veh_Type_ID_PK"])
                                                 select BindDataToProductEnt(drProd, dsProd.Tables[1])).ToList()
                };
        }
        private List<ProductEnt> BindProducts(DataSet dsProduct)
        {
            return (from dr in dsProduct.Tables[0].AsEnumerable()
                    select BindDataToProductEnt(dr, dsProduct.Tables[1])).ToList();

        }

        private ProductEnt BindDataToProductEnt(DataRow dr, DataTable dtLevel)
        {
            return new ProductEnt
            {
                ProductCode = Convert.ToString(dr["Product_Code"]),
                ProductName = Convert.ToString(dr["Product_Name"]),
               // ProductGrades = BindLevel(dtLevel),
                Make = BindMake(dr.Table, Convert.ToString(dr["Product_Code"]))
            };
        }


        private List<MakeEnt> BindMake(DataTable dtMake, string strProdCode)
        {
            return (from dr in dtMake.AsEnumerable().Where(d => d["MakeId"] != DBNull.Value && d["ModelId"] != DBNull.Value && Convert.ToString(d["Product_Code"]) == strProdCode)
                    select new MakeEnt
                    {
                        MakeId = Convert.ToInt32(dr["MakeId"] == DBNull.Value ? 0 : dr["MakeId"]),
                        MakeName = Convert.ToString(dr["MakeName"]),
                        Model = BindModel(dtMake, Convert.ToInt32(dr["MakeId"] == DBNull.Value ? 0 : dr["MakeId"]))
                    }).ToList();
        }

        private List<ModelEnt> BindModel(DataTable dtModel, int makeId)
        {
            if (makeId == 0)
                return null;
            return (from row in dtModel.AsEnumerable().Where(rw => rw["MakeId"] != DBNull.Value && Convert.ToString(rw["MakeId"]) == makeId.ToString())
                    select new ModelEnt
                    {
                        ModelId = Convert.ToInt32(row["ModelId"] == DBNull.Value ? 0 : row["ModelId"]),
                        ModelName = Convert.ToString(row["ModelName"]),
                    }).ToList();

        }

        private List<GradeEnt> BindLevel(DataTable dtLelve)
        {
            return (from dr in dtLelve.AsEnumerable()
                    select new GradeEnt
                    {
                        GradeId = Convert.ToInt32(dr["LevelID"] == DBNull.Value ? 0 : dr["LevelID"]),
                        GradeName = Convert.ToString(dr["LevelName"]),
                        MaxLevel = Convert.ToInt32(dr["ApprovalMaxLimit"]),
                        MinLevel = Convert.ToInt32(dr["ApprovalMinLimit"])
                    }).ToList();
        }

    }

    [Serializable]
    public class ProdCat
    {
        public List<ProductCategoryEnt> ProdCatList { get; set; }
    }
}
