﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class ControlPanelRepository
    {
        int iErrorno;

        public List<GarageClaimMappingEnt> GetGarageDetails(string iClaimRefNo)
        {
            List<GarageClaimMappingEnt> listGarageEnt = new List<GarageClaimMappingEnt>();
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetControlPanelDetails, out dsType
                    , oDAL.CreateParameter("@ClaimRefNo", DbType.String, iClaimRefNo));

                if (iErrorno == 0 && dsType != null)
                {
                    if (dsType.Tables.Count > 0)
                    {
                        return listGarageEnt = dsType.Tables[0].ToEntityList<GarageClaimMappingEnt>();                        
                    }
                }
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        public List<GarageClaimTAXMappingEnt> GetGarageTAXDetails(string iClaimRefNo, int GarageID)
        {
            List<GarageClaimTAXMappingEnt> listGarageClaimTAXMappingEnt= new List<GarageClaimTAXMappingEnt>();
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetGarageWiseTaxDetails, out dsType,
                                            oDAL.CreateParameter("@ClaimRefNo", DbType.String, iClaimRefNo),
                                            oDAL.CreateParameter("@GarageID", DbType.Int32, GarageID)
                                            );

                if (iErrorno == 0 && dsType != null)
                {
                    if (dsType.Tables.Count > 0)
                    {
                       return listGarageClaimTAXMappingEnt = dsType.Tables[0].ToEntityList<GarageClaimTAXMappingEnt>();                    
                    }
                }
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public PolicyEnt GetPolicyDetails(string iClaimRefNo)
        {
            PolicyEnt oPolicyEnt = new PolicyEnt();
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetPolicyDetails, out dsType
                    , oDAL.CreateParameter("@ClaimRefNo", DbType.String, iClaimRefNo));

                if (iErrorno == 0 && dsType != null)
                {
                    if (dsType.Tables.Count > 0)
                    {
                        return oPolicyEnt = dsType.Tables[0].Rows[0].ToEntity<PolicyEnt>();
                    }
                }
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        public int SaveGarageDetails(GarageClaimMappingEnt oGarageClaimMappingEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();
                DataTable GarageClaimMapping = null;
                DataTable GarageClaimTAXMapping = null;
                GarageClaimMapping = oGarageClaimMappingEnt.ToDataTable<GarageClaimMappingEnt>(TableTypeConstants.GarageClaimMapping);
                GarageClaimTAXMapping = oGarageClaimMappingEnt.listGarageClaimTAXMappingEnt.ToDataTable<GarageClaimTAXMappingEnt>(TableTypeConstants.GarageClaimTaxMapping);

                dsClaim.Tables.Add(GarageClaimMapping);
                dsClaim.Tables.Add(GarageClaimTAXMapping);

                this.iErrorno = oDAL.Insert(ProcedureConstants.UpdateGarageClaimMappingDetails, dsClaim);
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }

        public int SaveCoverageDetails(ClaimEnt oClaimEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this.iErrorno = oDAL.Update(
                                    ProcedureConstants.UpdateCoverageDetails,
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, oClaimEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@DepApplicable", DbType.String, oClaimEnt.DepApplicable),
                                    oDAL.CreateParameter("@DepApplicableDate", DbType.String, oClaimEnt.DepApplicableDate),
                                    oDAL.CreateParameter("@UpdatedBy", DbType.String, oClaimEnt.UpdatedBy)
                                    );
                return this.iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }
    }
}
