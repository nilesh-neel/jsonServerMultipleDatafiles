﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices;
using RGICL.MC.Common.Utilities;
using RGICL.MC.Common.Constants;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Encryption;
using System.DirectoryServices.AccountManagement;

namespace RGICL.MC.Repository
{
    public interface IAuthenticate
    {
        bool Autheticate(UserInformationEnt oUserInfo);
    }

    public class ADAuthentication : IAuthenticate
    {
        public bool AuthenticateActiveDirectory(string Domain, string UserName, string Password)
        {
            try
            {
                DirectoryEntry entry = new DirectoryEntry("LDAP://" + Domain, UserName, CustomEncryption.Decrypt(Password));
                object nativeObject = entry.NativeObject;
                return true;
            }
            catch (DirectoryServicesCOMException)
            {
                return false;
            }
        }


        public bool Autheticate(UserInformationEnt oUserInfo)
        {

            DirectoryEntry deADS = null;
            DirectorySearcher dsADS = null;
            try
            {

                SearchResult searchResult = null;
                if (oUserInfo.IsAutoLogin)
                {
                    //deADS = new DirectoryEntry("LDAP://" + AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ADSDomain));
                    //dsADS = new DirectorySearcher(deADS);                                        
                    //dsADS.Filter = "sAMAccountName=" + oUserInfo.LoginID;                  
                    //searchResult = dsADS.FindOne();
                    bool UserExists = false;
                    using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ADSDomain)))
                    {
                        UserPrincipal up = UserPrincipal.FindByIdentity(
                            pc,
                            IdentityType.SamAccountName,
                            oUserInfo.LoginID);

                        UserExists = (up != null);
                    }
                    return UserExists;
                }
                deADS = new DirectoryEntry("LDAP://" + AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.ADSDomain), oUserInfo.LoginID, CustomEncryption.Decrypt(oUserInfo.Password));
                dsADS = new DirectorySearcher(deADS);
                searchResult = dsADS.FindOne();
                return true;
            }
            catch (Exception Ex)
            {
                return false;
            }
            finally
            {
                deADS.Dispose();
                dsADS.Dispose();
            }

        }
    }
    public class DBAuthentication : IAuthenticate
    {
        int iErrorno;
        public bool AuthenticateActiveDirectory(string Domain, string UserName, string Password)
        {
            try
            {
                DirectoryEntry entry = new DirectoryEntry("LDAP://" + Domain, UserName, Password);
                object nativeObject = entry.NativeObject;
                return true;
            }
            catch (DirectoryServicesCOMException)
            {
                return false;
            }
        }


        public bool Autheticate(UserInformationEnt oUserInfo)
        {

            bool IsPresent = false;
            CRUD oDAL = new CRUD();
            DataSet dsUser = new DataSet();
            this.iErrorno = oDAL.Select(
                                ProcedureConstants.CheckUserExist, out dsUser,
                                oDAL.CreateParameter("@LoginID", DbType.String, oUserInfo.LoginID),
                                oDAL.CreateParameter("@Password", DbType.String, oUserInfo.Password),
                                oDAL.CreateParameter("@UserType", DbType.String, oUserInfo.UserType)
                                );

            if (this.iErrorno == 0)
            {

                if (dsUser != null && dsUser.Tables[0] != null && dsUser.Tables[0].Rows.Count > 0)
                {
                    IsPresent = true;
                }
            }
            return IsPresent;
        }
    }

    public class MobileAuthentication : IAuthenticate
    {
        int iErrorno;
        public bool Autheticate(UserInformationEnt oUserInfo)
        {
            if (oUserInfo.UserType.Equals("I"))
            {
                var oAdAuth = new ADAuthentication();
                if (oAdAuth.Autheticate(oUserInfo))
                    return ValidateMobileUser(oUserInfo);
                return false;
            }

            return ValidateMobileUser(oUserInfo);
        }

        private bool ValidateMobileUser(UserInformationEnt oUserInfo)
        {
            bool IsPresent = false;
            CRUD oDAL = new CRUD();
            DataSet dsUser = new DataSet();
            this.iErrorno = oDAL.Select(
                                ProcedureConstants.AuthenticateMobileUser, out dsUser,
                                oDAL.CreateParameter("@LoginID", DbType.String, oUserInfo.LoginID),
                                oDAL.CreateParameter("@Password", DbType.String, oUserInfo.Password),
                                oDAL.CreateParameter("@UserType", DbType.String, oUserInfo.UserType),
                                oDAL.CreateParameter("@DeviceNo", DbType.String, oUserInfo.DeviceId)
                                );

            if (this.iErrorno == 0)
            {

                if (dsUser != null && dsUser.Tables[0] != null && dsUser.Tables[0].Rows.Count > 0)
                {
                    IsPresent = true;
                }
            }
            return IsPresent;
        }
    }

}
