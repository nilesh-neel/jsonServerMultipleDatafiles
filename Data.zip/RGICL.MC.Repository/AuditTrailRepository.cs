﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;
namespace RGICL.MC.Repository
{
    public class AuditTrailRepository
    {
        int iErrorno;
        public List<AuditTrailEventEnt> GetListAuditTrailDetails(string strClaimRefNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsAuditDet = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetAuditTrailDetails, out dsAuditDet,
                                    oDAL.CreateParameter("@P_ClaimRefNo", DbType.String, Convert.ToString(strClaimRefNo)));

                return this.iErrorno == 0 ? (dsAuditDet.Tables[0].Rows.Count > 0 && dsAuditDet.Tables[0] != null ?
                   GetAuditTrailDet(dsAuditDet) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private List<AuditTrailEventEnt> GetAuditTrailDet(DataSet dsAuditDet)
        {
            return (from dr in dsAuditDet.Tables[0].AsEnumerable() select BindDataToAuditTrailEnt(dr)).ToList();
        }

        private AuditTrailEventEnt BindDataToAuditTrailEnt(DataRow dr)
        {
            return new AuditTrailEventEnt
                {
                    EventName = Convert.ToString(dr.Table.Columns.Contains("EventName") ? dr["EventName"] : null),
                    DisplayText = Convert.ToString(dr.Table.Columns.Contains("DisplayText") ? dr["DisplayText"] : null),
                    AuditEventDetail = new List<AuditTrailDetailsEnt> 
                    {
                        new AuditTrailDetailsEnt 
                        {
                            ClaimRefNo=new ClaimEnt{ClaimRefNo=Convert.ToString(dr.Table.Columns.Contains("ClaimRefNo") ? dr["ClaimRefNo"] : null)},
                            EventTime=Convert.ToString(dr.Table.Columns.Contains("EventTime") ? dr["EventTime"] : null),
                            Remarks=Convert.ToString(dr.Table.Columns.Contains("REMARKS") ? dr["REMARKS"] : null),
                            ReleasedBy=new UserInformationEnt
                            {
                                UserID=Convert.ToString(dr.Table.Columns.Contains("ReleasedBy") ? dr["ReleasedBy"] : null),
                                UserDetail=new UserDetails
                                {
                                    Role=new List<UserRoleEnt>()
                                    {new UserRoleEnt{RoleName=Convert.ToString(dr.Table.Columns.Contains("RoleName") ? dr["RoleName"] : null)
                            }}}}
                        },
                            
                    }

                };
        }

    }
}
