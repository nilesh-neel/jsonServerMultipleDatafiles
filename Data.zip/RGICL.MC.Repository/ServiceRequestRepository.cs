﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Data;
using RGICL.MC.Common.Utilities;


namespace RGICL.MC.Repository
{
    public class ServiceRequestRepository
    {
        int Status = 1;
        int? iErrorno;
        #region Claim
        /// <summary>
        /// Display the Claim   based on ClaimRef Number
        /// </summary>
        /// <param name="ClaimRefNumber"></param> 
        /// <returns>ClaimEnt</returns>
        public ClaimEnt GetClaimFromClaimRefNo(string ClaimRefNo)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetClaimFromRefNo, out dsClaim, oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));

                return this.iErrorno == 0 ? (dsClaim.Tables[0].Rows.Count > 0 && dsClaim.Tables[0] != null ?
                    BindDataToClaimEnt(dsClaim.Tables[0].Rows[0]) : null) : null;
            }
            catch (Exception ex)
            {
                throw;

            }



        }
        private ClaimEnt BindDataToClaimEnt(DataRow dr)
        {
            return new ClaimEnt
            {

                ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                PolicyNo = Convert.ToString(dr["PolicyNo"]),
                ProductId = Convert.ToInt16(dr["ProductID"]),
                Product = Convert.ToString(dr["Product"]),
                InsuredName = Convert.ToString(dr["InsuredName"]),
                VehicleNumber = Convert.ToString(dr["VehicleNumber"]),
                ClaimOwner = Convert.ToString(dr["ClaimOwner"]!=null?dr["ClaimOwner"]:""),
                CoverNoteNo = Convert.ToString(dr["CoverNoteNo"]),
                ClaimStatusMsg = Convert.ToString(dr["ClaimStatusDescription"]),
                VB64Status = Convert.ToString(Convert.ToInt16((string.IsNullOrEmpty(dr["VB64Status"].ToString()) ? 0 : dr["VB64Status"])) == 1 ? "YES" : "NO"),
                Claim_Status = Convert.ToInt16(String.IsNullOrEmpty(dr["ClaimStatus"].ToString()) ? 0 : dr["ClaimStatus"]),

                IsValidForClosure = Convert.ToInt16(dr["IsvalidForClosure"]) == 1 ? true : false,
                IsValidForReOpen = Convert.ToInt16(dr["IsvalidForReOpen"]) == 1 ? true : false,
                IsValidForReIssue = Convert.ToInt16(dr["IsvalidForReIssue"]) == 1 ? true : false,
                IsValidForRecovery = Convert.ToInt16(dr["IsvalidForRecovery"]) == 1 ? true : false,
                IsServiceRequestRaised = Convert.ToInt16(dr["IsServiceRequestRaised"]) == 1 ? true : false,
                IsValidForStopPayment = Convert.ToInt16(dr["IsvalidForStopPayment"]) == 1 ? true : false,
                IsValidForApproval = Convert.ToInt16(dr["IsValidForApproval"]) == 1 ? true : false,
                SR_RaisedFor = Convert.ToString(dr["SR_Type"]),
                TimeOfIntimation = Convert.ToString(dr["TimeOfIntimation"]),
                CreatedDate = Convert.ToDateTime(dr["CreatedDate"]),
                LOBName = Convert.ToString(dr["LOBName"]),
                PolicyIssuingSystem = Convert.ToString(dr["PolicyIssuingSystem"]),
            };
        }
        #endregion
        #region Closure
        /// <summary>
        /// Display the Closure Details   based on ClaimRef Number
        /// </summary>
        /// <param name="ClaimRefNo"></param> 
        /// <returns>List<ServiceRequestClosureEnt></returns>
        public List<ServiceRequestClosureEnt> GetClosureDetails(string ClaimRefNo, string ClosureID)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetClosureLetterDetails, out dsClaim,
               ClaimRefNo == string.Empty ? oDAL.CreateParameter("@ClaimRefNo", DbType.String, DBNull.Value) : oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo),
               ClosureID == string.Empty ? oDAL.CreateParameter("@ClosureID", DbType.Int16, DBNull.Value) : oDAL.CreateParameter("@ClosureID", DbType.Int16, ClosureID));


                return this.iErrorno == 0 ? (dsClaim.Tables != null &&
                        dsClaim.Tables[0].Rows.Count > 0 ? GetServiceRQClosureList(dsClaim) : null
                        ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }
        private List<ServiceRequestClosureEnt> GetServiceRQClosureList(DataSet dsClaim)
        {
            return (from dr in dsClaim.Tables[0].AsEnumerable()
                    select (new ServiceRequestClosureEnt
                    {
                        SRActionID = Convert.ToInt32(dr["SRActionID"]),
                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        ClosureID = Convert.ToString(dr["ClosureID"]),
                        ClosureReason = Convert.ToString(dr["ClosureReasonName"]),
                        ClosureReasonID = Convert.ToInt32(dr["ClosureReason"]),
                        ClosureRemarks = Convert.ToString(dr["ClosureRemarks"]),
                        ClosureType = Convert.ToString(dr["ClosureType"]),
                        GeneratedDate = Convert.ToDateTime(dr["CreatedDate"]),
                        GeneratedBy = Convert.ToString(dr["DisplayName"]),
                        SRID = Convert.ToInt32(dr["SRID"]),
                        ClosureLetterEntlst = dsClaim.Tables[1] != null && dsClaim.Tables[1].Rows.Count > 0 ? GetLetter(dsClaim.Tables[1]) : null,
                        SRAction = dr["SRAction"].ToString()

                    })).ToList();
        }



        private List<ClosureLetterEnt> GetLetter(DataTable dtLetter)
        {

            return (from dr in dtLetter.AsEnumerable()
                    select (new ClosureLetterEnt
                    {

                        LetterNumber = Convert.ToString(dr["LetterNumber"] != null ? dr["LetterNumber"] : null),
                        LetterType = Convert.ToString(dr["LookUpName"] != null ? dr["LookUpName"] : null),
                        AirwayBillNumber = Convert.ToString(dr["AirwayBillNo"] != null ? dr["AirwayBillNo"] : null),
                        GeneratedBy = Convert.ToString(dr["LetterGeneratedBy"]),
                        GeneratedDate = Convert.ToDateTime(dr["GeneratedDate"] != null ? dr["GeneratedDate"] : System.DateTime.Now),
                        LetterDispatchedDate = Convert.ToDateTime(dr["LetterDispatchedDate"] != null ? dr["LetterDispatchedDate"] : System.DateTime.Now)


                    })).ToList();
        }




        /// <summary>
        /// set the closure details and change claim status consequently 
        /// </summary>
        /// <param name="ClaimRefNumber"></param> 
        /// <returns>ClaimEnt</returns>
        public int SetClosureDetails(ServiceRequestClosureEnt oClosureEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertClosureDetails,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oClosureEnt.ClaimRefNo),
                                oDAL.CreateParameter("@ClosureId", DbType.String, oClosureEnt.ClosureID == "0" || string.IsNullOrEmpty(oClosureEnt.ClosureID) ? DBNull.Value.ToString() : oClosureEnt.ClosureID),
                                oDAL.CreateParameter("@ClosureReason", DbType.Int32, oClosureEnt.ClosureReasonID),
                                oDAL.CreateParameter("@ClosureRemarks", DbType.String, oClosureEnt.ClosureRemarks),
                                oDAL.CreateParameter("@CreatedBy", DbType.String, oClosureEnt.CreatedBy),
                                oDAL.CreateParameter("@LetterDispatchedDate", DbType.DateTime, oClosureEnt.ClosureLetterEnt != null ? oClosureEnt.ClosureLetterEnt.LetterDispatchedDate : DateTime.Now),
                                oDAL.CreateParameter("@AirwayBillNumber", DbType.String, oClosureEnt.ClosureLetterEnt != null ? oClosureEnt.ClosureLetterEnt.AirwayBillNumber : DBNull.Value.ToString())
                                     );


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }
        #endregion
        #region ReopenRegion
        /// <summary>
        /// set the Reopen details and change claim status consequently 
        /// </summary>
        /// <param name="ClaimRefNumber"></param> 
        /// <returns>ClaimEnt</returns>
        public int SetReopenDetails(ServiceRequestReopenEnt oReopenEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertReOpenDetails,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oReopenEnt.ClaimRefNo),
                                oDAL.CreateParameter("@ReOpenReason", DbType.Int32, oReopenEnt.ReOpenReason),
                                 oDAL.CreateParameter("@AdditionalPayment", DbType.String, oReopenEnt.AdditionalPayment),
                                oDAL.CreateParameter("@ReOpenRemarks", DbType.String, oReopenEnt.ReOpenRemarks),
                                oDAL.CreateParameter("@CreatedBy", DbType.String, oReopenEnt.ReopenBy)

                                     );


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }
        private List<ServiceRequestReopenEnt> GetServiceRQReOpenList(DataSet dsReopen)
        {
            return (from dr in dsReopen.Tables[0].AsEnumerable()
                    select (new ServiceRequestReopenEnt
                    {
                        SRActionID = Convert.ToInt32(dr["SRActionID"]),

                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        ReOpenID = Convert.ToString(dr["ReOpenID"]),
                        ReOpenReason = Convert.ToString(dr["ReOpenReason"]),
                        ReOpenReasonID = Convert.ToInt32(dr["ReOpenReasonID"]),
                        SRID = Convert.ToInt32(dr["SRID"]),

                        ReOpenRemarks = Convert.ToString(dr["ReOpenRemarks"]),
                        AdditionalPayment = Convert.ToString(dr["AdditionalAmount"]),
                        ReopenBy = Convert.ToString(dr["ReopenBy"]),
                        SRAction = dr["SRAction"].ToString(),
                        ReopenDate = Convert.ToDateTime(dr["CreatedDate"]),

                    })).ToList();
        }

        public List<ServiceRequestReopenEnt> GetReOpenDetails(string ClaimRefNo, string ReOpenID)
        {

            try
            {
                CRUD oDAL = new CRUD();

                DataSet dsReopen = new DataSet();
                if (string.IsNullOrEmpty(ClaimRefNo))
                {
                    this.iErrorno = oDAL.Select(ProcedureConstants.GetReOpenDetails, out dsReopen, oDAL.CreateParameter("@ClaimRefNo", DbType.String, DBNull.Value));
                }
                else
                {
                    this.iErrorno = oDAL.Select(ProcedureConstants.GetReOpenDetails, out dsReopen, oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));
                }

                return this.iErrorno == 0 ? (dsReopen.Tables != null &&
                        dsReopen.Tables[0].Rows.Count > 0 ? GetServiceRQReOpenList(dsReopen) : null
                        ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }
        #endregion
        #region RecoveryRegion
        /// <summary>
        /// set the Recovery details and change claim status consequently 
        /// </summary>
        /// <param name="ClaimRefNumber"></param> 
        /// <returns>Error Code</returns>
        public int SetRecoveryDetails(ServiceRequestRecoveryEnt oRecoveryEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertRecoveryDetails,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oRecoveryEnt.ClaimRefNo),
                                oDAL.CreateParameter("@CreatedBy", DbType.Int32, oRecoveryEnt.CreatedBy),
                                oDAL.CreateParameter("@RecoveryReason", DbType.String, oRecoveryEnt.RecoveryReason),
                                 oDAL.CreateParameter("@RecoveryType", DbType.String, oRecoveryEnt.RecoveryType),
                                oDAL.CreateParameter("@RecoveryFor", DbType.String, oRecoveryEnt.RecoveryFor),
                                oDAL.CreateParameter("@RecoveryMode", DbType.String, oRecoveryEnt.RecoveryMode),
                                 oDAL.CreateParameter("@RecoveredFrom", DbType.String, oRecoveryEnt.RecoveryFrom),
                                 oDAL.CreateParameter("@InstrumentNumber", DbType.String, oRecoveryEnt.InstrumentNumber),
                                oDAL.CreateParameter("@InstrumentAmount", DbType.String, oRecoveryEnt.InstrumentAmount),
                                  oDAL.CreateParameter("@IsTDSApplicable", DbType.String, oRecoveryEnt.IsTDSApplicable),
                                 oDAL.CreateParameter("@TotalLossPaid", DbType.Decimal, Convert.ToDecimal(oRecoveryEnt.TotalLossPayment)),
                                oDAL.CreateParameter("@LossPaymentRecovered", DbType.Decimal, Convert.ToDecimal(oRecoveryEnt.LossPaymentRecovered)),
                                oDAL.CreateParameter("@ExpensePayment", DbType.Decimal, Convert.ToDecimal(oRecoveryEnt.ExpensePayment)),
                                oDAL.CreateParameter("@ExpenseRecovered", DbType.Decimal, Convert.ToDecimal(oRecoveryEnt.ExpensePaymentRecovered)),
                                 oDAL.CreateParameter("@RecoveryMainReason", DbType.Int32, oRecoveryEnt.MainReasonRecoveryID),
                                oDAL.CreateParameter("@RecoverySubReason", DbType.Int32, oRecoveryEnt.SubReasonRecoveryID),
                                oDAL.CreateParameter("@Remarks", DbType.String, oRecoveryEnt.RecoveryRemarks)

                                );


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }
        private List<ServiceRequestRecoveryEnt> GetServiceRQRecoveryList(DataSet dsRecovery)
        {
            return (from dr in dsRecovery.Tables[0].AsEnumerable()
                    select (new ServiceRequestRecoveryEnt
                    {
                        SRActionID = Convert.ToInt32(dr["SRActionID"]),

                        SRID = Convert.ToInt32(dr["SRID"]),
                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        RecoveryID = Convert.ToString(dr["RecoveryID"]),
                        RecoveryReason = Convert.ToString(dr["RecoveryReason"]),
                        RecoveryRemarks = Convert.ToString(dr["Remarks"]),
                        RecoveryType = Convert.ToString(dr["RecoveryType"]),
                        SubReasonRecovery = Convert.ToString(dr["RecoverySubReasonID"]),
                        RecoveryFor = Convert.ToString(dr["RecoveryFor"]),
                        RecoveryFrom = Convert.ToString(dr["RecoveredFrom"]),
                        RecoveryMode = Convert.ToString(dr["RecoveryMode"]),
                        InstrumentNumber = Convert.ToString(dr["InstrumentNumber"]),
                        InstrumentAmount = Convert.ToString(dr["InstrumentAmount"]),
                        TotalLossPayment = Convert.ToString(dr["TotalLossPaid"]),
                        GeneratedBy = Convert.ToString(dr["DisplayName"]),
                        GeneratedDate = Convert.ToDateTime(dr["CreatedDate"]),
                        IsTDSApplicable = Convert.ToString(dr["IsTDSApplicable"]),
                        LossPaymentRecovered = Convert.ToString(dr["LossPaymentRecovered"]),
                        ExpensePayment = Convert.ToString(dr["ExpensePayment"]),
                        ExpensePaymentRecovered = Convert.ToString(dr["ExpenseRecovered"]),
                        MainReasonRecovery = Convert.ToString(dr["RecoveryMainReasonID"]),
                        SRAction = dr["SRAction"].ToString()

                    })).ToList();
        }

        public List<ServiceRequestRecoveryEnt> GetRecoverDetails(string ClaimRefNo, string RecoveryID)
        {

            try
            {
                CRUD oDAL = new CRUD();

                DataSet dsRecovery = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetRecoveryDetails, out dsRecovery,
                  ClaimRefNo == string.Empty ? oDAL.CreateParameter("@ClaimRefNo", DbType.String, DBNull.Value) : oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));

                return this.iErrorno == 0 ? (dsRecovery.Tables != null &&
                        dsRecovery.Tables[0].Rows.Count > 0 ? GetServiceRQRecoveryList(dsRecovery) : null
                        ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }
        #endregion
        #region StopPayment

        private List<ServiceRequestStopPaymentEnt> GetServiceRQStopPaymentList(DataSet dsStopPayment)
        {
            return (from dr in dsStopPayment.Tables[0].AsEnumerable()
                    select (new ServiceRequestStopPaymentEnt
                    {
                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        StopPaymentID = Convert.ToString(dr["StopPaymentID"]),
                        RequestTypeID = Convert.ToInt32(dr["RequestTypeID"]),
                        RequestType = Convert.ToString(dr["RequestType"]),
                        ReasonID = Convert.ToInt32(dr["ReasonID"]),
                        Reason = Convert.ToString(dr["Reason"]),
                        SRActionID = Convert.ToInt32(dr["SRActionID"]),
                        Remarks = Convert.ToString(dr["Remarks"]),
                        StopPaymentType = Convert.ToString(dr["StopPaymentType"]),
                        GeneratedBy = Convert.ToString(dr["DisplayName"]),
                        GeneratedDate = Convert.ToDateTime(dr["CreatedDate"]),
                        SRAction = Convert.ToString(dr["SRAction"]),
                        SRID = Convert.ToInt32(dr["SRID"]),
                        PaymentID = Convert.ToInt32(dr["PaymentID"]),
                        //LossPayment = dsStopPayment.Tables[0] != null && dsStopPayment.Tables[1].Rows.Count > 0 ? BindPayment(dsStopPayment.Tables[1]) : null,
                        //OnAccountPayment = dsStopPayment.Tables[1] != null && dsStopPayment.Tables[2].Rows.Count > 0 ? BindPayment(dsStopPayment.Tables[2]) : null,
                        //ExpensePayment = dsStopPayment.Tables[2] != null && dsStopPayment.Tables[3].Rows.Count > 0 ? BindPayment(dsStopPayment.Tables[3]) : null,
                        FilePath = Convert.ToString(dr["UploadedFilePath"])

                    })).ToList();
        }

        private List<PaymentEnt> BindPayment(DataSet dtPayment)
        {
            return (from dr in dtPayment.Tables[0].AsEnumerable()
                    select (new PaymentEnt
                    {
                        PaymentID = Convert.ToString(dr["PaymentID"]),
                        PaymentType = Convert.ToString(dr["PaymentType"]),
                        PaymentTo = Convert.ToString(dr["PaymentTo"]),
                        PayeeName = Convert.ToString(dr["PayeeName"]),
                        NameChange = Convert.ToString(dr["NameChange"]),
                        SettlementType = Convert.ToString(dr["SettlementType"]),
                        Amount = Convert.ToString(dr["Amount"]),

                        TotalAmount = Convert.ToString(dr["TotalAmount"]),

                        RecoveredAmount = Convert.ToString(dr["RecoveredAmount"]),



                        ModeOfSettlement = Convert.ToString(dr["ModeOfSettlement"]),
                        Number = Convert.ToString(dr["Number"]),
                        InstrumentDate = Convert.ToDateTime(dr["InstrumentDate"]),
                        InstrumentRealizationDate = Convert.ToDateTime(dr["InstrumentRealizationDate"]),
                        Status = Convert.ToString(dr["Status"]),
                    })).ToList();
        }

        public List<ServiceRequestStopPaymentEnt> GetStopPaymentDetails(string ClaimRefNo, string StopPaymentID)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsStopPayment = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetStopPaymentDetails, out dsStopPayment,
                    ClaimRefNo == string.Empty ? oDAL.CreateParameter("@ClaimRefNo", DbType.String, DBNull.Value) : oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo),
                    StopPaymentID == string.Empty ? oDAL.CreateParameter("@StopPaymentID", DbType.String, DBNull.Value) : oDAL.CreateParameter("@StopPaymentID", DbType.String, StopPaymentID));
                return this.iErrorno == 0 ? (dsStopPayment.Tables != null &&
                  dsStopPayment.Tables[0].Rows.Count > 0 ? GetServiceRQStopPaymentList(dsStopPayment) : null
                  ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }

        public List<PaymentEnt> GetPaymentDetails(string ClaimRefNo, string PaymentID)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsPayment = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetPaymentDetails, out dsPayment,
                    ClaimRefNo == string.Empty ? oDAL.CreateParameter("@ClaimRefNo", DbType.String, DBNull.Value) : oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));
                return this.iErrorno == 0 ? (dsPayment.Tables != null && (
                  dsPayment.Tables[0].Rows.Count > 0 || dsPayment.Tables[1].Rows.Count > 0 || dsPayment.Tables[2].Rows.Count > 0) ? BindPayment(dsPayment) : null
                  ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }
        /// <summary>
        /// set the StopPayment request details 
        /// </summary>
        /// <param name="oStopPaymentEnt"></param> 
        /// <returns>Status</returns>
        public int SetStopPaymentRQDetails(ServiceRequestStopPaymentEnt oStopPaymentEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertStopPaymentRQDetails,

                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oStopPaymentEnt.ClaimRefNo),
                                oDAL.CreateParameter("@Reason", DbType.Int32, oStopPaymentEnt.Reason),
                                oDAL.CreateParameter("@Remarks", DbType.String, oStopPaymentEnt.Remarks),
                                oDAL.CreateParameter("@RequestType", DbType.Int32, oStopPaymentEnt.RequestType),
                                oDAL.CreateParameter("@StopPaymentType", DbType.Int32, oStopPaymentEnt.StopPaymentType),
                                oDAL.CreateParameter("@PaymentID", DbType.Int32, oStopPaymentEnt.PaymentID),
                                oDAL.CreateParameter("@CreatedBy", DbType.String, oStopPaymentEnt.GeneratedBy),
                                oDAL.CreateParameter("@UploadedFilePath", DbType.String, oStopPaymentEnt.FilePath)
                                     );


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }
        public string CheckAccountclearanceStatus(string ClaimRefNo, string PaymentID, string PaymentTypeID, int RequestType)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet ds = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.CheckAccountclearanceStatus, out ds,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo),
                    oDAL.CreateParameter("@PaymentID", DbType.String, PaymentID),
                    oDAL.CreateParameter("@PaymentTypeID", DbType.String, PaymentTypeID),
                    oDAL.CreateParameter("@RequestType", DbType.Int16, RequestType));//6=stop Payment , 3=Reissue

                return this.iErrorno == 0 ? (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null ?
                    ClearanceStatus(ds) : null) : null;
            }
            catch (Exception ex)
            {
                throw;

            }
        }
        private string ClearanceStatus(DataSet data)
        {
            return (from items in data.Tables[0].AsEnumerable()
                    select new
                    {
                        ret = items["StatusMgs"] + "|" + items["IsValid"]

                    }).FirstOrDefault().ToString().Replace("{", "").Replace("}", "").Replace("ret", "");
        }



        #endregion
        #region ReIssueRegion
        /// <summary>
        /// set the ReIssue details and change claim status consequently 
        /// </summary>
        /// <param name="ClaimRefNumber"></param> 
        /// <returns>ClaimEnt</returns>
        public int SetReIssueSRDetails(ServiceRequestReIssueEnt oReIssueEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertReIssueDetails,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oReIssueEnt.ClaimRefNo),
                                oDAL.CreateParameter("@TypeOfRequest", DbType.Int32, oReIssueEnt.TypeOfRequestID),
                                 oDAL.CreateParameter("@RequestType", DbType.Int32, oReIssueEnt.RequestTypeID),
                                 oDAL.CreateParameter("@ModeOfPayment", DbType.Int32, oReIssueEnt.ModeOfPaymentID),
                                oDAL.CreateParameter("@RequestSubType", DbType.Int32, oReIssueEnt.RequestSubTypeID),
                                oDAL.CreateParameter("@ReIssueReason", DbType.Int32, oReIssueEnt.ReIssueReasonID),
                                oDAL.CreateParameter("@Remarks", DbType.String, oReIssueEnt.Remarks),
                                oDAL.CreateParameter("@NameChange", DbType.String, !string.IsNullOrEmpty(oReIssueEnt.NameChange) ? oReIssueEnt.NameChange : DBNull.Value.ToString()),
                                oDAL.CreateParameter("@AmountChange", DbType.Decimal, oReIssueEnt.AmountChange),
                                  oDAL.CreateParameter("@IsPysicalChequeAvble", DbType.Boolean, oReIssueEnt.IsPysicalChequeAvble),
                                 oDAL.CreateParameter("@PaymentID", DbType.Int32, oReIssueEnt.PaymentID),
                                 oDAL.CreateParameter("@PaymentType", DbType.Int32, oReIssueEnt.PaymentType),
                                oDAL.CreateParameter("@CreatedBy", DbType.Int32, oReIssueEnt.GeneratedBy));


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }
        private List<ServiceRequestReIssueEnt> GetServiceRQReIssueEntList(DataSet dsReIssue)
        {

            List<ServiceRequestReIssueEnt> ReIssueEntlst = dsReIssue.Tables[0].ToEntityList<ServiceRequestReIssueEnt>();
            return ReIssueEntlst;
        }

        public List<ServiceRequestReIssueEnt> GetReIssueDetails(string ClaimRefNo, string ReIssueID)
        {

            try
            {
                CRUD oDAL = new CRUD();

                DataSet dsReIssue = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetReIssueDetails, out dsReIssue, oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo),
                oDAL.CreateParameter("@ReIssueID", DbType.String, ReIssueID));


                return this.iErrorno == 0 ? (dsReIssue.Tables != null &&
                        dsReIssue.Tables[0].Rows.Count > 0 ? GetServiceRQReIssueEntList(dsReIssue) : null
                        ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }
        #endregion
        #region Approval
        /// <summary>
        /// Check Approval Rights 
        /// </summary>
        /// <param name="ClaimRefNumber"></param> 
        /// <returns>bool</returns>
        public bool IsApprover(string ClaimRefNo, string ProductID, string UserID, int RequestType)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet ds = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetCheckApprovalRights, out ds, oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo),
                    oDAL.CreateParameter("@ProductID", DbType.String, ProductID),
                    oDAL.CreateParameter("@UserID", DbType.String, UserID),
                    oDAL.CreateParameter("@RequestType", DbType.Int16, RequestType));

                return this.iErrorno == 0 ? (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null ?
                    CheckApprovalRights(ds.Tables[0].Rows[0]) : false) : false;
            }
            catch (Exception ex)
            {
                throw;

            }
        }
        private bool CheckApprovalRights(DataRow dataRow)
        {
            bool ret = false;
            ret = Convert.ToBoolean(dataRow["IsApprover"]);
            return ret;

        }
        public int InsertSRApprovalReject(ServiceRequestEnt oServiceRequestEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertSRApproval,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oServiceRequestEnt.ClaimRefNo),
                                oDAL.CreateParameter("@SR_TypeID", DbType.Int32, oServiceRequestEnt.SR_TypeID),
                                oDAL.CreateParameter("@ActorID", DbType.Int32, oServiceRequestEnt.ActorID),
                                oDAL.CreateParameter("@SR_ID ", DbType.Int32, oServiceRequestEnt.SR_ID),
                                oDAL.CreateParameter("@SUB_SR_ID", DbType.Int32, oServiceRequestEnt.SUB_SR_ID),
                                oDAL.CreateParameter("@Action", DbType.String, oServiceRequestEnt.Action),
                                oDAL.CreateParameter("@SavvionID", DbType.String, oServiceRequestEnt.SavvionID),
                                oDAL.CreateParameter("@Remarks", DbType.String, oServiceRequestEnt.Remarks)
                                     );


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }
        #endregion

        public List<CVMApprovalEnt> GetCVMLst(string ClaimRefNo, string CVMID)
        {

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetCVMDetails, out dsClaim,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo),
                    oDAL.CreateParameter("@CVMID", DbType.String, CVMID));
                return this.iErrorno == 0 ? (dsClaim.Tables[0].Rows.Count > 0 && dsClaim.Tables[0] != null ?
                    BindDataToCVMLst(dsClaim) : null) : null;
            }
            catch (Exception ex)
            {
                throw;

            }



        }

        private List<CVMApprovalEnt> BindDataToCVMLst(DataSet dsCVM)
        {
            List<CVMApprovalEnt> CVMEntlst = dsCVM.Tables[0].ToEntityList<CVMApprovalEnt>();
            return CVMEntlst;
        }


        public int SetCVMApprovalDetails(CVMApprovalEnt oCVMApprovalEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertCVMDetails,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oCVMApprovalEnt.ClaimRefNo),
                                oDAL.CreateParameter("@SRTYPE", DbType.Int32, oCVMApprovalEnt.SRTYPE),
                                oDAL.CreateParameter("@CVMID", DbType.Int32, oCVMApprovalEnt.PK_ID),
                                oDAL.CreateParameter("@Remarks", DbType.String, oCVMApprovalEnt.Remarks),
                                oDAL.CreateParameter("@SRID", DbType.Int32, oCVMApprovalEnt.SRID),
                                oDAL.CreateParameter("@SUB_SRID", DbType.Int32, oCVMApprovalEnt.SUB_SRID),
                                oDAL.CreateParameter("@SavvionID", DbType.Int32, oCVMApprovalEnt.SavvionID),
                                oDAL.CreateParameter("@CreatedBy", DbType.Int32, oCVMApprovalEnt.CreatedBy)
                                     );


                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

            return Status;

        }

        


    }
}
