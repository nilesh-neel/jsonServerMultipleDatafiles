﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class ClaimRepository
    {
        public int iErrorno;
        public string result;

        /// <summary>
        /// Check if the product belongs to ECS.
        /// This is required for ICE Integration.
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public bool IsECSClaim(int productId)
        {
            bool isECS;
            isECS = false;

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.IsECSClaim, out dsClaim, oDAL.CreateParameter("@Product_Id", DbType.Int32, productId));
                if (this.iErrorno == 0)
                {
                    if (dsClaim.Tables[0].Rows.Count > 0)
                    {
                        isECS = true;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                //ex.DisplayCustomMessage("");
            }

            return isECS;
        }

        /// <summary>
        /// Check if the Case No present in iCE query string exists in database.
        /// This will be used to redirect user to Claim Intimation OR Claim Search page.
        /// </summary>
        /// <param name="caseNo"></param>
        /// <returns></returns>
        public bool IsExistingCase(string caseNo)
        {

            bool isExistingCase;
            isExistingCase = false;

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.IsExistingCase, out dsClaim, oDAL.CreateParameter("@CaseNo", DbType.String, caseNo));
                if (this.iErrorno == 0)
                {
                    if (dsClaim.Tables[0].Rows.Count > 0)
                    {
                        isExistingCase = true;
                    }
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                //ex.DisplayCustomMessage("");
            }

            return isExistingCase;

        }

        public List<ClaimEnt> DisplayClaimDetails(string ClaimNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetClaimDetailsFromClaimId, out dsUserInfo,
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimNo)
                                    );
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     GetClaimData(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        #region Orphan
        public List<ClaimEnt> GetOCClaimData(DataSet dsClaim)
        {
            return (from dr in dsClaim.Tables[0].AsEnumerable() select BindDataToOCClaimEnt(dr)).ToList();
        }


        public ClaimEnt BindDataToOCClaimEnt(DataRow drClaim)
        {
            return new ClaimEnt
            {
                ClaimRefNo = Convert.ToString(drClaim["ClaimRefNo"]),
                //PolicyNo = Convert.ToString(drClaim["PolicyNo"]),
                //InsuredName = Convert.ToString(drClaim["InsuredName"]),
                //ClaimStatusMsg = Convert.ToString(drClaim["ClaimStatusDescription"]),
                //VehicleNumber = Convert.ToString(drClaim["VehicleNumber"]),
                //GarageName = Convert.ToString(drClaim["GarageName"]),
                //intimationDate = Convert.ToString(drClaim["IntimationDate"]),
                //DateOfLoss = Convert.ToString(drClaim["DateOfLoss"]),
                //ClaimOwner = Convert.ToString(drClaim["ClaimOwnerName"]),
                //LOBName = Convert.ToString(drClaim["LOB"]),
                NatureOfLoss = Convert.ToString(drClaim["NatureOfLoss"]),
                Product = Convert.ToString(drClaim["Product_Name"]),
                NatureOfLossID = Convert.ToInt32(drClaim["NatureOfLossID"]),
                ProductId = Convert.ToInt32(drClaim["Product_Code"]),
                HubName = Convert.ToString(drClaim["HubName"]),
                HubId = Convert.ToInt32(drClaim["HubID"]),
                IsOrphan = Convert.ToBoolean(drClaim["OC_IsOrphan"] != null ? drClaim["OC_IsOrphan"] : 0),
                IsCommon = Convert.ToBoolean(drClaim["OC_IsCommon"] != null ? drClaim["OC_IsCommon"] : 0),
                ClaimOwnerID = Convert.ToInt32(drClaim["CMID"] != null ? drClaim["CMID"] : 0),
                ClaimOwner = Convert.ToString(drClaim["DisplayName"] != null ? drClaim["DisplayName"] : "-"),
                IsValidToAcquire = Convert.ToBoolean(drClaim["IsValidToAcquire"] != null ? drClaim["IsValidToAcquire"] : 0),
                IsValidForHM = Convert.ToBoolean(drClaim["IsValidForHM"] != null ? drClaim["IsValidForHM"] : 0),



            };
        }

        public List<ClaimEnt> GetOrphanCommonClaimDetails(Int32 UserID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaimInfo = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetOrphanCommonClaimDetails, out dsClaimInfo,
                    oDAL.CreateParameter("@UserID", DbType.Int32, UserID));
                return this.iErrorno == 0 ? (dsClaimInfo.Tables[0].Rows.Count > 0 && dsClaimInfo.Tables[0] != null ?
                     GetOCClaimData(dsClaimInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        #endregion

        public List<ClaimEnt> GetClaimDetails(ClaimEnt objClaimEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetClaimDetails, out dsUserInfo,
                                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objClaimEnt.ClaimRefNo),
                                    oDAL.CreateParameter("@PolicyNo", DbType.String, objClaimEnt.PolicyNo),
                                    oDAL.CreateParameter("@InsuredName", DbType.String, objClaimEnt.InsuredName),
                                    oDAL.CreateParameter("@VehicleNumber", DbType.String, objClaimEnt.VehicleNumber),
                                    oDAL.CreateParameter("@ProductID", DbType.Int32, objClaimEnt.ProductId),
                                    oDAL.CreateParameter("@HubID", DbType.Int32, objClaimEnt.HubId),
                                    oDAL.CreateParameter("@GarageName", DbType.String, objClaimEnt.GarageName),
                                    oDAL.CreateParameter("@GarageLoc", DbType.String, objClaimEnt.GarageLoc),
                                    oDAL.CreateParameter("@ClaimStatus", DbType.Int32, objClaimEnt.Claim_Status),
                                    oDAL.CreateParameter("@LossType", DbType.Int32, objClaimEnt.PrimaryTypeOfLoss),
                                    oDAL.CreateParameter("@DOIFromDate", DbType.String, objClaimEnt.DOIFromDate),
                                    oDAL.CreateParameter("@DOITODate", DbType.String, objClaimEnt.DOITODate)
                                    );
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     GetClaimData(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<ClaimEnt> GetClaimData(DataSet dsClaim)
        {
            return (from dr in dsClaim.Tables[0].AsEnumerable() select BindDataToClaimEnt(dr)).ToList();
        }


        public ClaimEnt BindDataToClaimEnt(DataRow drClaim)
        {
            return new ClaimEnt
            {
                ClaimRefNo = Convert.ToString(drClaim["ClaimRefNo"]),
                PolicyNo = Convert.ToString(drClaim["PolicyNo"]),
                InsuredName = Convert.ToString(drClaim["InsuredName"]),
                ClaimStatusMsg = Convert.ToString(drClaim["ClaimStatusDescription"]),
                VehicleNumber = Convert.ToString(drClaim["VehicleNumber"]),
                GarageName = Convert.ToString(drClaim["GarageName"]),
                intimationDate = Convert.ToString(drClaim["IntimationDate"]),
                DateOfLoss = Convert.ToString(drClaim["DateOfLoss"]),
                ClaimOwner = Convert.ToString(drClaim["ClaimOwnerName"]),
                LOBName = Convert.ToString(drClaim["LOB"]),
                NatureOfLoss = Convert.ToString(drClaim["NatureOfLoss"]),
                Product = Convert.ToString(drClaim["Description"]),
                Aging = Convert.ToInt32(drClaim["Aging"]),
                CoverNoteNo = Convert.ToString(drClaim["CoverNoteNo"]),
                VB64Status = Convert.ToString(drClaim["VB64Status"]),
                PaymentDetails = ""

            };
        }

        public List<ProductEnt> GetProductMakeModel()
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsProd = new DataSet();
                List<ProductEnt> lstProd = null;
                iErrorno = oDAL.Select(ProcedureConstants.GetProductMakeModel, out dsProd);
                if (iErrorno == 0)
                {
                    lstProd = GetProduct(dsProd);
                }
                return lstProd;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private List<ProductEnt> GetProduct(DataSet dsProd)
        {
            return (from dr in dsProd.Tables[0].AsEnumerable() select BindDataToProdEnt(dr, dsProd)).ToList();
        }

        private ProductEnt BindDataToProdEnt(DataRow dr, DataSet dsMake)
        {
            return new ProductEnt
            {
                ProductCode = Convert.ToString(dr["ProductCode"]),
                ProductName = Convert.ToString(dr["ProductName"]),
                VehicleTypeId = Convert.ToInt32(dr["VehicleTypeId"]),
                VehicleTypeName = Convert.ToString(dr["VehicleType"]),
                Make = GetMake(dsMake, Convert.ToString(dr["ProductCode"]))
            };
        }
        private List<MakeEnt> GetMake(DataSet dsMake, string prodCode)
        {
            return (from dr in dsMake.Tables[1].AsEnumerable().Where(dr => dr.Table.Rows[0]["ProductCode"].ToString() == prodCode) select BindDataToMakeEnt(dr, dsMake)).ToList();
        }

        private MakeEnt BindDataToMakeEnt(DataRow dr, DataSet dsModel)
        {
            return new MakeEnt
            {
                MakeId = Convert.ToInt32(dr["MakeId"]),
                MakeName = Convert.ToString(dr["MakeName"]),
                MakeProductID = Convert.ToString(dr["ProductCode"]),
                Model = GetModel(dsModel, Convert.ToInt32(dr["MakeId"]))

            };
        }
        private List<ModelEnt> GetModel(DataSet dsModel, int makeId)
        {
            return (from dr in dsModel.Tables[2].AsEnumerable().Where(dr => Convert.ToInt32(dr.Table.Rows[0]["MakeId"]) == makeId) select BindDataToModelEnt(dr)).ToList();
        }

        private ModelEnt BindDataToModelEnt(DataRow dr)
        {
            return new ModelEnt
            {
                ModelId = Convert.ToInt32(dr["ModelId"]),
                ModelName = Convert.ToString(dr["ModelName"]),
                MakeId = Convert.ToInt32(dr["MakeId"])
            };
        }

        public List<ClaimEnt> GetICEDetails(string caseNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();
                List<ClaimEnt> lstClaim = null;
                ClaimEnt objClaim = null;
                iErrorno = oDAL.Select(ProcedureConstants.GetDetailsForICE, out dsClaim, oDAL.CreateParameter("@CaseNo", DbType.String, caseNo));
                if (iErrorno == 0)
                {
                    if (dsClaim.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsClaim.Tables[0].Rows)
                        {
                            if (lstClaim == null)
                                lstClaim = new List<ClaimEnt>();
                            objClaim = new ClaimEnt();
                            objClaim.CaseNo = Convert.ToString(dr["CaseNo"]);
                            objClaim.ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]);
                            objClaim.ClaimRegionId = Convert.ToInt32(dr["ClaimRegionId"]);
                            objClaim.ClaimRegionName = Convert.ToString(dr["ClaimRegionName"]);
                            objClaim.EstimatedLoss = Convert.ToDouble(dr["EstimatedLoss"]);
                            objClaim.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]);
                            lstClaim.Add(objClaim);
                        }
                    }
                }
                return lstClaim;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void UpdateICEDetails(string caseNo, bool insertFlag, string remark)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsClaim = new DataSet();
                this.iErrorno = oDAL.Update(ProcedureConstants.UpdateDetailsForICE, oDAL.CreateParameter("@CaseNo", DbType.String, caseNo),
                                                                        oDAL.CreateParameter("@InsertFlag", DbType.Boolean, insertFlag),
                                                                         oDAL.CreateParameter("@Remark", DbType.String, remark));

            }
            catch (Exception ex)
            {
                //throw ex;
                //ex.DisplayCustomMessage("");
            }

        }

        //public List<ClaimEnt> IntimateClaim(ClaimEnt objClaim, List<InsuredEnt> lstInsured, LossEnt objLoss, DriverEnt objDriver, List<PolicyEnt> lstPolicy, List<VictimEnt> lstVictim, GarageEnt objGarage)
        public List<ClaimEnt> IntimateClaim(ClaimEnt objClaim)
        {
            List<ClaimEnt> lstClaim = new List<ClaimEnt>();
            try
            {

                CRUD oDAL = new CRUD();
                DataSet dsClaimIntimation = new DataSet();
                DataTable claimDetails = null;
                DataTable insuredDetails = null;
                DataTable lossDetails = null;
                DataTable driverDetails = null;
                DataTable policyDetails = null;
                DataTable victimDetails = null;
                DataTable garageDetails = null;
                DataTable cityDetails = null;
                DataTable stateDetails = null;
                DataTable makeDetails = null;
                DataSet dsClaim = new DataSet();

                claimDetails = objClaim.ToDataTable<ClaimEnt>(TableTypeConstants.CI_Claim_Details_Columns);
                insuredDetails = objClaim.InsuredList.ToDataTable<InsuredEnt>(TableTypeConstants.CI_Insured_Details_Columns);
                lossDetails = objClaim.Loss.ToDataTable<LossEnt>(TableTypeConstants.CI_Loss_Details_Columns);
                driverDetails = objClaim.Driver.ToDataTable<DriverEnt>(TableTypeConstants.CI_Driver_Details_Columns);
                policyDetails = objClaim.PolicyList.ToDataTable<PolicyEnt>(TableTypeConstants.CI_Policy_Details_Columns);
                if (objClaim.VictimList == null || objClaim.VictimList.Count == 0)
                {
                    VictimEnt objVictim = new VictimEnt();
                    victimDetails = objVictim.ToDataTable(TableTypeConstants.CI_Victim_Details_Columns);
                }
                else
                {
                    victimDetails = objClaim.VictimList.ToDataTable<VictimEnt>(TableTypeConstants.CI_Victim_Details_Columns);
                }

                if (objClaim.GarageList == null || objClaim.GarageList.Count == 0)
                {
                    GarageEnt objGarage = new GarageEnt();
                    CityEnt objCity = new CityEnt();
                    StateEnt objState = new StateEnt();
                    MakeEnt objMake = new MakeEnt();
                    garageDetails = objGarage.ToDataTable<GarageEnt>(TableTypeConstants.CI_Garage_Details_Columns);
                    cityDetails = objCity.ToDataTable<CityEnt>(TableTypeConstants.CI_Garage_City_Columns);
                    stateDetails = objState.ToDataTable<StateEnt>(TableTypeConstants.CI_Garage_State_Columns);
                    makeDetails = objMake.ToDataTable<MakeEnt>(TableTypeConstants.CI_Garage_Make_Columns);

                    garageDetails = CopyColumns(cityDetails, garageDetails, TableTypeConstants.CI_Garage_City_Columns);
                    garageDetails = CopyColumns(stateDetails, garageDetails, TableTypeConstants.CI_Garage_State_Columns);
                    garageDetails = CopyColumns(makeDetails, garageDetails, TableTypeConstants.CI_Garage_Make_Columns);

                }
                else
                {
                    garageDetails = objClaim.GarageList.First().ToDataTable<GarageEnt>(TableTypeConstants.CI_Garage_Details_Columns);
                    cityDetails = objClaim.GarageList.First().City.ToDataTable<CityEnt>(TableTypeConstants.CI_Garage_City_Columns);
                    stateDetails = objClaim.GarageList.First().State.ToDataTable<StateEnt>(TableTypeConstants.CI_Garage_State_Columns);
                    makeDetails = objClaim.GarageList.First().Make.ToDataTable<MakeEnt>(TableTypeConstants.CI_Garage_Make_Columns);

                    garageDetails = CopyColumns(cityDetails, garageDetails, TableTypeConstants.CI_Garage_City_Columns);
                    garageDetails = CopyColumns(stateDetails, garageDetails, TableTypeConstants.CI_Garage_State_Columns);
                    garageDetails = CopyColumns(makeDetails, garageDetails, TableTypeConstants.CI_Garage_Make_Columns);
                }
                dsClaimIntimation.Tables.Add(claimDetails);
                dsClaimIntimation.Tables.Add(insuredDetails);
                dsClaimIntimation.Tables.Add(lossDetails);
                dsClaimIntimation.Tables.Add(driverDetails);
                dsClaimIntimation.Tables.Add(policyDetails);
                dsClaimIntimation.Tables.Add(garageDetails);
                dsClaimIntimation.Tables.Add(victimDetails);

                this.iErrorno = oDAL.Insert("USP_SaveClaimIntimationDetails", out dsClaim, dsClaimIntimation);
                if (iErrorno == 0 && dsClaim != null)
                {
                    if (dsClaim.Tables.Count > 0)
                    {
                        lstClaim = dsClaim.Tables[0].ToEntityList<ClaimEnt>();
                    }
                }

            }

            catch (Exception ex)
            {
                //throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }
        private DataTable CopyColumns(DataTable source, DataTable dest, List<string> sourceColumns)
        {
            if (sourceColumns != null && source.Rows.Count > 0 && dest.Rows.Count > 0)
            {
                foreach (string colname in sourceColumns)
                {
                    dest.Columns.Add(colname);
                    dest.Rows[0][colname] = source.Rows[0][colname];
                }
            }
            return dest;
        }

        public List<BlazeEnt> GetBlazeInputParameters(string policyNo)
        {
            List<BlazeEnt> lstBlaze = null;

            BlazeEnt objBlaze = null;

            DataSet dsBlaze = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetBlazeInputParameters, out dsBlaze, oDAL.CreateParameter("@PolicyNo", DbType.String, policyNo));
                if (iErrorno == 0)
                {
                    if (dsBlaze.Tables[0].Rows.Count > 0)
                    {
                        objBlaze = new BlazeEnt();
                        lstBlaze = dsBlaze.Tables[0].ToEntityList<BlazeEnt>();
                    }
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return lstBlaze;
        }

        public string SaveBlazeScoreCardDetails(BlazeEnt objBlaze)
        {

            DataSet dsBlaze = new DataSet();
            CRUD oDAL = new CRUD();
            string legend = "";
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.InsertBlazeScoreCardDetails, out dsBlaze,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, objBlaze.CurrClaimRefNo),
                    oDAL.CreateParameter("@InputXML", DbType.String, objBlaze.InputXML),
                    oDAL.CreateParameter("@OutputXML", DbType.String, objBlaze.OutputXML),
                    oDAL.CreateParameter("@NoOfRules", DbType.Int32, objBlaze.NoOfRules),
                    oDAL.CreateParameter("@Rules", DbType.String, objBlaze.Rules),
                    oDAL.CreateParameter("@Score", DbType.Double, objBlaze.ScoreCount),
                    oDAL.CreateParameter("@ErrorCode", DbType.String, objBlaze.ErrorCode),
                    oDAL.CreateParameter("@ErrorMessage", DbType.String, objBlaze.ErrorMessage),
                    oDAL.CreateParameter("@CreatedBy", DbType.Int32, objBlaze.CreatedBy));
                if (iErrorno == 0)
                {
                    if (dsBlaze.Tables[0].Rows.Count > 0)
                    {
                        legend = Convert.ToString(dsBlaze.Tables[0].Rows[0]["Legend"]);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return legend;
        }

        public List<ClaimEnt> GetClaimByPolicyId(string strPolicyId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Select("USP_GetClaimByPolicyNo", out dsUserInfo,
                                    oDAL.CreateParameter("@P_Policy_No", DbType.String, strPolicyId)
                                    );
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     BindClaimDetails(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private List<ClaimEnt> BindClaimDetails(DataSet dsClaim)
        {
            return (from dtRow in dsClaim.Tables[0].AsEnumerable()
                    select (new ClaimEnt
                    {
                        ClaimRefNo = Convert.ToString(dtRow["CLAIMREFNO"]),
                        PolicyNo = Convert.ToString(dtRow["POLICYNO"]),
                        HubName = Convert.ToString(dtRow["HubName"]),
                        DateOfLoss = Convert.ToString(dtRow["DATEOFLOSS"]),
                        CreatedDate = Convert.ToDateTime(dtRow["CREATEDDATE"]),
                    })).ToList();

        }

        public bool ProcessClaim(string claimRefNo, int createdBy)
        {

            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Insert(ProcedureConstants.ProcessClaim,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo),
                    oDAL.CreateParameter("@CreatedBy", DbType.Int32, createdBy));
                if (iErrorno == 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<ClaimEnt> GetInboxDetailsForCM_HM_ZM_CO_VH(int userId)
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInboxDetailsFor_CM_HM_ZM_CO_VH_CEO, out ds, oDAL.CreateParameter("@UserId", DbType.Int32, userId));
                if (iErrorno == 0)
                {
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }

        public List<ClaimEnt> GetCIInputParamsForSavvion(string claimRefNo)
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetCIInputParamsForSavvion, out ds, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo));
                if (iErrorno == 0)
                {
                    lstClaim = new List<ClaimEnt>();
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;

        }

        public bool IsExistingCMSClaim(string policyNo, string coverNoteNo, DateTime dateOfLoss, int primaryTypeofLoss, string insuredName)
        {

            DataSet dsClaim = new DataSet();
            CRUD oDAL = new CRUD();
            bool isExistingClaim = false;

            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.IsExistingCMSClaim, out dsClaim,
                    oDAL.CreateParameter("@PolicyNo", DbType.String, policyNo),
                    oDAL.CreateParameter("@CoverNoteNo", DbType.String, coverNoteNo),
                    oDAL.CreateParameter("@DateOfLoss", DbType.DateTime, dateOfLoss),
                    oDAL.CreateParameter("@PrimaryTypeofLoss", DbType.Int32, primaryTypeofLoss),
                    oDAL.CreateParameter("@InsuredName", DbType.String, insuredName));
                if (iErrorno == 0)
                {
                    if (dsClaim.Tables[0].Rows.Count > 0)
                    {
                        isExistingClaim = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return isExistingClaim;
        }

        public List<ClaimEnt> GetInboxDetailsForBSM()
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInboxDetailsForBSM, out ds);
                if (iErrorno == 0)
                {
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }
        public List<ClaimEnt> GetInboxDetailsForRAM()
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInboxDetailsForRAM, out ds);
                if (iErrorno == 0)
                {
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }
        public List<ClaimEnt> GetInboxDetailsForRCU()
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInboxDetailsForRCU, out ds);
                if (iErrorno == 0)
                {
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }
        public List<ClaimEnt> GetInboxDetailsForCVM()
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInboxDetailsForCVM, out ds);
                if (iErrorno == 0)
                {
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }

        public List<ClaimEnt> GetInboxDetailsForSurveyor(int userId)
        {
            List<ClaimEnt> lstClaim = null;
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInboxDetailsForSurveyor, out ds, oDAL.CreateParameter("@UserId", DbType.Int32, userId));
                if (iErrorno == 0)
                {
                    lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstClaim;
        }

        public ClaimEnt GetInsuredDetails(string claimRefNo)
        {
            //List<ClaimEnt> lstClaim = null;
            ClaimEnt objClaim = null;
            LossEnt objLoss = null; 
            List<InsuredEnt> lstInsured = null; 
            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetInsuredDetails, out ds, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo));
                if (iErrorno == 0)
                {
                    objClaim = ds.Tables[0].Rows[0].ToEntity<ClaimEnt>();
                    objLoss = ds.Tables[1].Rows[0].ToEntity<LossEnt>();
                    lstInsured = ds.Tables[2].ToEntityList<InsuredEnt>();
                    objClaim.InsuredList = lstInsured;
                    objClaim.Loss = objLoss;
                    //lstClaim = ds.Tables[0].ToEntityList<ClaimEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return objClaim;
        }

        public int SaveInsuredDetails(InsuredEnt objInsured)
        {            
            DataSet ds = new DataSet();
            DataTable dt = null;
            DataSet dsInsured = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                dt = objInsured.ToDataTable<InsuredEnt>(TableTypeConstants.CI_Insured_Details_Columns);
                dsInsured.Tables.Add(dt);
                iErrorno = oDAL.Insert(ProcedureConstants.InsertInsuredDetails, out ds, dsInsured);       
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return iErrorno;
        }
    }
}
