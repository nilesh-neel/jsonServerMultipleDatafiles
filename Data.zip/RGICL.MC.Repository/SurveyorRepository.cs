﻿using System;
using System.Collections.Generic;
using System.Data;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Contracts.Entity;
using System.Linq;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class SurveyorRepository
    {
        public int Status;
        int? iErrorno;
        static int? ErrorCode = 0;


        public string GetLicenceNumber(int iSurveyorID)
        {

            string sLicenceNumber = string.Empty;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsLicenceNumber = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetLicenceNumber, out dsLicenceNumber, oDAL.CreateParameter("@Serveyor_ID_PK", DbType.Int32, iSurveyorID));
                if (this.iErrorno == 0)
                {
                    if (dsLicenceNumber.Tables[0].Rows.Count > 0)
                        sLicenceNumber = Convert.ToString(dsLicenceNumber.Tables[0].Rows[0]["LicenceNO"]);
                }

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return sLicenceNumber;
        }

        public List<SurveyorEnt> GetSurveyorName(string strSurveyorType)
        {
            //SurveyorEnt oSurveyorEnt = null;
            //List<SurveyorEnt> lstSurveyor = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetSurveyor, out dsType, oDAL.CreateParameter("@SurveyorType", DbType.String, strSurveyorType));
                return this.iErrorno == 0 ? (dsType.Tables[0].Rows.Count > 0 && dsType.Tables[0] != null ?
                   GetSurveyorDetails(dsType) : null) : null;
                //if (this.iErrorno == 0)
                //{

                //    if (dsType.Tables[0].Rows.Count > 0)
                //    {
                //        foreach (DataRow dr in dsType.Tables[0].Rows)
                //        {
                //            if (lstSurveyor == null)
                //                lstSurveyor = new List<SurveyorEnt>();
                //            oSurveyorEnt = new SurveyorEnt();
                //            oSurveyorEnt.SurveyorID = Convert.ToInt32(dr["ServeyorID"]);
                //            oSurveyorEnt.SurveyorName = Convert.ToString(dr["SurveyorName"]);
                //            lstSurveyor.Add(oSurveyorEnt);
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                throw;
            }
            //return lstSurveyor;
        }


        private List<SurveyorEnt> GetSurveyorDetails(DataSet dsSurveyor)
        {
            return (from dr in dsSurveyor.Tables[0].AsEnumerable() select BindDataToSurveyorEnt(dr)).ToList();
        }

        private SurveyorEnt BindDataToSurveyorEnt(DataRow dr)
        {
            return new SurveyorEnt
                {
                    SurveyorID = Convert.ToInt32(dr["ServeyorID"]),
                    SurveyorName = Convert.ToString(dr["SurveyorName"]),
                    //GarageEntList = GetGarageName(iClaimRefNo),
                    //HubEntList = GetHubDetails()
                };
        }


        public List<HubEnt> GetHubDetails(string strClaimRefNo)
        {
            //HubEnt oHubEnt = null;
            //List<HubEnt> lstHub = null;
            //try
            //{
            CRUD oDAL = new CRUD();
            DataSet dsHub = new DataSet();

            this.iErrorno = oDAL.Select(ProcedureConstants.GetAllHub, out dsHub, oDAL.CreateParameter("@ClaimRefNo", DbType.String, strClaimRefNo));
            return this.iErrorno == 0 ? (dsHub.Tables[0].Rows.Count > 0 && dsHub.Tables[0] != null ?
              GetALLHubDetails(dsHub) : null) : null;

            //    if (this.iErrorno == 0)
            //    {

            //        if (dsType.Tables[0].Rows.Count > 0)
            //        {
            //            foreach (DataRow dr in dsType.Tables[0].Rows)
            //            {
            //                if (lstHub == null)
            //                    lstHub = new List<HubEnt>();
            //                oHubEnt = new HubEnt();
            //                oHubEnt.HubID = Convert.ToInt32(dr["HubID"]);
            //                oHubEnt.HubName = Convert.ToString(dr["HubName"]);
            //                lstHub.Add(oHubEnt);
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw;

            //}

            //return lstHub;
        }
        private List<HubEnt> GetALLHubDetails(DataSet dsHub)
        {
            return (from dr in dsHub.Tables[0].AsEnumerable() select BindDataToHubEnt(dr)).ToList();
        }

        private HubEnt BindDataToHubEnt(DataRow dr)
        {
            return new HubEnt
            {
                HubID = Convert.ToInt32(dr["HubID"]),
                HubName = Convert.ToString(dr["HubName"])
            };
        }
        public List<GarageEnt> GetGarageName(string iClaimRefNo)
        {
            //GarageEnt oGarageEnt = null;
            //List<GarageEnt> lstGarageName = null;
            //try
            //{
            CRUD oDAL = new CRUD();
            DataSet dsType = new DataSet();

            this.iErrorno = oDAL.Select(ProcedureConstants.GetClaimGarageName, out dsType
                , oDAL.CreateParameter("@ClaimRefNo", DbType.String, iClaimRefNo));

            return this.iErrorno == 0 ? (dsType.Tables[0].Rows.Count > 0 && dsType.Tables[0] != null) ?
                GetGarageList(dsType) : null : null;

            //if (this.iErrorno == 0)
            //{
            //    if (dsType.Tables[0].Rows.Count > 0)
            //    {
            //        foreach (DataRow dr in dsType.Tables[0].Rows)
            //        {
            //            if (lstGarageName == null)
            //                lstGarageName = new List<GarageEnt>();
            //            oGarageEnt = new GarageEnt();
            //            oGarageEnt.GarageID = Convert.ToInt32(dr["GarageID"]);
            //            oGarageEnt.GarageName = Convert.ToString(dr["GarageName"]);
            //            lstGarageName.Add(oGarageEnt);
            //        }
            //    }
            //}
            //}
            //catch (Exception ex)
            //{
            //    throw;

            //}

            // return lstGarageName;
        }


        private static List<GarageEnt> GetGarageList(DataSet dsGarageName)
        {
            return (from dr in dsGarageName.Tables[0].AsEnumerable() select BindDataToGarageEnt(dr)).ToList();
        }
        private static GarageEnt BindDataToGarageEnt(DataRow dr)
        {
            return new GarageEnt
            {
                GarageID = Convert.ToInt32(dr["GarageID"]),
                GarageName = Convert.ToString(dr["GarageName"])
            };
        }
        public int SetManualSurveyAppointment(List<SurveyorEnt> lstSurveyAppointmentEnt)
        {
            CRUD oDAL = new CRUD();
            DataSet dsManualSurvey = new DataSet();
            DataTable dtManualSurveyDetails = null;

            dtManualSurveyDetails = lstSurveyAppointmentEnt.ToDataTable<SurveyorEnt>(TableTypeConstants.Manual_Survey_Apoointment);
            dsManualSurvey.Tables.Add(dtManualSurveyDetails);
            try
            {
                CRUD objDAL = new CRUD();

                this.iErrorno = objDAL.Insert(ProcedureConstants.SetManualSurveyorDetails, dsManualSurvey);

                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }
            return Status;
        }
        public List<SurveyorEnt> GetManualSurveyDetails()
        {
            CRUD oDAL = new CRUD();
            DataSet dsType = new DataSet();

            this.iErrorno = oDAL.Select(ProcedureConstants.GetManualSurveyorDetails, out dsType);
            return this.iErrorno == 0 ? (dsType.Tables.Count > 0 && dsType.Tables[0].Rows.Count != null) ?
                GetManualSurveyorList(dsType) : null : null;

        }
        private static List<SurveyorEnt> GetManualSurveyorList(DataSet dsManualSurveyorDetail)
        {
            return (from dr in dsManualSurveyorDetail.Tables[0].AsEnumerable() select BindDataToManualSurveyorEnt(dr)).ToList();
        }
        private static SurveyorEnt BindDataToManualSurveyorEnt(DataRow dr)
        {
            return new SurveyorEnt
            {
                ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                PolicyNo = Convert.ToString(dr["PolicyNo"]),
                ClaimSurveyorMapID = Convert.ToInt32(dr["ClaimSurveyorMapID"]),
                GarageID = Convert.ToInt32(dr["GarageID"]),
                GarageName = Convert.ToString(dr["GarageName"]),
                SurveyorType = Convert.ToString(dr["SurveyorType"]),
                HubID = Convert.ToInt32(dr["HubID"]),
                HubName = Convert.ToString(dr["HubName"]),
                SurveyorID = Convert.ToInt32(dr["SurveyorID"]),
                SurveyorName = Convert.ToString(dr["SurveyorName"]),
                TypeOfSurvey = Convert.ToString(dr["TypeOfSurvey"]),
                ReasonforExtSurvey = Convert.ToString(dr["ReasonForExtSurveyor"]),
                Category = Convert.ToString(dr["Category"]),
                SurveyorStatus = Convert.ToString(dr["Status"]),
                AppointmentDate = Convert.ToDateTime(dr["DateOfAppointment"]),
                LicenseNo = Convert.ToInt32(dr["LicenseNo"]),
                Remarks = Convert.ToString(dr["Remarks"]),
                AppointmentStatus = Convert.ToString(dr["AppointmentStatus"])
                //IsActive = Convert.ToBoolean(dr["IsActive"])
            };
        }

        public List<LookupEnt> GetSurveyorCategory(string SurveyorID)
        {
            //SurveyorEnt oSurveyorEnt = null;
            //List<SurveyorEnt> lstSurveyor = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetSurveyorCategory, out dsType, oDAL.CreateParameter("@Serveyor_ID_PK", DbType.String, SurveyorID));
                return this.iErrorno == 0 ? (dsType.Tables[0].Rows.Count > 0 && dsType.Tables[0] != null ?
                   GetSurveyorCategoryDetails(dsType) : null) : null;
                //if (this.iErrorno == 0)
                //{

                //    if (dsType.Tables[0].Rows.Count > 0)
                //    {
                //        foreach (DataRow dr in dsType.Tables[0].Rows)
                //        {
                //            if (lstSurveyor == null)
                //                lstSurveyor = new List<SurveyorEnt>();
                //            oSurveyorEnt = new SurveyorEnt();
                //            oSurveyorEnt.SurveyorID = Convert.ToInt32(dr["ServeyorID"]);
                //            oSurveyorEnt.SurveyorName = Convert.ToString(dr["SurveyorName"]);
                //            lstSurveyor.Add(oSurveyorEnt);
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                throw;
            }
            //return lstSurveyor;
        }
        private static List<LookupEnt> GetSurveyorCategoryDetails(DataSet dsManualSurveyorDetail)
        {
            return (from dr in dsManualSurveyorDetail.Tables[0].AsEnumerable() select BindDataToCategoryLookup(dr)).ToList();
        }
         private static LookupEnt BindDataToCategoryLookup(DataRow dr)
         {
             return new LookupEnt
             {
                 LookupID = Convert.ToInt32(dr["LookUpId"]),
                 LookupName = Convert.ToString(dr["LookUpName"])
             
             };
         }
        public void UpdateSurveyorAppointment(SurveyorEnt objSurveyorEnt)
        {
            CRUD oDAL = new CRUD();

            try
            {
                CRUD objDAL = new CRUD();

                this.iErrorno = objDAL.Insert(ProcedureConstants.UpdateSyrveyorAppointmentStatus,
                objDAL.CreateParameter("@AppointmentStatusID", DbType.String, objSurveyorEnt.AppointmentStatusID),
                objDAL.CreateParameter("@AppointmentStatus", DbType.Int32, objSurveyorEnt.AppointmentStatus),
                objDAL.CreateParameter("@UpdatedBy", DbType.Int32, objSurveyorEnt.UpdatedBy));
                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }

        }

    }
}
