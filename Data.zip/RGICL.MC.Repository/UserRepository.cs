﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Web.Security;
using System.Web;
using RGICL.MC.Common.Utilities;
using System.Xml.Linq;
using System.IO;
using System.Xml.Serialization;
using System.Xml;
namespace RGICL.MC.Repository
{
    public class UserRepository
    {
        int _iErrorno;
        public List<UserInformationEnt> GetUserList(string strLoginID, string strFName, string strLName)
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.SelectUserList, out dsUser,
                                    oDal.CreateParameter("@P_Login_Id", DbType.String, strLoginID),
                                    oDal.CreateParameter("@P_FName", DbType.String, strFName),
                                        oDal.CreateParameter("@P_LName", DbType.String, strLName)
                                    );
                return this._iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                    GetUsers(dsUser) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public string GeHubLocationDetails(string strHubId)
        {
            try
            {
                var oDal = new CRUD();
                DataSet dsSample;

                _iErrorno = oDal.Select("USP_GetHubLocationMapping", out dsSample,
                                    oDal.CreateParameter("@P_Hub_Id", DbType.String, strHubId)
                                    );
                return _iErrorno == 0 ? (dsSample.Tables[0].Rows.Count > 0 && dsSample.Tables[0] != null ?
                   Convert.ToString(dsSample.Tables[0].Rows[0][0])
                : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public string GetLocationGarageDetails(string strLocationId)
        {
            try
            {
                var oDal = new CRUD();
                DataSet dsSample;

                _iErrorno = oDal.Select("USP_GetLocationGarageMapp", out dsSample,
                                    oDal.CreateParameter("@P_Location_Id", DbType.String, strLocationId)
                                    );
                return _iErrorno == 0 ? (dsSample.Tables[0].Rows.Count > 0 && dsSample.Tables[0] != null ?
                   Convert.ToString(dsSample.Tables[0].Rows[0][0])
                : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        #region "SaveUser"
        public int SaveUser(UserInformationEnt oUser)
        {
            try
            {
                CRUD oDAL = new CRUD();
                var dsUser = new DataSet();

                var userXml = ObjectXmlUtility.CreateXml(oUser);


                this._iErrorno = oDAL.Select("USP_SaveUser", out dsUser,
                                    oDAL.CreateParameter("@XmlData", DbType.String, userXml));

                var xmlUser = ObjectXmlUtility.ToXml(oUser);
                DataSet dsXmlUser = new DataSet();
                var strReader = new StringReader(xmlUser);
                dsUser.ReadXml(strReader);
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public int SaveUserDetails(UserInformationEnt oUser)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                var userXml = ObjectXmlUtility.CreateXml(oUser);


                this._iErrorno = oDAL.Select(ProcedureConstants.SaveUserDetails, out dsUser,
                                    oDAL.CreateParameter("@XmlData", DbType.String, userXml));
                return this._iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                    Convert.ToInt32(dsUser.Tables[0].Rows[0][0]) : 00) : 00;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        public int SaveUserZoneHub(string strZoneHubXml)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.SaveZoneHubTeams, out dsUser,
                                      oDAL.CreateParameter("@XmlData", DbType.String, strZoneHubXml));

                return this._iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                Convert.ToInt32(dsUser.Tables[0].Rows[0][0]) : 00) : 00;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public int SaveUserProductCategoryMapp(string strProductCatXml)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDAL.Select(ProcedureConstants.SaveUserProductCateMapp, out dsUser,
                                     oDAL.CreateParameter("@XmlData", DbType.String, strProductCatXml));

                return this._iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                  Convert.ToInt32(dsUser.Tables[0].Rows[0][0]) : 00) : 00;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public int SaveUserHubLocation(UserInformationEnt oUser)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                var userXml = ObjectXmlUtility.CreateXml(oUser);


                this._iErrorno = oDAL.Select(ProcedureConstants.SaveUserHubLocationMapp, out dsUser,
                                    oDAL.CreateParameter("@XmlData", DbType.String, userXml));

                var xmlUser = ObjectXmlUtility.ToXml(oUser);
                DataSet dsXmlUser = new DataSet();
                var strReader = new StringReader(xmlUser);
                dsUser.ReadXml(strReader);
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public int SaveUserLocationGarage(UserInformationEnt oUser)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                var userXml = ObjectXmlUtility.CreateXml(oUser);


                this._iErrorno = oDAL.Select(ProcedureConstants.SaveUserLocationGarageMapp, out dsUser,
                                    oDAL.CreateParameter("@XmlData", DbType.String, userXml));

                var xmlUser = ObjectXmlUtility.ToXml(oUser);
                DataSet dsXmlUser = new DataSet();
                var strReader = new StringReader(xmlUser);
                dsUser.ReadXml(strReader);
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public int SaveUserMackerChecker(UserInformationEnt oUser)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                var userXml = ObjectXmlUtility.CreateXml(oUser);


                this._iErrorno = oDAL.Select(ProcedureConstants.SaveUserMackerChecker, out dsUser,
                                    oDAL.CreateParameter("@XmlData", DbType.String, userXml));

                var xmlUser = ObjectXmlUtility.ToXml(oUser);
                DataSet dsXmlUser = new DataSet();
                var strReader = new StringReader(xmlUser);
                dsUser.ReadXml(strReader);
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public void SaveMobileServiceResponse(string strServiceName, string strRequest, string strResponse, string strLoginId, string strDeviceNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.LogMobileServiceResponse, out dsUser,
                                    oDAL.CreateParameter("@P_ServiceName", DbType.String, strServiceName),
                                    oDAL.CreateParameter("@P_Request", DbType.String, strRequest),
                                    oDAL.CreateParameter("@P_Response", DbType.String, strResponse),
                                    oDAL.CreateParameter("@P_LoginId", DbType.String, strLoginId),
                                        oDAL.CreateParameter("@P_DeviceId", DbType.String, strDeviceNo)
                                    );
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        #endregion

        public UserInformationEnt GetUserInfo(string strLoginID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsSample = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.SelectUserLoginInfo, out dsSample,
                                    oDAL.CreateParameter("@LoginID", DbType.String, strLoginID)
                                    );
                return this._iErrorno == 0 ? (dsSample.Tables[0].Rows.Count > 0 && dsSample.Tables[0] != null ?
                    BindDataToUserEnt(dsSample.Tables[0].Rows[0], dsSample)
                : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public UserInformationEnt GetUserInfo(string strLoginID, string strSAPCode)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsSample = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.SelectUserLoginInfo, out dsSample,
                                    oDAL.CreateParameter("@LoginID", DbType.String, strLoginID),
                                    oDAL.CreateParameter("@SAPCode", DbType.String, strSAPCode)
                                    );
                return this._iErrorno == 0 ? (dsSample.Tables[0].Rows.Count > 0 && dsSample.Tables[0] != null ?
                    BindDataToUserEnt(dsSample.Tables[0].Rows[0])
                : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public UserInformationEnt GetUserLoginInfo(string strLoginID)
        {
            try
            {
                UserInformationEnt objUserInfo = GetUserInfo(strLoginID);
                //objUserInfo.UserDetail = GetUserDetailsById(strLoginID);
                return objUserInfo;
            }
            catch (Exception ex)
            { throw; }

        }

        public List<UserAuthorizationEnt> GetAuthorizationPages(string strLoginID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsPages = new DataSet();
                this._iErrorno = oDAL.Select(ProcedureConstants.GetAuthorizedPages, out dsPages, oDAL.CreateParameter("@P_LoginID", DbType.String, strLoginID));
                return this._iErrorno == 0 ? (dsPages.Tables != null &&
                        dsPages.Tables[0].Rows.Count > 0 ? GetAuthPagesList(dsPages) : null
                        ) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private List<UserAuthorizationEnt> GetAuthPagesList(DataSet dsData)
        {
            return (from dr in dsData.Tables[0].AsEnumerable()
                    select (new UserAuthorizationEnt
                    {
                        PageID = Convert.ToString(dr["PageID"]),
                        PageURL = Convert.ToString(dr["PageURL"]),
                        IsReadOnly = Convert.ToBoolean(Convert.ToString(dr["IsReadOnly"]) == string.Empty ? 0 : dr["IsReadOnly"])
                    })).ToList();
        }

        public List<Menu> GetAllMenu(string strLoginId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                var dsUserInfo = new DataSet();
                int Errorno = oDAL.Select(ProcedureConstants.GetUserMenu, out dsUserInfo,
                                  oDAL.CreateParameter("@LoginID", DbType.String, strLoginId)
                                  );
                return this._iErrorno == 0 ? (dsUserInfo.Tables != null && dsUserInfo.Tables[0].Rows.Count > 0 ?
                      GetMenus(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            { throw; }
        }

        public UserInformationEnt ValidateSession(string strLoginID, string strSessionID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();
                int Errorno = oDAL.Select(ProcedureConstants.SelectUserLoginInfo, out dsUserInfo,
                                  oDAL.CreateParameter("@LoginID", DbType.String, strLoginID)
                                  );
                return this._iErrorno == 0 ? (dsUserInfo.Tables != null && dsUserInfo.Tables[0].Rows.Count > 0 ?
                      BindDataToUserEnt(dsUserInfo.Tables[0].Rows[0]) : null) : null;
            }
            catch (Exception ex)
            { throw; }
        }

        public void UpdateIPAddress(string strLoginID, string strIPAddress, string strSessionID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this._iErrorno = oDAL.Update(
                                    ProcedureConstants.SetUserIPAddress,
                                    oDAL.CreateParameter("@LoginID", DbType.String, strLoginID),
                                    oDAL.CreateParameter("@IPAddress", DbType.String, strIPAddress),
                                    oDAL.CreateParameter("@SessionId", DbType.String, strSessionID)
                                    );
            }
            catch (Exception ex)
            { throw; }
        }

        public int UpdateIsLocked(string strUserID, bool bIsLocked)
        {
            try
            {
                CRUD oDAL = new CRUD();
                this._iErrorno = oDAL.Update(
                                    ProcedureConstants.UpdateUserLockedDetails,
                                    oDAL.CreateParameter("@UserID", DbType.String, strUserID),
                                    oDAL.CreateParameter("@IsLocked", DbType.Boolean, bIsLocked)
                                    );
                return this._iErrorno;
            }
            catch (Exception ex)
            { throw; }
        }
        public List<UserRoleEnt> GetUserRole(string strLoginID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserRoles = new DataSet();
                this._iErrorno = oDAL.Select(ProcedureConstants.GetUserRole, out dsUserRoles, oDAL.CreateParameter("@LoginID", DbType.String, strLoginID));
                return this._iErrorno == 0 ? GetUserRoles(dsUserRoles) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public UserInformationEnt GetUserDetails(string strUserID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.GetUserDetails, out dsUserInfo,
                                    oDAL.CreateParameter("@UserID", DbType.String, strUserID)
                                    );
                return this._iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     BindDataToUserEnt(dsUserInfo.Tables[0].Rows[0]) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<EmployeeEnt> SearchEmployee(string strSapCode, string fName, string lName)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this._iErrorno = oDAL.Select(
                                 ProcedureConstants.SearchEmployee, out dsUserInfo,
                                 oDAL.CreateParameter("@SAP_Id", DbType.String, strSapCode),
                                 oDAL.CreateParameter("@FName", DbType.String, fName),
                                 oDAL.CreateParameter("@LName", DbType.String, lName)
                                 );


                return this._iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     GetEmployees(dsUserInfo) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }

        }
        public List<MakerCheckerEnt> GetMakerChecker(string strUserId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserRoles = new DataSet();
                this._iErrorno = oDAL.Select(ProcedureConstants.GetMakerChecker, out dsUserRoles, oDAL.CreateParameter("@P_User_Id", DbType.String, strUserId));
                return this._iErrorno == 0 ? BindDataToMakerCheckerEnt(dsUserRoles) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }


        public UserMaser GetUserMasterDetailsByUserId(int iUserId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.GetUserDetailsById, out dsUser
                    , oDAL.CreateParameter("@P_User_Id", DbType.Int32, iUserId));

                if (this._iErrorno == 0)
                {
                    return new UserMaser()
                    {
                        UserDetails = dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ? Convert.ToString(dsUser.Tables[0].Rows[0][0]) : null,
                        DTZHT = dsUser.Tables[1].Rows.Count > 0 && dsUser.Tables[1] != null ? ObjectXmlUtility.ConvertDatatableToXML(dsUser.Tables[1]) : null,
                        DTProduct = dsUser.Tables[2].Rows.Count > 0 && dsUser.Tables[2] != null ? ObjectXmlUtility.ConvertDatatableToXML(dsUser.Tables[2]) : null,
                        UserProductCatMapping = dsUser.Tables[3].Rows.Count > 0 && dsUser.Tables[3] != null ? Convert.ToString(dsUser.Tables[3].Rows[0][0]) : null,
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public Dictionary<string, object> GetUserDetailsByUserId(int iUserId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.GetUserDetailsById, out dsUser
                    , oDAL.CreateParameter("@P_User_Id", DbType.Int32, iUserId));

                if (this._iErrorno == 0)
                {
                    UserInformationEnt oUser = null;
                    string strProdCatXml = null;
                    DataTable dtZHT = null, dtProdCat = null;
                    if (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null)
                    {
                        oUser = BindXmlToUserDetails(dsUser);
                        dtZHT = dsUser.Tables[1] != null ? dsUser.Tables[1] : null;
                        dtProdCat = dsUser.Tables[2] != null ? dsUser.Tables[2] : null;
                        strProdCatXml = dsUser.Tables[3] != null ? Convert.ToString(dsUser.Tables[3].Rows[0][0]) : null;
                    }
                    return new Dictionary<string, object>() 
                    { 
                        { "UserDetails", oUser }, { "ZHTTable",dtZHT },{"ProdCatTable",dtProdCat} 
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public UserInformationEnt GetUserDetailsById(int iUserId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUser = new DataSet();

                this._iErrorno = oDAL.Select(ProcedureConstants.GetUserDetailsById, out dsUser
                    , oDAL.CreateParameter("@P_User_Id", DbType.Int32, iUserId));

                return this._iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                   BindXmlToUserDetails(dsUser) : null) : null;
                //GetAllCategory(dsUser) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private UserInformationEnt BindXmlToUserDetails(DataSet dsProdCat)
        {
            var xmlDoc = Convert.ToString(dsProdCat.Tables[0].Rows[0][0]);
            XDocument doc = XDocument.Parse(xmlDoc);
            var oUserDetails = (UserInformationEnt)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(UserInformationEnt));
            return oUserDetails;
        }


        private List<MakerCheckerEnt> BindDataToMakerCheckerEnt(DataSet dsMakerChe)
        {
            return (from dr in dsMakerChe.Tables[0].AsEnumerable()
                    select (new MakerCheckerEnt
                    {
                        MakerId = Convert.ToInt32(dr["MasterID"]),
                        PageId = Convert.ToString(dr["PageID"]),
                        PageName = Convert.ToString(dr["MasterName"]),
                        IsMaker = Convert.ToBoolean(Convert.ToString(dr["IsMaker"]) == string.Empty ? 0 : dr["IsMaker"]),
                        IsChecker = Convert.ToBoolean(Convert.ToString(dr["IsChecker"]) == string.Empty ? 0 : dr["IsChecker"]),
                    })).ToList();

        }

        public bool GetAccessType(string strUserID, string strPageName)
        {
            bool bIsReadOnly;

            //CMSMenu objMenu = new CMSMenu();
            //List<CMSMenuEnt> lstMenu = null;

            //lstMenu = objMenu.GetAccessType(strUserID, strPageName);

            ////bIsReadOnly = lstMenu.Any(page => page.MenuLocation.ToUpper() == strPageName);
            //var v = lstMenu.Select(o => o.IsReadOnly == true);
            //if (v == null)
            //    bIsReadOnly = false;
            //else
            //    bIsReadOnly = true;

            ////bIsReadOnly = Convert.ToBoolean(lstMenu.Select(o => o.IsReadOnly));

            //return bIsReadOnly;
            return true;
        }

        private List<UserInformationEnt> GetUsers(DataSet dsData)
        {
            //sreturn dsData.Tables[0].ToEntityList<UserInformationEnt>();
            return (from dr in dsData.Tables[0].AsEnumerable() select BindDataToUserEnt(dr)).ToList();
        }

        private List<EmployeeEnt> GetEmployees(DataSet dsData)
        {
            //sreturn dsData.Tables[0].ToEntityList<UserInformationEnt>();
            return (from dr in dsData.Tables[0].AsEnumerable() select BindDataToEmployeeEnt(dr)).ToList();
        }

        private EmployeeEnt BindDataToEmployeeEnt(DataRow dr)
        {
            return new EmployeeEnt
            {
                EmployeeCode = Convert.ToInt32(dr["Employee_Code"]),
                Title = Convert.ToString(dr["Title"]),
                FirstName = Convert.ToString(dr["First_Name"]),
                MiddleName = Convert.ToString(dr["Middle_Name"]),
                LastName = Convert.ToString(dr["Last_Name"]),
                DisplayName = Convert.ToString(dr["Employee_Name"]),
                Email = Convert.ToString(dr["EMail"]),
                ContactNo = Convert.ToString(dr["Contact_No"]),
                IsActive = Convert.ToBoolean(Convert.ToString(dr["Employee_ARC"]) == string.Empty ? 0 : dr["Employee_ARC"])
            };
        }


        private UserInformationEnt BindDataToUserEnt(DataRow dr, DataSet dsZoneDet = null)
        {

            var userID = dr.Table.Columns.Contains("UserID") ? Convert.ToString(dr["UserID"]) : null;

            return new UserInformationEnt
            {
                UserID = userID,//Convert.ToString(dr["UserID"]),
                LoginID = Convert.ToString(dr["LoginID"]),
                FirstName = dr.Table.Columns.Contains("FirstName") ? Convert.ToString(dr["FirstName"]) : null,
                LastName = dr.Table.Columns.Contains("LastName") ? Convert.ToString(dr["LastName"]) : null,
                Password = dr.Table.Columns.Contains("Password") ? Convert.ToString(dr["Password"]) : null,
                IsLocked = Convert.ToBoolean(dr.Table.Columns.Contains("IsLocked") ? Convert.ToBoolean(dr["IsLocked"]) : false),
                DisplayName = Convert.ToString(dr["DisplayName"]),
                EmailID = Convert.ToString(dr["EmailID"]),
                ContactNumber = Convert.ToString(dr["ContactNumber"]),
                MobileNumber = Convert.ToString(dr["MobileNumber"]),
                UserType = Convert.ToString(dr["UserType"]),
                SAPCode = Convert.ToString(dr["SAPCode"]),
                //LevelID = Convert.ToInt32(dr["LevelID"]),
                // LastLoginDate = Convert.ToDateTime(dr["LastLoginDate"] ?? DateTime.Now),
                IPAddress = Convert.ToString(dr["IPAddress"]),
                SessionID = Convert.ToString(dr["SessionID"]),
                IsMultiLogin = Convert.ToBoolean(!string.IsNullOrEmpty(dr["IsMultiLogin"].ToString()) ? dr["IsMultiLogin"] : false),
                IsActive = Convert.ToBoolean(!string.IsNullOrEmpty(dr["IsActive"].ToString()) ? dr["IsActive"] : false),
                MaxInActiveDays = Convert.ToInt32(!string.IsNullOrEmpty(dr["MaxInActiveDays"].ToString()) ? dr["MaxInActiveDays"] : 0),
                IsWebUser = Convert.ToBoolean(dr.Table.Columns.Contains("IsActiveInWeb") ? Convert.ToBoolean(dr["IsActiveInWeb"]) : false),
                IsMobileUser = Convert.ToBoolean(dr.Table.Columns.Contains("IsActiveInMobile") ? Convert.ToBoolean(dr["IsActiveInMobile"]) : false),
                Grade = new GradeEnt
                {
                    GradeName = Convert.ToString(dr.Table.Columns.Contains("Grade") ? Convert.ToString(dr["Grade"]) : ""),
                    MaxLevel = Convert.ToDouble(dr.Table.Columns.Contains("ApprovalMaxLimit") ? Convert.ToDouble(dr["ApprovalMaxLimit"]) : 0.00),
                    MinLevel = Convert.ToDouble(dr.Table.Columns.Contains("ApprovalMinLimit") ? Convert.ToDouble(dr["ApprovalMinLimit"]) : 0.00)
                },
                Role = BindDataToRoleEnt(dr),

                TypeOfLoss = BindDataToNatureOfLossEnt(dr),

                ProductCategory = BindDataToProductCategoryEnt(dr),

                Product = new ProductEnt { Description = dr.Table.Columns.Contains("ProductName") ? Convert.ToString(dr["ProductName"]) : null },
                Hub = new HubEnt { HubName = dr.Table.Columns.Contains("HubName") ? Convert.ToString(dr["HubName"]) : null },
                PhotoName = dr.Table.Columns.Contains("PhotoName") ? Convert.ToString(dr["PhotoName"]) : null,

                AuthorizedPages = GetAuthorizationPages(Convert.ToString(dr["LoginID"])),

                UserDetail = new UserDetails
                {
                    MakerChecker = GetMakerChecker(userID),
                    Role = new List<UserRoleEnt> {new UserRoleEnt{
                        RoleId=Convert.ToInt32(dr.Table.Columns.Contains("RoleID") ? Convert.ToInt32(dr["RoleID"]) : 0),
                        RoleCode=Convert.ToString(dr.Table.Columns.Contains("RoleCode") ? Convert.ToString(dr["RoleCode"]) : ""),
                        RoleName=Convert.ToString(dr.Table.Columns.Contains("RoleName") ? Convert.ToString(dr["RoleName"]) : "")
                    
                    } },
                    Zone = BindDataToZoneEntity(dsZoneDet),

                    TypeOfLoss = new List<NatureOfLossEnt> {new NatureOfLossEnt{
                        LossName=Convert.ToString(dr.Table.Columns.Contains("NatureOfLoss") ? Convert.ToString(dr["NatureOfLoss"]) : ""),
                    
                    } },

                    ProductCategory = new List<ProductCategoryEnt> {new ProductCategoryEnt{
                        CategoryName=Convert.ToString(dr.Table.Columns.Contains("ProductCategory") ? Convert.ToString(dr["ProductCategory"]) : ""),
                    
                    } }

                },

            };
        }

        private List<ZoneEnt> BindDataToZoneEntity(DataSet dsUserDet)
        {
            try
            {
                var objUserDetails = new UserDetails();
                if (dsUserDet != null && dsUserDet.Tables[1] != null && dsUserDet.Tables[1].Rows.Count > 0)
                {
                    List<ZoneEnt> objZone = new List<ZoneEnt>();
                    var xmlDoc = Convert.ToString(dsUserDet.Tables[1].Rows[0][0]);
                    if (!string.IsNullOrEmpty(xmlDoc))
                    {
                        XDocument doc = XDocument.Parse(xmlDoc);
                        XmlSerializer oXmlSerializer1 = new XmlSerializer(objZone.GetType());
                        return (List<ZoneEnt>)oXmlSerializer1.Deserialize(new StringReader(xmlDoc));
                    }
                }
                return null;
            }
            catch (Exception)
            {

                throw;
            }


        }

        private List<UserRoleEnt> GetUserRoles(DataSet dsdata)
        {
            return (from dr in dsdata.Tables[0].AsEnumerable() select BindDataToRoleEnt(dr)).ToList();
        }

        private UserRoleEnt BindDataToRoleEnt(DataRow dr)
        {
            return new UserRoleEnt
            {
                RoleId = Convert.ToInt32(dr.Table.Columns.Contains("RoleID") ? dr["RoleID"] : null),
                RoleName = Convert.ToString(dr.Table.Columns.Contains("RoleName") ? dr["RoleName"] : null),
                RoleDescription = Convert.ToString(dr.Table.Columns.Contains("RolDesc") ? dr["RolDesc"] : null)
            };
        }


        private List<NatureOfLossEnt> GetUserTypeOfLoss(DataSet dsdata)
        {
            return (from dr in dsdata.Tables[0].AsEnumerable() select BindDataToNatureOfLossEnt(dr)).ToList();
        }

        private NatureOfLossEnt BindDataToNatureOfLossEnt(DataRow dr)
        {
            return new NatureOfLossEnt
            {
                LossName = Convert.ToString(dr.Table.Columns.Contains("NatureOfLoss") ? Convert.ToString(dr["NatureOfLoss"]) : ""),
            };
        }


        private List<ProductCategoryEnt> GetUserProductCategory(DataSet dsdata)
        {
            return (from dr in dsdata.Tables[0].AsEnumerable() select BindDataToProductCategoryEnt(dr)).ToList();
        }

        private ProductCategoryEnt BindDataToProductCategoryEnt(DataRow dr)
        {
            return new ProductCategoryEnt
            {
                CategoryName = Convert.ToString(dr.Table.Columns.Contains("ProductCategory") ? Convert.ToString(dr["ProductCategory"]) : ""),
            };
        }

        private List<Menu> GetMenus(DataSet dsMenu)
        {
            return (from dr in dsMenu.Tables[0].AsEnumerable() select BIndDataToMenuEnt(dr)).ToList();

        }

        private Menu BIndDataToMenuEnt(DataRow dr)
        {
            return new Menu
            {
                Id = Convert.ToInt32(dr.Table.Columns.Contains("PAGEID") ? dr["PAGEID"] : null),
                DisplayName = Convert.ToString(dr.Table.Columns.Contains("DISPLAYNAME") ? dr["DISPLAYNAME"] : null),
                PageUrl = Convert.ToString(dr.Table.Columns.Contains("PAGEURL") ? dr["PAGEURL"] : null),
                ParentId = Convert.ToInt16(dr.Table.Columns.Contains("PARENTID") ? dr["PARENTID"] : null),
                OrderNo = Convert.ToInt16(dr.Table.Columns.Contains("ORDERNUMBER") ? dr["ORDERNUMBER"] : null)
            };
        }

    }

}
