﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class RemarksHistoryRepository
    {
        int iErrorno;
        public List<RemarksTypeEnt> GetListRemarksHistory(string strClaimRefNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsAuditDet = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetRemarksHistory, out dsAuditDet,
                                    oDAL.CreateParameter("@P_ClaimRefNo", DbType.String, strClaimRefNo));

                return this.iErrorno == 0 ? (dsAuditDet.Tables[0].Rows.Count > 0 && dsAuditDet.Tables[0] != null ?
                   GetRemarksDetails(dsAuditDet) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private List<RemarksTypeEnt> GetRemarksDetails(DataSet dsAuditDet)
        {
            return (from dtRow in dsAuditDet.Tables[0].AsEnumerable()
                    select (new RemarksTypeEnt
                    {
                        RemarkTypeID = 1,
                        RemarkTypeName = Convert.ToString(dtRow["RemarkTypeName"]),
                        RemarkDetail = new List<RemarksDetailsEnt>
                     {
                         new RemarksDetailsEnt
                         {
                             ClaimRefNo=new ClaimEnt{ClaimRefNo = "12345"},
                             RemarkDescription =  Convert.ToString(dtRow["RemarkDescription"]),
                             CreatedDate =  Convert.ToString(dtRow["RemarksDate"])
                            
                         },
                     },
                        CreatedBy = new UserInformationEnt
                        {
                            DisplayName = Convert.ToString(dtRow["DisplayName"]),
                            UserDetail = new UserDetails
                            {
                                Role = new List<UserRoleEnt> { new UserRoleEnt { RoleName = Convert.ToString(dtRow["RoleName"]) } }
                            }
                        }
                    })).ToList();
            //select BindDataToRemarksHisEnt(dr)).ToList();
        }

        private RemarksTypeEnt BindDataToRemarksHisEnt(DataRow dtRow)
        {
            return new RemarksTypeEnt
            {
                RemarkTypeID = 1,
                RemarkTypeName = Convert.ToString(dtRow["RemarkTypeName"]),
                RemarkDetail = new List<RemarksDetailsEnt>
                     {
                         new RemarksDetailsEnt
                         {
                             ClaimRefNo=new ClaimEnt{ClaimRefNo = "12345"},
                             RemarkDescription =  Convert.ToString(dtRow["RemarkDescription"]),
                             CreatedDate =  Convert.ToString(dtRow["RemarksDate"])
                            
                         },
                     },
                CreatedBy = new UserInformationEnt
                {
                    DisplayName = Convert.ToString(dtRow["DisplayName"]),
                    UserDetail = new UserDetails
                    {
                        Role = new List<UserRoleEnt> { new UserRoleEnt { RoleName = Convert.ToString(dtRow["RoleName"]) } }
                    }
                }
            };
        }
    }
}
