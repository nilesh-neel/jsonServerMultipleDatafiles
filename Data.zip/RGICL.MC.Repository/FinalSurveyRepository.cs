﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class FinalSurveyRepository
    {
        public int Status;
        int? iErrorno;
        public List<ParticularEnt> GetParticularsAsPerPolicy(string strCLaimRefNumber)
        {
            CRUD oDAL = new CRUD();
            DataSet dsParticulars = new DataSet();
            this.iErrorno = oDAL.Select(ProcedureConstants.GetParticularsAsPerPOlicy, out dsParticulars, oDAL.CreateParameter("@ClaimRefNo", DbType.String, strCLaimRefNumber));
            return this.iErrorno == 0 ? (dsParticulars.Tables[0].Rows.Count > 0 && dsParticulars.Tables[0] != null ?
                   GetParticularDetails(dsParticulars) : null) : null;

        }
        private List<ParticularEnt> GetParticularDetails(DataSet dsParticulars)
        {
            return (from dr in dsParticulars.Tables[0].AsEnumerable() select BindDataToParticularEnt(dr)).ToList();
        }

        private ParticularEnt BindDataToParticularEnt(DataRow dr)
        {
            return new ParticularEnt
            {
                ParticularID = (!string.IsNullOrEmpty(Convert.ToString(dr["ParticularID"]))) ? Convert.ToInt32(dr["ParticularID"]) : 0,
                ParticularName = (!string.IsNullOrEmpty(Convert.ToString(dr["ParticularName"]))) ? Convert.ToString(dr["ParticularName"]) : null,
                ParticularValueAsPerPolicy = (!string.IsNullOrEmpty(Convert.ToString(dr["Value"]))) ? Convert.ToString(dr["Value"]) : null,
                ParticularsAsPerSurvey = (!string.IsNullOrEmpty(Convert.ToString(dr["ParticularsAsPerSurvey"]))) ? Convert.ToString(dr["ParticularsAsPerSurvey"]) : null,
                IsParticularAsPerSurvey = (!string.IsNullOrEmpty(Convert.ToString(dr["IsParticularAsPerSurvey"]))) ? Convert.ToBoolean(dr["IsParticularAsPerSurvey"]) : false              

            };
        }
        public FinalSurveyEnt GetExistingSurveyDetails(string claimrefno)
        {

            CRUD oDAL = new CRUD();
            DataSet dsData = new DataSet();
            this.iErrorno = oDAL.Select(ProcedureConstants.GetExistingSurveyDetails, out dsData, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimrefno));
            return this.iErrorno == 0 ? (dsData.Tables[0].Rows.Count > 0 && dsData.Tables[0] != null ?
                   GetExistingSurveyDetails(dsData) : null) : null;

        }
        public FinalSurveyEnt GetFinalSurveyDetails(string claimrefno)
        {
            CRUD oDAL = new CRUD();
            DataSet dsData = new DataSet();
            this.iErrorno = oDAL.Select(ProcedureConstants.GetFinalSurveyDetails, out dsData, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimrefno));
            return this.iErrorno == 0 ? (dsData.Tables[0].Rows.Count > 0 && dsData.Tables[0] != null ?
                   GetExistingSurveyDetails(dsData) : null) : null;
        }


        public void SetFinalSurveyDetails(FinalSurveyEnt objFinalSurveyEnt)
        {
            CRUD oDAL = new CRUD();
            DataSet dsFinalSurveyData = new DataSet();

            DataTable dtParticularDetail = new DataTable();
            DataTable dtCommertialVehical = new DataTable();
            DataTable dtVehical = new DataTable();
            DataTable dtDriver = new DataTable();
            DataTable dtFinalSurvey = new DataTable();
            dtParticularDetail = objFinalSurveyEnt.ListParticular.ToDataTable<ParticularEnt>(TableTypeConstants.Particular_Details);
            dtVehical = objFinalSurveyEnt.Vehical.ToDataTable<VehicalEnt>(TableTypeConstants.Vehical_Details);
            dtDriver = objFinalSurveyEnt.Driver.ToDataTable<DriverEnt>(TableTypeConstants.Driver_Details);
            dtCommertialVehical = objFinalSurveyEnt.CommertialVehical.ToDataTable<CommertialVehicalEnt>(TableTypeConstants.Commertial_Vehical_Details);
            dtFinalSurvey = objFinalSurveyEnt.ToDataTable<FinalSurveyEnt>(TableTypeConstants.Final_Survey);

            dsFinalSurveyData.Tables.Add(dtParticularDetail);
            dsFinalSurveyData.Tables.Add(dtVehical);
            dsFinalSurveyData.Tables.Add(dtDriver);
            dsFinalSurveyData.Tables.Add(dtCommertialVehical);
            dsFinalSurveyData.Tables.Add(dtFinalSurvey);

            try
            {

                this.iErrorno = oDAL.Insert(ProcedureConstants.SetFinalSurveyDetails, dsFinalSurveyData);

                if (iErrorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }


        }
        private FinalSurveyEnt GetExistingSurveyDetails(DataSet dsData)
        {

            FinalSurveyEnt obj = new FinalSurveyEnt();
            if (dsData.Tables[2] != null && dsData.Tables[2].Rows.Count > 0)
                obj = dsData.Tables[2].Rows[0].ToEntity<FinalSurveyEnt>();
            obj.CommertialVehical = dsData.Tables[0] != null && dsData.Tables[0].Rows.Count > 0 ? GetCommertialVehical(dsData.Tables[0]) : null;
            obj.Driver = dsData.Tables[1] != null && dsData.Tables[1].Rows.Count > 0 ? GetDriverDetails(dsData.Tables[1]) : null; 
              //  GetFinalSurveyDetails(dsData, obj);
            if (dsData.Tables[3] != null && dsData.Tables[3].Rows.Count > 0)
                obj.Vehical = GetVehicalDetails(dsData.Tables[3]);

            return obj;

            //return
            //        new FinalSurveyEnt
            //        {
            //            CommertialVehical = dsData.Tables[0] != null && dsData.Tables[0].Rows.Count > 0 ? GetCommertialVehical(dsData.Tables[0]) : null,
            //            Driver = dsData.Tables[1] != null && dsData.Tables[1].Rows.Count > 0 ? GetDriverDetails(dsData.Tables[1]) : null,
            //            Vehical = dsData.Tables[4] != null && dsData.Tables[4].Rows.Count > 0 ? GetVehicalDetails(dsData.Tables[4]) : null
            //        };


        }

        private static void GetFinalSurveyDetails(DataSet dsData, FinalSurveyEnt obj)
        {
            obj.IsSkipDriversInfo = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToBoolean(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : false;
            obj.LossDescription = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["LoadChallanLoadPerKG"]))) ? Convert.ToString(dsData.Tables[3].Rows[0]["LoadChallanLoadPerKG"]) : null;
            obj.CauseOfLoss = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["LoadChallanLoadPerKG"]))) ? Convert.ToString(dsData.Tables[3].Rows[0]["LoadChallanLoadPerKG"]) : null;
            obj.NatureOfLoss = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["LoadChallanLoadPerKG"]))) ? Convert.ToString(dsData.Tables[3].Rows[0]["LoadChallanLoadPerKG"]) : null;
            obj.IsPassengerList = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToBoolean(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : false;
            obj.FIRNo = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToInt32(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : 0;
            obj.FIRDate = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToDateTime(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : DateTime.MinValue;
            obj.FIRDesciption = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : null;
            obj.ChargeSheetNo = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToInt32(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : 0;
            obj.ChargeSheetDate = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToDateTime(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : DateTime.MinValue;
            obj.ChargeSheetDesciption = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : null;
            obj.PanchNamaNo = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToInt32(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : 0;
            obj.PanchNamaDate = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToDateTime(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : DateTime.MinValue;
            obj.PanchNamaDesciption = (!string.IsNullOrEmpty(Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]))) ? Convert.ToString(dsData.Tables[3].Rows[0]["IsSkipDriversInfo"]) : null;
        }
        private CommertialVehicalEnt GetCommertialVehical(DataTable dtCV)
        {

            return new CommertialVehicalEnt
            {

                LoadChallanLoadPerKG = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["LoadChallanLoadPerKG"]))) ? Convert.ToString(dtCV.Rows[0]["LoadChallanLoadPerKG"]) : null,
                LoadChallanNo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["LoadChallanNo"]))) ? Convert.ToString(dtCV.Rows[0]["LoadChallanNo"]) : null,
                LoadChallanDate = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["LoadChallanDate"]))) ? Convert.ToDateTime(dtCV.Rows[0]["LoadChallanDate"]) : DateTime.MinValue,
                PermitType = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["PermitType"]))) ? Convert.ToString(dtCV.Rows[0]["PermitType"]) : null,
                RoutePermitNo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["RoutePermitNo"]))) ? Convert.ToString(dtCV.Rows[0]["RoutePermitNo"]) : null,
                RoutePeriodTo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["RoutePeriodTo"]))) ? Convert.ToDateTime(dtCV.Rows[0]["RoutePeriodTo"]) : DateTime.MinValue,
                RoutePeriodFrom = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["RoutePeriodFrom"]))) ? Convert.ToDateTime(dtCV.Rows[0]["RoutePeriodFrom"]) : DateTime.MinValue,
                AuthorizationNo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["AuthorizationNo"]))) ? Convert.ToInt32(dtCV.Rows[0]["AuthorizationNo"]) : 0,
                AuthorizationDateTo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["AuthorizationDateTo"]))) ? Convert.ToDateTime(dtCV.Rows[0]["AuthorizationDateTo"]) : DateTime.MinValue,
                AuthorizationDateFrom = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["AuthorizationDateFrom"]))) ? Convert.ToDateTime(dtCV.Rows[0]["AuthorizationDateFrom"]) : DateTime.MinValue,
                FitnessNo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["FitnessNo"]))) ? Convert.ToString(dtCV.Rows[0]["FitnessNo"]) : null,
                FitnessCertificateTo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["FitnessCertificateTo"]))) ? Convert.ToDateTime(dtCV.Rows[0]["FitnessCertificateTo"]) : DateTime.MinValue,
                FitnessCertificateFrom = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["FitnessCertificateFrom"]))) ? Convert.ToDateTime(dtCV.Rows[0]["FitnessCertificateFrom"]) : DateTime.MinValue,
                RoadTaxNo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["RoadTaxNo"]))) ? Convert.ToString(dtCV.Rows[0]["RoadTaxNo"]) : null,
                RoadTaxTo = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["RoadTaxTo"]))) ? Convert.ToDateTime(dtCV.Rows[0]["RoadTaxTo"]) : DateTime.MinValue,
                RoadTaxFrom = (!string.IsNullOrEmpty(Convert.ToString(dtCV.Rows[0]["RoadTaxFrom"]))) ? Convert.ToDateTime(dtCV.Rows[0]["RoadTaxFrom"]) : DateTime.MinValue

            };
        }
        private DriverEnt GetDriverDetails(DataTable dtDriver)
        {
            return new DriverEnt
            {
                DriverName = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["DriverName"]))) ? (Convert.ToString(dtDriver.Rows[0]["DriverName"])) : null,
                DriverRelationship = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["DriverRelationship"]))) ? (Convert.ToString(dtDriver.Rows[0]["DriverRelationship"])) : null,
                Gender = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["Gender"]))) ? (Convert.ToString(dtDriver.Rows[0]["Gender"])) : null,
                IsAlcohol = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["IsAlcohol"]))) ? (Convert.ToBoolean(dtDriver.Rows[0]["IsAlcohol"])) : false,
                Occupation = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["Occupation"]))) ? (Convert.ToString(dtDriver.Rows[0]["Occupation"])) : null,
                LicensingAuthority = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["LicensingAuthority"]))) ? (Convert.ToString(dtDriver.Rows[0]["LicensingAuthority"])) : null,
                TypeOfLicence = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["TypeOfLicence"]))) ? (Convert.ToString(dtDriver.Rows[0]["TypeOfLicence"])) : null,
                DateOfBirth = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["DateOfBirth"]))) ? (Convert.ToDateTime(dtDriver.Rows[0]["DateOfBirth"])) : DateTime.MinValue,
                DLExpiryDate = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["DLExpiryDate"]))) ? Convert.ToDateTime(dtDriver.Rows[0]["DLExpiryDate"]) : DateTime.MinValue,
                DLIssueDate = (!string.IsNullOrEmpty(Convert.ToString(dtDriver.Rows[0]["DLIssueDate"]))) ? Convert.ToDateTime(dtDriver.Rows[0]["DLIssueDate"]) : DateTime.MinValue
            };
        }
        private VehicalEnt GetVehicalDetails(DataTable dtVehical)
        {
            return new VehicalEnt
            {
                RegistrationDate = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["RegistrationDate"]))) ? Convert.ToDateTime(dtVehical.Rows[0]["RegistrationDate"]) : DateTime.MinValue,
                OdoMeterReading = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["OdoMeterReading"]))) ? Convert.ToString(dtVehical.Rows[0]["OdoMeterReading"]) : null,
                Color = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["Color"]))) ? Convert.ToString(dtVehical.Rows[0]["Color"]) : null,
                AverageReading = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["AverageReading"]))) ? Convert.ToString(dtVehical.Rows[0]["AverageReading"]) : null,
                TypeOfPaint = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["TypeOfPaint"]))) ? Convert.ToString(dtVehical.Rows[0]["TypeOfPaint"]) : null,
                IsParked = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["IsParked"]))) ? Convert.ToBoolean(dtVehical.Rows[0]["IsParked"]) : false,
                TypeOfEngine = (!string.IsNullOrEmpty(Convert.ToString(dtVehical.Rows[0]["TypeOfEngine"]))) ? Convert.ToString(dtVehical.Rows[0]["TypeOfEngine"]) : null,
            };
        }
    }
}
