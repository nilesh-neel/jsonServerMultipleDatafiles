﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Data;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Repository
{
    public class ReInspectionRepository
    {
        public int Status;
        int? Errorno;
        public void SetReInspectionDetails(ReinspectionEnt oReinspectionEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.Errorno = oDAL.Insert(ProcedureConstants.SetReinspectionDetails,
                                oDAL.CreateParameter("@ClaimRefNo", DbType.String, oReinspectionEnt.ClaimRefNo),
                                oDAL.CreateParameter("@IsReinsDone", DbType.Boolean, oReinspectionEnt.IsReinsDone),
                                oDAL.CreateParameter("@ReinsDate", DbType.DateTime, oReinspectionEnt.ReinsDate),
                                oDAL.CreateParameter("@ReinsTIme", DbType.DateTime, oReinspectionEnt.ReinsTIme),
                                oDAL.CreateParameter("@Remarks", DbType.String, oReinspectionEnt.Remarks),
                                oDAL.CreateParameter("@ReinDoneBy", DbType.String, oReinspectionEnt.ReinDoneBy),
                                oDAL.CreateParameter("@ContactNo", DbType.Int32, oReinspectionEnt.ContactNo),
                                oDAL.CreateParameter("@GarageAddress", DbType.String, oReinspectionEnt.GarageAddress),
                                oDAL.CreateParameter("@ReinsAddress", DbType.String, oReinspectionEnt.ReinsDoneOnAddress),
                                oDAL.CreateParameter("@DocID", DbType.Int32, oReinspectionEnt.DocID),
                                oDAL.CreateParameter("@CreatedBy", DbType.Int32, oReinspectionEnt.CreatedBy));
                if (Errorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }
        }
    }
}
