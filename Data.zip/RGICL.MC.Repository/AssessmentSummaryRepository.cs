﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class AssessmentSummaryRepository
    {
        int? iErrorno;
        public List<PartsEnt> GetPartSubPartDetail(string iClaimRefNo)
        {
            List<PartsEnt> lstparts = new List<PartsEnt>();
            CRUD oDAL = new CRUD();
            DataSet dsType = new DataSet();

            this.iErrorno = oDAL.Select(ProcedureConstants.GetPartSubPartDetail, out dsType
                , oDAL.CreateParameter("@ClaimRefNo", DbType.String, iClaimRefNo));

            if (this.iErrorno == 0)
            {
                lstparts = dsType.Tables[0].ToEntityList<PartsEnt>();
            }
            return lstparts;
        }
        public List<LookupEnt> GetPartType()
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetPartType, out dsType);
                return this.iErrorno == 0 ? (dsType.Tables[0].Rows.Count > 0 && dsType.Tables[0] != null ?
                   GetPartTypeDetails(dsType) : null) : null;


            }
            catch (Exception ex)
            {
                throw;
            }

        }
        private static List<LookupEnt> GetPartTypeDetails(DataSet dsManualSurveyorDetail)
        {
            return (from dr in dsManualSurveyorDetail.Tables[0].AsEnumerable() select BindDataToPartLookup(dr)).ToList();
        }
        private static LookupEnt BindDataToPartLookup(DataRow dr)
        {
            return new LookupEnt
            {
                LookupID = Convert.ToInt32(dr["LookUpId"]),
                LookupName = Convert.ToString(dr["LookUpName"])

            };
        }
        public List<PartAssesmentEnt> GetTaxOnPartDetail(string iClaimRefNo, int iGarageID, int iPartTypeID)
        {
            List<PartAssesmentEnt> lstTaxonParts = new List<PartAssesmentEnt>();
            CRUD oDAL = new CRUD();
            DataSet dsType = new DataSet();

            this.iErrorno = oDAL.Select(ProcedureConstants.GetTaxType, out dsType
                , oDAL.CreateParameter("@ClaimRefNo", DbType.String, iClaimRefNo),
                oDAL.CreateParameter("@GarageID", DbType.String, iGarageID),
                oDAL.CreateParameter("@PartType", DbType.String, iPartTypeID));

            return this.iErrorno == 0 ? (dsType.Tables[0].Rows.Count > 0 && dsType.Tables[0] != null ?
                   GetPartTypeTax(dsType) : null) : null;
            //if (this.iErrorno == 0)
            //{
            //    lstTaxonParts = dsType.Tables[0].ToEntityList<PartAssesmentEnt>();
            //}
            //return lstTaxonParts;
        }
        private static List<PartAssesmentEnt> GetPartTypeTax(DataSet dsManualSurveyorDetail)
        {
            return (from dr in dsManualSurveyorDetail.Tables[0].AsEnumerable() select BindDataToPartTypeTax(dr)).ToList();
        }
        private static PartAssesmentEnt BindDataToPartTypeTax(DataRow dr)
        {
            return new PartAssesmentEnt
            {
                TaxTypeID = Convert.ToInt32(dr["TaxTypeID"]),
                TaxType = Convert.ToString(dr["TaxTypeNAme"]),
                TaxRatePer = Convert.ToDecimal(dr["TaxTypeValue"]),

            };
        }




    }
}
