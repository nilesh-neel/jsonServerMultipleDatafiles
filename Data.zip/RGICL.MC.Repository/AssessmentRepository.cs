﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;
using RGICL.MC.Contracts.Entity;

namespace RGICL.MC.Repository
{

    public class AssessmentRepository
    {
        public int iErrorno;
        #region Buyers
        public List<BuyerEnt> GetBuyersList(string ClaimRefNo, string param1)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDocumentType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetBuyersDetails, out dsDocumentType,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));
                return this.iErrorno == 0 ? (dsDocumentType.Tables[0].Rows.Count > 0 && dsDocumentType.Tables[0] != null ?
                    GetBuyersDetailslst(dsDocumentType) : null) : null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        private List<BuyerEnt> GetBuyersDetailslst(DataSet dsDocumentType)
        {
            return (from dr in dsDocumentType.Tables[0].AsEnumerable()
                    select (new BuyerEnt
                    {
                        BuyersID = Convert.ToInt32(dr["BuyersID"]),
                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        CreatedBy = Convert.ToInt32(dr["CreatedBy"]),
                        AmountQuoted = Convert.ToDecimal(dr["AmountQuoted"]),
                        BuyerContactNo = Convert.ToString(dr["BuyerContactNumber"]),
                        BuyerName = Convert.ToString(dr["BuyersName"]),
                        Status = Convert.ToString(dr["Status"]),
                        Type = Convert.ToInt32(dr["Type"]),
                    })).ToList();
        } 
        #endregion

        #region TotalLoss
        public TotalLossEnt GetTotalLossList(string ClaimRefNo, string param1)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDocumentType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetTotalLossDetails, out dsDocumentType,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));
                return this.iErrorno == 0 ? (dsDocumentType.Tables[0].Rows.Count > 0 && dsDocumentType.Tables[0] != null ?
                    GetTotalLossDetailslst(dsDocumentType.Tables[0].Rows[0], ClaimRefNo) : null) : null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        private TotalLossEnt GetTotalLossDetailslst(DataRow dr, string ClaimRefNo)
        {

            var retval = new TotalLossEnt
           {
               Total_Loss_id = Convert.ToInt32(dr["Total_Loss_id"]),
               ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
               CreatedBy = Convert.ToInt32(dr["CreatedBy"]),
               FinalLiability = Convert.ToString(dr["FinalLiability"]),
               InsuredAgreedValue = Convert.ToString(dr["InsuredAgreedValue"]),
               InsuredDeclaredValue = Convert.ToString(dr["InsuredDeclaredValue"]),
               IsRCbookCancelled = Convert.ToBoolean(dr["IsRCbookCancelled"]),
               IsSalvageRealised = Convert.ToBoolean(dr["IsSalvageRealised"]),
               LiabilityonRepair = Convert.ToString(dr["LiabilityonRepair"]),
               NonStandardSettlement = Convert.ToString(dr["NonStandardSettlement"]),
               ReasonNonStandardClaim = Convert.ToString(dr["ReasonNonStandardClaim"]),
               SalvageAmount = Convert.ToString(dr["SalvageAmount"]),
               SalvageRealisedby = Convert.ToString(dr["SalvageRealisedby"]),
               SalvageRelPer = Convert.ToString(dr["SalvageRelPer"]),
               SalvageRelPerIDV = Convert.ToString(dr["SalvageRelPerIDV"]),
               YearofManufacturing = Convert.ToString(dr["YearofManufacturing"]),
               ParkingCharges = Convert.ToDecimal(dr["ParkingCharges"]),
               UploadRCcancellationDocument = Convert.ToString(dr["UploadRCcancellationDocument"]),

               BuyerEntlst = GetBuyersList(ClaimRefNo, "").Where(a => a.Type == 2 || a.Type == 0).ToList()

           };
            return retval;
        }
        public int InsertTotalLoss(TotalLossEnt oTotalLossEnt, List<BuyerEnt> oBuyerEntlst)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertTotalLoss,
                                        oDAL.CreateParameter("@ClaimRefNo", DbType.String, oTotalLossEnt.ClaimRefNo),
                                        oDAL.CreateParameter("@YearofManufacturing", DbType.String, oTotalLossEnt.YearofManufacturing),
                                        oDAL.CreateParameter("@LiabilityonRepair", DbType.String, oTotalLossEnt.LiabilityonRepair),
                                        oDAL.CreateParameter("@ReasonNonStandardClaim", DbType.String, oTotalLossEnt.ReasonNonStandardClaim),
                                        oDAL.CreateParameter("@IsSalvageRealised", DbType.String, oTotalLossEnt.IsSalvageRealised),
                                        oDAL.CreateParameter("@InsuredDeclaredValue", DbType.String, oTotalLossEnt.InsuredDeclaredValue),
                                        oDAL.CreateParameter("@NonStandardSettlement", DbType.String, oTotalLossEnt.NonStandardSettlement),
                                        oDAL.CreateParameter("@InsuredAgreedValue", DbType.String, oTotalLossEnt.InsuredAgreedValue),
                                        oDAL.CreateParameter("@SalvageRealisedby", DbType.String, oTotalLossEnt.SalvageRealisedby),
                                        oDAL.CreateParameter("@IsRCbookCancelled", DbType.String, oTotalLossEnt.IsRCbookCancelled),
                                        oDAL.CreateParameter("@SalvageAmount", DbType.String, oTotalLossEnt.SalvageAmount),
                                        oDAL.CreateParameter("@FinalLiability", DbType.String, oTotalLossEnt.FinalLiability),
                                        oDAL.CreateParameter("@SalvageRelPer", DbType.String, oTotalLossEnt.SalvageRelPer),
                                        oDAL.CreateParameter("@SalvageRelPerIDV", DbType.String, oTotalLossEnt.SalvageRelPerIDV),
                                        oDAL.CreateParameter("@CreatedBy", DbType.String, oTotalLossEnt.CreatedBy),
                                        oDAL.CreateParameter("@ParkingCharges", DbType.String, oTotalLossEnt.ParkingCharges),
                                        oDAL.CreateParameter("@UploadRCcancellationDocument", DbType.String, oTotalLossEnt.UploadRCcancellationDocument));

                if (oBuyerEntlst != null && oBuyerEntlst.Count > 0)
                {
                    DataTable dtoBuyerEntEnt = null;
                    dtoBuyerEntEnt = oBuyerEntlst.ToDataTable<BuyerEnt>(TableTypeConstants.Buyers);
                    this.iErrorno = oDAL.Insert(ProcedureConstants.InsertBuyersList, dtoBuyerEntEnt);
                }
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        } 
        #endregion


        #region NetOFsalvage
        public NetOfSalvageEnt GetNetOfSalvageList(string ClaimRefNo, string param1)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDocumentType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetNetOfSalvage, out dsDocumentType,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));
                return this.iErrorno == 0 ? (dsDocumentType.Tables[0].Rows.Count > 0 && dsDocumentType.Tables[0] != null ?
                    GetNetOfSalvageDetailslst(dsDocumentType.Tables[0].Rows[0], ClaimRefNo) : null) : null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        private NetOfSalvageEnt GetNetOfSalvageDetailslst(DataRow dr, string ClaimRefNo)
        {

            var retval = new NetOfSalvageEnt
            {
                NetOfSalvageID = Convert.ToInt32(dr["NetOfSalvageID"]),
                ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                CreatedBy = Convert.ToInt32(dr["CreatedBy"]),
                FinalLiability = Convert.ToString(dr["FinalLiability"]),
                InsuredAgreedValue = Convert.ToString(dr["InsuredAgreedValue"]),
                InsuredDeclaredValue = Convert.ToString(dr["InsuredDeclaredValue"]),
                IsRCbookCancelled = Convert.ToBoolean(dr["IsRCbookCancelled"]),
                IsSalvageRealised = Convert.ToBoolean(dr["IsSalvageRealised"]),
                LiabilityonRepair = Convert.ToString(dr["LiabilityonRepair"]),
                NonStandardSettlement = Convert.ToString(dr["NonStandardSettlement"]),
                ReasonNonStandardClaim = Convert.ToString(dr["ReasonNonStandardClaim"]),
                SalvageAmount = Convert.ToString(dr["SalvageAmount"]),
                SalvageRealisedby = Convert.ToString(dr["SalvageRealisedby"]),
                SalvageRelPer = Convert.ToString(dr["SalvageRelPer"]),
                SalvageRelPerIDV = Convert.ToString(dr["SalvageRelPerIDV"]),
                YearofManufacturing = Convert.ToString(dr["YearofManufacturing"]),
                ParkingCharges = Convert.ToDecimal(dr["ParkingCharges"]),
                UploadRCcancellationDocument = Convert.ToString(dr["UploadRCcancellationDocument"]),

                BuyerEntlst = GetBuyersList(ClaimRefNo, "").Where(a => a.Type == 2 || a.Type == 0).ToList()

            };
            return retval;
        }
        public int InsertNetOfSalvage(NetOfSalvageEnt oNetOfSalvageEnt, List<BuyerEnt> oBuyerEntlst)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.iErrorno = oDAL.Insert(ProcedureConstants.InsertNetOfSalvage,
                                        oDAL.CreateParameter("@ClaimRefNo", DbType.String, oNetOfSalvageEnt.ClaimRefNo),
                                        oDAL.CreateParameter("@YearofManufacturing", DbType.String, oNetOfSalvageEnt.YearofManufacturing),
                                        oDAL.CreateParameter("@LiabilityonRepair", DbType.String, oNetOfSalvageEnt.LiabilityonRepair),
                                        oDAL.CreateParameter("@ReasonNonStandardClaim", DbType.String, oNetOfSalvageEnt.ReasonNonStandardClaim),
                                        oDAL.CreateParameter("@IsSalvageRealised", DbType.String, oNetOfSalvageEnt.IsSalvageRealised),
                                        oDAL.CreateParameter("@InsuredDeclaredValue", DbType.String, oNetOfSalvageEnt.InsuredDeclaredValue),
                                        oDAL.CreateParameter("@NonStandardSettlement", DbType.String, oNetOfSalvageEnt.NonStandardSettlement),
                                        oDAL.CreateParameter("@InsuredAgreedValue", DbType.String, oNetOfSalvageEnt.InsuredAgreedValue),
                                        oDAL.CreateParameter("@SalvageRealisedby", DbType.String, oNetOfSalvageEnt.SalvageRealisedby),
                                        oDAL.CreateParameter("@IsRCbookCancelled", DbType.String, oNetOfSalvageEnt.IsRCbookCancelled),
                                        oDAL.CreateParameter("@SalvageAmount", DbType.String, oNetOfSalvageEnt.SalvageAmount),
                                        oDAL.CreateParameter("@FinalLiability", DbType.String, oNetOfSalvageEnt.FinalLiability),
                                        oDAL.CreateParameter("@SalvageRelPer", DbType.String, oNetOfSalvageEnt.SalvageRelPer),
                                        oDAL.CreateParameter("@SalvageRelPerIDV", DbType.String, oNetOfSalvageEnt.SalvageRelPerIDV),
                                        oDAL.CreateParameter("@CreatedBy", DbType.String, oNetOfSalvageEnt.CreatedBy),
                                        oDAL.CreateParameter("@ParkingCharges", DbType.String, oNetOfSalvageEnt.ParkingCharges),
                                        oDAL.CreateParameter("@UploadRCcancellationDocument", DbType.String, oNetOfSalvageEnt.UploadRCcancellationDocument));

                if (oBuyerEntlst != null && oBuyerEntlst.Count > 0)
                {
                    DataTable dtoBuyerEntEnt = null;
                    dtoBuyerEntEnt = oBuyerEntlst.ToDataTable<BuyerEnt>(TableTypeConstants.Buyers);
                    this.iErrorno = oDAL.Insert(ProcedureConstants.InsertBuyersList, dtoBuyerEntEnt);
                }
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        }
        #endregion
    }
}
