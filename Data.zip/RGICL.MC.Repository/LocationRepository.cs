﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;

namespace RGICL.MC.Repository
{
    public class LocationRepository
    {
        static int? ErrorCode = 0;

        public List<LocationEnt> GetLocationFromCity(int cityId)
        {
            List<LocationEnt> lstLocation = null;
            LocationEnt objLoc = null;

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsLocation = new DataSet();
                ErrorCode = oDAL.Select(ProcedureConstants.GetLocationFromCity, out dsLocation, oDAL.CreateParameter("CityId", DbType.Int32, cityId));
                if (ErrorCode == 0)
                {
                    if (dsLocation.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsLocation.Tables[0].Rows)
                        {
                            objLoc = new LocationEnt();
                            objLoc.LocationId = Convert.ToInt32(dr["LocationID"]);
                            objLoc.LocationName = Convert.ToString(dr["LocationName"]);

                            if (lstLocation == null)
                                lstLocation = new List<LocationEnt>();
                            lstLocation.Add(objLoc);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return lstLocation;
        }
    }
}
