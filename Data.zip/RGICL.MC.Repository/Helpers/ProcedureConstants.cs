﻿/****************************************************************************************************************
Class Name   : ProcedureConstants.cs 
Purpose      : Used to define constants for all procedures/steps name for Manager classes.
Created By   : Ravi Kant Shivhare
Created Date : 26/Sep/2013
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion

namespace RGICL.MC.Repository.Helpers
{
    public static class ProcedureConstants
    {
        /// <summary>
        /// Purpose: 
        /// Output Parameters:
        ///     1. 
        /// Input Parameters:
        ///     1. 
        ///     2. 
        /// </summary>
        /// 

        #region "UserManagement"

        public const string SelectUserLoginInfo = "USP_GetUserLoginInfo";
        public const string SelectUserList = "USP_SearchUsers";
        public const string SetUserIPAddress = "USP_SetUserIPAddress";
        public const string GetAccessType = "USP_GetAccessType";
        public const string GetAuthorizedPages = "USP_GetAuthorizedPages";
        public const string GetUserRole = "USP_GetUserRole";
        public const string GetUserDetailsById = "USP_SearchUser_Details";
        public const string SaveUserDetails = "USP_InsertUserDetails";
        public const string SaveZoneHubTeams = "USP_InsertZoneHubMapping";
        public const string SaveUserProductCateMapp = "USP_InsertProductCategoryMapping";
        public const string SaveUserHubLocationMapp = "USP_InsertHubLocationMapping";
        public const string SaveUserLocationGarageMapp = "USP_InsertLocationGarageMapping";
        public const string SaveUserMackerChecker = "USP_InsertMackerChecker";

        #endregion
        public const string SelectEmployeeDetails = "USP_SELECT_EMP_DETAILS";
       
        public const string CheckUserExist = "USP_CheckUserExist";
        public const string SelectLookupType = "USP_GetLookupTypes";
        public const string GetDBErrorLogDetails = "USP_GetDBErrorLog";
       

        public const string GetLookupTypes = "USP_GetLookupTypes";
        public const string GetLookupDetailsById = "USP_GetLookupDetailsById";
        public const string InsertLookupDetails = "USP_InsertLookupDetails";

        public const string IsECSClaim = "USP_IsECSClaim";
        public const string IsExistingCase = "USP_IsExistingCase";
      

        public const string GetLookupsDetail = "USP_GetLookups";
        public const string GetUserDetails = "USP_GetUserDetails";

        public const string SendCommunication = "USP_SendCommunication";
        public const string SendCommunicationForClaim = "USP_SendCommunicationForClaim";
        public const string SendCommunicationForMaster = "USP_SendCommunicationForMaster";
        public const string SendCommunicationEmail = "USP_SendCommunicationEmail";
        public const string SendCommunicationSMS = "USP_SendCommunicationSMS";
        #region surveyor
        public const string GetUserCategory = "USP_GetUserCategory";
        public const string GetLicenceNumber = "USP_GetLicenceNo";
        public const string GetSurveyor = "USP_GetSurveyor";
        public const string GetSurveyorCategory = "Usp_GetSurveyorCategory";
        public const string GetAllHub = "USP_GetAllHUb";
        public const string GetClaimGarageName = "USP_GetClaimGarageName";
        public const string SetManualSurveyorDetails = "Usp_InsertSurveyorDetail";
        public const string GetManualSurveyorDetails = "USP_GetManualSurveyorDetails";
        public const string UpdateSyrveyorAppointmentStatus = "USP_UpdateSurveyorAppointment";



        #endregion surveyor
        #region Spotsurveyor
        public const string SetSpotSurveyDetails = "USP_InsSpotSurvey";


        #endregion Spotsurveyor

        public const string GetParticularsAsPerPOlicy = "USP_GetParticularDetails";
        public const string GetExistingSurveyDetails = "USP_GetExistingDetails";
        public const string SetFinalSurveyDetails = "USP_InsertFinalDetails";
        public const string GetFinalSurveyDetails = "USp_GetFinalSurveyDetails";

        public const string GetUserMenu = "USP_GetUserMenu";
        public const string SearchEmployee = "USP_GetEmployeeMOMData";
        public const string GetMakerChecker = "USP_GetMakerChecker";

        # region Region Master

        public const string GetLocationFromState = "USP_GetLocationFromState";
        //public const string GetAllStates = "USP_GetAllStates";
        //public const string GetCityFromState = "USP_GetCityFromState";
        //public const string GetDistrictFromState = "USP_GetDistrictFromState";
        //public const string GetCityFromDistrict = "USP_GetCityFromDistrict";
        public const string GetAllStateDistrictCity = "USP_GetAllStateDistrictCity";
        public const string GetLocationFromCity = "USP_GetLocationFromCity";

        #endregion Region Master
        #region Region Service Request
        public const string InsertDocumentlist = "USP_InsertDocumentlist";
        public const string DeleteDocument = "USP_DeleteDocument";

        public const string InsertAssignCOClaimToCM = "USP_InsertAssignCOClaimToCM";
        public const string InsertTransferCOClaimtoHub = "USP_InsertTransferCOClaimtoHub";
        public const string GetAllUserListOfHub = "USP_GetAllUserListOfHub";
        public const string InsertAcquireOCClaim = "USP_InsertAcquireOCClaim";
        public const string GetCVMDetails = "USP_GetCVMDetails";
        public const string InsertCVMDetails = "USP_InsertCVMDetails";

        public const string GetClaimFromRefNo = "USP_GetClaimFromRefNo";
        public const string InsertClosureDetails = "USP_InsertClosureDetails";
        public const string InsertRecoveryDetails = "USP_InsertRecoveryDetails";
        public const string InsertReOpenDetails = "USP_InsertReOpenDetails";
        public const string GetClosureLetterDetails = "USP_GetClosureLetterDetails";
        public const string GetCheckApprovalRights = "USP_GetCheckApprovalRights";
        public const string GetReOpenDetails = "USP_GetReOpenDetails";
        public const string GetRecoveryDetails = "USP_GetRecoveryDetails";
        public const string GetStopPaymentDetails = "USP_GetStopPaymentDetails";
        public const string GetPaymentDetails = "USP_GetPaymentDetails";
        public const string InsertStopPaymentRQDetails = "USP_InsertStopPaymentRQDetails";
        public const string CheckAccountclearanceStatus = "USP_CheckAccountclearanceStatus";
        public const string InsertReIssueDetails = "USP_InsertReIssueDetails";
        public const string GetReIssueDetails = "USP_GetReIssueDetails";
        public const string InsertSRApproval = "USP_InsertSRApproval";

        #endregion

        public const string GetProductMakeModel = "USP_GetProductMakeModel";
        public const string GetDetailsForICE = "USP_GetDetailsForICE";
        public const string UpdateDetailsForICE = "USP_UpdateDetailsForICE";
        public const string GenerateTableData = "USP_GenerateTableData";
        public const string InsertEmailDetails = "USP_InsertEmailDetails";
        public const string GetEmailTemplate = "USP_GetEmailTemplate";

        public const string GetProductCategoryAndProductList = "USP_GetProducts";
        public const string UpdateUserLockedDetails = "USP_UpdateUserLockedDetails";

        public const string SetReinspectionDetails = "USP_InsertReinspectionDetails";
        public const string GetDocumentType = "GetDocumentDetails";
        public const string GetAssesmentDocument = "GetAssesmentDocumentDetails";
        public const string GetUplodedDocumentlist = "USP_GetUplodedDocumentlist";

        public const string GetOrphanCommonClaimDetails = "USP_GetOrphanCommonClaimDetails";
        
        public const string GetAllGarage = "USP_GetAllGarage";
        public const string GetBlazeInputParameters = "USP_GetBlazeInputParameters";
        public const string InsertBlazeScoreCardDetails = "USP_InsertBlazeScoreCardDetails";
        public const string GetTehnicalApprovalList = "USP_GetTehnicalApprovalList";
        public const string GetAuditTrailDetails = "USP_GetAuditTrail";
        public const string GetRemarksHistory = "USP_GetRemarksHistory";
        public const string InsetUpdateWorkFlowDetails = "USP_InsetUpdateWorkFlowDetails";
        public const string InsetWorkFlowDetailsAudit = "USP_InsetWorkFlowDetails_audit";
        public const string InsetClaimApprovalMatrix = "USP_InsetClaimApprovalMatrix";
        public const string InsetSavvionServiceErrorLog = "USP_InsetSavvionServiceErrorLog";
        public const string ProcessClaim = "USP_ProcessClaim";

        public const string GetClaimDetailsFromClaimId = "USP_GetClaimDetailsFromClaimId";
        public const string GetClaimDetails = "USP_GetClaimDetails";
        public const string GetInboxDetailsFor_CM_HM_ZM_CO_VH_CEO = "USP_GetInboxDetailsFor_CM_HM_ZM_CO_VH_CEO";

        public const string GetFinancialApprovalList = "USP_GetFinancialApprovalList";
        public const string GetCIInputParamsForSavvion = "USP_GetCIInputParamsForSavvion";
        public const string IsExistingCMSClaim = "USP_IsExistingCMSClaim";

        public const string GetInboxDetailsForBSM = "USP_GetInboxDetailsForBSM";
        public const string GetInboxDetailsForRAM = "USP_GetInboxDetailsForRAM";
        public const string GetInboxDetailsForRCU = "USP_GetInboxDetailsForRCU";
        public const string GetInboxDetailsForSurveyor = "USP_GetInboxDetailsForSurveyor";
        public const string GetInboxDetailsForCVM = "USP_GetInboxDetailsForCVM";

        public const string GetControlPanelDetails = "USP_GetControlPanelDetails";
        public const string GetGarageWiseTaxDetails = "USP_GetGarageWiseTaxDetails";

        public const string GetDashboardCountForCM = "USP_GetDashboardDetailsFor_CM_HM_ZM_CO_VH_CEO";
        public const string GetDashboardCountForSurveyor = "USP_GetDashboardDetailsForSurveyor";
        public const string GetInsuredDetails = "USP_GetInsuredDetails";
        public const string InsertInsuredDetails = "USP_InsertInsuredDetails";
        public const string GetMappedGarage = "USP_GetMappedGarage";
        public const string InsertGarageForClaim = "USP_InsertGarageForClaim";
        public const string UpdateISDDetails = "USP_UpdateISDDetails";
        public const string GetISDDetails = "USP_GetISDDetails";
        public const string GetCIDataForISD = "USP_GetCIDataForISD";
        public const string UpdateClaimStatus = "USP_UpdateClaimStatus";

        #region Assesment
        public const string InsertTotalLoss = "USP_InsertTotalLoss";
        public const string InsertNetOfSalvage = "USP_InsertNetOfSalvage";

        public const string InsertBuyersList = "USP_InsertBuyersList";
        public const string UpdateGarageClaimMappingDetails = "USP_UpdateGarageClaimMappingDetails";
        public const string GetPartSubPartDetail = "USP_GetPartSubPartDetail";
        public const string GetTaxType = "Usp_GetTaxType";
        public const string GetPartType = "Usp_GetPartType";
        public const string GetPolicyDetails = "USP_GetPolicyDetails";
        public const string GetNetOfSalvage = "USP_GetNetOfSalvage";

        public const string GetTotalLossDetails = "USP_GetTotalLossDetails";
        public const string GetBuyersDetails = "USP_GetBuyersDetails";
        public const string UpdateCoverageDetails = "USP_UpdateCoverageDetails";
        public const string UpdateCustNEFTDetails = "USP_UpdateCustNEFTDetails";
        public const string GetNEFTDetailsForClaim = "USP_GetNEFTDetailsForClaim";
        #endregion

        #region "MobileService"
        public const string LogMobileServiceResponse = "USP_InsertMobileServiceResponse";
        public const string GetAllMasterData = "USP_GetAllMaster";
        public const string AuthenticateMobileUser = "USP_AuthenticateMobileUser";

        public const string GetPartMasterData = "USP_GetPartMasterData";
        public const string GetLocationMasterData = "USP_GetLocationMasterData";

        #endregion

    }


}



