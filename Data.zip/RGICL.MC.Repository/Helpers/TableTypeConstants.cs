﻿/****************************************************************************************************************
Class Name   : TableTypeConstants.cs 
Purpose      : Used to define list of all the 'Table Type' with their corresponding columns name defined in DB.
Created By   : Ravi Kant Shivhar
Created Date : 24/Jan/2014
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion

using System.Collections.Generic;
namespace RGICL.MC.Repository.Helpers
{
    public static class TableTypeConstants
    {
        #region Public Variables

        #region Claim Intimation
        public static List<string> CI_Claim_Details_Columns = new List<string> { "ClaimRefNo", "PolicyNo", "IntimaterName", "IntimaterAddress", "IntimaterPhoneNo", 
                                                                      "IntimaterMobileNo", "CoverNote", "Lob",  "MakeID", "ModelID", "VehicleNo", "IntimatedBy", 
                                                                      "YearOfMFG", "CallerIsNotGarage", "VehicleNotInGarage", "PolicyNotFromDealer","CreatedBy", 
                                                                       "UpdatedBy","ProductId", "CaseNo" };

        public static List<string> CI_Insured_Details_Columns = new List<string> { "InsuredID", "ClaimRefNo", "AddressCategory", "InsuredName", "AddressLine1", 
                                                                       "AddressLine2", "InsuredState", "InsuredCity", "InsuredPinCode","InsuredPhoneNumber", "InsuredMobileNumber", "EmailId", 
                                                                       "CreatedBy","UpdatedBy" };

        public static List<string> CI_Driver_Details_Columns = new List<string> { "DriverID", "DriverName", "Age", "DLExpiryDate", 
                                                                        "LicensingAuthority", "LicenseNumber","CreatedBy", "UpdatedBy", "VehicleAuthorizedToDrive" };

        public static List<string> CI_Loss_Details_Columns = new List<string> { "LossID", "ClaimRefNo", "DateOfLoss", "HourOfLoss", "MinOfLoss", 
                                                                        "ReasonForDelayInIntimation", "PrimaryTypeOfLoss", "IsInjury", "IsSpotSurvey", "SecondaryTypeOfLoss", 
                                                                        "VehicleType", "CurrentVehicleLocation", "LossEvent", "NatureOfLoss", "DescriptionOfLoss", 
                                                                        "EstimatedLoss", "RelevantInformation", "LocationOfLoss", "State_ID_PK", "City_or_Village_ID_PK", 
                                                                        "IsTerrorism", "IsGroupCompanyClaim", "CreatedBy", "UpdatedBy" , "LocationOfSpot",
                                                                        "NearestLandmarkForSpot", "SpotContactPersonName", "SpotContactPersonNumber" };

        public static List<string> CI_Victim_Details_Columns = new List<string> { "VictimName", "VictimCategoryId", "NatureOfInjuryId", "CreatedBy" };

        public static List<string> CI_Garage_Details_Columns = new List<string> { "GarageID", "GarageName", "Address", "GarageStatusId", "GaragePinCode", "CreatedBy" };
        public static List<string> CI_Garage_City_Columns = new List<string> { "CityId" };
        public static List<string> CI_Garage_State_Columns = new List<string> { "StateId" };
        public static List<string> CI_Garage_Make_Columns = new List<string> { "MakeId" };

        public static List<string> CI_Policy_Details_Columns = new List<string> {"PolicyNo","CoverNote","ProductCode",
                                                                        "PolicyIssuingOffice","VehicleNo","YearOfMFG","MakeId",
                                                                        "ModelId","PolicyStartDate","PolicyEndDate","EngineNo","ChasisNo","IsActive", "SumInsured","CreatedBy" };

        public static List<string> CI_Output_Fields = new List<string> { "ClaimRefNo", "DocumentName" };

        public static List<string> CIOCClaim = new List<string> {
"ClaimRefNo",
	"IsOrphan" ,
	"IsCommon"   ,
	"CMID"   ,
	"NatureOfLossID"  ,
	"HubId"  ,
    "UpdatedBy"
        };




        public static List<string> Buyers = new List<string> {
"ClaimRefNo",
	"BuyerName" ,
	"BuyerContactNo"   ,
	"AmountQuoted"   ,
	"Status"  ,
	"CreatedBy",
    "Type" 
   
        };








        public static List<string> DocumentEnt = new List<string> { 
        
         "DocID", 
         "ClaimRefNo", 
         "CreatedBy",  
         "UpdatedBy", 
         "IsExternal",  
         "NoOfDocument", 
         "RecievedDate",  
         "UploadDate"  
        };
        public static List<string> FileEnt = new List<string> { 
         "DocID", 
         "ClaimRefNo", 
          "FileName",
          "Type"
        };
        #endregion Claim Intimation

        public static List<string> Manual_Survey_Apoointment = new List<string>
        {
            "ClaimSurveyorMapID",
            "ClaimRefNo"
      ,"PolicyNo"
      ,"GarageID"
      ,"SurveyorType"
      ,"HubID"
      ,"SurveyorID"
      ,"TypeOfSurvey"
      ,"ReasonForExtSurveyor"    
      ,"ApprovedBy"
      ,"Category"
      ,"Status"
      ,"DateOfAppointment"
      ,"LicenseNo"
      ,"Remarks"
      ,"IsActive"
      ,"CreatedBy"      
      ,"UpdatedBy"    
        };

        public static List<string> Vehical_Details = new List<string>
        {
           "VehicleID",
           "ClaimRefNo",
           "PolicyNo",
           "RegistrationDate",
            "Color",
            "TypeOfPaint",
            "TypeOfEngine",
            "EngineFuelType",
            "AverageReading",
            "IsParked",
            "OdoMeterReading",
            "CreatedBy"
        };
        public static List<string> Driver_Details = new List<string>
        {  
       "ClaimRefNo",
       "DriverName",          
       "Age",      
       "Gender",
       "DriverRelationship", 
       "DLIssueDate",        
       "DLExpiryDate",
       "LicensingAuthority",  
       "DateOfBirth",   
       "IsAlcohol",
       "TypeOfLicence",
       "Occupation",
       "CreatedBy"   
        };

        public static List<string> Final_Survey = new List<string>
        {
   "ClaimRefNo",        
"IsSkipDriversInfo",
"CauseofLoss",
"LossDescription",
"NatureOfLoss",
"IsPassengerList",
"FIRNo",
"FIRDate",
"FIRDesciption",
"PanchNamaNo",
"PanchNamaDate",
"PanchNamaDesciption",
"ChargeSheetNo",
"ChargeSheetDate",
"ChargeSheetDesciption",
"CreatedBy"
        };
        public static List<string> Particular_Details = new List<string>
        {           
"ParticularID",
"ParticularsAsPerSurvey",
"IsParticularAsPerSurvey",
"Remarks",
"CreatedBy"
        };
        public static List<string> Commertial_Vehical_Details = new List<string>
        {
            "CommercialVehicalID" ,
	"LoadChallanLoadPerKG" ,
	"LoadChallanNo" ,
	"LoadChallanDate" ,
	"RoutePermitNo" ,
	"PermitType" ,
	"RoutePeriodTo" ,
	"RoutePeriodFrom" ,
	"CreatedBy" ,
	"UpdatedBy" ,
	"AuthorizationNo" ,
	"AuthorizationDateTo" ,
	"AuthorizationDateFrom" ,
	"FitnessNo" ,
	"FitnessCertificateTo" ,
	"FitnessCertificateFrom" ,
	"RoadTaxNo" ,
	"RoadTaxTo",
	"RoadTaxFrom" 
        };
        #endregion

        #region GarageClaimMapping
        public static List<string> GarageClaimMapping = new List<string>
            {
            "ClaimRefNo","GarageID","ServiceTaxApplicable","ServiceTaxNumber","ApplyExcess","CompulsoryExcess",
            "VoluntaryExcess","AdditionalExcess","WCTonPaintApplicable","WCTonLabourApplicable","VATOnPaintApplicable","CreatedBy"
            };
        #endregion

        #region GarageClaimTaxMapping
        public static List<string> GarageClaimTaxMapping = new List<string>
            {
            "ID","TAXType","TAXCategory","Value","ClaimGarageMapID","IsActive","CreatedBy"
            };
        #endregion

        public static List<string> InitialSurveyDetails = new List<string>
        {"InitialSurveyID" ,"ClaimRefNo" ,"VehicleReportedToGarage" ,"SurveyDate"  ,"EstimatedLoss" ,"TentativeRepairDate" 
           ,"ImpacttOfLoss" ,"CatastrophicEventOfLoss" ,"NegativeCustomer" ,"Remark" ,"CreatedBy"   ,"UpdatedBy", "SettlementType", "LossEventID"
        };

        public static List<string> ReserveDetails = new List<string>
        {"ClaimRefNo" ,"ReserveId" ,"ReserveAmount" ,"ReserveType"  ,"ReserveEventId" ,"CreatedBy"   ,"UpdatedBy"
        };

        public static List<string> NEFTDetails = new List<string>
        {"CustId", "ClaimRefNo","AccountHolderName","CustAccNo","ConfirmAccNo","ISFCCode","MICR","BankName","BranchName","StateId","CityId","CancelledChequeNo","CreatedBy","UpdatedBy"
        };
    }

    
}
