﻿/****************************************************************************************************************
Class Name   : CommonConstants.cs 
Purpose      : Used to define constants for common constants for Repository.
Created By   : Ravi Kant Shivhare
Created Date : 20/Jan/2014
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion

using System.Collections.Generic;
namespace RGICL.MC.Repository.Helpers
{
    public static class CommonConstants
    {
        #region Public Variables
        public const string EmployeeDetailsXML = "EmployeeDetails.xml";
        public const string Role_ICE = "CCE";        
        #endregion
    }
}
