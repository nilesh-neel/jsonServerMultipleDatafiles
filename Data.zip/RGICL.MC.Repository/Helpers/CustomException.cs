using System;
using System.Web;
using System.IO;
using System.Net;

namespace RGICL.MC.Repository.Helpers
{
    public class CustomException : Exception
    {
        private CustomExceptionConstants.ErrorCode enmErrCode;
        private CustomExceptionConstants.ExceptionType enmExType;
        private string sMessage;

        public CustomException()
        {

        }
        public CustomException(string sErrMessage)
            : base(sErrMessage)
        {
          //  enmExType = CustomExceptionConstants.ExceptionType.Internal;
        }

        public CustomException(CustomExceptionConstants.ErrorCode oErrCode)
        {
            enmErrCode = oErrCode;
            enmExType = CustomExceptionConstants.ExceptionType.Internal;
        }

        public CustomException(Exception ex)
        {
            enmExType = CustomExceptionConstants.ExceptionType.System;
        }
        public override string Message
        {
            get
            {
                return base.Message;
            }
        }

        public string GetErrorMessage()
        {
            string sErrMsg="";
            switch (enmErrCode)
            { 
                case CustomExceptionConstants.ErrorCode.AccessDenied:
                    break;
                case CustomExceptionConstants.ErrorCode.ConnectionFailed:
                    sErrMsg = "DB.Connection.Failed";
                    break;
                case CustomExceptionConstants.ErrorCode.NoData:
                    break;
                case CustomExceptionConstants.ErrorCode.ServerDown:
                    sErrMsg = "Server not responding";
                    break;
                case CustomExceptionConstants.ErrorCode.FileUploadProblem:
                    sErrMsg = "File upload problem please try again";
                    break;
                case CustomExceptionConstants.ErrorCode.FileWrongFormat:
                    sErrMsg = "File format is not correct";
                    break;
                case CustomExceptionConstants.ErrorCode.LoginRequired:
                    sErrMsg = "Please Login!";
                    break;
                default: 
                    sErrMsg = base.Message;
                    break;
            }

            return sErrMsg;
        
        }
        public void DisplayCustomMessage(string sMethodName)
        {
            string sPath = HttpContext.Current.Server.MapPath("~");
            FileInfo oLogFile = new FileInfo(sPath + @"\logs\Log.txt");
         
            StreamWriter oSW = oLogFile.AppendText();
            string oIPHostName = Dns.GetHostName();
            IPHostEntry oIPHostEntry = Dns.GetHostEntry(oIPHostName);
            IPAddress[] oIPAddress = oIPHostEntry.AddressList;
            try
            {
                oSW.WriteLine("<LogData>");
                oSW.WriteLine("<LogDateAndTime>" + DateTime.UtcNow + "</LogDateAndTime>");
                oSW.WriteLine("<LogURL>" + " " + "</LogURL>");
                oSW.WriteLine("<LogType>" + this.enmExType + "</LogExceptionType>");
                oSW.WriteLine("<LogMassage>" + this.Message + "</LogExceptionMassage>");
                oSW.WriteLine("<LogMethod>" + sMethodName + "</LogExceptionMethod>");
                oSW.WriteLine("<LogUserName>" + "Ravi" + "</LogUserName>");

                for (int i = 0; i < oIPAddress.Length; i++)
                {
                    oSW.WriteLine("<LogUserMachineID>" + oIPAddress[i].ToString() + "</LogUserMachineID>");
                }
                oSW.WriteLine("</LogData>");
                oSW.WriteLine("-----------------------------------------------------------------------------");
                oSW.Close();
            }
            catch
            { 
          
            }
        }

        #region CustomExceptionConstants

        public class CustomExceptionConstants
        {
            public enum ErrorCode
            {
                ConnectionFailed = 1,
                NoData,
                AccessDenied,
                ServerDown,
                SiteMaintenance,
                UnderConstuction,
                FileUploadProblem,
                FileWrongFormat,
                LoginRequired,
                Other
            }
            public enum ExceptionType
            {
                Internal = 1,//manual
                System
            }
        }
        #endregion
    }
}
