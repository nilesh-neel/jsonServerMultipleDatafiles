﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.RestService.Entity.JsonEnt;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;
using System.Xml.Linq;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class GetAllMasterRepository
    {
        int _iErrorno;
        public JsonMasterData GetMasterData()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetAllMasterData, out dsUser);

                return this._iErrorno == 0 ? (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null ?
                    BindXmlToJsonMasterDataEnt(dsUser) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        private JsonMasterData BindXmlToJsonMasterDataEnt(DataSet dsProdCat)
        {
            var xmlDoc = Convert.ToString(dsProdCat.Tables[0].Rows[0][0]);
            XDocument doc = XDocument.Parse(xmlDoc);
            var oMasterData = (JsonMasterData)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(JsonMasterData));
            return oMasterData;
        }

        public JsonPartMasterData GetPartMasterData()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetPartMasterData, out dsUser);

                if (_iErrorno == 0 && (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null))
                {
                    var xmlDoc = Convert.ToString(dsUser.Tables[0].Rows[0][0]);
                    XDocument doc = XDocument.Parse(xmlDoc);
                    return (JsonPartMasterData)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(JsonPartMasterData));
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public JsonPartMasterData GetLocationMasterData()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetLocationMasterData, out dsUser);

                if (_iErrorno == 0 && (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null))
                {
                    var xmlDoc = Convert.ToString(dsUser.Tables[0].Rows[0][0]);
                    XDocument doc = XDocument.Parse(xmlDoc);
                    return (JsonPartMasterData)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(JsonPartMasterData));
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<JsonStateEnt> GetStateMaster()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetLocationMasterData, out dsUser,
                                            oDal.CreateParameter("@P_FLAGE", DbType.String, "STATE"));

                if (_iErrorno == 0 && (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null))
                {
                    var xmlDoc = Convert.ToString(dsUser.Tables[0].Rows[0][0]);
                    XDocument doc = XDocument.Parse(xmlDoc);
                    return (List<JsonStateEnt>)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(List<JsonStateEnt>));
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }

        }

        public List<JsonDistrictEnt> GetDistrictMaster()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetLocationMasterData, out dsUser,
                                            oDal.CreateParameter("@P_FLAGE", DbType.String, "DISTRICT"));

                if (_iErrorno == 0 && (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null))
                {
                    var xmlDoc = Convert.ToString(dsUser.Tables[0].Rows[0][0]);
                    XDocument doc = XDocument.Parse(xmlDoc);
                    return (List<JsonDistrictEnt>)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(List<JsonDistrictEnt>));
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }

        }

        public List<JsonCityEnt> GetCityMaster()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetLocationMasterData, out dsUser,
                                            oDal.CreateParameter("@P_FLAGE", DbType.String, "CITY"));

                if (_iErrorno == 0 && (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null))
                {
                    var xmlDoc = Convert.ToString(dsUser.Tables[0].Rows[0][0]);
                    XDocument doc = XDocument.Parse(xmlDoc);
                    return (List<JsonCityEnt>)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(List<JsonCityEnt>));
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }

        }

        public List<JsonLocationEnt> GetLocationMaster()
        {
            try
            {
                CRUD oDal = new CRUD();
                DataSet dsUser;

                this._iErrorno = oDal.Select(ProcedureConstants.GetLocationMasterData, out dsUser,
                                            oDal.CreateParameter("@P_FLAGE", DbType.String, "LOCATION"));

                if (_iErrorno == 0 && (dsUser.Tables[0].Rows.Count > 0 && dsUser.Tables[0] != null))
                {
                    var xmlDoc = Convert.ToString(dsUser.Tables[0].Rows[0][0]);
                    XDocument doc = XDocument.Parse(xmlDoc);
                    return (List<JsonLocationEnt>)ObjectXmlUtility.DeSerializeObject(xmlDoc, typeof(List<JsonLocationEnt>));
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }

        }

    }
}
