﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Data;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class DocumentDetailRepository
    {
        public int Status;
        int iErrorno = 0;
        public List<SurveyorEnt> GetDocumentType()
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDocumentType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetDocumentType, out dsDocumentType);
                return this.iErrorno == 0 ? (dsDocumentType.Tables[0].Rows.Count > 0 && dsDocumentType.Tables[0] != null ?
                    GetDocumentDetails(dsDocumentType) : null) : null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        private List<SurveyorEnt> GetDocumentDetails(DataSet dsDocumentType)
        {
            return (from dr in dsDocumentType.Tables[0].AsEnumerable() select BindDataToDocumentEnt(dr)).ToList();
        }
        private SurveyorEnt BindDataToDocumentEnt(DataRow dr)
        {
            return new SurveyorEnt
            {
                DocID = Convert.ToInt32(dr["DocID"]),
                DocumentDescription = Convert.ToString(dr["DocDescription"]),
                ClaimRefNo = Convert.ToString(dr["ClaimRefNo"])
            };
        }

        public int InsertDocumentDetails(List<DocumentEnt> objDocumentEnt, List<FileEnt> objFileEnt)
        {

            CRUD oDAL = new CRUD();
            DataSet dsDoc = new DataSet();
            DataTable dtDocEnt = null;
            DataTable dtFileEnt = null;

            dtDocEnt = objDocumentEnt.ToDataTable<DocumentEnt>(TableTypeConstants.DocumentEnt);
            dtFileEnt = objFileEnt.ToDataTable<FileEnt>(TableTypeConstants.FileEnt);
            dsDoc.Tables.Add(dtDocEnt);
            dsDoc.Tables.Add(dtFileEnt);
            try
            {
                string Proc = objFileEnt[0].RQTYPE == 1 ? ProcedureConstants.DeleteDocument : ProcedureConstants.InsertDocumentlist;
                this.iErrorno = oDAL.Insert(Proc, dsDoc);
            }
            catch (Exception ex)
            {
                throw;

            }
            return iErrorno;
        }


        public List<DocumentEnt> GetUplodedDocumentlst(string ClaimRefNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDocumentType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetUplodedDocumentlist, out dsDocumentType,
                    oDAL.CreateParameter("@ClaimRefNo", DbType.String, ClaimRefNo));
                return this.iErrorno == 0 ? (dsDocumentType.Tables[0].Rows.Count > 0 && dsDocumentType.Tables[0] != null ?
                    GetUplodedDocumentDetailslst(dsDocumentType) : null) : null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }







        private List<DocumentEnt> GetUplodedDocumentDetailslst(DataSet dsDocumentType)
        {
            return (from dr in dsDocumentType.Tables[0].AsEnumerable()
                    select (new DocumentEnt
                    {
                        DocID = Convert.ToInt32(dr["DocID"]),
                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        CreatedBy = Convert.ToInt32(dr["CreatedBy"]),
                        UpdatedBy = Convert.ToInt32(dr["UpdatedBy"]),
                        IsExternal = Convert.ToBoolean(dr["IsExternal"]),
                        NoOfDocument = Convert.ToInt32(dr["NoOfDocument"]),
                        RecievedDate = Convert.ToDateTime(dr["RecievedDate"]),
                        UploadDate = Convert.ToDateTime(dr["UploadDate"]),
                        DocDescription = Convert.ToString(dr["DocDescription"]),
                        SubCategoryID = Convert.ToInt32(dr["SubCategoryID"]),
                        DocumentTypeName = Convert.ToString(dr["DocumentTypeName"]),
                        FileName = dsDocumentType.Tables[1] != null && dsDocumentType.Tables[1].Rows.Count > 0 ? GetFilelst(dsDocumentType.Tables[1]) : null,
                    })).ToList();
        }

        private List<FileEnt> GetFilelst(DataTable dtFile)
        {

            return (from dr in dtFile.AsEnumerable()
                    select (new FileEnt
                    {
                        DocID = Convert.ToInt32(dr["DocID"]),
                        ClaimRefNo = Convert.ToString(dr["ClaimRefNo"]),
                        FileName = Convert.ToString(dr["FileName"]),
                        Type = Convert.ToInt16(dr["Type"]),
                        DocumentTypeName = Convert.ToString(dr["DocumentTypeName"])

                    })).ToList();
        }

        public List<DocumentEnt> GetAssesmentDocument(string Type)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDocumentType = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetAssesmentDocument, out dsDocumentType);
                return this.iErrorno == 0 ? (dsDocumentType.Tables[0].Rows.Count > 0 && dsDocumentType.Tables[0] != null ?
                    GetAssesmentDocumentDetails(dsDocumentType, Type).Where(a => a.SubCategoryID == Convert.ToInt16(Type)).ToList() : null) : null;

            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        private List<DocumentEnt> GetAssesmentDocumentDetails(DataSet dsDocumentType, string Type)
        {
            return (from dr in dsDocumentType.Tables[0].AsEnumerable() select BindDataToAssDocumentEnt(dr)).ToList();
        }
        private DocumentEnt BindDataToAssDocumentEnt(DataRow dr)
        {
            return new DocumentEnt
            {
                DocID = Convert.ToInt32(dr["DocID"]),
                DocDescription = Convert.ToString(dr["DocDescription"]),
                SubCategoryID = Convert.ToInt32(dr["SubCategoryID"]),
                IsExternal = true,
                RecievedDate = System.DateTime.Now,
                UploadDate = System.DateTime.Now
            };
        }






    }

}
