﻿using System.Collections.Generic;
using RGICL.MC.Contracts.Entity;
using System.Data;
using System;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;


namespace RGICL.MC.Repository
{
    public class LookupRepository
    {
        public int Status;
        int? Errorno;

        public List<LookupEnt> GetLookupType()
        {
            LookupEnt oLookupDetailsEnt = null;
            List<LookupEnt> lstLookup = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.Errorno = oDAL.Select(ProcedureConstants.GetLookupTypes, out dsType);

                if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookup == null)
                                lstLookup = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpTypeID"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpTypeName"]);
                            lstLookup.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
                
            }

            return lstLookup;
        }
        public void SetLookupDetails(LookupEnt oLookupDetailsEnt)
        {
            try
            {
                CRUD oDAL = new CRUD();

                this.Errorno = oDAL.Insert(ProcedureConstants.InsertLookupDetails,
                                oDAL.CreateParameter("@LookUpName", DbType.String, oLookupDetailsEnt.LookupName),
                                oDAL.CreateParameter("@LookUpTypeId", DbType.Int32, oLookupDetailsEnt.LookupTypeID),
                                oDAL.CreateParameter("@IsActive", DbType.Boolean, oLookupDetailsEnt.IsActive),
                                oDAL.CreateParameter("@CreatedBy", DbType.String, "261866"));
                if (Errorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw ;
                
            }
        }
        public List<LookupEnt> GetLookupDetailsById(int iLookupTypeID)  
        {
          LookupEnt oLookupDetailsEnt=null;
            List<LookupEnt> lstLookupDetails = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.Errorno = oDAL.Select(ProcedureConstants.GetLookupDetailsById, out dsType,
                    oDAL.CreateParameter("@LookUpTypeId", DbType.Int32, iLookupTypeID ));

                if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookupDetails == null)
                                lstLookupDetails = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.LookupName = Convert.ToString(dr["LookUpName"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpTypeName"]);
                            oLookupDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookupTypeID"]);
                            oLookupDetailsEnt.LookupID = Convert.ToInt32(dr["LookupID"]);
                            oLookupDetailsEnt.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            lstLookupDetails.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
                
            }
            return lstLookupDetails;
        }

        public List<LookupEnt> GetLookups()
        {

            LookupEnt oLookupsDetailsEnt = null;
            List<LookupEnt> lstLookups = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsType = new DataSet();

                this.Errorno = oDAL.Select(ProcedureConstants.GetLookupsDetail, out dsType);

                if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookups == null)
                                lstLookups = new List<LookupEnt>();
                            oLookupsDetailsEnt = new LookupEnt();
                            oLookupsDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpTypeID"]);
                            oLookupsDetailsEnt.LookupID = Convert.ToInt32(dr["LookUpID"]);
                            oLookupsDetailsEnt.LookupName = Convert.ToString(dr["LookUpName"]);
                            lstLookups.Add(oLookupsDetailsEnt);                    
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;

            }

            return lstLookups;
        }
    }
}
