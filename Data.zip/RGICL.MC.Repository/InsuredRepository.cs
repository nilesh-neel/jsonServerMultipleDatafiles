﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.Common.Utilities;
namespace RGICL.MC.Repository
{
    public class InsuredRepository
    {
        public int iErrorno;

        public InsuredEnt GetNEFTDetails(string claimRefNo)
        {
            InsuredEnt objIS = null;

            DataSet ds = new DataSet();
            CRUD oDAL = new CRUD();
            try
            {
                iErrorno = oDAL.Select(ProcedureConstants.GetNEFTDetailsForClaim, out ds, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo));
                if (iErrorno == 0 && ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count>0)
                        objIS = ds.Tables[0].Rows[0].ToEntity<InsuredEnt>();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
            return objIS;
        }

        public InsuredEnt UpdateNEFTDetails(InsuredEnt objInsured)
        {
            InsuredEnt oInsured = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataTable dt = null;
                DataSet ds = new DataSet();
                DataSet dsResult = new DataSet();

                dt = objInsured.ToDataTable<InsuredEnt>(TableTypeConstants.NEFTDetails);
                ds.Tables.Add(dt);

                iErrorno = oDAL.Insert(ProcedureConstants.UpdateCustNEFTDetails, out dsResult, ds);
                if (iErrorno == 0)
                {
                    if (dsResult.Tables.Count > 0)
                        oInsured = dsResult.Tables[0].Rows[0].ToEntity<InsuredEnt>();
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return oInsured;
        }
    }
}
