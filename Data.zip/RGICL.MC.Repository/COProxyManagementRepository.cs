﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Data;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class COProxyManagementRepository
    {
        int iErrorno;
        public int InsertAcquireOCClaim(List<COClaimEnt> objCOClaimEnt)
        {

            CRUD oDAL = new CRUD();
            DataSet dsManualSurvey = new DataSet();
            DataTable dtobjCOClaimEnt = null;
            dtobjCOClaimEnt = objCOClaimEnt.ToDataTable<COClaimEnt>(TableTypeConstants.CIOCClaim);
            dsManualSurvey.Tables.Add(dtobjCOClaimEnt);
            try
            {
                string proc = "";
                CRUD objDAL = new CRUD();
                if (((int)objCOClaimEnt[0].eREQUESTTYPE) == 0)
                    proc = ProcedureConstants.InsertAcquireOCClaim;
                if (((int)objCOClaimEnt[0].eREQUESTTYPE) == 1)
                    proc = ProcedureConstants.InsertAssignCOClaimToCM;
                if (((int)objCOClaimEnt[0].eREQUESTTYPE) == 2)
                    proc = ProcedureConstants.InsertTransferCOClaimtoHub;


                this.iErrorno = objDAL.Insert(proc, dsManualSurvey);
            }
            catch (Exception ex)
            {
                throw;

            }
            return iErrorno;
        }

        private List<COUserEnt> GetCOUserEntList(DataSet dsCOUserEnt)
        {
            List<COUserEnt> ReCOUserEntlst = dsCOUserEnt.Tables[0].ToEntityList<COUserEnt>();
            return ReCOUserEntlst;
        }

        public List<COUserEnt> GetCOUserEntDetails(string ClaimRefNo, string UserID)
        {

            try
            {
                CRUD oDAL = new CRUD();

                DataSet dsCOUserEnt = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetAllUserListOfHub, out dsCOUserEnt);


                return this.iErrorno == 0 ? (dsCOUserEnt.Tables != null &&
                        dsCOUserEnt.Tables[0].Rows.Count > 0 ? GetCOUserEntList(dsCOUserEnt) : null
                        ) : null;

            }
            catch (Exception ex)
            {
                throw;

            }
        }

    }
}
