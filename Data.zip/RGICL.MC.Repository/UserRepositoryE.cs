﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;

namespace RGICL.MC.Repository
{
    public class UserRepositoryE
    {
        int iErrorno;
        IAuthenticate oLDAP = null;
        public List<UserInformationEnt> GetuserList(string strLoginId)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsSample = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.SelectUserLoginInfo, out dsSample,
                                    oDAL.CreateParameter("@LoginID", DbType.String, strLoginId)
                                    );
                return this.iErrorno == 0 ? GetUsers(dsSample) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }


        public UserInformationEnt GetUserInfo(string strLoginID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsSample = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.SelectUserLoginInfo, out dsSample,
                                    oDAL.CreateParameter("@LoginID", DbType.String, strLoginID)
                                    );
                return this.iErrorno == 0 ? (dsSample.Tables[0].Rows.Count > 0 && dsSample.Tables[0] != null ?
                    BindDataToUserEnt(dsSample.Tables[0].Rows[0]) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }
        public List<UserAuthorizationEnt> GetAuthorizationPages(string strLoginID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsPages = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetAuthorizedPages, out dsPages, oDAL.CreateParameter("@P_LoginID", DbType.String, strLoginID));
                return this.iErrorno == 0 ? GetAuthPagesList(dsPages) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        private List<UserAuthorizationEnt> GetAuthPagesList(DataSet dsData)
        {
            return (from dr in dsData.Tables[0].AsEnumerable()
                    select (new UserAuthorizationEnt
                              {
                                  PageID = Convert.ToString(dr["PageID"]),
                                  PageURL = Convert.ToString(dr["PageURL"])

                              })).ToList();
        }

        public UserInformationEnt ValidateSession(string strLoginID, string strSessionID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();
                int Errorno = oDAL.Select(ProcedureConstants.SelectUserLoginInfo, out dsUserInfo,
                                  oDAL.CreateParameter("@LoginID", DbType.String, strLoginID)
                                  );
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                      BindDataToUserEnt(dsUserInfo.Tables[0].Rows[0]) : null) : null;
            }
            catch (Exception ex)
            { throw; }


        }

        public List<UserRole> GetUserRole(string strLoginID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserRoles = new DataSet();
                this.iErrorno = oDAL.Select(ProcedureConstants.GetUserRole, out dsUserRoles, oDAL.CreateParameter("@LoginID", DbType.String, strLoginID));
                return this.iErrorno == 0 ? GetUserRoles(dsUserRoles) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public UserInformationEnt GetUserLoginInfo(string strLoginID)
        {
            try
            {
                UserInformationEnt objUserInfo = GetUserInfo(strLoginID);
                return objUserInfo;
            }
            catch (Exception ex)
            { throw; }

        }

        private List<UserInformationEnt> GetUsers(DataSet dsData)
        {
            return (from dr in dsData.Tables[0].AsEnumerable() select BindDataToUserEnt(dr)).ToList();
        }

        private UserInformationEnt BindDataToUserEnt(DataRow dr)
        {
            return new UserInformationEnt
                {
                    UserID = Convert.ToString(dr["UserID"]),
                    LoginID = Convert.ToString(dr["LoginID"]),
                    //Password = Convert.ToString(dr["Password"]),
                    DisplayName = Convert.ToString(dr["DisplayName"]),
                    EmailID = Convert.ToString(dr["EmailID"]),
                    ContactNumber = Convert.ToString(dr["ContactNumber"]),
                    MobileNumber = Convert.ToString(dr["MobileNumber"]),
                    UserType = Convert.ToChar(dr["UserType"]),
                    SAPCode = Convert.ToString(dr["SAPCode"]),
                    LevelID = Convert.ToInt32(dr["LevelID"]),
                    LastLoginDate = Convert.ToDateTime(dr["LastLoginDate"] ?? DateTime.Now),
                    IPAddress = Convert.ToString(dr["IPAddress"]),
                    SessionID = Convert.ToString(dr["SessionID"]),
                    IsMultiLogin = Convert.ToBoolean(dr["IsMultiLogin"]),
                    IsActive = Convert.ToBoolean(dr["IsActive"]),
                    MaxInActiveDays = Convert.ToInt32(dr["MaxInActiveDays"])
                };
        }

        private List<UserRole> GetUserRoles(DataSet dsdata)
        {
            return (from dr in dsdata.Tables[0].AsEnumerable() select BindDataToRoleEnt(dr)).ToList();
        }

        private UserRole BindDataToRoleEnt(DataRow dr)
        {
            return new UserRole
                {
                    RoleId = Convert.ToInt32(dr["RoleID"]),
                    RoleName = Convert.ToString(dr["RoleName"]),
                    RoleDescription = Convert.ToString(dr["RoleName"])
                };
        }

        public UserInformationEnt GetUserDetails(string strUserID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsSample = new DataSet();
                UserInformationEnt objUserInformationEnt = new UserInformationEnt();

                this.iErrorno = oDAL.Select(ProcedureConstants.GetUserDetails, out dsSample,
                                    oDAL.CreateParameter("@UserIDs", DbType.String, strUserID)
                  
                                    );

                return this.iErrorno == 0 ? (dsSample.Tables[0].Rows.Count > 0 && dsSample.Tables[0] != null ?
                   BindDataToUserEnt(dsSample.Tables[0].Rows[0]) : null) : null;
              
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

    }

    public class UserRole
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
    }
}
