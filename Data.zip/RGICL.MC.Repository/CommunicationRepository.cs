﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Web.Security;
using System.Web;
using RGICL.MC.Common.Utilities;
using System.Xml.Linq;
namespace RGICL.MC.Repository
{
    public class CommunicationRepository
    {
        public int iErrorno;
        public int SendCommunication(string sEventCode, string sClaimRefNo)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Insert(ProcedureConstants.SendCommunicationForClaim,
                                        oDAL.CreateParameter("@P_EventCode", DbType.String, sEventCode),
                                        oDAL.CreateParameter("@P_ClaimRefNo", DbType.String, sClaimRefNo),
                                        oDAL.CreateParameter("@P_SenderUserID", DbType.Int32, CommonUtility.LoggedInUserID)
                                    );
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        }
        public int SendCommunication(string sEventCode, int iUserID, string sPassword)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();
                if (!string.IsNullOrEmpty(sPassword))
                {
                    this.iErrorno = oDAL.Insert(ProcedureConstants.SendCommunication,
                                        oDAL.CreateParameter("@P_EventCode", DbType.String, sEventCode),
                                        oDAL.CreateParameter("@P_No", DbType.String, iUserID.ToString()),
                                        oDAL.CreateParameter("@P_SenderUserID", DbType.Int32, Convert.ToInt32(string.IsNullOrEmpty(CommonUtility.LoggedInUserID) ? "0" : Convert.ToString(CommonUtility.LoggedInUserID))),
                                        oDAL.CreateParameter("@P_Password", DbType.String, sPassword)
                                    );
                }
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        }
        public int SendCommunication(string sEventCode, int iMasterID)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();
                this.iErrorno = oDAL.Insert(ProcedureConstants.SendCommunicationForMaster,
                                        oDAL.CreateParameter("@P_EventCode", DbType.String, sEventCode),
                                        oDAL.CreateParameter("@P_MasterID", DbType.Int32, iMasterID),
                                        oDAL.CreateParameter("@P_SenderUserID", DbType.Int32, CommonUtility.LoggedInUserID)
                                    );
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        }

        public int SendCommunication(EmailEnt oEmail)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Insert(ProcedureConstants.SendCommunicationEmail,
                                        oDAL.CreateParameter("@P_ClaimRefNo", DbType.String, oEmail.ClaimRefNo),
                                        oDAL.CreateParameter("@P_EmailFrom", DbType.String, oEmail.EmailFrom),
                                        oDAL.CreateParameter("@P_EmailTo", DbType.String, oEmail.EmailTo),
                                        oDAL.CreateParameter("@P_EmailCC", DbType.String, oEmail.EmailCC),
                                        oDAL.CreateParameter("@P_EmailSubject", DbType.String, oEmail.EmailSubject),
                                        oDAL.CreateParameter("@P_EmailMessage", DbType.String, oEmail.EmailMessage),
                                        oDAL.CreateParameter("@P_EmailAttachmentFileName", DbType.String, oEmail.EmailAttachmentFileName),
                                        oDAL.CreateParameter("@P_SenderUserID", DbType.Int32, CommonUtility.LoggedInUserID)
                                    );
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        }
        public int SendCommunication(SMSEnt oSMS)
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Insert(ProcedureConstants.SendCommunicationSMS,
                                        oDAL.CreateParameter("@P_ClaimRefNo", DbType.String, oSMS.ClaimRefNo),
                                        oDAL.CreateParameter("@P_SMSFrom", DbType.String, oSMS.SMSFrom),
                                        oDAL.CreateParameter("@P_SMSTo", DbType.String, oSMS.SMSTo),
                                        oDAL.CreateParameter("@P_SMSMessage", DbType.String, oSMS.SMSMessage),
                                        oDAL.CreateParameter("@P_SenderUserID", DbType.Int32, CommonUtility.LoggedInUserID)
                                    );
                //this.iErrorno = 0;
                return this.iErrorno;
            }
            catch (Exception ex)
            {
                LogUtility.WriteExceptionLog(ex, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return 0;
        }
    }
}
