﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Data;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class SpotSurveyRepository
    {
        public int Status;
        int? Errorno;
        public void SetSpotSurveyDetail(SpotSurveyEnt objSpotSurvey, CommertialVehicalEnt objCommVehical)
        {
            DataSet dsSpotSurveyDetails = new DataSet();
           // DataSet dsCommVehicalDetails = new DataSet();

            DataTable dtSpotSurveyDetails = new DataTable();
            DataTable dtCommVehicalDetails = new DataTable();

            dtSpotSurveyDetails = objSpotSurvey.ToDataTable<SpotSurveyEnt>();
            dtCommVehicalDetails =objCommVehical.ToDataTable<CommertialVehicalEnt>();

            dsSpotSurveyDetails.Tables.Add(dtSpotSurveyDetails);
            dsSpotSurveyDetails.Tables.Add(dtCommVehicalDetails);
            try
            {
                CRUD oDAL = new CRUD();

                this.Errorno = oDAL.Insert(ProcedureConstants.SetSpotSurveyDetails, dsSpotSurveyDetails);

                if (Errorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }
        }
    }
}
