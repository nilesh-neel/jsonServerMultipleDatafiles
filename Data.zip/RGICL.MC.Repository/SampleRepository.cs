﻿using System;
using System.Data;
using RGICL.MC.Repository.Helpers;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.Contracts;

namespace RGICL.MC.Repository
{
    public class SampleRepository : SampleEnt
    {
        int Errorno;

        #region Public Functions
        public SampleEnt GetEmpDetails()
        {
            SampleEnt oSampleDO = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsSample = new DataSet();

                this.Errorno = oDAL.Select(ProcedureConstants.SelectEmployeeDetails, out dsSample,
                                    oDAL.CreateParameter("P_EmpId", DbType.String, this.EmpId),
                                    oDAL.CreateParameter("P_IsActive", DbType.Boolean, this.IsActive)
                                    );


                if (this.Errorno == 0)
                {
                    oSampleDO = new SampleEnt();
                    if (dsSample.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow drSample in dsSample.Tables[0].Rows)
                        {
                            oSampleDO.EmpId = Convert.ToInt32(drSample["Emp_Id"]);
                            oSampleDO.EmpName = Convert.ToString(drSample["Emp_Name"]);
                            oSampleDO.IsActive = Convert.ToString(drSample["Is_Active"]) == "Y" ? true : false;
                            oSampleDO.Description = Convert.ToString(drSample["Emp_Desc"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                //ex.DisplayCustomMessage("");
            }
            return oSampleDO;
        }
        #endregion
    }
}
