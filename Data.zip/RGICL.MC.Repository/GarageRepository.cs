﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Repository.Helpers;
using System.Web.Security;
using System.Web;
using RGICL.MC.Common.Utilities;

namespace RGICL.MC.Repository
{
    public class GarageRepository
    {
        static int? ErrorCode = 0;
        public int iErrorno;

        public List<GarageEnt> GetAllGarage()
        {
            List<GarageEnt> lstGarage = null;
            GarageEnt objGarage = null;

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsGarage = new DataSet();
                ErrorCode = oDAL.Select(ProcedureConstants.GetAllGarage, out dsGarage);
                if (ErrorCode == 0)
                {
                    if (dsGarage.Tables[0].Rows.Count > 0)
                    {
                        //lstGarage = new List<GarageEnt>();
                        //lstGarage = dsGarage.Tables[0].ToEntityList<GarageEnt>();
                        foreach (DataRow dr in dsGarage.Tables[0].Rows)
                        {
                            objGarage = new GarageEnt();

                            objGarage.GarageID = Convert.ToInt32(dr["GarageID"]);
                            objGarage.GarageName = Convert.ToString(dr["GarageName"]);
                            objGarage.Address = Convert.ToString(dr["Address"]);
                            objGarage.GarageFullName = Convert.ToString(dr["GarageFullName"]);                            
                            objGarage.NetworkScore = (!string.IsNullOrEmpty(Convert.ToString(dr["NetworkScore"]))) ? Convert.ToInt32(dr["NetworkScore"]) : 0;

                            objGarage.GarageStatusId = Convert.ToInt32(dr["GarageStatusId"]);
                            objGarage.GarageStatus = Convert.ToString(dr["GarageStatus"]);
                            objGarage.GarageTypeId = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageTypeId"]))) ? Convert.ToInt32(dr["NetworkScore"]) : 0; ;
                            objGarage.GarageTypeName = Convert.ToString(dr["GarageType"]);
                            objGarage.GaragePinCode = Convert.ToString(dr["PinCode"]);
                            objGarage.ContactPerson = Convert.ToString(dr["ContactPerson"]);
                            objGarage.ContactNo= Convert.ToString(dr["ContactNo"]);

                            //objGarage.GarageStatus = new LookupEnt { LookupID = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageStatusId"])) ? Convert.ToInt32(dr["GarageStatusId"]) : 0), LookupName = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageStatus"])) ? Convert.ToString(dr["Make_Name"]) : "") } ;
                            //objGarage.GarageType = new LookupEnt { LookupID = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageTypeId"])) ? Convert.ToInt32(dr["GarageTypeId"]) : 0), LookupName = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageType"])) ? Convert.ToString(dr["GarageType"]) : "") } ;
                            objGarage.City = new CityEnt { CityId = Convert.ToInt32(dr["CityId"]), CityName = Convert.ToString(dr["CityName"]) };
                            objGarage.District = new DistrictEnt { DistrictId = Convert.ToInt32(dr["DistrictId"]), DistrictName = Convert.ToString(dr["District_Name"]) };
                            objGarage.State = new StateEnt { StateId = Convert.ToInt32(dr["StateId"]), StateName = Convert.ToString(dr["State_Name"]) };
                            objGarage.Location = new LocationEnt { LocationId = (!string.IsNullOrEmpty(Convert.ToString(dr["LocationID"])) ? Convert.ToInt32(dr["LocationID"]) : 0), LocationName = (Convert.ToString(dr["LocationName"])) };
                            objGarage.Make = new MakeEnt { MakeId = (!string.IsNullOrEmpty(Convert.ToString(dr["MakeId"])) ? Convert.ToInt32(dr["MakeId"]) : 0), MakeName = (!string.IsNullOrEmpty(Convert.ToString(dr["Make_Name"])) ? Convert.ToString(dr["Make_Name"]) : "") };
                            objGarage.UserInfo = new UserInformationEnt { UserID = (!string.IsNullOrEmpty(Convert.ToString(dr["UserId"])) ? Convert.ToString(dr["UserId"]) : "") };

                            if (lstGarage == null)
                                lstGarage = new List<GarageEnt>();
                            lstGarage.Add(objGarage);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return lstGarage;
        }

        public List<GarageEnt> GetMappedGarage(string claimRefNo)
        {
            List<GarageEnt> lstGarage = null;
            GarageEnt objGarage = null;

            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsGarage = new DataSet();
                ErrorCode = oDAL.Select(ProcedureConstants.GetMappedGarage, out dsGarage, oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo));
                if (ErrorCode == 0)
                {
                    if (dsGarage.Tables[0].Rows.Count > 0)
                    {                        
                        foreach (DataRow dr in dsGarage.Tables[0].Rows)
                        {
                            objGarage = new GarageEnt();

                            objGarage.GarageID = Convert.ToInt32(dr["GarageID"]);
                            objGarage.GarageName = Convert.ToString(dr["GarageName"]);
                            objGarage.Address = Convert.ToString(dr["Address"]);
                            objGarage.GarageFullName = Convert.ToString(dr["GarageFullName"]);
                            objGarage.NetworkScore = (!string.IsNullOrEmpty(Convert.ToString(dr["NetworkScore"]))) ? Convert.ToInt32(dr["NetworkScore"]) : 0;

                            objGarage.GarageStatusId = Convert.ToInt32(dr["GarageStatusId"]);
                            objGarage.GarageStatus = Convert.ToString(dr["GarageStatus"]);
                            objGarage.GarageTypeId = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageTypeId"]))) ? Convert.ToInt32(dr["NetworkScore"]) : 0; ;
                            objGarage.GarageTypeName = Convert.ToString(dr["GarageType"]);
                            objGarage.GaragePinCode = Convert.ToString(dr["PinCode"]);
                            objGarage.ContactPerson = Convert.ToString(dr["ContactPerson"]);
                            objGarage.ContactNo = Convert.ToString(dr["ContactNo"]);

                            //objGarage.GarageStatus = new LookupEnt { LookupID = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageStatusId"])) ? Convert.ToInt32(dr["GarageStatusId"]) : 0), LookupName = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageStatus"])) ? Convert.ToString(dr["Make_Name"]) : "") } ;
                            //objGarage.GarageType = new LookupEnt { LookupID = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageTypeId"])) ? Convert.ToInt32(dr["GarageTypeId"]) : 0), LookupName = (!string.IsNullOrEmpty(Convert.ToString(dr["GarageType"])) ? Convert.ToString(dr["GarageType"]) : "") } ;
                            objGarage.City = new CityEnt { CityId = Convert.ToInt32(dr["CityId"]), CityName = Convert.ToString(dr["CityName"]) };
                            objGarage.District = new DistrictEnt { DistrictId = Convert.ToInt32(dr["DistrictId"]), DistrictName = Convert.ToString(dr["District_Name"]) };
                            objGarage.State = new StateEnt { StateId = Convert.ToInt32(dr["StateId"]), StateName = Convert.ToString(dr["State_Name"]) };
                            objGarage.Location = new LocationEnt { LocationId = (!string.IsNullOrEmpty(Convert.ToString(dr["LocationID"])) ? Convert.ToInt32(dr["LocationID"]) : 0), LocationName = (Convert.ToString(dr["LocationName"])) };
                            objGarage.Make = new MakeEnt { MakeId = (!string.IsNullOrEmpty(Convert.ToString(dr["MakeId"])) ? Convert.ToInt32(dr["MakeId"]) : 0), MakeName = (!string.IsNullOrEmpty(Convert.ToString(dr["Make_Name"])) ? Convert.ToString(dr["Make_Name"]) : "") };
                            objGarage.UserInfo = new UserInformationEnt { UserID = (!string.IsNullOrEmpty(Convert.ToString(dr["UserId"])) ? Convert.ToString(dr["UserId"]) : "") };

                            if (lstGarage == null)
                                lstGarage = new List<GarageEnt>();
                            lstGarage.Add(objGarage);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return lstGarage;
        }

        public int InsertGarageForClaim(string garageId, string claimRefNo, int createdBy)
        {           
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsGarage = new DataSet();
                iErrorno = oDAL.Select(ProcedureConstants.InsertGarageForClaim, out dsGarage, oDAL.CreateParameter("@GarageId", DbType.String, garageId),
                                                                                              oDAL.CreateParameter("@ClaimRefNo", DbType.String, claimRefNo),
                                                                                              oDAL.CreateParameter("@CreatedBy", DbType.Int32, createdBy));                   
            }
            catch (Exception ex)
            {
                throw;
            }
            return iErrorno;
        }
    }
}

