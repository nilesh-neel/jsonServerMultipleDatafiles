﻿using System;
using System.Collections.Generic;
using System.Data;
using RGICL.MC.DataAccessLayer;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.Repository.Helpers;

namespace RGICL.MC.Repository
{
    public class DBErrorLogRepository
    {
        int Errorno;
        public DBErrorLogRepository()
        {}

        public List<DBErrorLogEnt> GetDBErrorLogDetails(DateTime fromDate, DateTime toDate)
        {
            DBErrorLogEnt oDBErrorLogEnt = null;
            List<DBErrorLogEnt> lstDBErrorLog = null;
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsDBErrorLog = new DataSet();
                this.Errorno = oDAL.Select(ProcedureConstants.GetDBErrorLogDetails, out dsDBErrorLog,
                                    oDAL.CreateParameter("@FromDate", DbType.DateTime, fromDate),
                                    oDAL.CreateParameter("@ToDate", DbType.DateTime, toDate));

                if (this.Errorno == 0)
                {

                    if (dsDBErrorLog.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsDBErrorLog.Tables[0].Rows)
                        {
                            if (lstDBErrorLog == null)
                                lstDBErrorLog = new List<DBErrorLogEnt>();
                            oDBErrorLogEnt = new DBErrorLogEnt();
                            oDBErrorLogEnt.UserName = Convert.ToString(dr["UserName"]);
                            oDBErrorLogEnt.ErrorProcedure = Convert.ToString(dr["ErrorProcedure"]);
                            oDBErrorLogEnt.ErrorMessage = Convert.ToString(dr["ErrorMessage"]);
                            oDBErrorLogEnt.ErrorLine = Convert.ToInt32(dr["ErrorLine"]);
                            oDBErrorLogEnt.ErrorDate = Convert.ToDateTime(dr["ErrorDate"]);
                            lstDBErrorLog.Add(oDBErrorLogEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                //ex.DisplayCustomMessage("");
            }
            return lstDBErrorLog;
        }
    }
}
