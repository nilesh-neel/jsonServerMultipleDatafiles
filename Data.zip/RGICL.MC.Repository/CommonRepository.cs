﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGICL.MC.Contracts.Entity;
using RGICL.MC.DataAccessLayer;
using System.Data;
using RGICL.MC.Repository.Helpers;

namespace RGICL.MC.Repository
{
    public class CommonRepository
    {
        int iErrorno;

        public List<MasterEnt> GetTableData(string TableName,string ColumnName,string whereCondition ="",string orderBy="",string TextField = "",string valueField="")
        {
            try
            {
                CRUD oDAL = new CRUD();
                DataSet dsUserInfo = new DataSet();

                this.iErrorno = oDAL.Select(ProcedureConstants.GenerateTableData, out dsUserInfo,
                                    oDAL.CreateParameter("@pvTableName", DbType.String, TableName),
                                    oDAL.CreateParameter("@pvColumnName", DbType.String, ColumnName),
                                    oDAL.CreateParameter("@pvWhereCondition", DbType.String, whereCondition),
                                    oDAL.CreateParameter("@pvorderBy", DbType.String, orderBy)
                                    );
                return this.iErrorno == 0 ? (dsUserInfo.Tables[0].Rows.Count > 0 && dsUserInfo.Tables[0] != null ?
                     GetData(dsUserInfo, TextField,valueField) : null) : null;
            }
            catch (Exception ex)
            {
                throw ex;
                //ex.DisplayCustomMessage("");
            }
        }

        public List<MasterEnt> GetData(DataSet dsMaster, string TextField = "", string valueField = "")
        {
            return (from dr in dsMaster.Tables[0].AsEnumerable() select BindDataToMasterEnt(dr, TextField, valueField)).ToList();
        }

        public MasterEnt BindDataToMasterEnt(DataRow drMaster, string TextField = "", string valueField = "")
        {
            return new MasterEnt
            {
                Text = Convert.ToString(drMaster[TextField]),
                Value = Convert.ToString(drMaster[valueField]),             
            };
        }

        //public int SaveEmailData(EmailEnt objEmailEnt)
        //{
        //    CRUD oDAL = new CRUD();
        //    DataSet dsUserInfo = new DataSet();

        //    this.iErrorno = oDAL.Insert(ProcedureConstants.InsertEmailDetails, oDAL.CreateParameter("@CommMappingID", DbType.String, objEmailEnt.CommMappingID),
        //                        oDAL.CreateParameter("@ClaimRefNo", DbType.String, objEmailEnt.ClaimRefNo),
        //                        oDAL.CreateParameter("@CommEmailFrom", DbType.String, objEmailEnt.EmailFrom),
        //                        oDAL.CreateParameter("@CommEmailTo", DbType.String, objEmailEnt.EmailTo),
        //                        oDAL.CreateParameter("@CommEmailCC", DbType.String, objEmailEnt.EmailCC),
        //                        oDAL.CreateParameter("@CommEmailSubject", DbType.String, objEmailEnt.EmailSubject),
        //                        oDAL.CreateParameter("@CommEmailMessage", DbType.String, objEmailEnt.EmailMessage),
        //                        oDAL.CreateParameter("@CreatedBy", DbType.String, objEmailEnt.CreatedBy)
        //                        );
        //    return this.iErrorno;
        //}

        //public EmailEnt GetEmailTemplate(EmailEnt objEmailEnt)
        //{
        //    CRUD oDAL = new CRUD();
        //    DataSet dsEmail = new DataSet();

        //    this.iErrorno = oDAL.Insert(ProcedureConstants.GetEmailTemplate,out dsEmail,
        //                        oDAL.CreateParameter("@EventName", DbType.String, objEmailEnt.EventName),
        //                        oDAL.CreateParameter("@CommRoleID", DbType.String, objEmailEnt.RoleId)
        //                        );
        //    return this.iErrorno == 0 ? (dsEmail.Tables[0].Rows.Count > 0 && dsEmail.Tables[0] != null ?
        //            BindDataToEmailEnt(dsEmail.Tables[0].Rows[0]) : null) : null;
        //}
               

        //public EmailEnt BindDataToEmailEnt(DataRow drEmail)
        //{
        //    return new EmailEnt
        //    {
        //        EmailSubject = Convert.ToString(drEmail["CommSubject"]),
        //        EmailMessage = Convert.ToString(drEmail["CommContent"]),
        //        CommMappingID = Convert.ToInt32(drEmail["CommMappingID"]),
        //    };
        //}
    }
}
