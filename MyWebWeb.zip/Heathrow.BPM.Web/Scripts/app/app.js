﻿(function ($) {
    'use strict';

    $('.homeLinkIcon').on('click', function () {
        window.location.href = '/Home/Index';
    });


})(jQuery);