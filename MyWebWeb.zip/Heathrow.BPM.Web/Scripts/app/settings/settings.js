﻿(function ($) {
    'use strict';
    $(document).ready(function () {
        $('.settings').on('click', function SettingsController() {
            window.location.href = '/Settings/Index/';
        });

        $('.mSetting').on('click', function SettingsController() {
            window.location.href = '/Settings/Index/';
        });

    })

})(jQuery);