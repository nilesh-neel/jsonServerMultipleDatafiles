﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.Common
{
    public class Constant
    {
    }
}