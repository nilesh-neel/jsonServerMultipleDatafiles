﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Azure;
using System.Threading.Tasks;
using Heathrow.BPM.Security;
using Heathrow.BPM.Entity;

namespace Heathrow.BPM.Web
{
    public class ConnectionManager
    {

        /// <summary>
        /// Below method will get the access keys from azure keyvalut store
        /// </summary>
        /// <returns></returns>
        public ConnectionKey GetConnection()
        {
            ConnectionKey _accesDetails = new ConnectionKey();

            return _accesDetails;

        }
    }
}